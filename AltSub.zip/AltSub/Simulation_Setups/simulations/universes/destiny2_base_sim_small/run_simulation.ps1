# PowerShell version of run_simulation.sh for Windows
# Python Simulation Runner Script

param(
    [switch]$SkipInit,
    [switch]$SkipServices,
    [switch]$SkipSimulation,
    [switch]$SkipAnalysis,
    [switch]$Help
)

if ($Help) {
    Get-Content $PSCommandPath | Select-Object -First 20
    exit 0
}

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

# Load environment variables from .env file if it exists
$SimulationSetupsRoot = (Resolve-Path "..\..").Path
$EnvFile = Join-Path $SimulationSetupsRoot ".env"
if (Test-Path $EnvFile) {
    Write-Host "Loading environment variables from .env file..." -ForegroundColor Cyan
    Get-Content $EnvFile | ForEach-Object {
        if ($_ -match '^\s*([^#][^=]*)=(.*)$') {
            $name = $matches[1].Trim()
            $value = $matches[2].Trim()
            [Environment]::SetEnvironmentVariable($name, $value, "Process")
        }
    }
    Write-Host "✓ Environment variables loaded" -ForegroundColor Green
} else {
    Write-Host "⚠ No .env file found at $EnvFile" -ForegroundColor Yellow
    Write-Host "⚠ Copy .env.example to .env and add your API keys" -ForegroundColor Yellow
}

. .\experiment_config.sh

# Helper functions
function Print-Header {
    param([string]$Message)
    Write-Host ""
    Write-Host "==================================================" -ForegroundColor Cyan
    Write-Host "  $Message" -ForegroundColor Cyan
    Write-Host "==================================================" -ForegroundColor Cyan
}

function Print-Step {
    param([string]$Message)
    Write-Host ""
    Write-Host ">>> $Message" -ForegroundColor Yellow
}

function Print-Success {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor Green
}

function Print-Error {
    param([string]$Message)
    Write-Host "✗ ERROR: $Message" -ForegroundColor Red
}

function Print-Warning {
    param([string]$Message)
    Write-Host "⚠ WARNING: $Message" -ForegroundColor Yellow
}

# Check prerequisites
function Check-Prerequisites {
    Print-Header "Checking Prerequisites"
    
    try {
        $pythonVersion = python --version 2>&1
        Print-Success "Python found: $pythonVersion"
    } catch {
        Print-Error "Python not found. Please install Python 3.8+"
        exit 1
    }
    
    if (-not (Test-Path $env:REDDIT_DB_PATH)) {
        Print-Warning "Reddit database not found at: $env:REDDIT_DB_PATH"
        Print-Warning "You may need to create it using Pushshift scripts"
    } else {
        Print-Success "Reddit database found"
    }
    
    if (-not (Test-Path $env:BACKEND_DIR)) {
        Print-Error "Backend directory not found at: $env:BACKEND_DIR"
        exit 1
    }
    Print-Success "Backend directory found"
    
    $pythonSimPath = Join-Path $env:BACKEND_DIR "python_simulation"
    if (-not (Test-Path $pythonSimPath)) {
        Print-Error "Python simulation package not found at: $pythonSimPath"
        exit 1
    }
    Print-Success "Python simulation package found"
    
    if (-not $env:OPENAI_API_KEY -and -not $env:MISTRAL_API_KEY) {
        Print-Warning "Neither OPENAI_API_KEY nor MISTRAL_API_KEY is set"
        Print-Warning "LLM service may fail to start"
    } else {
        if ($env:OPENAI_API_KEY) { Print-Success "OPENAI_API_KEY is set" }
        if ($env:MISTRAL_API_KEY) { Print-Success "MISTRAL_API_KEY is set" }
    }
}

# Initialize agents
function Initialize-Agents {
    Print-Header "Step 1: Initializing Agents & Generating Configuration"
    
    Set-Location (Join-Path $env:BACKEND_DIR "python_simulation\tools")
    
    $cmdArgs = @(
        "-m", "python_simulation.tools.reddit_agent_initializer",
        "--db-path", $env:REDDIT_DB_PATH,
        "--subreddit", $env:SUBREDDIT,
        "--num-regular-users", $env:NUM_REGULAR_USERS,
        "--num-llm-users", $env:NUM_LLM_USERS,
        "--num-moderator", $env:NUM_MODERATORS,
        "--num-attacker", $env:NUM_ATTACKERS,
        "--duration-days", $env:DURATION_DAYS,
        "--interval-minutes", $env:INTERVAL_MINUTES,
        "--llm-service-url", $env:LLM_SERVICE_URL,
        "--output-dir", $env:EXPERIMENT_DIR,
        "--campaign-templates-dir", $env:CAMPAIGN_TEMPLATES_DIR
    )
    
    if ($env:LLM_VOTING_ENABLED -eq "true") {
        $cmdArgs += "--llm-voting-enabled"
    }
    if ($env:VERBAL_ACCEPTANCE_LABELS -eq "true") {
        $cmdArgs += "--verbal-acceptance-labels"
    }
    
    $nta = if ($env:NUM_TEMPLATE_ATTACKERS) { [int]$env:NUM_TEMPLATE_ATTACKERS } else { 0 }
    $needNarrative = (
        ([int]$env:NUM_ATTACKERS -gt 0) -or ($nta -gt 0) -or ($env:ENABLE_BIASED_MODERATOR -eq "true")
    )
    if ($needNarrative -and $env:CAMPAIGN_NARRATIVE) {
        $cmdArgs += "--attacker-target-narrative", $env:CAMPAIGN_NARRATIVE
    }
    
    if ($env:ENABLE_DUPLICATE_DETECTION -eq "true") {
        $cmdArgs += "--enable-duplicate-detection", "--duplicate-similarity-threshold", $env:DUPLICATE_SIMILARITY_THRESHOLD
    }
    
    if ($env:ENABLE_RATE_LIMIT -eq "true") {
        $cmdArgs += "--enable-rate-limiting", "--rate-limit-window", $env:RATE_LIMIT_WINDOW, "--rate-limit-threshold", $env:RATE_LIMIT_THRESHOLD
    }
    
    if ($env:ENABLE_COORDINATED_DETECTION -eq "true") {
        $coordSim = if ($env:COORDINATION_SIMILARITY_THRESHOLD) { $env:COORDINATION_SIMILARITY_THRESHOLD } elseif ($env:COORDINATION_SUSPICION_THRESHOLD) { $env:COORDINATION_SUSPICION_THRESHOLD } else { "0.3" }
        $cmdArgs += "--enable-coordinated-detection", "--coordination-similarity-threshold", $coordSim
    }
    
    $cmdArgs += "--mitigation-ban-threshold", $env:MITIGATION_BAN_THRESHOLD
    $cmdArgs += "--mitigation-scan-frequency", $env:MITIGATION_SCAN_FREQUENCY
    
    if ($env:ENABLE_BIASED_MODERATOR -eq "true") {
        $cmdArgs += "--enable-biased-moderator",
            "--biased-mod-risk-tolerance", $env:BIASED_MOD_RISK_TOLERANCE,
            "--biased-mod-scan-frequency", $env:BIASED_MOD_SCAN_FREQUENCY,
            "--biased-mod-detection-threshold", $env:BIASED_MOD_DETECTION_THRESHOLD,
            "--biased-mod-beliefs-file", $env:BIASED_MOD_BELIEFS_FILE,
            "--subreddit-rules", $env:SUBREDDIT_RULES
    }

    if ($env:ENABLE_RULE_MODERATORS -eq "true") {
        $nrm = if ($env:NUM_RULE_MODERATOR) { $env:NUM_RULE_MODERATOR } else { "1" }
        $raf = if ($env:RULE_MODERATOR_ACTIVE_FRACTION) { $env:RULE_MODERATOR_ACTIVE_FRACTION } else { "0.25" }
        $rrd = if ($env:RULE_MODERATOR_READ_DENSITY) { $env:RULE_MODERATOR_READ_DENSITY } else { "25" }
        $rss = if ($env:RULE_MODERATOR_SCHEDULE_SEED) { $env:RULE_MODERATOR_SCHEDULE_SEED } else { "42" }
        $rdt = if ($env:RULE_MODERATOR_DETECTION_THRESHOLD) { $env:RULE_MODERATOR_DETECTION_THRESHOLD } else { "0.7" }
        $rmd = if ($env:RULE_MODERATOR_MODERATION_DELAY_TIMESTEPS) { $env:RULE_MODERATOR_MODERATION_DELAY_TIMESTEPS } else { "2" }
        $cmdArgs += "--enable-rule-moderators",
            "--num-rule-moderator", $nrm,
            "--rule-moderator-active-fraction", $raf,
            "--rule-moderator-read-density", $rrd,
            "--rule-moderator-schedule-seed", $rss,
            "--rule-moderator-detection-threshold", $rdt,
            "--rule-moderator-moderation-delay-timesteps", $rmd,
            "--subreddit-rules", $env:SUBREDDIT_RULES
    }
    
    if ($env:CACHED_BELIEFS_FILE -and (Test-Path $env:CACHED_BELIEFS_FILE)) {
        $cmdArgs += "--cached-beliefs-file", $env:CACHED_BELIEFS_FILE
    }

    # Belief model and axes (axes file relative to this experiment folder)
    $beliefModel = if ($env:BELIEF_MODEL) { $env:BELIEF_MODEL } else { "axes" }
    $cmdArgs += "--belief-model", $beliefModel
    $timeModel = if ($env:TIME_MODEL) { $env:TIME_MODEL } else { "event" }
    $cmdArgs += "--time-model", $timeModel
    if ($env:BELIEF_AXES_FILE) {
        $axesFile = $env:BELIEF_AXES_FILE
        if (-not [System.IO.Path]::IsPathRooted($axesFile)) { $axesFile = Join-Path $ScriptDir $axesFile }
        if (-not (Test-Path $axesFile)) {
            Write-Host "BELIEF_AXES_FILE not found: $axesFile" -ForegroundColor Red
            exit 1
        }
        $cmdArgs += "--belief-axes-file", (Resolve-Path $axesFile).Path
    }

    # Campaign settings for the in-process orchestrator (written to campaign_config).
    # The standalone orchestrator service still gets them on its own command line.
    $campObjective = if ($env:CAMPAIGN_OBJECTIVE) { $env:CAMPAIGN_OBJECTIVE } else { "amplify_narrative" }
    $campCoord = if ($env:COORDINATION_STRENGTH) { $env:COORDINATION_STRENGTH } else { "0.8" }
    $campIntensity = if ($env:ATTACK_INTENSITY) { $env:ATTACK_INTENSITY } else { "0.7" }
    $campDaily = if ($env:DAILY_POST_TARGET) { $env:DAILY_POST_TARGET } else { "5" }
    $campComment = if ($env:COORDINATION_COMMENT_PROB) { $env:COORDINATION_COMMENT_PROB } else { "0.5" }
    $campDelayMin = if ($env:COORDINATION_DELAY_MIN) { $env:COORDINATION_DELAY_MIN } else { "1" }
    $campDelayMax = if ($env:COORDINATION_DELAY_MAX) { $env:COORDINATION_DELAY_MAX } else { "6" }
    $cmdArgs += "--campaign-objective", $campObjective,
        "--coordination-strength", $campCoord,
        "--attack-intensity", $campIntensity,
        "--daily-post-target", $campDaily,
        "--coordination-comment-prob", $campComment,
        "--coordination-delay-min", $campDelayMin,
        "--coordination-delay-max", $campDelayMax

    # Belief extraction failures are fatal unless explicitly allowed
    if ($env:ALLOW_BELIEF_FAILURES -eq "true") {
        $cmdArgs += "--allow-belief-failures"
    }

    Print-Step "Running agent initializer..."
    Write-Host "Command: python $($cmdArgs -join ' ')"
    
    python @cmdArgs
    
    if ($LASTEXITCODE -eq 0) {
        Print-Success "Agent initialization complete"
        Print-Success "Configuration JSON: $($env:EXPERIMENT_DIR)/simulation_config.json"
    } else {
        Print-Error "Agent initialization failed"
        exit 1
    }
    
    Set-Location $ScriptDir
}

# Start LLM service
function Start-LLMService {
    Print-Header "Step 2: Starting LLM Service"
    
    try {
        $response = Invoke-WebRequest -Uri "$($env:LLM_SERVICE_URL)/health" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            Print-Warning "LLM service already running at $($env:LLM_SERVICE_URL)"
            return
        }
    } catch {
        # Service not running, continue
    }
    
    Print-Step "Starting LLM service on port $($env:LLM_SERVICE_PORT)..."
    
    Set-Location (Join-Path $env:BACKEND_DIR "python_simulation\tools")
    
    $logFile = Join-Path $env:EXPERIMENT_DIR "llm_service.log"
    $pidFile = Join-Path $env:EXPERIMENT_DIR "llm_service.pid"
    
    $process = Start-Process -FilePath "python" -ArgumentList @(
        "-m", "python_simulation.services.llm_reddit_service",
        "--port", $env:LLM_SERVICE_PORT,
        "--provider", $env:LLM_PROVIDER,
        "--model", $env:LLM_MODEL
    ) -PassThru -NoNewWindow -RedirectStandardOutput $logFile -RedirectStandardError $logFile
    
    $process.Id | Out-File -FilePath $pidFile
    
    Print-Step "Waiting for LLM service to start..."
    Start-Sleep -Seconds 5
    
    for ($i = 1; $i -le 30; $i++) {
        try {
            $response = Invoke-WebRequest -Uri "$($env:LLM_SERVICE_URL)/health" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                Print-Success "LLM service started (PID: $($process.Id))"
                Print-Success "Logs: $logFile"
                Set-Location $ScriptDir
                return
            }
        } catch {
            # Service not ready yet
        }
        Start-Sleep -Seconds 1
    }
    
    Print-Error "LLM service failed to start after 30 seconds"
    Print-Error "Check logs: $logFile"
    exit 1
}

# Start orchestrator
function Start-Orchestrator {
    Print-Header "Step 3: Starting Campaign Orchestrator"
    
    if ([int]$env:NUM_ATTACKERS -eq 0) {
        Print-Warning "No attackers configured, skipping orchestrator"
        return
    }
    
    try {
        $response = Invoke-WebRequest -Uri "$($env:CAMPAIGN_ORCHESTRATOR_URL)/health" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
        if ($response.StatusCode -eq 200) {
            Print-Warning "Orchestrator already running at $($env:CAMPAIGN_ORCHESTRATOR_URL)"
            return
        }
    } catch {
        # Service not running, continue
    }
    
    Print-Step "Starting orchestrator on port $($env:ORCHESTRATOR_PORT)..."
    
    Set-Location (Join-Path $env:BACKEND_DIR "python_simulation\tools")
    
    $objectiveArg = if ($env:CAMPAIGN_OBJECTIVE -eq "disrupt_discourse") { "disrupt_discourse" } else { "amplify_narrative" }
    
    $logFile = Join-Path $env:EXPERIMENT_DIR "orchestrator.log"
    $pidFile = Join-Path $env:EXPERIMENT_DIR "orchestrator.pid"
    
    $process = Start-Process -FilePath "python" -ArgumentList @(
        "-m", "python_simulation.services.attacker_campaign_orchestrator",
        "--port", $env:ORCHESTRATOR_PORT,
        "--objective", $objectiveArg,
        "--target-narrative", $env:CAMPAIGN_NARRATIVE,
        "--target-subreddit", $env:SUBREDDIT,
        "--coordination-strength", $env:COORDINATION_STRENGTH,
        "--intensity", $env:ATTACK_INTENSITY,
        "--daily-post-target", $env:DAILY_POST_TARGET,
        "--llm-service-url", $env:LLM_SERVICE_URL,
        "--output-dir", $env:EXPERIMENT_DIR
    ) -PassThru -NoNewWindow -RedirectStandardOutput $logFile -RedirectStandardError $logFile
    
    $process.Id | Out-File -FilePath $pidFile
    
    Print-Step "Waiting for orchestrator to start..."
    Start-Sleep -Seconds 5
    
    for ($i = 1; $i -le 30; $i++) {
        try {
            $response = Invoke-WebRequest -Uri "$($env:CAMPAIGN_ORCHESTRATOR_URL)/health" -UseBasicParsing -TimeoutSec 2 -ErrorAction SilentlyContinue
            if ($response.StatusCode -eq 200) {
                Print-Success "Orchestrator started (PID: $($process.Id))"
                Print-Success "Logs: $logFile"
                Set-Location $ScriptDir
                return
            }
        } catch {
            # Service not ready yet
        }
        Start-Sleep -Seconds 1
    }
    
    Print-Error "Orchestrator failed to start after 30 seconds"
    Print-Error "Check logs: $logFile"
    exit 1
}

# Run simulation
function Run-Simulation {
    Print-Header "Step 4: Running Python Simulation"
    
    Set-Location (Join-Path $env:BACKEND_DIR "python_simulation\tools")
    
    Print-Step "Starting Python simulation..."
    Print-Step "Configuration: $($env:EXPERIMENT_DIR)/simulation_config.json"
    Print-Step "Output directory: $($env:EXPERIMENT_DIR)"
    
    $logFile = Join-Path $env:EXPERIMENT_DIR "simulation.log"
    
    python -m python_simulation.run_simulation `
        --config-dir $env:EXPERIMENT_DIR `
        --output-dir $env:EXPERIMENT_DIR 2>&1 | Tee-Object -FilePath $logFile
    
    if ($LASTEXITCODE -eq 0) {
        Print-Success "Simulation completed successfully"
        Print-Success "Logs: $logFile"
        Print-Success "Output: $($env:EXPERIMENT_DIR)/simulation_output/"
    } else {
        Print-Error "Simulation failed with exit code $LASTEXITCODE"
        Print-Error "Check logs: $logFile"
        exit 1
    }
    
    Set-Location $ScriptDir
}

# Run analysis
function Run-Analysis {
    Print-Header "Step 5: Analyzing Results"
    
    $analysisScript = Join-Path $env:BACKEND_DIR "python_simulation\tools\analyze_simulation.py"
    if (-not (Test-Path $analysisScript)) {
        Print-Warning "Analysis script not found at $analysisScript"
        Print-Warning "Skipping analysis step"
        return
    }
    
    Print-Step "Running analysis..."
    
    Set-Location (Join-Path $env:BACKEND_DIR "python_simulation\tools")
    
    $analysisOutputDir = $env:ANALYSIS_OUTPUT_DIR
    if (-not (Test-Path $analysisOutputDir)) {
        New-Item -ItemType Directory -Path $analysisOutputDir -Force | Out-Null
    }
    
    $analysisLog = Join-Path $env:EXPERIMENT_DIR "analysis.log"
    
    python analyze_simulation.py `
        --input-dir "$($env:EXPERIMENT_DIR)/simulation_output" `
        --output-dir $analysisOutputDir 2>&1 | Tee-Object -FilePath $analysisLog
    
    if ($LASTEXITCODE -eq 0) {
        Print-Success "Analysis completed"
        Print-Success "Results: $analysisOutputDir"
    } else {
        Print-Warning "Analysis completed with warnings"
    }
    
    Set-Location $ScriptDir
}

function Summarize-Profiling {
    Print-Header "Profiling Summary"

    $profilingLog = Join-Path $env:EXPERIMENT_DIR "profiling.log"
    if (-not (Test-Path $profilingLog)) {
        Print-Warning "profiling.log not found at $profilingLog; skipping profiling summary"
        return
    }

    Print-Step "Running profiling summarizer..."

    Set-Location (Join-Path $env:BACKEND_DIR "python_simulation\tools")

    $summaryPath = Join-Path $env:EXPERIMENT_DIR "profiling_summary.txt"

    python -m python_simulation.tools.summarize_profiling_log `
        --input $profilingLog `
        --output $summaryPath `
        --json 2>&1 | Tee-Object -FilePath (Join-Path $env:EXPERIMENT_DIR "profiling_summary.log")

    if ($LASTEXITCODE -eq 0) {
        Print-Success "Profiling summary written to $summaryPath"
    } else {
        Print-Warning "Profiling summary completed with warnings (exit code $LASTEXITCODE)"
    }

    Set-Location $ScriptDir
}

# Main execution
function Main {
    Print-Header "Python Reddit Simulation: $env:EXPERIMENT_NAME"
    Write-Host "Description: $env:EXPERIMENT_DESCRIPTION"
    Write-Host ""
    
    Check-Prerequisites
    
    if (-not $SkipInit) {
        Initialize-Agents
    } else {
        Print-Warning "Skipping agent initialization (using existing config)"
    }
    
    if (-not $SkipServices) {
        Start-LLMService
        Start-Orchestrator
    } else {
        Print-Warning "Skipping service startup (assuming services are running)"
    }
    
    if (-not $SkipSimulation) {
        Run-Simulation
    } else {
        Print-Warning "Skipping simulation execution"
    }
    
    if (-not $SkipAnalysis) {
        Run-Analysis
    } else {
        Print-Warning "Skipping analysis step"
    }

    # Always attempt profiling summary if profiling.log exists
    Summarize-Profiling
    
    Print-Header "Simulation Complete"
    Write-Host ""
    Write-Host "Output files:"
    Write-Host "  - Configuration: $($env:EXPERIMENT_DIR)/simulation_config.json"
    Write-Host "  - Agent profiles: $($env:EXPERIMENT_DIR)/agent_profiles.json"
    Write-Host "  - Simulation output: $($env:EXPERIMENT_DIR)/simulation_output/"
    Write-Host "  - Logs: $($env:EXPERIMENT_DIR)/*.log"
    if (-not $SkipAnalysis) {
        Write-Host "  - Analysis: $($env:ANALYSIS_OUTPUT_DIR)"
    }
    Write-Host ""
    Write-Host "To stop services, run: .\stop_services.ps1"
}

Main

