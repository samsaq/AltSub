#!/usr/bin/env bash
# Build this universe's mode folders for auto_runner / parameter_tuning.
#
# For each mode: set the agent counts in experiment_config.sh, run only the
# initialization step of run_simulation.sh, check the output, then copy the four
# setup files into <mode>/. experiment_config.sh is restored when the script ends
# (also on failure). Everything else in experiment_config.sh (narrative, LLM,
# mitigation settings, ...) is used as-is.
#
# Usage:  ./setup_modes.sh [mode ...]
#         modes: llm_attackers template_attackers no_attackers (default: all three)
# Counts (override via environment):
#         USERS_WITH_ATTACKERS=23  ATTACKERS_PER_MODE=2  USERS_CONTROL=25
#
# Note: each init samples users afresh, so modes get different users.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

USERS_WITH_ATTACKERS="${USERS_WITH_ATTACKERS:-23}"
ATTACKERS_PER_MODE="${ATTACKERS_PER_MODE:-2}"
USERS_CONTROL="${USERS_CONTROL:-25}"

REQUIRED_FILES=(simulation_config.json agent_profiles.json)
# belief_clustering_metadata.json: free-text belief model only (the belief statements model writes none)
OPTIONAL_FILES=(subreddit_seed_context.json belief_clustering_metadata.json)
ALL_MODES=(llm_attackers template_attackers no_attackers)

if [ "$#" -gt 0 ]; then
    MODES=("$@")
else
    MODES=("${ALL_MODES[@]}")
fi
for mode in "${MODES[@]}"; do
    case "$mode" in
        llm_attackers|template_attackers|no_attackers) ;;
        *) echo "Unknown mode: $mode (valid: ${ALL_MODES[*]})" >&2; exit 2 ;;
    esac
done

for f in experiment_config.sh run_simulation.sh; do
    [ -f "$f" ] || { echo "Missing $f in $SCRIPT_DIR" >&2; exit 2; }
done

BACKUP=".experiment_config.sh.setup_modes_backup"
cp experiment_config.sh "$BACKUP"
restore_config() {
    if [ -f "$BACKUP" ]; then
        mv "$BACKUP" experiment_config.sh
        echo "Restored experiment_config.sh"
    fi
}
trap restore_config EXIT

set_counts() {  # llm_users llm_attackers template_attackers
    sed -i \
        -e "s/^export NUM_LLM_USERS=.*/export NUM_LLM_USERS=$1/" \
        -e "s/^export NUM_ATTACKERS=.*/export NUM_ATTACKERS=$2  # LLM Based Attackers/" \
        -e "s/^export NUM_TEMPLATE_ATTACKERS=.*/export NUM_TEMPLATE_ATTACKERS=$3/" \
        experiment_config.sh
}

# Fail if the init output doesn't have the expected agents / campaign settings
check_output() {  # mode llm_users llm_attackers template_attackers
    python3 - "$@" <<'PY'
import collections
import json
import sys

mode, n_users, n_llm_att, n_tpl_att = sys.argv[1], *map(int, sys.argv[2:5])
cfg = json.load(open("simulation_config.json", encoding="utf-8"))
profiles = json.load(open("agent_profiles.json", encoding="utf-8"))
types = collections.Counter(p.get("user_type") for p in profiles)
cc = cfg.get("campaign_config", {})
narrative = (cc.get("target_narrative") or "").strip()
problems = []
if types.get("llm_user", 0) != n_users:
    problems.append(f"{types.get('llm_user', 0)} llm_user profiles, expected {n_users}")
if types.get("attacker", 0) != n_llm_att:
    problems.append(f"{types.get('attacker', 0)} LLM attacker profiles, expected {n_llm_att}")
if types.get("template_attacker", 0) != n_tpl_att:
    problems.append(f"{types.get('template_attacker', 0)} template attacker profiles, expected {n_tpl_att}")
if (n_llm_att or n_tpl_att) and not narrative:
    problems.append("campaign_config.target_narrative is empty")
if n_llm_att:
    if not cc.get("campaign_belief_texts"):
        problems.append("campaign_config.campaign_belief_texts is empty (campaign belief distillation failed?)")
    if any(not p.get("beliefs") for p in profiles if p.get("user_type") == "attacker"):
        problems.append("an LLM attacker has no beliefs")
schedules = cfg.get("agent_activity_schedules", {})
if len(schedules) != len(profiles):
    problems.append(f"{len(schedules)} activity schedules for {len(profiles)} profiles")
if problems:
    print(f"  [{mode}] init output check FAILED:")
    for p in problems:
        print(f"    - {p}")
    sys.exit(1)
print(f"  [{mode}] OK: {dict(types)}, narrative {'set' if narrative else 'none'}, "
      f"{len(cc.get('campaign_belief_texts') or {})} campaign belief texts")
PY
}

for mode in "${MODES[@]}"; do
    case "$mode" in
        llm_attackers)      counts=("$USERS_WITH_ATTACKERS" "$ATTACKERS_PER_MODE" 0) ;;
        template_attackers) counts=("$USERS_WITH_ATTACKERS" 0 "$ATTACKERS_PER_MODE") ;;
        no_attackers)       counts=("$USERS_CONTROL" 0 0) ;;
    esac
    echo
    echo "=================================================================="
    echo " $mode: ${counts[0]} LLM users, ${counts[1]} LLM attackers, ${counts[2]} template attackers"
    echo "=================================================================="

    set_counts "${counts[@]}"
    # Remove the previous init's outputs so a failed init can't leave stale files to copy
    rm -f "${REQUIRED_FILES[@]}" "${OPTIONAL_FILES[@]}"

    ./run_simulation.sh --skip-services --skip-simulation --skip-analysis

    for f in "${REQUIRED_FILES[@]}"; do
        [ -f "$f" ] || { echo "  [$mode] init did not write $f" >&2; exit 1; }
    done
    check_output "$mode" "${counts[@]}"

    mkdir -p "$mode"
    cp "${REQUIRED_FILES[@]}" "$mode"/
    for f in "${OPTIONAL_FILES[@]}"; do
        if [ -f "$f" ]; then
            cp "$f" "$mode"/
        else
            rm -f "$mode/$f"  # don't leave a stale copy from an earlier init
            echo "  [$mode] note: init wrote no $f"
        fi
    done
    echo "  [$mode] copied setup files into $mode/"
done

echo
echo "Done: ${MODES[*]}"
