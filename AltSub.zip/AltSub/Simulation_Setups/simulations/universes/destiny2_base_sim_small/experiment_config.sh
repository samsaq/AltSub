#!/bin/bash
# Experiment Configuration for Python Simulation
# LLM attackers, no mitigations

# ===== EXPERIMENT METADATA =====
export EXPERIMENT_NAME="destiny2_base_sim_small"
export EXPERIMENT_DESCRIPTION="Destiny 2 campaign simulation: LLM attackers, no mitigations. Testing amplification of narrative that latest Destiny 2 campaign is disappointing and final, users should move to Warframe."

# ===== FILE PATHS =====
export PROJECT_ROOT="$(cd "../../../.." && pwd)"
export SIMULATION_SETUPS_DIR="$PROJECT_ROOT/Simulation_Setups"
export BACKEND_DIR="$PROJECT_ROOT/backend"
export EXPERIMENT_DIR="$SIMULATION_SETUPS_DIR/simulations/universes/$EXPERIMENT_NAME"
export CAMPAIGN_TEMPLATES_DIR="$EXPERIMENT_DIR/campaign_templates"
export ANALYSIS_OUTPUT_DIR="$SIMULATION_SETUPS_DIR/simulations/universes/analysis/$EXPERIMENT_NAME"

# ===== DATABASE & SUBREDDIT =====
export REDDIT_DB_PATH="$SIMULATION_SETUPS_DIR/reddit_databases/2025-06-destiny2.db"
export SUBREDDIT="destiny2"

# ===== AGENT CONFIGURATION =====
# When true, initializer assigns activity level / frequency / session length in exact proportion
# to reddit_agent_initializer distributions (reader 40%, voter 25%, commenter 20%, poster 15%, etc.)
export STRATIFY_AGENT_MIX=true
export NUM_REGULAR_USERS=0
export NUM_LLM_USERS=25
export NUM_MODERATORS=0
export NUM_ATTACKERS=0  # LLM Based Attackers
export NUM_TEMPLATE_ATTACKERS=0

# ===== SIMULATION PARAMETERS =====
export DURATION_DAYS=3
export INTERVAL_MINUTES=5
export START_TIMESTEP=0
export ENABLE_TIMESTEP_PARALLELISM=true

# ===== LLM Runtime Throttling (used by python_simulation at runtime) =====
# These are read directly from the environment by `run_simulation.py` and `llm_provider.py`.
export LLM_MAX_CONCURRENCY=8  # Max concurrent LLM calls (default used in code if unset)
export LLM_RATE_LIMIT_QPS=0  # Max LLM requests per second (0 disables rate limiting)

# ===== SERVICE URLS =====
export LLM_SERVICE_URL="http://localhost:5000"
export CAMPAIGN_ORCHESTRATOR_URL="http://localhost:5001"

# ===== LLM PROVIDER SETTINGS =====
export LLM_PROVIDER="mistral"  # "openai", "mistral", or "local"
export LLM_MODEL="mistral-small-latest"
# NOTE: Set one of these in your environment before running (or export them here):
# export OPENAI_API_KEY="..."
# export MISTRAL_API_KEY="..."

# ===== CAMPAIGN PARAMETERS =====
export CAMPAIGN_OBJECTIVE="amplify_narrative"
export CAMPAIGN_NARRATIVE="The latest Destiny 2 Final Shape expansion is disappointing and marks the end of meaningful content. The story is over and there's nothing left to do. Players should move on to other games like Warframe, which offers better content and more engaging gameplay. Most of this sub already agrees, and people here are already moving to Warframe."
export COORDINATION_STRENGTH=0.8
export ATTACK_INTENSITY=0.7
export DAILY_POST_TARGET=5
# Attackers amplify each other's posts: chance of a comment with the upvote, and delay range (timesteps)
export COORDINATION_COMMENT_PROB=0.5
export COORDINATION_DELAY_MIN=1
export COORDINATION_DELAY_MAX=6

# ===== MITIGATION FLAGS =====
export ENABLE_DUPLICATE_DETECTION=false
export DUPLICATE_SIMILARITY_THRESHOLD=0.85
export USE_EMBEDDING_SIMILARITY_FOR_DUPLICATES=false


export ENABLE_RATE_LIMIT=false
export RATE_LIMIT_WINDOW=24  # timesteps (5-min intervals)
export RATE_LIMIT_THRESHOLD=10

export ENABLE_COORDINATED_DETECTION=false
# Co-action network detector: co-engagement TF-IDF cosine threshold (other detector
# settings use the initializer/MitigationSystem defaults)
export COORDINATION_SIMILARITY_THRESHOLD=0.3

export MITIGATION_BAN_THRESHOLD=3
export MITIGATION_SCAN_FREQUENCY=10  # timesteps

# ===== RULE MODERATORS (LLM feed review → MitigationSystem flags; requires LLM service) =====
# Wired in run_simulation.sh / run_simulation.ps1 to reddit_agent_initializer.
# Uses SUBREDDIT_RULES below as mitigation_config.subreddit_rules for prompts.
export ENABLE_RULE_MODERATORS=false   # set true to add rule_moderator agents + schedules
export NUM_RULE_MODERATOR=2
export RULE_MODERATOR_ACTIVE_FRACTION=0.5   # fraction of each day each mod is on (contiguous block)
export RULE_MODERATOR_READ_DENSITY=15       # feed items per timestep when active
export RULE_MODERATOR_SCHEDULE_SEED=42
export RULE_MODERATOR_DETECTION_THRESHOLD=0 # at 0, the moderation decision depends on the rule broken: true/false instead of confidence score + true/false
export RULE_MODERATOR_MODERATION_DELAY_TIMESTEPS=2

# Optional: runtime overrides for run_simulation.py (same names as backend env helpers)
# export MITIGATION_RULE_MODERATOR_COUNT=2
# export MITIGATION_RULE_MODERATOR_ACTIVE_FRACTION=0.25

# ===== BELIEF CAPPING =====
export ENABLE_BELIEF_CAPPING=true
export BELIEF_CAP=60
export PROTECT_ATTACKER_BELIEFS=false
export ATTACKER_SIMILARITY_THRESHOLD=0.6
export WEAK_BELIEF_THRESHOLD=0.2

# ===== BIASED MODERATOR =====
export ENABLE_BIASED_MODERATOR=false
export BIASED_MOD_RISK_TOLERANCE=0.7
export BIASED_MOD_SCAN_FREQUENCY=12  # timesteps (every hour for 5-min intervals)
export BIASED_MOD_DETECTION_THRESHOLD=0.6
export SUBREDDIT_RULES="
1. Be Kind, Civil, and Respectful
Our subreddit is a safe space for people of all races, genders, and walks of life. It is important for us all to be civil to one another, and maintain a degree of respect for each other. Racism and bigotry will not be tolerated, and depending on the severity of the infraction, may result in a permanent ban.

2. Absolutely No Witch-Hunting
Witch hunting, as defined on our subreddit, is the open presentation of a person's identifying information, such as Bungie ID or otherwise, with intent to name, shame, and/or call attention to them in a negative light. It is not only against our rules, but Bungie's TOS as well.
Even if the person in question was cheating, or verbally attacked you - posting their name, or screenshots of chat with them, is forbidden. A 14-day ban will be issued on the first infraction of this rule.

3. No Spam/Low Effort Content/Rant Posts
Frequently (re)posted questions/content that serve to karma farm, mislead, troll or inspire rage, are spam. Low Effort is any/all content that contains no creativity or thought. This extends to AI-generated content, which is STRICTLY forbidden on our subreddit.
If your post was removed for being a repost or spam, it may be because while you haven't spammed it yourself, it may be something that many others before you already have posted.

4. No Simple Loot/Achievement/Gear Roll Posts
Posts showing weapon rolls, triumphs, exotic drops, weapon kill counts, Trials Flawlesses, or raid clears, fall under this rule and will be removed. Very few exceptions to this rule will be made, in the form of only truly extraordinary achievements.
Players achieve great things in Destiny every day, and if even a fraction of the users on our subreddit began posting about them, it would become very cluttered, very quickly.

5. No Phone Screenshots
Pictures and videos of a monitor or TV, taken with a phone or similar device, are not allowed. All consoles have a built in way to screenshot and export it, and so do computers.

6. Content must be Relevant to Destiny 2
Content that is unrelated to Destiny 2 will be removed. This includes Destiny 1 content. Posts that simply show an image of a real-life object or shape that only vaguely resemble something found in Destiny 2, such as a 4-segmented square pattern resembling a shader, or a park decoration shaped like an engram, fall under this rule.

7. No LFG/Recruitment/In Game Help Posts
No Looking For Guardians posts. Check r/RaidSherpa, r/CrucibleGuidebook, or use the in-game Fireteam Finder, located under the Roster tab. All LFG posts will be removed and frequent posts will result in a temporary ban.

8. Spoilers Must Be Marked
New content will be given a 24 hour grace period where all posts pertaining to said content will be marked as a spoiler or it will be removed. These include new & reprised Raids, new Dungeons, new Exotic quests, and seasonal story content. Courtesy towards your fellow Guardian is expected.
Leaks are strictly forbidden.

9. No NSFW Content and Vulgarity
Explicit content and offensive material is forbidden. Strive for a PG-13 rating and use common sense when determining if content, including comments, falls here. If you believe yours might, but are unsure, message the mod team for assistance.

10. No Self-Promotion, Advertisement, or Giveaways Without Mod Approval
Moderator approval must be given for posts containing or pertaining to self promotion or giveaways. Social media accounts and Discord Servers are prohibited. YouTube videos that are creative or provide discussion will be allowed (See Rule 3 for Low Effort content)

11. No Discussion of Third-Party Devices, Software, or Services
Third Party Devices/Macros in accordance with Bungie guidelines will be permitted. Posts regarding any device or service used to manipulate the game outside of the aforementioned guidelines will result in a permanent ban.

12. Links to X.com are forbidden
Due to the rising presence of far-right ties to X.com, links to the website are forbidden from being posted, so as to generate less traffic to it. Destiny 2's official social media can be found on Bluesky, as an alternative to X.com.

13. Disproven Info/Baseless Claim/Misinformation
It's important to always make sure that everything that's posted on our subreddit is true and verifiable. Making statements that have not been proven, or otherwise have BEEN disproven, is not allowed. If any comments or posts make claims as such, they will be removed.
"

# ===== PORT CONFIGURATION =====
export LLM_SERVICE_PORT=5000
export ORCHESTRATOR_PORT=5001

# ===== LLM VOTING =====
export LLM_VOTING_ENABLED=false  # Enable LLM-based voting decisions
export VERBAL_ACCEPTANCE_LABELS=false  # Likert-style labels next to belief acceptance values in prompts

# ===== BELIEF CACHING =====
export CACHED_BELIEFS_FILE=""  # Path to cached beliefs JSON (optional, speeds up initialization)

# ===== TIME MODEL =====
# "event" (default): continuous-time event-driven engine (each action takes simulated
# time; see backend/python_simulation/core/time_model.py). "discrete": fixed-timestep
# engine.
export TIME_MODEL="event"

# ===== BELIEF MODEL =====
# "axes" (default): a fixed set of belief statements per scenario,
# each held as an acceptance value (0 = complete rejection, 0.5 = neutral,
# 1 = complete acceptance); the LLM updates them per item read (capped per update).
# "free_text": claims extracted from content.
export BELIEF_MODEL="axes"
# Belief statements + campaign targets (JSON, see backend/python_simulation/core/belief_axes.py).
# Empty = built-in set for the subreddit (thesis C1-C7 / P1-P6). Relative paths are from this folder.
export BELIEF_AXES_FILE=""  # e.g. ../../../belief_axes/destiny2.json

# ===== FEED ORDERING STRATEGY =====
# Options: default, chronological, score-based, engagement-weighted, reddit-hot, reddit-all-hot
# - default: priority groups + score sorting + 10% shuffle
# - chronological: Simple newest-first ordering
# - score-based: Score-only ordering with recency decay
# - engagement-weighted: Weighted engagement scoring with priority boosts
# - reddit-hot: Reddit's actual hot algorithm from open-source codebase
# - reddit-all-hot: Reddit's r/all hot algorithm (aggregates across subreddits)
export FEED_STRATEGY="reddit-hot"

echo "✓ Configuration loaded for experiment: $EXPERIMENT_NAME"
