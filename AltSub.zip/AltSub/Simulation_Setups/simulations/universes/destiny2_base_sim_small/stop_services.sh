#!/bin/bash
###############################################################################
# Stop Services Script
# 
# Stops the LLM service and campaign orchestrator for Python simulation
###############################################################################

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

source ./experiment_config.sh

print_step() {
    echo ">>> $1"
}

print_success() {
    echo "✓ $1"
}

print_warning() {
    echo "⚠ $1"
}

# Stop LLM service
if [ -f "$EXPERIMENT_DIR/llm_service.pid" ]; then
    LLM_PID=$(cat "$EXPERIMENT_DIR/llm_service.pid")
    if ps -p $LLM_PID > /dev/null 2>&1; then
        print_step "Stopping LLM service (PID: $LLM_PID)..."
        kill $LLM_PID
        rm "$EXPERIMENT_DIR/llm_service.pid"
        print_success "LLM service stopped"
    else
        print_warning "LLM service not running (stale PID file)"
        rm "$EXPERIMENT_DIR/llm_service.pid"
    fi
else
    print_warning "No LLM service PID file found"
fi

# Stop orchestrator
if [ -f "$EXPERIMENT_DIR/orchestrator.pid" ]; then
    ORCH_PID=$(cat "$EXPERIMENT_DIR/orchestrator.pid")
    if ps -p $ORCH_PID > /dev/null 2>&1; then
        print_step "Stopping orchestrator (PID: $ORCH_PID)..."
        kill $ORCH_PID
        rm "$EXPERIMENT_DIR/orchestrator.pid"
        print_success "Orchestrator stopped"
    else
        print_warning "Orchestrator not running (stale PID file)"
        rm "$EXPERIMENT_DIR/orchestrator.pid"
    fi
else
    print_warning "No orchestrator PID file found"
fi

print_success "All services stopped"

