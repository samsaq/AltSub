# PowerShell version of stop_services.sh for Windows
# Stop Services Script

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptDir

. .\experiment_config.sh

function Print-Step {
    param([string]$Message)
    Write-Host ">>> $Message" -ForegroundColor Yellow
}

function Print-Success {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor Green
}

function Print-Warning {
    param([string]$Message)
    Write-Host "⚠ $Message" -ForegroundColor Yellow
}

# Stop LLM service
$llmPidFile = Join-Path $env:EXPERIMENT_DIR "llm_service.pid"
if (Test-Path $llmPidFile) {
    $llmPid = Get-Content $llmPidFile
    try {
        $process = Get-Process -Id $llmPid -ErrorAction SilentlyContinue
        if ($process) {
            Print-Step "Stopping LLM service (PID: $llmPid)..."
            Stop-Process -Id $llmPid -Force
            Remove-Item $llmPidFile
            Print-Success "LLM service stopped"
        } else {
            Print-Warning "LLM service not running (stale PID file)"
            Remove-Item $llmPidFile
        }
    } catch {
        Print-Warning "Could not stop LLM service: $_"
        Remove-Item $llmPidFile -ErrorAction SilentlyContinue
    }
} else {
    Print-Warning "No LLM service PID file found"
}

# Stop orchestrator
$orchPidFile = Join-Path $env:EXPERIMENT_DIR "orchestrator.pid"
if (Test-Path $orchPidFile) {
    $orchPid = Get-Content $orchPidFile
    try {
        $process = Get-Process -Id $orchPid -ErrorAction SilentlyContinue
        if ($process) {
            Print-Step "Stopping orchestrator (PID: $orchPid)..."
            Stop-Process -Id $orchPid -Force
            Remove-Item $orchPidFile
            Print-Success "Orchestrator stopped"
        } else {
            Print-Warning "Orchestrator not running (stale PID file)"
            Remove-Item $orchPidFile
        }
    } catch {
        Print-Warning "Could not stop orchestrator: $_"
        Remove-Item $orchPidFile -ErrorAction SilentlyContinue
    }
} else {
    Print-Warning "No orchestrator PID file found"
}

Print-Success "All services stopped"

