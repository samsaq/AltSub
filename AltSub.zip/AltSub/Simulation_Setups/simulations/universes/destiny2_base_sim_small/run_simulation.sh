#!/bin/bash
###############################################################################
# Python Simulation Runner Script
# 
# This script runs a complete Reddit astroturfing simulation using the pure
# Python implementation, including:
# 1. Agent initialization and JSON generation
# 2. LLM service startup (optional)
# 3. Campaign orchestrator startup (optional)
# 4. Python simulation execution
# 5. Results analysis (optional)
#
# Usage: 
#   ./run_simulation.sh [options]
#
# Options:
#   --skip-init          Skip agent initialization (use existing config)
#   --skip-services      Skip starting services (must be running already)
#   --skip-simulation    Skip running the simulation (just init)
#   --skip-analysis      Skip analysis step
#   --help               Show this help message
###############################################################################

set -e  # Exit on error

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# Load environment variables from .env file if it exists
SIMULATION_SETUPS_ROOT="$(cd "../../.." && pwd)"
if [ -f "$SIMULATION_SETUPS_ROOT/.env" ]; then
    echo "Loading environment variables from .env file..."
    set -a  # Export all variables
    source "$SIMULATION_SETUPS_ROOT/.env"
    set +a  # Stop exporting
    echo "✓ Environment variables loaded"
else
    echo "⚠ No .env file found at $SIMULATION_SETUPS_ROOT/.env"
    echo "⚠ Copy .env.example to .env and add your API keys"
fi

source ./experiment_config.sh

SKIP_INIT=false
SKIP_SERVICES=false
SKIP_SIMULATION=false
SKIP_ANALYSIS=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --skip-init)
            SKIP_INIT=true
            shift
            ;;
        --skip-services)
            SKIP_SERVICES=true
            shift
            ;;
        --skip-simulation)
            SKIP_SIMULATION=true
            shift
            ;;
        --skip-analysis)
            SKIP_ANALYSIS=true
            shift
            ;;
        --help)
            head -n 20 "$0" | tail -n +2
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use --help for usage information"
            exit 1
            ;;
    esac
done

print_header() {
    echo ""
    echo "=================================================="
    echo "  $1"
    echo "=================================================="
}

print_step() {
    echo ""
    echo ">>> $1"
}

print_success() {
    echo "✓ $1"
}

print_error() {
    echo "✗ ERROR: $1" >&2
}

print_warning() {
    echo "⚠ WARNING: $1"
}

# Check prerequisites
check_prerequisites() {
    print_header "Checking Prerequisites"
    
    if ! command -v python3 &> /dev/null; then
        print_error "python3 not found. Please install Python 3.8+"
        exit 1
    fi
    print_success "Python3 found: $(python3 --version)"
    
    if [ ! -f "$REDDIT_DB_PATH" ]; then
        print_warning "Reddit database not found at: $REDDIT_DB_PATH"
        print_warning "You may need to create it using Pushshift scripts"
    else
        print_success "Reddit database found"
    fi
    
    if [ ! -d "$BACKEND_DIR" ]; then
        print_error "Backend directory not found at: $BACKEND_DIR"
        exit 1
    fi
    print_success "Backend directory found"
    
    if [ ! -d "$BACKEND_DIR/python_simulation" ]; then
        print_error "Python simulation package not found at: $BACKEND_DIR/python_simulation"
        exit 1
    fi
    print_success "Python simulation package found"
    
    if [ -z "$OPENAI_API_KEY" ] && [ -z "$MISTRAL_API_KEY" ]; then
        print_warning "Neither OPENAI_API_KEY nor MISTRAL_API_KEY is set"
        print_warning "LLM service may fail to start"
    else
        if [ -n "$OPENAI_API_KEY" ]; then
            print_success "OPENAI_API_KEY is set"
        fi
        if [ -n "$MISTRAL_API_KEY" ]; then
            print_success "MISTRAL_API_KEY is set"
        fi
    fi
}

# Initialize agents and generate JSON configuration
initialize_agents() {
    print_header "Step 1: Initializing Agents & Generating Configuration"
    
    cd "$BACKEND_DIR"
    
    CMD="python3 -m python_simulation.tools.reddit_agent_initializer \
        --db-path \"$REDDIT_DB_PATH\" \
        --subreddit \"$SUBREDDIT\" \
        --num-regular-users $NUM_REGULAR_USERS \
        --num-llm-users $NUM_LLM_USERS \
        --num-moderator $NUM_MODERATORS \
        --num-attacker $NUM_ATTACKERS \
        --num-template-attackers $NUM_TEMPLATE_ATTACKERS \
        --duration-days $DURATION_DAYS \
        --interval-minutes $INTERVAL_MINUTES \
        --llm-service-url \"$LLM_SERVICE_URL\" \
        --output-dir \"$EXPERIMENT_DIR\" \
        --campaign-templates-dir \"$CAMPAIGN_TEMPLATES_DIR\""
    
    if [ "$LLM_VOTING_ENABLED" = true ]; then
        CMD="$CMD --llm-voting-enabled"
    fi
    # Prompt option: Likert-style labels next to belief acceptance values
    if [ "$VERBAL_ACCEPTANCE_LABELS" = true ]; then
        CMD="$CMD --verbal-acceptance-labels"
    fi
    
    # Campaign narrative for belief distillation (LLM/template attackers + biased moderator).
    # Do not gate on NUM_ATTACKERS only: biased mod with zero attackers still needs narrative.
    NEED_NARRATIVE=false
    if [ "$NUM_ATTACKERS" -gt 0 ] || [ "${NUM_TEMPLATE_ATTACKERS:-0}" -gt 0 ]; then
        NEED_NARRATIVE=true
    fi
    if [ "${ENABLE_BIASED_MODERATOR:-false}" = true ]; then
        NEED_NARRATIVE=true
    fi
    if [ "$NEED_NARRATIVE" = true ] && [ -n "${CAMPAIGN_NARRATIVE:-}" ]; then
        CMD="$CMD --attacker-target-narrative \"$CAMPAIGN_NARRATIVE\""
    fi

    # Always pass full subreddit rules to initializer so they are persisted into
    # simulation_config.json for auto_runner / config reuse (even if mitigations disabled).
    if [ -n "${SUBREDDIT_RULES:-}" ]; then
        CMD="$CMD --subreddit-rules \"$SUBREDDIT_RULES\""
    fi
    
    if [ "$ENABLE_DUPLICATE_DETECTION" = true ]; then
        CMD="$CMD --enable-duplicate-detection --duplicate-similarity-threshold $DUPLICATE_SIMILARITY_THRESHOLD"
    fi
    
    if [ "$ENABLE_RATE_LIMIT" = true ]; then
        CMD="$CMD --enable-rate-limiting --rate-limit-window $RATE_LIMIT_WINDOW --rate-limit-threshold $RATE_LIMIT_THRESHOLD"
    fi
    
    if [ "$ENABLE_COORDINATED_DETECTION" = true ]; then
        CMD="$CMD --enable-coordinated-detection --coordination-similarity-threshold ${COORDINATION_SIMILARITY_THRESHOLD:-${COORDINATION_SUSPICION_THRESHOLD:-0.3}}"
    fi
    
    CMD="$CMD --mitigation-ban-threshold $MITIGATION_BAN_THRESHOLD"
    CMD="$CMD --mitigation-scan-frequency $MITIGATION_SCAN_FREQUENCY"
    
    if [ "$ENABLE_BIASED_MODERATOR" = true ]; then
        CMD="$CMD --enable-biased-moderator \
            --biased-mod-risk-tolerance $BIASED_MOD_RISK_TOLERANCE \
            --biased-mod-scan-frequency $BIASED_MOD_SCAN_FREQUENCY \
            --biased-mod-detection-threshold $BIASED_MOD_DETECTION_THRESHOLD \
            --biased-mod-beliefs-file \"$BIASED_MOD_BELIEFS_FILE\""
    fi

    # Rule mitigation moderators (rules-only LLM; feed + MitigationSystem flags)
    if [ "${ENABLE_RULE_MODERATORS:-false}" = true ]; then
        CMD="$CMD --enable-rule-moderators \
            --num-rule-moderator ${NUM_RULE_MODERATOR:-1} \
            --rule-moderator-active-fraction ${RULE_MODERATOR_ACTIVE_FRACTION:-0.25} \
            --rule-moderator-read-density ${RULE_MODERATOR_READ_DENSITY:-25} \
            --rule-moderator-schedule-seed ${RULE_MODERATOR_SCHEDULE_SEED:-42} \
            --rule-moderator-detection-threshold ${RULE_MODERATOR_DETECTION_THRESHOLD:-0.7} \
            --rule-moderator-moderation-delay-timesteps ${RULE_MODERATOR_MODERATION_DELAY_TIMESTEPS:-2}"
    fi
    
    if [ -n "$CACHED_BELIEFS_FILE" ] && [ -f "$CACHED_BELIEFS_FILE" ]; then
        CMD="$CMD --cached-beliefs-file \"$CACHED_BELIEFS_FILE\""
    fi

    # Belief model and axes (axes file relative to this experiment folder)
    CMD="$CMD --belief-model ${BELIEF_MODEL:-axes}"
    CMD="$CMD --time-model ${TIME_MODEL:-event}"
    if [ -n "$BELIEF_AXES_FILE" ]; then
        AXES_FILE="$BELIEF_AXES_FILE"
        case "$AXES_FILE" in
            /*|[A-Za-z]:*) ;;
            *) AXES_FILE="$SCRIPT_DIR/$AXES_FILE" ;;
        esac
        if [ ! -f "$AXES_FILE" ]; then
            print_error "BELIEF_AXES_FILE not found: $AXES_FILE"
            exit 1
        fi
        CMD="$CMD --belief-axes-file \"$AXES_FILE\""
    fi
    
    # Proportional activity mix for regular + LLM users (small sims avoid all-readers samples)
    if [ "${STRATIFY_AGENT_MIX:-true}" = true ]; then
        CMD="$CMD --stratify-agent-mix"
    else
        CMD="$CMD --no-stratify-agent-mix"
    fi

    CMD="$CMD --feed-strategy \"$FEED_STRATEGY\""

    # Campaign settings for the in-process orchestrator (written to campaign_config).
    # The standalone orchestrator service below still gets them on its own command line.
    CMD="$CMD --campaign-objective \"${CAMPAIGN_OBJECTIVE:-amplify_narrative}\" \
        --coordination-strength ${COORDINATION_STRENGTH:-0.8} \
        --attack-intensity ${ATTACK_INTENSITY:-0.7} \
        --daily-post-target ${DAILY_POST_TARGET:-5} \
        --coordination-comment-prob ${COORDINATION_COMMENT_PROB:-0.5} \
        --coordination-delay-min ${COORDINATION_DELAY_MIN:-1} \
        --coordination-delay-max ${COORDINATION_DELAY_MAX:-6}"

    # Belief extraction failures are fatal unless explicitly allowed
    if [ "${ALLOW_BELIEF_FAILURES:-false}" = true ]; then
        CMD="$CMD --allow-belief-failures"
    fi

    print_step "Running agent initializer..."
    echo "Command: $CMD"
    
    eval $CMD
    
    if [ $? -eq 0 ]; then
        print_success "Agent initialization complete"
        print_success "Configuration JSON: $EXPERIMENT_DIR/simulation_config.json"
        print_success "Agent profiles: $EXPERIMENT_DIR/agent_profiles.json"
    else
        print_error "Agent initialization failed"
        exit 1
    fi
    
    cd "$SCRIPT_DIR"
}

# Start LLM service
start_llm_service() {
    print_header "Step 2: Starting LLM Service"
    
    if curl -s "$LLM_SERVICE_URL/health" &> /dev/null; then
        print_warning "LLM service already running at $LLM_SERVICE_URL"
        return 0
    fi
    
    print_step "Starting LLM service on port $LLM_SERVICE_PORT..."
    
    cd "$BACKEND_DIR"
    
    nohup python3 -m python_simulation.services.llm_reddit_service \
        --port $LLM_SERVICE_PORT \
        --provider "$LLM_PROVIDER" \
        --model "$LLM_MODEL" \
        > "$EXPERIMENT_DIR/llm_service.log" 2>&1 &
    
    LLM_PID=$!
    echo $LLM_PID > "$EXPERIMENT_DIR/llm_service.pid"
    
    print_step "Waiting for LLM service to start..."
    for i in {1..30}; do
        if curl -s "$LLM_SERVICE_URL/health" &> /dev/null; then
            print_success "LLM service started (PID: $LLM_PID)"
            print_success "Logs: $EXPERIMENT_DIR/llm_service.log"
            cd "$SCRIPT_DIR"
            return 0
        fi
        sleep 1
    done
    
    print_error "LLM service failed to start after 30 seconds"
    print_error "Check logs: $EXPERIMENT_DIR/llm_service.log"
    exit 1
}

# Start campaign orchestrator
start_orchestrator() {
    print_header "Step 3: Starting Campaign Orchestrator"
    
    if [ "$NUM_ATTACKERS" -eq 0 ]; then
        print_warning "No attackers configured, skipping orchestrator"
        return 0
    fi
    
    if curl -s "$CAMPAIGN_ORCHESTRATOR_URL/health" &> /dev/null; then
        print_warning "Orchestrator already running at $CAMPAIGN_ORCHESTRATOR_URL"
        return 0
    fi
    
    print_step "Starting orchestrator on port $ORCHESTRATOR_PORT..."
    
    cd "$BACKEND_DIR"
    
    OBJECTIVE_ARG="amplify_narrative"
    if [ "$CAMPAIGN_OBJECTIVE" = "disrupt_discourse" ]; then
        OBJECTIVE_ARG="disrupt_discourse"
    fi
    
    nohup python3 -m python_simulation.services.attacker_campaign_orchestrator \
        --port $ORCHESTRATOR_PORT \
        --objective $OBJECTIVE_ARG \
        --target-narrative "$CAMPAIGN_NARRATIVE" \
        --target-subreddit "$SUBREDDIT" \
        --coordination-strength $COORDINATION_STRENGTH \
        --intensity $ATTACK_INTENSITY \
        --daily-post-target $DAILY_POST_TARGET \
        --llm-service-url "$LLM_SERVICE_URL" \
        --output-dir "$EXPERIMENT_DIR" \
        > "$EXPERIMENT_DIR/orchestrator.log" 2>&1 &
    
    ORCH_PID=$!
    echo $ORCH_PID > "$EXPERIMENT_DIR/orchestrator.pid"
    
    print_step "Waiting for orchestrator to start..."
    for i in {1..30}; do
        if curl -s "$CAMPAIGN_ORCHESTRATOR_URL/health" &> /dev/null; then
            print_success "Orchestrator started (PID: $ORCH_PID)"
            print_success "Logs: $EXPERIMENT_DIR/orchestrator.log"
            cd "$SCRIPT_DIR"
            return 0
        fi
        sleep 1
    done
    
    print_error "Orchestrator failed to start after 30 seconds"
    print_error "Check logs: $EXPERIMENT_DIR/orchestrator.log"
    exit 1
}

# Run Python simulation
run_simulation() {
    print_header "Step 4: Running Python Simulation"
    
    cd "$BACKEND_DIR"
    
    print_step "Starting Python simulation..."
    print_step "Configuration: $EXPERIMENT_DIR/simulation_config.json"
    print_step "Output directory: $EXPERIMENT_DIR/simulation_output"
    
    python3 -m python_simulation.run_simulation \
        --config-dir "$EXPERIMENT_DIR" \
        --output-dir "$EXPERIMENT_DIR/simulation_output" \
        2>&1 | tee "$EXPERIMENT_DIR/simulation.log"
    
    SIM_EXIT_CODE=${PIPESTATUS[0]}
    
    if [ $SIM_EXIT_CODE -eq 0 ]; then
        print_success "Simulation completed successfully"
        print_success "Logs: $EXPERIMENT_DIR/simulation.log"
        print_success "Output: $EXPERIMENT_DIR/simulation_output/"
    else
        print_error "Simulation failed with exit code $SIM_EXIT_CODE"
        print_error "Check logs: $EXPERIMENT_DIR/simulation.log"
        exit 1
    fi
    
    cd "$SCRIPT_DIR"
}

# Run analysis (optional)
run_analysis() {
    print_header "Step 5: Analyzing Results"
    
    ANALYSIS_SCRIPT="$BACKEND_DIR/python_simulation/tools/analyze_simulation.py"
    if [ ! -f "$ANALYSIS_SCRIPT" ]; then
        print_warning "Analysis script not found at $ANALYSIS_SCRIPT"
        print_warning "Skipping analysis step"
        return 0
    fi
    
    print_step "Running analysis..."
    
    cd "$BACKEND_DIR"
    
    mkdir -p "$ANALYSIS_OUTPUT_DIR"
    
    python3 -m python_simulation.tools.analyze_simulation \
        --input-dir "$EXPERIMENT_DIR/simulation_output" \
        --output-dir "$ANALYSIS_OUTPUT_DIR" \
        2>&1 | tee "$EXPERIMENT_DIR/analysis.log"
    
    if [ $? -eq 0 ]; then
        print_success "Analysis completed"
        print_success "Results: $ANALYSIS_OUTPUT_DIR"
    else
        print_warning "Analysis completed with warnings"
    fi
    
    cd "$SCRIPT_DIR"
}

summarize_profiling() {
    print_header "Profiling Summary"

    if [ ! -f "$EXPERIMENT_DIR/profiling.log" ]; then
        print_warning "profiling.log not found at $EXPERIMENT_DIR/profiling.log; skipping profiling summary"
        return 0
    fi

    print_step "Running profiling summarizer..."

    cd "$BACKEND_DIR"

    python3 -m python_simulation.tools.summarize_profiling_log \
        --input "$EXPERIMENT_DIR/profiling.log" \
        --output "$EXPERIMENT_DIR/profiling_summary.txt" \
        --json || print_warning "Profiling summary completed with warnings (see profiling.log)"

    cd "$SCRIPT_DIR"
}

# Main execution
main() {
    print_header "Python Reddit Simulation: $EXPERIMENT_NAME"
    echo "Description: $EXPERIMENT_DESCRIPTION"
    echo ""
    
    check_prerequisites
    
    if [ "$SKIP_INIT" = false ]; then
        initialize_agents
    else
        print_warning "Skipping agent initialization (using existing config)"
    fi
    
    if [ "$SKIP_SERVICES" = false ]; then
        start_llm_service
        start_orchestrator
    else
        print_warning "Skipping service startup (assuming services are running)"
    fi
    
    if [ "$SKIP_SIMULATION" = false ]; then
        run_simulation
    else
        print_warning "Skipping simulation execution"
    fi
    
    if [ "$SKIP_ANALYSIS" = false ]; then
        run_analysis
    else
        print_warning "Skipping analysis step"
    fi

    # Always attempt profiling summary if profiling.log exists
    summarize_profiling
    
    print_header "Simulation Complete"
    echo ""
    echo "Output files:"
    echo "  - Configuration: $EXPERIMENT_DIR/simulation_config.json"
    echo "  - Agent profiles: $EXPERIMENT_DIR/agent_profiles.json"
    echo "  - Simulation output: $EXPERIMENT_DIR/simulation_output/"
    echo "  - Logs: $EXPERIMENT_DIR/*.log"
    if [ "$SKIP_ANALYSIS" = false ]; then
        echo "  - Analysis: $ANALYSIS_OUTPUT_DIR"
    fi
    echo ""
    echo "To stop services, run: ./stop_services.sh"
}

main

