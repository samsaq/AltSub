#!/bin/bash
# Experiment Configuration for Python Simulation
# LLM attackers, no mitigations

# ===== EXPERIMENT METADATA =====
export EXPERIMENT_NAME="politics_base_sim_small"
export EXPERIMENT_DESCRIPTION="R/worldnews campaign simulation: Testing disruption of the narrative around the Russian missile strike on the Okhmatdyt children's hospital in Kyiv during the Russian invasion of Ukraine."

# ===== FILE PATHS =====
export PROJECT_ROOT="$(cd "../../../.." && pwd)"
export SIMULATION_SETUPS_DIR="$PROJECT_ROOT/Simulation_Setups"
export BACKEND_DIR="$PROJECT_ROOT/backend"
export EXPERIMENT_DIR="$SIMULATION_SETUPS_DIR/simulations/universes/$EXPERIMENT_NAME"
export CAMPAIGN_TEMPLATES_DIR="$EXPERIMENT_DIR/campaign_templates"
export ANALYSIS_OUTPUT_DIR="$SIMULATION_SETUPS_DIR/simulations/universes/analysis/$EXPERIMENT_NAME"

# ===== DATABASE & SUBREDDIT =====
export REDDIT_DB_PATH="$SIMULATION_SETUPS_DIR/reddit_databases/2025-06-worldnews.db"
export SUBREDDIT="worldnews"

# ===== AGENT CONFIGURATION =====
# When true, initializer assigns activity level / frequency / session length in exact proportion
# to reddit_agent_initializer distributions (reader 40%, voter 25%, commenter 20%, poster 15%, etc.)
export STRATIFY_AGENT_MIX=true
export NUM_REGULAR_USERS=0
export NUM_LLM_USERS=25
export NUM_MODERATORS=0
export NUM_ATTACKERS=0  # LLM Based Attackers
export NUM_TEMPLATE_ATTACKERS=0

# ===== SIMULATION PARAMETERS =====
export DURATION_DAYS=3
export INTERVAL_MINUTES=5
export START_TIMESTEP=0
export ENABLE_TIMESTEP_PARALLELISM=true

# ===== LLM Runtime Throttling (used by python_simulation at runtime) =====
# These are read directly from the environment by `run_simulation.py` and `llm_provider.py`.
export LLM_MAX_CONCURRENCY=8  # Max concurrent LLM calls (default used in code if unset)
export LLM_RATE_LIMIT_QPS=0  # Max LLM requests per second (0 disables rate limiting)

# ===== SERVICE URLS =====
export LLM_SERVICE_URL="http://localhost:5000"
export CAMPAIGN_ORCHESTRATOR_URL="http://localhost:5001"

# ===== LLM PROVIDER SETTINGS =====
export LLM_PROVIDER="mistral"  # "openai", "mistral", or "local"
export LLM_MODEL="mistral-small-latest"
# NOTE: Set one of these in your environment before running (or export them here):
# export OPENAI_API_KEY="..."
# export MISTRAL_API_KEY="..."

# ===== CAMPAIGN PARAMETERS =====
export CAMPAIGN_OBJECTIVE="disrupt_discourse"
export CAMPAIGN_NARRATIVE="The July 8 Kyiv hospital bombing is being exploited as propaganda with no real evidence. Witness reports conflict, casualty numbers are unverified, and the site may have been a legitimate military target. Media ignores context. Most people on this sub aren't convinced Russia did it. Don’t buy the outrage without proof."
export COORDINATION_STRENGTH=0.8
export ATTACK_INTENSITY=0.7
export DAILY_POST_TARGET=5
# Attackers amplify each other's posts: chance of a comment with the upvote, and delay range (timesteps)
export COORDINATION_COMMENT_PROB=0.5
export COORDINATION_DELAY_MIN=1
export COORDINATION_DELAY_MAX=6

# ===== MITIGATION FLAGS =====
export ENABLE_DUPLICATE_DETECTION=false
export DUPLICATE_SIMILARITY_THRESHOLD=0.85
export USE_EMBEDDING_SIMILARITY_FOR_DUPLICATES=false


export ENABLE_RATE_LIMIT=false
export RATE_LIMIT_WINDOW=24  # timesteps (5-min intervals)
export RATE_LIMIT_THRESHOLD=10

export ENABLE_COORDINATED_DETECTION=false
# Co-action network detector: co-engagement TF-IDF cosine threshold (other detector
# settings use the initializer/MitigationSystem defaults)
export COORDINATION_SIMILARITY_THRESHOLD=0.3

export MITIGATION_BAN_THRESHOLD=3
export MITIGATION_SCAN_FREQUENCY=10  # timesteps

# ===== RULE MODERATORS (LLM feed review → MitigationSystem flags; requires LLM service) =====
# Wired in run_simulation.sh / run_simulation.ps1 to reddit_agent_initializer.
# Uses SUBREDDIT_RULES below as mitigation_config.subreddit_rules for prompts.
export ENABLE_RULE_MODERATORS=false   # set true to add rule_moderator agents + schedules
export NUM_RULE_MODERATOR=2
export RULE_MODERATOR_ACTIVE_FRACTION=0.5   # fraction of each day each mod is on (contiguous block)
export RULE_MODERATOR_READ_DENSITY=15       # feed items per timestep when active
export RULE_MODERATOR_SCHEDULE_SEED=42
export RULE_MODERATOR_DETECTION_THRESHOLD=0 # at 0, the moderation decision depends on the rule broken: true/false instead of confidence score + true/false
export RULE_MODERATOR_MODERATION_DELAY_TIMESTEPS=2

# Optional: runtime overrides for run_simulation.py (same names as backend env helpers)
# export MITIGATION_RULE_MODERATOR_COUNT=2
# export MITIGATION_RULE_MODERATOR_ACTIVE_FRACTION=0.25

# ===== BELIEF CAPPING =====
export ENABLE_BELIEF_CAPPING=true
export BELIEF_CAP=60
export PROTECT_ATTACKER_BELIEFS=false
export ATTACKER_SIMILARITY_THRESHOLD=0.6
export WEAK_BELIEF_THRESHOLD=0.2

# ===== BIASED MODERATOR =====
export ENABLE_BIASED_MODERATOR=false
export BIASED_MOD_RISK_TOLERANCE=0.7
export BIASED_MOD_SCAN_FREQUENCY=12  # timesteps (every hour for 5-min intervals)
export BIASED_MOD_DETECTION_THRESHOLD=0.6
# r/worldnews rules (sidebar, 2026-11), adapted for simulated text posts: original numbers kept;
# omitted as not applicable (they govern linked articles or media, which agents do not post):
# 3 No Feature stories, 4 No Editorials/Opinion/Analysis Pieces, 5 No Articles In Languages Other
# Than English, 6 No Images/Videos/Audio Clips, 7 No Old News Articles, 11 No Memes/Gifs/NSFW;
# omitted by choice: 12 No chatGPT bots or copy/paste bots (all agents write with an LLM, so a
# moderator judging this cannot separate attackers from users; copy/paste is covered by duplicate detection).
export SUBREDDIT_RULES="r/worldnews rules:

1. No US Internal News or Politics
Posts and comments must concern world news. U.S. internal news or domestic politics is off-topic.

2. No Editorialized or Misleading Titles
Post titles must not be editorialized or misrepresent the facts.

8. Content might be removed if r/worldnews is not the appropriate subreddit for the story.

9. No Bigotry or Other Offensive Content

10. No Personal Attacks On Other Users
"

# ===== PORT CONFIGURATION =====
export LLM_SERVICE_PORT=5000
export ORCHESTRATOR_PORT=5001

# ===== LLM VOTING =====
export LLM_VOTING_ENABLED=false  # Enable LLM-based voting decisions
export VERBAL_ACCEPTANCE_LABELS=false  # Likert-style labels next to belief acceptance values in prompts

# ===== BELIEF CACHING =====
export CACHED_BELIEFS_FILE=""  # Path to cached beliefs JSON (optional, speeds up initialization)

# ===== TIME MODEL =====
# "event" (default): continuous-time event-driven engine (each action takes simulated
# time; see backend/python_simulation/core/time_model.py). "discrete": fixed-timestep
# engine.
export TIME_MODEL="event"

# ===== BELIEF MODEL =====
# "axes" (default): a fixed set of belief statements per scenario,
# each held as an acceptance value (0 = complete rejection, 0.5 = neutral,
# 1 = complete acceptance); the LLM updates them per item read (capped per update).
# "free_text": claims extracted from content.
export BELIEF_MODEL="axes"
# Belief statements + campaign targets (JSON, see backend/python_simulation/core/belief_axes.py).
# Empty = built-in set for the subreddit (thesis C1-C7 / P1-P6). Relative paths are from this folder.
export BELIEF_AXES_FILE=""  # e.g. ../../../belief_axes/politics.json

# ===== FEED ORDERING STRATEGY =====
# Options: default, chronological, score-based, engagement-weighted, reddit-hot, reddit-all-hot
# - default: priority groups + score sorting + 10% shuffle
# - chronological: Simple newest-first ordering
# - score-based: Score-only ordering with recency decay
# - engagement-weighted: Weighted engagement scoring with priority boosts
# - reddit-hot: Reddit's actual hot algorithm from open-source codebase
# - reddit-all-hot: Reddit's r/all hot algorithm (aggregates across subreddits)
export FEED_STRATEGY="reddit-hot"

echo "✓ Configuration loaded for experiment: $EXPERIMENT_NAME"
