# Reddit databases (not included)

Universe initialization reads one SQLite database per subreddit, built from the monthly Pushshift Reddit dumps with `backend/Pushshift_Scripts/zst_to_sqlite.py`. The paper's universes used the June 2025 dumps:

- `2025-06-destiny2.db`: r/Destiny2
- `2025-06-worldnews.db`: r/worldnews

These databases are not distributed with this repository due to their size (~500gb for a month). They are only needed to build a new universe or regenerate one; the included universes are ready to run without them.
