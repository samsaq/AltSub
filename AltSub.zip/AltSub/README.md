# AltSub

AltSub is an LLM-driven agent-based model (ABM) of Reddit-style discussion for studying astroturfing campaigns and platform mitigations in a controlled setting. Ordinary users, template-based attackers, LLM attackers coordinated by an orchestrator, and moderator agents interact in a continuous-time simulation of one subreddit. Each user holds acceptance values over a small, scenario-specific set of belief statements, and these update as users read and respond to content. Mitigations (duplicate detection, rate limiting, coordination detection and LLM rule moderators) flag and ban accounts. Their thresholds are tuned with an account-level Matthews correlation coefficient (MCC).

This repository holds the code, the two scenario setups, and the result data behind the accompanying paper.

## Repository layout

```
backend/
  python_simulation/        the simulation package
    run_simulation.py       entry point for one run
    agents/ core/ services/ systems/
    tools/                  initialization, analysis, batch runs, tuning, validation
    tests/                  unit, integration and regression tests (pytest)
    validation/belief_space belief-statement validation inputs, run artifacts, revision log
  Pushshift_Scripts/        build subreddit SQLite databases from Pushshift dumps
  requirements.txt
Simulation_Setups/
  belief_axes/              belief statements per scenario
  simulations/universes/    the two scenario setups (see below)
  simulations/mitigation_tuning_grid/   mitigation threshold tuning runs and results
  auto_runs/completed_set_3/            the paper's experiment set (32 runs)
  reddit_databases/         place Pushshift-derived databases here (not included)
```

### Scenarios

Both scenarios use 25 agents over three simulated days, with posting hours weighted by US Eastern time and ten real posts (with their top 5 comments) as seed content.

| `destiny2_base_sim_small` | r/Destiny2 | Commercial amplification: promote Warframe as the alternative to Destiny 2 |
| `politics_base_sim_small` | r/worldnews | Political disruption: cast doubt on the July 2024 Okhmatdyt hospital strike on its anniversary |

Each universe has one folder per attacker mode: `llm_attackers`, `template_attackers` and `no_attackers` (23 ordinary users plus 2 attackers, or 25 ordinary users). Each folder holds a ready-to-run `simulation_config.json` and `agent_profiles.json`, plus the seed content.

## Setup

Requires Python 3.10 or later. Linux or WSL is recommended - the shell scripts are bash.

```bash
cd backend
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp ../Simulation_Setups/.env.example ../Simulation_Setups/.env   # add your API key
cp ../Simulation_Setups/.env.example .env
```

The simulation calls an OpenAI-compatible chat API. The paper's runs used Mistral Small (`MISTRAL_API_KEY`). A stub provider (`"llm_config": {"provider": "stub"}` in a config) runs everything offline with canned responses, which is useful for testing (though it has not recently been tested and may have broken).

## Running

**One simulation** (from `backend/`):

```bash
python3 -m python_simulation.run_simulation \
  --config-dir ../Simulation_Setups/simulations/universes/politics_base_sim_small/llm_attackers \
  --output-dir /tmp/run_out
```

Outputs go to the output directory: `final_output.json`, `media_events.json` and `daily_snapshots/`. Analyse them with `python3 -m python_simulation.tools.analyze_simulation`.

**The full experiment set** (from the repository root). This runs both universes × attacker modes × mitigation configurations, using the tuned thresholds in `mitigation_tuning_grid`:

```bash
LLM_RATE_LIMIT_QPS=1.3 python3 -m backend.python_simulation.tools.auto_runner \
  --runs 1 --max-workers 24 --batch-id my_set \
  --exclude-scenarios coordination_only,all_mitigations
```

`LLM_RATE_LIMIT_QPS` caps each simulation's request rate. Keep `max-workers × QPS` under your provider's limit. Mistral lists rate limits under their admin dashboard -> API limits per model

**Mitigation threshold tuning** (from `backend/`):

```bash
python3 -m python_simulation.tools.grid_tuning --dry-run          # show the plan
python3 -m python_simulation.tools.grid_tuning --stub --points 2  # offline check
python3 -m python_simulation.tools.grid_tuning --concurrency 24 --qps 1.3
```

**Tests** (from `backend/`): `python3 -m pytest python_simulation/tests`

## Building a new universe

Initializing a universe needs a SQLite database for the subreddit, built from the [Pushshift Reddit dumps](https://academictorrents.com/details/ba051999301b109eab37d16f027b3f49ade2de13). These dumps are not included here due to size.

```bash
python3 backend/Pushshift_Scripts/prefilter_subreddit_zst.py ...   # optional: filter one subreddit out of a month
python3 backend/Pushshift_Scripts/zst_to_sqlite.py <month_folder> Simulation_Setups/reddit_databases/<name>.db
```

Then point a universe's `experiment_config.sh` at the database and run its `setup_modes.sh`. That calls `python_simulation.tools.reddit_agent_initializer` to build agent profiles, activity schedules and seed content. `tools/reddit_hourly_activity.py` and `tools/reddit_text_length_stats.py` derive the activity and text-length statistics used for timing. `tools/mitigation_range_analysis.py` derives mitigation parameter ranges.

## Paper results

- `Simulation_Setups/auto_runs/completed_set_3/`: the experiment set reported in the paper. It has 32 runs: both scenarios × three attacker modes × five mitigation configurations, plus one biased-moderator run per scenario. Each run folder holds its exact `config/`, `simulation_output/` and `analysis/`. `thesis_results.csv` collects one row per run (events, flags, bans, belief alignment, MCC); `summary.csv` and `summary.json` hold the batch summary.
- `Simulation_Setups/simulations/mitigation_tuning_grid/`: the 84 calibration runs that selected the mitigation thresholds. `results/tuning_results.json` is the file `auto_runner` reads; `tuning_evaluations.csv` and `tuning_results.txt` list every evaluation.
- `backend/python_simulation/validation/belief_space/`: the belief-statement validation inputs (`scenario_items.json`), the scripted semantic and belief-update probe runs, and the revision log.

## Data and privacy notes

- **Usernames:** agent profiles are derived from real subreddit users in the Pushshift data. Every username is replaced by a pseudonym (`user_0001`, …), consistently across all files. The simulation only uses numeric IDs, so behaviour is unchanged.
- **Seed content:** `subreddit_seed_context.json` contains the text, score and post ID of ten public posts and their top comments per scenario, without author names.
- **Paths:** absolute paths recorded in run configs and logs were replaced with `<REPO_ROOT>`. Those configs are a record of each run; to rerun an experiment, use the universe setups and `auto_runner`.
- **Not included:** the Pushshift-derived databases.
