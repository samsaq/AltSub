#!/usr/bin/env python3
"""
Script to convert PushShift .zst files directly to SQLite database.
Creates separate tables for comments and submissions with proper indexing.

Usage:
    python zst_to_sqlite.py <month_folder_path> [database_path] [options]
    
Examples:
    # Full conversion
    python zst_to_sqlite.py 2025-06 reddit_data.db
    
    # Only one subreddit (smaller DB; scans full monthly .zst files)
    python zst_to_sqlite.py 2025-05 2025-05-politics.db --subreddit politics
    
    # Test mode (first 1000 lines only)
    python zst_to_sqlite.py 2025-06 --test
    
    # Test mode with custom line count
    python zst_to_sqlite.py 2025-06 --test --test-lines 5000
    
    # Test with custom database name
    python zst_to_sqlite.py 2025-06 --test my_test.db
    
    # Debug mode
    python zst_to_sqlite.py 2025-06 --debug

Parameters:
    month_folder_path    Path to the month folder containing .zst files
    database_path        Path for SQLite database file (optional)
    
Options:
    --test              Run in test mode (process only first 1000 lines)
    --test-lines N      Number of lines to process in test mode (default: 1000)
    --subreddit NAME    Only store rows for this subreddit (case-insensitive); full .zst still scanned
    --debug             Enable debug logging
    --help              Show this help message

Test Mode:
    Test mode processes only the first N lines from one .zst file to quickly
    verify the database creation works correctly. This creates a small test
    database that you can inspect before running the full conversion.

Output:
    Creates a SQLite database with two tables:
    - comments: Reddit comments with fields like id, author, subreddit, body, score, etc.
    - submissions: Reddit posts with fields like id, author, subreddit, title, selftext, etc.
    
    Both tables include proper indexes for fast searching by subreddit, author, date, etc.
"""

import zstandard
import os
import sys
import json
import sqlite3
from datetime import datetime, timezone
import logging
import argparse
from typing import Optional, Dict, Any
import multiprocessing as mp
from multiprocessing import Pool, Manager
import tempfile
import shutil
import time
import signal
import pickle
import json as json_lib
from multiprocessing import Process, Queue
from threading import Thread, Event


log = logging.getLogger("zst_to_sqlite")
log.setLevel(logging.INFO)
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')

log_str_handler = logging.StreamHandler()
log_str_handler.setFormatter(log_formatter)
log.addHandler(log_str_handler)


def read_and_decode(reader, chunk_size, max_window_size, previous_chunk=None, bytes_read=0):
    """Recursively decompress and decode a chunk of bytes."""
    chunk = reader.read(chunk_size)
    bytes_read += chunk_size
    if previous_chunk is not None:
        chunk = previous_chunk + chunk
    try:
        return chunk.decode()
    except UnicodeDecodeError:
        if bytes_read > max_window_size:
            raise UnicodeError(f"Unable to decode frame after reading {bytes_read:,} bytes")
        log.info(f"Decoding error with {bytes_read:,} bytes, reading another chunk")
        return read_and_decode(reader, chunk_size, max_window_size, chunk, bytes_read)


def read_lines_zst(file_name, max_lines=None, start_line=0):
    """Read lines from a zst compressed file."""
    with open(file_name, 'rb') as file_handle:
        buffer = ''
        reader = zstandard.ZstdDecompressor(max_window_size=2**31).stream_reader(file_handle)
        lines_read = 0
        
        while True:
            chunk = read_and_decode(reader, 2**27, (2**29) * 2)

            if not chunk:
                break
            lines = (buffer + chunk).split("\n")

            for line in lines[:-1]:
                if lines_read >= start_line:
                    yield line.strip(), file_handle.tell()
                
                lines_read += 1
                
                # Stop if we've reached the max_lines limit - used for testing
                if max_lines and lines_read >= start_line + max_lines:
                    reader.close()
                    return

            buffer = lines[-1]

        reader.close()


def get_file_line_count(file_name):
    """Quickly estimate the number of lines in a zst file."""
    try:
        with open(file_name, 'rb') as file_handle:
            reader = zstandard.ZstdDecompressor(max_window_size=2**31).stream_reader(file_handle)
            lines = 0
            while True:
                chunk = read_and_decode(reader, 2**20, (2**29) * 2)
                if not chunk:
                    break
                lines += chunk.count('\n')
            reader.close()
            return lines
    except:
        return 1000000


def save_checkpoint(checkpoint_file, progress_data):
    """Save progress to checkpoint file."""
    try:
        with open(checkpoint_file, 'w') as f:
            json_lib.dump(progress_data, f, indent=2)
        log.debug(f"Checkpoint saved: {checkpoint_file}")
    except Exception as e:
        log.warning(f"Failed to save checkpoint: {e}")


def load_checkpoint(checkpoint_file):
    """Load progress from checkpoint file."""
    try:
        if os.path.exists(checkpoint_file):
            with open(checkpoint_file, 'r') as f:
                return json_lib.load(f)
    except Exception as e:
        log.warning(f"Failed to load checkpoint: {e}")
    return None


def cleanup_checkpoint(checkpoint_file):
    """Remove checkpoint file after successful completion."""
    try:
        if os.path.exists(checkpoint_file):
            os.unlink(checkpoint_file)
            log.info("Checkpoint file cleaned up")
    except Exception as e:
        log.warning(f"Failed to cleanup checkpoint: {e}")


interrupt_requested = False

def signal_handler(signum, frame):
    """Handle Ctrl+C gracefully."""
    global interrupt_requested
    if interrupt_requested:
        log.info("\nForce exit requested. Terminating all processes...")
        os._exit(1)
    else:
        log.info("\nReceived interrupt signal. Stopping gracefully...")
        log.info("Setting interrupt flag and waiting for processes to respond...")
        interrupt_requested = True


def recover_worker_checkpoints(temp_dbs, input_path):
    """Recover data from worker checkpoints if they exist."""
    recovered_data = []
    
    for i, temp_db_path in enumerate(temp_dbs):
        worker_checkpoint_file = f"{temp_db_path}.worker_{i}.checkpoint"
        checkpoint_data = load_checkpoint(worker_checkpoint_file)
        
        if checkpoint_data and checkpoint_data.get('interrupted', False):
            log.info(f"Found interrupted worker {i} with {checkpoint_data.get('lines_processed', 0):,} lines")
            recovered_data.append({
                'worker_id': i,
                'temp_db_path': temp_db_path,
                'lines_processed': checkpoint_data.get('lines_processed', 0),
                'bad_lines': checkpoint_data.get('bad_lines', 0)
            })
    
    return recovered_data


def create_database_schema(cursor, create_indexes: bool = True):
    """Create the SQLite database schema with proper tables and optional indexes.

    Pass create_indexes=False to defer index creation until after bulk load.
    """
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS comments (
            id TEXT PRIMARY KEY,
            author TEXT,
            subreddit TEXT,
            body TEXT,
            score INTEGER,
            created_utc INTEGER,
            parent_id TEXT,
            link_id TEXT,
            permalink TEXT,
            is_submitter BOOLEAN,
            controversiality INTEGER,
            gilded INTEGER,
            archived BOOLEAN,
            locked BOOLEAN,
            stickied BOOLEAN,
            distinguished TEXT,
            edited BOOLEAN,
            retrieved_on INTEGER,
            raw_json TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS submissions (
            id TEXT PRIMARY KEY,
            author TEXT,
            subreddit TEXT,
            title TEXT,
            selftext TEXT,
            url TEXT,
            score INTEGER,
            created_utc INTEGER,
            permalink TEXT,
            is_self BOOLEAN,
            over_18 BOOLEAN,
            spoiler BOOLEAN,
            locked BOOLEAN,
            stickied BOOLEAN,
            distinguished TEXT,
            edited BOOLEAN,
            num_comments INTEGER,
            upvote_ratio REAL,
            retrieved_on INTEGER,
            raw_json TEXT
        )
    """)
    
    if create_indexes:
        # Create indexes for fast searching
        for index_sql in get_schema_indexes():
            cursor.execute(index_sql)
        log.info("Database schema created with indexes")
    else:
        log.info("Database schema created without indexes (deferred)")


def get_schema_indexes():
    return [
        "CREATE INDEX IF NOT EXISTS idx_comments_subreddit ON comments(subreddit)",
        "CREATE INDEX IF NOT EXISTS idx_comments_author ON comments(author)",
        "CREATE INDEX IF NOT EXISTS idx_comments_created_utc ON comments(created_utc)",
        "CREATE INDEX IF NOT EXISTS idx_comments_score ON comments(score)",
        "CREATE INDEX IF NOT EXISTS idx_comments_parent_id ON comments(parent_id)",
        "CREATE INDEX IF NOT EXISTS idx_comments_link_id ON comments(link_id)",
        "CREATE INDEX IF NOT EXISTS idx_submissions_subreddit ON submissions(subreddit)",
        "CREATE INDEX IF NOT EXISTS idx_submissions_author ON submissions(author)",
        "CREATE INDEX IF NOT EXISTS idx_submissions_created_utc ON submissions(created_utc)",
        "CREATE INDEX IF NOT EXISTS idx_submissions_score ON submissions(score)",
        "CREATE INDEX IF NOT EXISTS idx_submissions_is_self ON submissions(is_self)",
        "CREATE INDEX IF NOT EXISTS idx_submissions_over_18 ON submissions(over_18)",
    ]


def safe_get(obj: Dict[str, Any], key: str, default=None):
    """Safely get a value from a dictionary, handling missing keys."""
    try:
        return obj.get(key, default)
    except (KeyError, TypeError):
        return default


def normalize_subreddit_filter(subreddit_filter: Optional[str]) -> Optional[str]:
    """Return lowercase subreddit name, or None if unset / empty (meaning: no filter)."""
    if subreddit_filter is None:
        return None
    s = subreddit_filter.strip()
    return s.lower() if s else None


def row_matches_subreddit_filter(obj: Dict[str, Any], normalized_target: Optional[str]) -> bool:
    """If normalized_target is set, require obj['subreddit'] to match (case-insensitive)."""
    if normalized_target is None:
        return True
    sr = obj.get("subreddit")
    if sr is None:
        return False
    return str(sr).lower() == normalized_target


def process_comment(obj: Dict[str, Any]) -> tuple:
    """Extract and clean comment data for database insertion."""
    return (
        safe_get(obj, 'id', ''),
        safe_get(obj, 'author', ''),
        safe_get(obj, 'subreddit', ''),
        safe_get(obj, 'body', ''),
        safe_get(obj, 'score', 0),
        safe_get(obj, 'created_utc', 0),
        safe_get(obj, 'parent_id', ''),
        safe_get(obj, 'link_id', ''),
        safe_get(obj, 'permalink', ''),
        safe_get(obj, 'is_submitter', False),
        safe_get(obj, 'controversiality', 0),
        safe_get(obj, 'gilded', 0),
        safe_get(obj, 'archived', False),
        safe_get(obj, 'locked', False),
        safe_get(obj, 'stickied', False),
        safe_get(obj, 'distinguished', ''),
        safe_get(obj, 'edited', False),
        safe_get(obj, 'retrieved_on', 0),
        None  # raw_json - only populated on errors
    )


def process_submission(obj: Dict[str, Any]) -> tuple:
    """Extract and clean submission data for database insertion."""
    return (
        safe_get(obj, 'id', ''),
        safe_get(obj, 'author', ''),
        safe_get(obj, 'subreddit', ''),
        safe_get(obj, 'title', ''),
        safe_get(obj, 'selftext', ''),
        safe_get(obj, 'url', ''),
        safe_get(obj, 'score', 0),
        safe_get(obj, 'created_utc', 0),
        safe_get(obj, 'permalink', ''),
        safe_get(obj, 'is_self', False),
        safe_get(obj, 'over_18', False),
        safe_get(obj, 'spoiler', False),
        safe_get(obj, 'locked', False),
        safe_get(obj, 'stickied', False),
        safe_get(obj, 'distinguished', ''),
        safe_get(obj, 'edited', False),
        safe_get(obj, 'num_comments', 0),
        safe_get(obj, 'upvote_ratio', 0.0),
        safe_get(obj, 'retrieved_on', 0),
        None  # raw_json - only populated on errors
    )


def writer_process(database_path: str, queue: Queue, stop_token: str = "__STOP__", progress: bool = True, progress_interval: float = 2.0, file_label: Optional[str] = None, logging_queue: Optional[Queue] = None, estimated_total: Optional[int] = None, eta_interval: float = 60.0):
    """Dedicated writer process: receives batches and writes to SQLite.

    If progress is True, periodically prints aggregate insert stats to console.
    """
    conn = sqlite3.connect(database_path, timeout=30.0)
    cursor = conn.cursor()
    try:
        # Performance-oriented PRAGMAs during bulk load
        cursor.execute("PRAGMA busy_timeout=10000")
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA temp_store=MEMORY")
        cursor.execute("PRAGMA cache_size=-400000")  # ~400 MB
        cursor.execute("PRAGMA mmap_size=30000000000")  # 30 GB if supported
        cursor.execute("PRAGMA locking_mode=EXCLUSIVE")
    except Exception:
        pass
    create_database_schema(cursor)
    conn.commit()

    comments_sql = (
        """
        INSERT OR REPLACE INTO comments (
            id, author, subreddit, body, score, created_utc, parent_id, link_id,
            permalink, is_submitter, controversiality, gilded, archived, locked,
            stickied, distinguished, edited, retrieved_on, raw_json
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
        """
    )
    submissions_sql = (
        """
        INSERT OR REPLACE INTO submissions (
            id, author, subreddit, title, selftext, url, score, created_utc,
            permalink, is_self, over_18, spoiler, locked, stickied, distinguished,
            edited, num_comments, upvote_ratio, retrieved_on, raw_json
        ) VALUES (
            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
        )
        """
    )

    inserted_since_commit = 0
    total_inserted = 0
    total_comments = 0
    total_submissions = 0
    start_time = time.time()
    last_report = start_time
    # ETA sampling
    last_eta_sample_time = start_time
    last_eta_sample_inserted = 0
    eta_str_cached = ""
    commit_every = 5000
    
    if logging_queue is not None:
        try:
            logging_queue.put(f"Writer started for {file_label or 'processing'} - waiting for data...")
        except Exception:
            pass

    while True:
        item = queue.get()
        if item == stop_token:
            break
        kind, batch = item
        if not batch:
            continue
        if kind == 'c':
            cursor.executemany(comments_sql, batch)
            batch_len = len(batch)
            inserted_since_commit += batch_len
            total_inserted += batch_len
            total_comments += batch_len
            if total_inserted == batch_len and logging_queue is not None:
                try:
                    logging_queue.put(f"First batch received: {batch_len} comments")
                except Exception:
                    pass
        elif kind == 's':
            cursor.executemany(submissions_sql, batch)
            batch_len = len(batch)
            inserted_since_commit += batch_len
            total_inserted += batch_len
            total_submissions += batch_len
            if total_inserted == batch_len and logging_queue is not None:
                try:
                    logging_queue.put(f"First batch received: {batch_len} submissions")
                except Exception:
                    pass
        else:
            continue
        if inserted_since_commit >= commit_every:
            conn.commit()
            inserted_since_commit = 0
        now = time.time()
        # Refresh sample-based ETA on its own cadence
        if progress and eta_interval and (now - last_eta_sample_time) >= eta_interval:
            delta_rows = max(0, total_inserted - last_eta_sample_inserted)
            delta_time = max(0.001, now - last_eta_sample_time)
            sample_rate = delta_rows / delta_time
            if estimated_total and total_inserted > 0 and sample_rate > 0:
                remaining = max(0, estimated_total - total_inserted)
                eta_seconds = remaining / sample_rate
                eta_minutes = eta_seconds / 60
                if eta_minutes < 1:
                    eta_str_cached = f" ETA={eta_seconds:.0f}s"
                elif eta_minutes < 60:
                    eta_str_cached = f" ETA={eta_minutes:.1f}m"
                else:
                    eta_hours = eta_minutes / 60
                    eta_str_cached = f" ETA={eta_hours:.1f}h"
            else:
                eta_str_cached = ""
            last_eta_sample_time = now
            last_eta_sample_inserted = total_inserted

        if progress and (now - last_report) >= progress_interval:
            elapsed = max(0.001, now - start_time)
            rate = total_inserted / elapsed
            label = f" [{file_label}]" if file_label else ""
            message = f"Progress{label}: inserted={total_inserted:,} (comments={total_comments:,}, submissions={total_submissions:,}) rate={rate:,.0f}/s elapsed={elapsed:,.1f}s{eta_str_cached}"
            if logging_queue is not None:
                try:
                    logging_queue.put(message)
                except Exception:
                    pass
            else:
                log.info(message)
            last_report = now
    conn.commit()
    conn.close()
    if progress:
        elapsed = max(0.001, time.time() - start_time)
        label = f" [{file_label}]" if file_label else ""
        message = f"Writer finished{label}: total_inserted={total_inserted:,} (comments={total_comments:,}, submissions={total_submissions:,}) in {elapsed:,.1f}s"
        if logging_queue is not None:
            try:
                logging_queue.put(message)
            except Exception:
                pass
        else:
            log.info(message)


def parse_zst_chunk_worker(args):
    """Parser worker: reads a chunk of a zst file and sends tuples to the writer via queue."""
    (
        input_path,
        is_submission,
        max_lines,
        start_line,
        queue,
        checkpoint_interval,
        batch_size,
        normalized_subreddit,
    ) = args

    comment_batch = []
    submission_batch = []
    last_checkpoint = 0
    sent = 0

    try:
        lines_processed = 0
        for line, _ in read_lines_zst(input_path, max_lines, start_line):
            if not line:
                continue
            lines_processed += 1
            try:
                obj = json.loads(line)
                if not row_matches_subreddit_filter(obj, normalized_subreddit):
                    continue
                if is_submission:
                    submission_batch.append(process_submission(obj))
                    if len(submission_batch) >= batch_size:
                        queue.put(('s', submission_batch))
                        sent += len(submission_batch)
                        submission_batch = []
                else:
                    comment_batch.append(process_comment(obj))
                    if len(comment_batch) >= batch_size:
                        queue.put(('c', comment_batch))
                        sent += len(comment_batch)
                        comment_batch = []
                if checkpoint_interval and (lines_processed - last_checkpoint) >= checkpoint_interval:
                    last_checkpoint = lines_processed
            except (json.JSONDecodeError, KeyError, ValueError, TypeError):
                # Skip bad line; raw_json is for errors only in main path
                continue
    except KeyboardInterrupt:
        # Flush current batches before exiting
        if comment_batch:
            queue.put(('c', comment_batch))
        if submission_batch:
            queue.put(('s', submission_batch))
        return sent
    except Exception:
        # On error, flush and exit
        if comment_batch:
            queue.put(('c', comment_batch))
        if submission_batch:
            queue.put(('s', submission_batch))
        return sent

    # Flush remaining
    if comment_batch:
        queue.put(('c', comment_batch))
    if submission_batch:
        queue.put(('s', submission_batch))

    return sent


def process_zst_file_worker(args):
    """Worker function for multiprocessing - processes a single .zst file chunk."""
    (
        input_path,
        is_submission,
        max_lines,
        start_line,
        temp_db_path,
        checkpoint_interval,
        worker_id,
        normalized_subreddit,
    ) = args

    conn = sqlite3.connect(temp_db_path)
    cursor = conn.cursor()
    
    create_database_schema(cursor)
    
    file_lines = 0
    bad_lines = 0
    created = None
    last_checkpoint = 0
    
    batch_size = 1000
    comment_batch = []
    submission_batch = []
    
    worker_checkpoint_file = f"{temp_db_path}.worker_{worker_id}.checkpoint"
    
    try:
        lines_processed = 0
        for line, file_bytes_processed in read_lines_zst(input_path, max_lines, start_line):
            if not line:
                continue
            
            lines_processed += 1
            if lines_processed <= 5:
                log.debug(f"Worker {worker_id} processing line {lines_processed}: {line[:100]}...")
                
            try:
                obj = json.loads(line)
                if not row_matches_subreddit_filter(obj, normalized_subreddit):
                    continue
                created = datetime.fromtimestamp(int(obj.get('created_utc', 0)), tz=timezone.utc)
                
                if is_submission:
                    submission_batch.append(process_submission(obj))
                    if len(submission_batch) >= batch_size:
                        cursor.executemany(
                            """INSERT OR REPLACE INTO submissions 
                               (id, author, subreddit, title, selftext, url, score, created_utc, 
                                permalink, is_self, over_18, spoiler, locked, stickied, distinguished, 
                                edited, num_comments, upvote_ratio, retrieved_on, raw_json)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            submission_batch
                        )
                        submission_batch = []
                else:
                    comment_batch.append(process_comment(obj))
                    if len(comment_batch) >= batch_size:
                        cursor.executemany(
                            """INSERT OR REPLACE INTO comments 
                               (id, author, subreddit, body, score, created_utc, parent_id, link_id, 
                                permalink, is_submitter, controversiality, gilded, archived, locked, 
                                stickied, distinguished, edited, retrieved_on, raw_json)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            comment_batch
                        )
                        comment_batch = []
                
                file_lines += 1
                
                if checkpoint_interval > 0 and file_lines - last_checkpoint >= checkpoint_interval:
                    conn.commit()
                    last_checkpoint = file_lines
                    
                    worker_checkpoint = {
                        'worker_id': worker_id,
                        'file_path': input_path,
                        'start_line': start_line,
                        'lines_processed': file_lines,
                        'bad_lines': bad_lines,
                        'temp_db_path': temp_db_path,
                        'timestamp': time.time()
                    }
                    save_checkpoint(worker_checkpoint_file, worker_checkpoint)
                    log.debug(f"Worker {worker_id} checkpoint: {file_lines:,} lines processed")
                    
            except json.JSONDecodeError as e:
                bad_lines += 1
            except (KeyError, ValueError, TypeError) as e:
                bad_lines += 1
    
    except KeyboardInterrupt:
        conn.commit()
        worker_checkpoint = {
            'worker_id': worker_id,
            'file_path': input_path,
            'start_line': start_line,
            'lines_processed': file_lines,
            'bad_lines': bad_lines,
            'temp_db_path': temp_db_path,
            'timestamp': time.time(),
            'interrupted': True
        }
        save_checkpoint(worker_checkpoint_file, worker_checkpoint)
        log.info(f"Worker {worker_id} interrupted, saved {file_lines:,} lines to checkpoint")
        conn.close()
        return file_lines, bad_lines
    except Exception as e:
        log.error(f"Error processing file {input_path}: {e}")
        raise
    
    if comment_batch:
        cursor.executemany(
            """INSERT OR REPLACE INTO comments 
               (id, author, subreddit, body, score, created_utc, parent_id, link_id, 
                permalink, is_submitter, controversiality, gilded, archived, locked, 
                stickied, distinguished, edited, retrieved_on, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            comment_batch
        )
    
    if submission_batch:
        cursor.executemany(
            """INSERT OR REPLACE INTO submissions 
               (id, author, subreddit, title, selftext, url, score, created_utc, 
                permalink, is_self, over_18, spoiler, locked, stickied, distinguished, 
                edited, num_comments, upvote_ratio, retrieved_on, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            submission_batch
        )
    
    conn.commit()
    conn.close()
    
    if os.path.exists(worker_checkpoint_file):
        os.unlink(worker_checkpoint_file)
    
    return file_lines, bad_lines


def process_zst_file(
    input_path: str,
    conn: sqlite3.Connection,
    is_submission: bool,
    max_lines=None,
    normalized_subreddit: Optional[str] = None,
):
    """Process a single .zst file and insert data into SQLite."""
    log.info(f"Processing {input_path} ({'submissions' if is_submission else 'comments'})")
    if max_lines:
        log.info(f"Test mode: Processing only first {max_lines:,} lines")
    
    file_size = os.stat(input_path).st_size
    file_lines = 0
    bad_lines = 0
    created = None
    
    cursor = conn.cursor()
    
    batch_size = 1000
    comment_batch = []
    submission_batch = []
    
    try:
        lines_processed = 0
        for line, file_bytes_processed in read_lines_zst(input_path, max_lines):
            if not line:
                continue
            
            lines_processed += 1
            if lines_processed <= 5:
                log.debug(f"Processing line {lines_processed}: {line[:100]}...")
                
            try:
                obj = json.loads(line)
                if not row_matches_subreddit_filter(obj, normalized_subreddit):
                    continue
                created = datetime.fromtimestamp(int(obj.get('created_utc', 0)), tz=timezone.utc)
                
                if is_submission:
                    submission_batch.append(process_submission(obj))
                    if len(submission_batch) >= batch_size:
                        cursor.executemany(
                            """INSERT OR REPLACE INTO submissions 
                               (id, author, subreddit, title, selftext, url, score, created_utc, 
                                permalink, is_self, over_18, spoiler, locked, stickied, distinguished, 
                                edited, num_comments, upvote_ratio, retrieved_on, raw_json)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            submission_batch
                        )
                        log.debug(f"Inserted {len(submission_batch)} submissions into database")
                        submission_batch = []
                else:
                    comment_batch.append(process_comment(obj))
                    if len(comment_batch) >= batch_size:
                        cursor.executemany(
                            """INSERT OR REPLACE INTO comments 
                               (id, author, subreddit, body, score, created_utc, parent_id, link_id, 
                                permalink, is_submitter, controversiality, gilded, archived, locked, 
                                stickied, distinguished, edited, retrieved_on, raw_json)
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                            comment_batch
                        )
                        log.debug(f"Inserted {len(comment_batch)} comments into database")
                        comment_batch = []
                
                file_lines += 1
                
                if file_lines % 100000 == 0:
                    log.info(f"{created.strftime('%Y-%m-%d %H:%M:%S')} : {file_lines:,} : {bad_lines:,} : {(file_bytes_processed / file_size) * 100:.0f}%")
                elif file_lines <= 10:
                    log.debug(f"Successfully processed line {file_lines}")
                    
            except json.JSONDecodeError as e:
                bad_lines += 1
                if bad_lines <= 5:
                    log.warning(f"JSON decode error on line {lines_processed}: {e}")
                    log.warning(f"Problematic line: {line[:200]}...")
            except (KeyError, ValueError, TypeError) as e:
                bad_lines += 1
                if bad_lines <= 5:
                    log.warning(f"Error processing line {lines_processed}: {e}")
                    log.warning(f"Problematic line: {line[:200]}...")
    
    except Exception as e:
        log.error(f"Error processing file {input_path}: {e}")
        import traceback
        log.error(f"Full traceback: {traceback.format_exc()}")
        raise
    
    if comment_batch:
        log.debug(f"Inserting final batch of {len(comment_batch)} comments")
        cursor.executemany(
            """INSERT OR REPLACE INTO comments 
               (id, author, subreddit, body, score, created_utc, parent_id, link_id, 
                permalink, is_submitter, controversiality, gilded, archived, locked, 
                stickied, distinguished, edited, retrieved_on, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            comment_batch
        )
        log.debug(f"Successfully inserted final {len(comment_batch)} comments")
    
    if submission_batch:
        log.debug(f"Inserting final batch of {len(submission_batch)} submissions")
        cursor.executemany(
            """INSERT OR REPLACE INTO submissions 
               (id, author, subreddit, title, selftext, url, score, created_utc, 
                permalink, is_self, over_18, spoiler, locked, stickied, distinguished, 
                edited, num_comments, upvote_ratio, retrieved_on, raw_json)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            submission_batch
        )
        log.debug(f"Successfully inserted final {len(submission_batch)} submissions")
    
    conn.commit()
    log.info(f"Completed {input_path}: {file_lines:,} lines, {bad_lines:,} bad lines")
    return file_lines, bad_lines


def process_month_folder_multiprocess(
    month_folder_path: str,
    database_path: str,
    test_mode=False,
    test_lines=1000,
    num_processes=None,
    resume=False,
    checkpoint_interval=50000,
    normalized_subreddit: Optional[str] = None,
):
    """Process all .zst files in a month folder using multiprocessing for speed."""
    if not os.path.exists(month_folder_path):
        log.error(f"Month folder does not exist: {month_folder_path}")
        return False
    
    signal.signal(signal.SIGINT, signal_handler)
    
    global interrupt_requested
    interrupt_requested = False
    
    checkpoint_file = f"{database_path}.checkpoint"
    
    if num_processes is None:
        num_processes = min(mp.cpu_count(), 4)
    
    log.info(f"Using {num_processes} processes for parallel processing")
    log.info(f"Checkpoint interval: {checkpoint_interval:,} lines")
    if normalized_subreddit:
        log.info(
            f"Subreddit filter: only rows with subreddit={normalized_subreddit!r} are written "
            "(full .zst files are still scanned)"
        )
    
    zst_files_found = []
    for root, dirs, files in os.walk(month_folder_path):
        for file in files:
            if file.endswith('.zst'):
                input_path = os.path.join(root, file)
                is_submission = file.startswith('RS_') or 'submission' in root.lower()
                zst_files_found.append((input_path, file, root, is_submission))
    
    log.info(f"Found {len(zst_files_found)} .zst files in {month_folder_path}")
    
    if not zst_files_found:
        log.error("No .zst files found in the specified folder!")
        return False
    
    progress_data = None
    if resume:
        progress_data = load_checkpoint(checkpoint_file)
        if progress_data:
            log.info("Resuming from checkpoint...")
            log.info(f"Previously processed: {progress_data.get('files_processed', 0)} files")
            log.info(f"Previously processed lines: {progress_data.get('total_lines', 0):,}")
        else:
            log.info("No checkpoint found, starting fresh")
    
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()
    create_database_schema(cursor, create_indexes=False)
    conn.close()
    
    total_files = progress_data.get('files_processed', 0) if progress_data else 0
    total_lines = progress_data.get('total_lines', 0) if progress_data else 0
    total_bad_lines = progress_data.get('total_bad_lines', 0) if progress_data else 0
    start_file_index = progress_data.get('current_file_index', 0) if progress_data else 0
    
    log.info(f"Starting from file index {start_file_index}")
    
    try:
        for file_index, (input_path, file, root, is_submission) in enumerate(zst_files_found[start_file_index:], start_file_index):
            if interrupt_requested:
                log.info("Stopping processing due to interrupt signal")
                break
                
            log.info(f"Processing {file} ({'submission' if is_submission else 'comment'}) with multiprocessing")
            
            if interrupt_requested:
                log.info("Interrupt detected before starting workers")
                break

            # For large files, split into chunks for parallel parsing
            if not test_mode:
                estimated_lines = get_file_line_count(input_path)
                chunk_size = max(100000, estimated_lines // num_processes)  # At least 100k lines per chunk
                log.info(f"Estimated {estimated_lines:,} lines, using chunk size of {chunk_size:,}")
            else:
                chunk_size = test_lines
                num_processes = 1

            batch_size = 1000
            manager = Manager()
            q = manager.Queue(maxsize=10)
            log_q = manager.Queue(maxsize=50)
            estimated_lines = get_file_line_count(input_path) if not test_mode else test_lines
            
            writer = Process(target=writer_process, args=(database_path, q), kwargs={
                'progress': True,
                'progress_interval': 5.0,  # Show progress every 5 seconds
                'file_label': file,
                'logging_queue': log_q,
                'estimated_total': estimated_lines
            })
            writer.start()
            
            if interrupt_requested:
                log.info("Interrupt detected after starting writer, stopping...")
                try:
                    q.put("__STOP__")
                except:
                    pass
                writer.join(timeout=5)
                if writer.is_alive():
                    writer.terminate()
                break

            # Start a lightweight log forwarder thread in the parent to print messages from child
            stop_log_forwarder: Event = Event()
            def _forward_logs():
                while not stop_log_forwarder.is_set():
                    try:
                        msg = log_q.get(timeout=0.5)
                        print(f"[WRITER] {msg}", flush=True)
                    except Exception:
                        pass
            log_forwarder = Thread(target=_forward_logs, daemon=True)
            log_forwarder.start()
            
            log.info(f"Starting processing of {file} with {num_processes} workers...")

            worker_args = []
            for i in range(num_processes):
                start_line = i * chunk_size
                worker_args.append(
                    (
                        input_path,
                        is_submission,
                        # Last worker takes the remainder (lines // num_processes drops up to N-1 lines otherwise)
                        test_lines if test_mode else (None if i == num_processes - 1 else chunk_size),
                        start_line,
                        q,
                        min(checkpoint_interval, 100000),
                        batch_size,
                        normalized_subreddit,
                    )
                )

            if interrupt_requested:
                log.info("Interrupt detected before starting workers, stopping...")
                try:
                    q.put("__STOP__")
                except:
                    pass
                writer.join(timeout=5)
                if writer.is_alive():
                    writer.terminate()
                break
                
            start_time = time.time()
            try:
                with Pool(processes=num_processes) as pool:
                    async_result = pool.map_async(parse_zst_chunk_worker, worker_args)
                    
                    check_count = 0
                    while not async_result.ready():
                        if interrupt_requested:
                            log.info("Interrupt detected, terminating workers...")
                            pool.terminate()
                            log.info("Pool terminated, waiting for workers to exit...")
                            pool.join(timeout=5)
                            log.info("Workers should be stopped now")
                            break
                        check_count += 1
                        if check_count % 50 == 0:  # Log every 5 seconds (50 * 0.1s)
                            log.info(f"Still waiting for workers to complete... (checked {check_count} times)")
                        time.sleep(0.1)
                    
                    if not interrupt_requested:
                        results = async_result.get(timeout=1)
                    else:
                        results = []
                log.info("Signaling writer to stop...")
                try:
                    q.put("__STOP__")
                    log.info("Stop signal sent to writer")
                except Exception as e:
                    log.warning(f"Failed to signal writer: {e}")
                
                log.info("Waiting for writer to exit...")
                writer.join(timeout=10)
                if writer.is_alive():
                    log.warning("Writer did not exit cleanly; terminating")
                    writer.terminate()
                    log.info("Writer terminated, waiting for exit...")
                    writer.join(timeout=3)
                    if writer.is_alive():
                        log.warning("Force killing writer process")
                        writer.kill()
                        log.info("Writer force killed")
                else:
                    log.info("Writer exited cleanly")
                stop_log_forwarder.set()
                log_forwarder.join(timeout=2)
                log.info(f"Processing completed in {time.time() - start_time:.1f} seconds")
            except KeyboardInterrupt:
                log.info("Processing interrupted, stopping all processes...")
                interrupt_requested = True
                try:
                    q.put("__STOP__")
                    log.info("Stop signal sent to writer")
                except Exception as e:
                    log.warning(f"Failed to signal writer: {e}")
                
                log.info("Force terminating worker pool...")
                try:
                    pool.terminate()
                    pool.join(timeout=2)
                    log.info("Worker pool terminated")
                except Exception as e:
                    log.warning(f"Error terminating pool: {e}")
                
                log.info("Waiting for writer to exit...")
                writer.join(timeout=10)
                if writer.is_alive():
                    log.warning("Force terminating writer")
                    writer.terminate()
                    writer.join(timeout=3)
                    if writer.is_alive():
                        log.warning("Force killing writer")
                        writer.kill()
                else:
                    log.info("Writer exited cleanly")
                
                log.info("Stopping log forwarder...")
                stop_log_forwarder.set()
                log_forwarder.join(timeout=2)
                log.info("Log forwarder stopped")
                
                checkpoint_data = {
                    'current_file_index': file_index,
                    'files_processed': total_files,
                    'total_lines': total_lines,
                    'total_bad_lines': total_bad_lines,
                    'database_path': database_path,
                    'timestamp': time.time(),
                    'last_processed_file': file,
                    'interrupted': True
                }
                save_checkpoint(checkpoint_file, checkpoint_data)
                log.info(f"Checkpoint saved. To resume: python zst_to_sqlite.py {month_folder_path} {database_path} --resume")
                return False

            lines_from_workers = sum(results) if results else 0
            total_lines += lines_from_workers
            total_files += 1

            checkpoint_data = {
                'current_file_index': file_index + 1,
                'files_processed': total_files,
                'total_lines': total_lines,
                'total_bad_lines': total_bad_lines,
                'database_path': database_path,
                'timestamp': time.time(),
                'last_processed_file': file
            }
            save_checkpoint(checkpoint_file, checkpoint_data)
            log.info(f"Checkpoint saved: {total_files} files, {total_lines:,} lines processed")

            if test_mode:
                main_conn = sqlite3.connect(database_path)
                cursor = main_conn.cursor()
                cursor.execute("SELECT COUNT(*) FROM comments")
                comment_count = cursor.fetchone()[0]
                cursor.execute("SELECT COUNT(*) FROM submissions")
                submission_count = cursor.fetchone()[0]
                main_conn.close()

                if comment_count > 0 and submission_count > 0:
                    log.info("Test mode: Found both comments and submissions, stopping")
                    break
                elif total_files >= 2:
                    log.info("Test mode: Tried 2 files, stopping")
                    break

    except KeyboardInterrupt:
        log.info("\nProcessing interrupted by user. Progress saved to checkpoint.")
        log.info(f"To resume: python zst_to_sqlite.py {month_folder_path} {database_path} --resume")
        return False
    except Exception as e:
        log.error(f"Error during processing: {e}")
        return False
    finally:
        try:
            if 'writer' in locals() and writer.is_alive():
                writer.terminate()
                writer.join(timeout=2)
        except:
            pass
        try:
            if 'stop_log_forwarder' in locals():
                stop_log_forwarder.set()
        except:
            pass
    
    # After all files processed: create indexes (deferred) and collect stats
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()
    try:
        for index_sql in get_schema_indexes():
            cursor.execute(index_sql)
        conn.commit()
        log.info("Deferred indexes created")
    except Exception as e:
        log.warning(f"Index creation issue: {e}")

    cursor.execute("SELECT COUNT(*) FROM comments")
    comment_count = cursor.fetchone()[0]
    cursor.execute("SELECT COUNT(*) FROM submissions")
    submission_count = cursor.fetchone()[0]
    conn.close()
    
    log.info(f"Processing complete:")
    log.info(f"  Files processed: {total_files}")
    log.info(f"  Total lines: {total_lines:,}")
    log.info(f"  Bad lines: {total_bad_lines:,}")
    log.info(f"  Comments in database: {comment_count:,}")
    log.info(f"  Submissions in database: {submission_count:,}")
    log.info(f"  Database file: {database_path}")
    
    cleanup_checkpoint(checkpoint_file)
    
    return True


def process_month_folder(
    month_folder_path: str,
    database_path: str,
    test_mode=False,
    test_lines=1000,
    normalized_subreddit: Optional[str] = None,
):
    """Process all .zst files in a month folder and create SQLite database."""
    if not os.path.exists(month_folder_path):
        log.error(f"Month folder does not exist: {month_folder_path}")
        return False
    
    if normalized_subreddit:
        log.info(
            f"Subreddit filter: only rows with subreddit={normalized_subreddit!r} are written "
            "(full .zst files are still scanned)"
        )

    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()
    
    create_database_schema(cursor)
    
    total_files = 0
    total_lines = 0
    total_bad_lines = 0
    zst_files_found = []
    
    for root, dirs, files in os.walk(month_folder_path):
        for file in files:
            if file.endswith('.zst'):
                input_path = os.path.join(root, file)
                zst_files_found.append((input_path, file, root))
    
    log.info(f"Found {len(zst_files_found)} .zst files in {month_folder_path}")
    
    if not zst_files_found:
        log.error("No .zst files found in the specified folder!")
        return False
    
    for input_path, file, root in zst_files_found:
        is_submission = file.startswith('RS_') or 'submission' in root.lower()
        log.info(f"Processing file: {file} (type: {'submission' if is_submission else 'comment'})")
        
        try:
            max_lines = test_lines if test_mode else None
            lines, bad_lines = process_zst_file(
                input_path,
                conn,
                is_submission,
                max_lines,
                normalized_subreddit=normalized_subreddit,
            )
            total_files += 1
            total_lines += lines
            total_bad_lines += bad_lines
            
            log.info(f"Successfully processed {file}: {lines:,} lines, {bad_lines:,} bad lines")
            
            if test_mode:
                log.info(f"Test mode: Processed {file} ({'submission' if is_submission else 'comment'})")
                
        except Exception as e:
            log.error(f"Failed to process {input_path}: {e}")
            import traceback
            log.error(f"Full error: {traceback.format_exc()}")
        
        if test_mode:
            cursor.execute("SELECT COUNT(*) FROM comments")
            comment_count = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM submissions")
            submission_count = cursor.fetchone()[0]
            
            if comment_count > 0 and submission_count > 0:
                log.info("Test mode: Found both comments and submissions, stopping")
                break
            elif total_files >= 2:
                log.info("Test mode: Tried 2 files, stopping")
                break
    
    cursor.execute("SELECT COUNT(*) FROM comments")
    comment_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM submissions")
    submission_count = cursor.fetchone()[0]
    
    conn.close()
    
    log.info(f"Processing complete:")
    log.info(f"  Files processed: {total_files}")
    log.info(f"  Total lines: {total_lines:,}")
    log.info(f"  Bad lines: {total_bad_lines:,}")
    log.info(f"  Comments in database: {comment_count:,}")
    log.info(f"  Submissions in database: {submission_count:,}")
    log.info(f"  Database file: {database_path}")
    
    return True


def test_database_creation(
    month_folder_path: str,
    test_database_path: str = "test_reddit.db",
    test_lines: int = 1000,
    normalized_subreddit: Optional[str] = None,
):
    """Quick test function to verify database creation works correctly."""
    log.info("=" * 60)
    log.info("TESTING DATABASE CREATION")
    log.info("=" * 60)
    log.info(f"Test database: {test_database_path}")
    log.info(f"Processing first {test_lines:,} lines from one file")
    if normalized_subreddit:
        log.info(
            f"With subreddit filter {normalized_subreddit!r}: increase --test-lines if the sample has no matching rows"
        )

    success = process_month_folder(
        month_folder_path,
        test_database_path,
        test_mode=True,
        test_lines=test_lines,
        normalized_subreddit=normalized_subreddit,
    )
    
    if success:
        log.info("=" * 60)
        log.info("TEST RESULTS:")
        log.info("=" * 60)
        
        conn = sqlite3.connect(test_database_path)
        cursor = conn.cursor()
        
        cursor.execute("SELECT id, author, subreddit, body, score, created_utc FROM comments LIMIT 5")
        comments = cursor.fetchall()
        
        log.info("Sample comments:")
        for comment in comments:
            created = datetime.fromtimestamp(comment[5], tz=timezone.utc)
            body_preview = comment[3][:50] + "..." if len(comment[3]) > 50 else comment[3]
            log.info(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{comment[2]} | u/{comment[1]} | Score: {comment[4]} | {body_preview}")
        
        cursor.execute("SELECT id, author, subreddit, title, score, created_utc FROM submissions LIMIT 5")
        submissions = cursor.fetchall()
        
        log.info("\nSample submissions:")
        for submission in submissions:
            created = datetime.fromtimestamp(submission[5], tz=timezone.utc)
            title_preview = submission[3][:50] + "..." if len(submission[3]) > 50 else submission[3]
            log.info(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{submission[2]} | u/{submission[1]} | Score: {submission[4]} | {title_preview}")
        
        db_size = os.path.getsize(test_database_path)
        log.info(f"\nTest database size: {db_size / (1024*1024):.2f} MB")
        
        conn.close()
        
        log.info("=" * 60)
        log.info("TEST COMPLETED SUCCESSFULLY!")
        log.info("You can now inspect the test database or run the full conversion.")
        log.info("=" * 60)
    
    return success


def main():
    parser = argparse.ArgumentParser(description="Convert PushShift .zst files to SQLite database")
    parser.add_argument("month_folder", help="Path to the month folder (e.g., '2025-06' or '/path/to/2025-06')")
    parser.add_argument("database_path", nargs='?', help="Path for SQLite database file (default: reddit_data.db)")
    parser.add_argument("--test", help="Run test mode with first 1000 lines only", action='store_true')
    parser.add_argument("--test-lines", type=int, default=1000, help="Number of lines to process in test mode (default: 1000)")
    parser.add_argument("--processes", type=int, help="Number of processes to use for parallel processing (default: auto)")
    parser.add_argument("--no-multiprocess", help="Disable multiprocessing (use single-threaded mode)", action='store_true')
    parser.add_argument("--resume", help="Resume processing from checkpoint", action='store_true')
    parser.add_argument("--checkpoint-interval", type=int, default=50000, help="Checkpoint interval in lines (default: 50000)")
    parser.add_argument(
        "--subreddit",
        type=str,
        default=None,
        help="Only store comments/submissions for this subreddit (case-insensitive). "
        "Scans entire monthly .zst files but writes a small DB.",
    )
    parser.add_argument("--debug", help="Enable debug logging", action='store_true')
    
    args = parser.parse_args()
    
    if args.debug:
        log.setLevel(logging.DEBUG)

    normalized_subreddit = normalize_subreddit_filter(args.subreddit)
    
    if not args.database_path:
        database_path = "test_reddit.db" if args.test else "reddit_data.db"
    else:
        database_path = args.database_path
    
    month_folder_path = args.month_folder
    if not os.path.isabs(month_folder_path):
        month_folder_path = os.path.abspath(month_folder_path)
    
    if args.test:
        log.info(f"TEST MODE: Converting first {args.test_lines:,} lines from {month_folder_path}")
        success = test_database_creation(
            month_folder_path,
            database_path,
            args.test_lines,
            normalized_subreddit=normalized_subreddit,
        )
    else:
        log.info(f"Converting {month_folder_path} to SQLite database: {database_path}")
        
        if args.no_multiprocess:
            log.info("Using single-threaded processing")
            success = process_month_folder(
                month_folder_path,
                database_path,
                normalized_subreddit=normalized_subreddit,
            )
        else:
            log.info("Using multiprocessing for faster conversion")
            success = process_month_folder_multiprocess(
                month_folder_path,
                database_path,
                num_processes=args.processes,
                resume=args.resume,
                checkpoint_interval=args.checkpoint_interval,
                normalized_subreddit=normalized_subreddit,
            )
    
    if success:
        if args.test:
            log.info("Test completed successfully!")
            log.info(f"Test database created at: {os.path.abspath(database_path)}")
            log.info("You can inspect the test database or run without --test for full conversion")
        else:
            log.info("Conversion completed successfully!")
            log.info(f"Database created at: {os.path.abspath(database_path)}")
    else:
        log.error("Conversion failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()
