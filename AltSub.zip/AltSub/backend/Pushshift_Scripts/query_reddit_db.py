#!/usr/bin/env python3
"""
Script showing how to query the Reddit SQLite database.
Demonstrates common search patterns and queries for reference.

Usage:
    python query_reddit_db.py <database_path>
    
Example:
    python query_reddit_db.py reddit_data.db
"""

import sqlite3
import sys
from datetime import datetime, timedelta
import argparse


def connect_to_database(db_path):
    """Connect to the SQLite database."""
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        return conn
    except sqlite3.Error as e:
        print(f"Error connecting to database: {e}")
        return None


def get_database_stats(conn):
    """Get basic statistics about the database."""
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM comments")
    comment_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM submissions")
    submission_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT MIN(created_utc), MAX(created_utc) FROM comments")
    comment_dates = cursor.fetchone()
    
    cursor.execute("SELECT MIN(created_utc), MAX(created_utc) FROM submissions")
    submission_dates = cursor.fetchone()
    
    print(f"Database Statistics:")
    print(f"  Comments: {comment_count:,}")
    print(f"  Submissions: {submission_count:,}")
    print(f"  Total records: {comment_count + submission_count:,}")
    
    if comment_dates[0]:
        print(f"  Comment date range: {datetime.fromtimestamp(comment_dates[0])} to {datetime.fromtimestamp(comment_dates[1])}")
    
    if submission_dates[0]:
        print(f"  Submission date range: {datetime.fromtimestamp(submission_dates[0])} to {datetime.fromtimestamp(submission_dates[1])}")


def search_by_subreddit(conn, subreddit, limit=10):
    """Search for posts and comments from a specific subreddit."""
    cursor = conn.cursor()
    
    print(f"\nSearching for r/{subreddit}:")
    
    cursor.execute("""
        SELECT title, author, score, created_utc, permalink
        FROM submissions 
        WHERE subreddit = ? 
        ORDER BY created_utc DESC 
        LIMIT ?
    """, (subreddit, limit))
    
    submissions = cursor.fetchall()
    print(f"\nRecent submissions in r/{subreddit}:")
    for row in submissions:
        created = datetime.fromtimestamp(row['created_utc'])
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | {row['author']} | Score: {row['score']} | {row['title'][:80]}...")
    
    cursor.execute("""
        SELECT body, author, score, created_utc, permalink
        FROM comments 
        WHERE subreddit = ? 
        ORDER BY created_utc DESC 
        LIMIT ?
    """, (subreddit, limit))
    
    comments = cursor.fetchall()
    print(f"\nRecent comments in r/{subreddit}:")
    for row in comments:
        created = datetime.fromtimestamp(row['created_utc'])
        body_preview = row['body'][:60].replace('\n', ' ') if row['body'] else "[deleted]"
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | {row['author']} | Score: {row['score']} | {body_preview}...")


def search_by_author(conn, author, limit=10):
    """Search for posts and comments by a specific author."""
    cursor = conn.cursor()
    
    print(f"\nSearching for u/{author}:")
    
    cursor.execute("""
        SELECT title, subreddit, score, created_utc, permalink
        FROM submissions 
        WHERE author = ? 
        ORDER BY created_utc DESC 
        LIMIT ?
    """, (author, limit))
    
    submissions = cursor.fetchall()
    print(f"\nSubmissions by u/{author}:")
    for row in submissions:
        created = datetime.fromtimestamp(row['created_utc'])
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{row['subreddit']} | Score: {row['score']} | {row['title'][:80]}...")
    
    cursor.execute("""
        SELECT body, subreddit, score, created_utc, permalink
        FROM comments 
        WHERE author = ? 
        ORDER BY created_utc DESC 
        LIMIT ?
    """, (author, limit))
    
    comments = cursor.fetchall()
    print(f"\nComments by u/{author}:")
    for row in comments:
        created = datetime.fromtimestamp(row['created_utc'])
        body_preview = row['body'][:60].replace('\n', ' ') if row['body'] else "[deleted]"
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{row['subreddit']} | Score: {row['score']} | {body_preview}...")


def search_by_keywords(conn, keywords, limit=10):
    """Search for posts containing specific keywords."""
    cursor = conn.cursor()
    
    print(f"\nSearching for keywords: {keywords}")
    
    keyword_conditions = " OR ".join(["title LIKE ? OR selftext LIKE ?" for _ in keywords])
    params = []
    for keyword in keywords:
        params.extend([f"%{keyword}%", f"%{keyword}%"])
    params.append(limit)
    
    cursor.execute(f"""
        SELECT title, author, subreddit, score, created_utc, permalink
        FROM submissions 
        WHERE {keyword_conditions}
        ORDER BY created_utc DESC 
        LIMIT ?
    """, params)
    
    submissions = cursor.fetchall()
    print(f"\nSubmissions containing keywords:")
    for row in submissions:
        created = datetime.fromtimestamp(row['created_utc'])
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{row['subreddit']} | {row['author']} | Score: {row['score']} | {row['title'][:80]}...")
    
    keyword_conditions = " OR ".join(["body LIKE ?" for _ in keywords])
    params = []
    for keyword in keywords:
        params.append(f"%{keyword}%")
    params.append(limit)
    
    cursor.execute(f"""
        SELECT body, author, subreddit, score, created_utc, permalink
        FROM comments 
        WHERE {keyword_conditions}
        ORDER BY created_utc DESC 
        LIMIT ?
    """, params)
    
    comments = cursor.fetchall()
    print(f"\nComments containing keywords:")
    for row in comments:
        created = datetime.fromtimestamp(row['created_utc'])
        body_preview = row['body'][:60].replace('\n', ' ') if row['body'] else "[deleted]"
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{row['subreddit']} | {row['author']} | Score: {row['score']} | {body_preview}...")


def get_top_subreddits(conn, limit=20):
    """Get the most active subreddits by post count."""
    cursor = conn.cursor()
    
    print(f"\nTop {limit} most active subreddits:")
    
    cursor.execute("""
        SELECT subreddit, COUNT(*) as post_count
        FROM (
            SELECT subreddit FROM submissions
            UNION ALL
            SELECT subreddit FROM comments
        )
        GROUP BY subreddit
        ORDER BY post_count DESC
        LIMIT ?
    """, (limit,))
    
    results = cursor.fetchall()
    for i, row in enumerate(results, 1):
        print(f"  {i:2d}. r/{row['subreddit']:<25} {row['post_count']:,} posts")


def get_top_authors(conn, limit=20):
    """Get the most active authors by post count."""
    cursor = conn.cursor()
    
    print(f"\nTop {limit} most active authors:")
    
    cursor.execute("""
        SELECT author, COUNT(*) as post_count
        FROM (
            SELECT author FROM submissions WHERE author != '[deleted]'
            UNION ALL
            SELECT author FROM comments WHERE author != '[deleted]'
        )
        GROUP BY author
        ORDER BY post_count DESC
        LIMIT ?
    """, (limit,))
    
    results = cursor.fetchall()
    for i, row in enumerate(results, 1):
        print(f"  {i:2d}. u/{row['author']:<25} {row['post_count']:,} posts")


def search_by_date_range(conn, start_date, end_date, limit=10):
    """Search for posts within a date range."""
    cursor = conn.cursor()
    
    start_timestamp = int(start_date.timestamp())
    end_timestamp = int(end_date.timestamp())
    
    print(f"\nPosts from {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}:")
    
    cursor.execute("""
        SELECT title, author, subreddit, score, created_utc, permalink
        FROM submissions 
        WHERE created_utc >= ? AND created_utc <= ?
        ORDER BY created_utc DESC 
        LIMIT ?
    """, (start_timestamp, end_timestamp, limit))
    
    submissions = cursor.fetchall()
    print(f"\nSubmissions in date range:")
    for row in submissions:
        created = datetime.fromtimestamp(row['created_utc'])
        print(f"  {created.strftime('%Y-%m-%d %H:%M')} | r/{row['subreddit']} | {row['author']} | Score: {row['score']} | {row['title'][:80]}...")


def main():
    parser = argparse.ArgumentParser(description="Query Reddit SQLite database")
    parser.add_argument("database_path", help="Path to SQLite database file")
    parser.add_argument("--subreddit", help="Search by subreddit")
    parser.add_argument("--author", help="Search by author")
    parser.add_argument("--keywords", nargs='+', help="Search by keywords")
    parser.add_argument("--top-subreddits", type=int, help="Show top N subreddits")
    parser.add_argument("--top-authors", type=int, help="Show top N authors")
    parser.add_argument("--date-range", nargs=2, help="Search by date range (YYYY-MM-DD YYYY-MM-DD)")
    parser.add_argument("--limit", type=int, default=10, help="Limit number of results")
    
    args = parser.parse_args()
    
    conn = connect_to_database(args.database_path)
    if not conn:
        sys.exit(1)
    
    try:
        get_database_stats(conn)
        
        if args.subreddit:
            search_by_subreddit(conn, args.subreddit, args.limit)
        
        if args.author:
            search_by_author(conn, args.author, args.limit)
        
        if args.keywords:
            search_by_keywords(conn, args.keywords, args.limit)
        
        if args.top_subreddits:
            get_top_subreddits(conn, args.top_subreddits)
        
        if args.top_authors:
            get_top_authors(conn, args.top_authors)
        
        if args.date_range:
            start_date = datetime.strptime(args.date_range[0], '%Y-%m-%d')
            end_date = datetime.strptime(args.date_range[1], '%Y-%m-%d')
            search_by_date_range(conn, start_date, end_date, args.limit)
        
        if not any([args.subreddit, args.author, args.keywords, args.top_subreddits, args.top_authors, args.date_range]):
            print("\nExample queries:")
            print("  python query_reddit_db.py reddit_data.db --subreddit python")
            print("  python query_reddit_db.py reddit_data.db --author someuser")
            print("  python query_reddit_db.py reddit_data.db --keywords 'machine learning'")
            print("  python query_reddit_db.py reddit_data.db --top-subreddits 10")
            print("  python query_reddit_db.py reddit_data.db --date-range 2025-01-01 2025-01-31")
    
    finally:
        conn.close()


if __name__ == "__main__":
    main()
