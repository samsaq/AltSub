#!/usr/bin/env python3
"""
Fast pre-filter: stream Pushshift monthly .zst dumps and keep only lines for one subreddit,
writing them to small .zst files with the same folder layout. No JSON parsing, no text decoding:
lines are located with a raw byte search for  "subreddit": "<name>"  so throughput is close to
raw zstd decompression speed (~1.5 GB/s of uncompressed JSON per file). Each input file runs in
its own process, so comments and submissions are filtered in parallel.

Then build the SQLite DB from the tiny filtered folder with the normal script (which still does
the proper case-insensitive JSON-level filter, removing any false positives):

    python prefilter_subreddit_zst.py <month_folder> worldnews <out_folder>
    python zst_to_sqlite.py <out_folder> 2025-06-worldnews.db --subreddit worldnews

Matching is on the subreddit's canonical spelling (Pushshift always stores the canonical
display name, e.g. "worldnews", "DestinyTheGame"). Pass --ignore-case if unsure; it is slower.
"""

from __future__ import annotations

import argparse
import os
import re
import sys
import time
from multiprocessing import Process

import zstandard

READ_SIZE = 2**25  # 32 MiB of decompressed data per read
PROGRESS_EVERY_S = 30.0


def _filter_file(in_path: str, out_path: str, subreddit: str, ignore_case: bool) -> None:
    label = os.path.basename(in_path)
    total_comp = os.path.getsize(in_path)
    name = subreddit.lower() if ignore_case else subreddit
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    tmp_out = out_path + ".partial"

    t0 = time.time()
    last_report = t0
    raw_bytes = 0
    matches = 0
    needle = None

    with open(in_path, "rb") as fin, open(tmp_out, "wb") as fout_raw:
        reader = zstandard.ZstdDecompressor(max_window_size=2**31).stream_reader(fin)
        writer = zstandard.ZstdCompressor(level=3).stream_writer(fout_raw)
        leftover = b""
        while True:
            chunk = reader.read(READ_SIZE)
            if not chunk:
                break
            raw_bytes += len(chunk)
            buf = leftover + chunk
            cut = buf.rfind(b"\n") + 1
            if cut == 0:
                leftover = buf
                continue
            data, leftover = buf[:cut], buf[cut:]
            hay = data.lower() if ignore_case else data

            if needle is None:  # detect separator style ("k": "v" vs "k":"v") from the data
                m = re.search(rb'"subreddit":( ?)"', data)
                if not m:
                    continue
                needle = b'"subreddit":' + m.group(1) + b'"' + name.encode() + b'"'

            pos = 0
            while True:
                idx = hay.find(needle, pos)
                if idx < 0:
                    break
                start = data.rfind(b"\n", 0, idx) + 1
                end = data.find(b"\n", idx) + 1
                writer.write(data[start:end])
                matches += 1
                pos = end

            now = time.time()
            if now - last_report >= PROGRESS_EVERY_S:
                last_report = now
                frac = fin.tell() / total_comp
                el = now - t0
                eta = el / frac - el if frac > 0 else 0
                print(
                    f"[{label}] {frac*100:5.1f}%  {raw_bytes/2**30:7.1f} GiB raw  "
                    f"{raw_bytes/2**20/el:5.0f} MiB/s  {matches:,} matches  ETA {eta/60:4.1f} min",
                    flush=True,
                )
        if leftover.strip():  # final line without trailing newline
            hay = leftover.lower() if ignore_case else leftover
            if needle and needle in hay:
                writer.write(leftover + b"\n")
                matches += 1
        writer.flush(zstandard.FLUSH_FRAME)

    os.replace(tmp_out, out_path)
    print(
        f"[{label}] done: {matches:,} lines kept from {raw_bytes/2**30:.1f} GiB raw "
        f"in {(time.time()-t0)/60:.1f} min -> {out_path}",
        flush=True,
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("month_folder", help="Folder containing the monthly .zst files (searched recursively)")
    ap.add_argument("subreddit", help="Canonical subreddit name, without r/")
    ap.add_argument("out_folder", help="Output folder; mirrors the input subfolder layout")
    ap.add_argument("--ignore-case", action="store_true", help="Case-insensitive byte match (slower)")
    args = ap.parse_args()

    sub = args.subreddit.strip()
    if sub.lower().startswith("r/"):
        sub = sub[2:]

    jobs = []
    for root, _dirs, files in os.walk(args.month_folder):
        for f in sorted(files):
            if f.endswith(".zst"):
                in_path = os.path.join(root, f)
                rel = os.path.relpath(in_path, args.month_folder)
                jobs.append((in_path, os.path.join(args.out_folder, rel)))
    if not jobs:
        print(f"No .zst files under {args.month_folder}", file=sys.stderr)
        return 1

    procs = [Process(target=_filter_file, args=(i, o, sub, args.ignore_case)) for i, o in jobs]
    for p in procs:
        p.start()
    for p in procs:
        p.join()
    return 0 if all(p.exitcode == 0 for p in procs) else 1


if __name__ == "__main__":
    sys.exit(main())
