#!/usr/bin/env python3
"""
Copy comments + submissions for one subreddit from a large Reddit SQLite DB into a new file.

Use this when you already have an aggregate database (e.g. redditdata.db) and want a
smaller per-subreddit .db like Simulation_Setups/reddit_databases/2025-06-destiny2.db.

Alternative (no existing DB): build from Pushshift monthly .zst archives with
    python zst_to_sqlite.py <month> out.db --subreddit <name>

Usage:
    python extract_subreddit_sqlite.py --source path/to/redditdata.db --subreddit gaming \\
        --output path/to/gaming.db

Optional:
    --vacuum       Run VACUUM on the output file when done (slower, smaller file)
    --batch-size   Rows per batch when copying (default 10000); lower uses less RAM

Does not use ATTACH (avoids "database srcdb is locked" on many Windows/WAL databases).
"""

from __future__ import annotations

import argparse
import os
import sqlite3
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple


def _table_create_sql(conn: sqlite3.Connection, name: str) -> Optional[str]:
    cur = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?",
        (name,),
    )
    row = cur.fetchone()
    return row[0] if row else None


def _index_sql_list(conn: sqlite3.Connection, tbl: str) -> List[str]:
    """Return CREATE INDEX statements for tbl (skip internal autoindexes)."""
    cur = conn.execute(
        """
        SELECT sql FROM sqlite_master
        WHERE type = 'index' AND tbl_name = ? AND sql IS NOT NULL
        AND name NOT LIKE 'sqlite_autoindex_%'
        ORDER BY name
        """,
        (tbl,),
    )
    return [r[0] for r in cur.fetchall() if r[0]]


def _normalize_subreddit(name: str) -> str:
    s = name.strip()
    if not s:
        raise ValueError("subreddit name is empty")
    if s.startswith("r/"):
        s = s[2:]
    return s.lower()


def _sqlite_fs_path(path: str) -> str:
    """Absolute path with forward slashes (portable for SQLite on Windows)."""
    return str(Path(path).resolve()).replace("\\", "/")


def _read_source_schema_and_indexes(
    src_abs: str,
) -> Tuple[Dict[str, str], Dict[str, List[str]]]:
    """Read DDL and index SQL from the source DB, then close (short-lived connection)."""
    conn = sqlite3.connect(_sqlite_fs_path(src_abs))
    try:
        conn.execute("PRAGMA busy_timeout = 60000")
        ddls: Dict[str, str] = {}
        indexes: Dict[str, List[str]] = {}
        for tbl in ("comments", "submissions"):
            ddl = _table_create_sql(conn, tbl)
            if not ddl:
                raise RuntimeError(
                    f"Source database has no '{tbl}' table. "
                    "Expected Pushshift-style schema (see zst_to_sqlite.py)."
                )
            ddls[tbl] = ddl
            indexes[tbl] = _index_sql_list(conn, tbl)
        return ddls, indexes
    finally:
        conn.close()


def _copy_filtered_rows(
    src: sqlite3.Connection,
    out: sqlite3.Connection,
    table: str,
    sub_norm: str,
    batch_size: int,
) -> int:
    """
    Stream rows from src into out (same table name and column order as SELECT *).
    Avoids ATTACH, which often hits 'database srcdb is locked' on Windows/WAL sources.
    """
    cur = src.execute(
        f"SELECT * FROM {table} WHERE LOWER(subreddit) = ?",
        (sub_norm,),
    )
    desc = cur.description
    if not desc:
        return 0
    cols = [d[0] for d in desc]
    col_list = ",".join(cols)
    placeholders = ",".join("?" * len(cols))
    insert_sql = f"INSERT INTO {table} ({col_list}) VALUES ({placeholders})"
    total = 0
    while True:
        rows = cur.fetchmany(batch_size)
        if not rows:
            break
        out.executemany(insert_sql, rows)
        total += len(rows)
    return total


def extract_subreddit(
    source_path: str,
    output_path: str,
    subreddit: str,
    vacuum: bool = False,
    batch_size: int = 10_000,
) -> Tuple[int, int]:
    """
    Create output_path with the same comments/submissions schema as source,
    containing only rows where LOWER(subreddit) matches the given name.
    Returns (comment_count, submission_count).
    """
    sub_norm = _normalize_subreddit(subreddit)
    src_abs = os.path.abspath(source_path)
    out_abs = os.path.abspath(output_path)

    if not os.path.isfile(src_abs):
        raise FileNotFoundError(f"Source database not found: {src_abs}")

    if os.path.exists(out_abs):
        raise FileExistsError(
            f"Output file already exists: {out_abs}\n"
            "Remove it or choose a different --output path."
        )

    ddls, index_sql_by_table = _read_source_schema_and_indexes(src_abs)

    out = sqlite3.connect(out_abs)
    try:
        out.execute("PRAGMA busy_timeout = 60000")
        out.execute("PRAGMA journal_mode = WAL")
        out.execute("PRAGMA synchronous = NORMAL")

        for tbl in ("comments", "submissions"):
            out.execute(ddls[tbl])

        out.commit()

        src = sqlite3.connect(_sqlite_fs_path(src_abs))
        try:
            src.execute("PRAGMA busy_timeout = 60000")
            out.execute("BEGIN IMMEDIATE")
            try:
                n_comments = _copy_filtered_rows(
                    src, out, "comments", sub_norm, batch_size
                )
                n_submissions = _copy_filtered_rows(
                    src, out, "submissions", sub_norm, batch_size
                )
            except Exception:
                out.execute("ROLLBACK")
                raise
            else:
                out.execute("COMMIT")
        finally:
            src.close()

        for tbl in ("comments", "submissions"):
            for idx_sql in index_sql_by_table[tbl]:
                try:
                    out.execute(idx_sql)
                except sqlite3.OperationalError as e:
                    print(f"Warning: skipped index ({tbl}): {e}", file=sys.stderr)

        out.commit()

        if vacuum:
            out.execute("VACUUM")
            out.commit()

    finally:
        out.close()

    return n_comments, n_submissions


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Extract one subreddit from a combined Reddit SQLite DB into a new file."
    )
    parser.add_argument(
        "--source",
        required=True,
        help="Path to the full multi-subreddit SQLite file (e.g. redditdata.db)",
    )
    parser.add_argument(
        "--subreddit",
        required=True,
        help="Subreddit name (e.g. destiny2 or r/destiny2); match is case-insensitive",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Path for the new SQLite file (must not exist yet)",
    )
    parser.add_argument(
        "--vacuum",
        action="store_true",
        help="Run VACUUM on the output database when finished",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=10_000,
        metavar="N",
        help="Rows per batch when copying from source (default: 10000)",
    )
    args = parser.parse_args()

    try:
        nc, ns = extract_subreddit(
            args.source,
            args.output,
            args.subreddit,
            vacuum=args.vacuum,
            batch_size=max(1, args.batch_size),
        )
    except (FileNotFoundError, FileExistsError, RuntimeError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1
    except sqlite3.Error as e:
        print(f"SQLite error: {e}", file=sys.stderr)
        return 1

    print(f"Wrote {args.output}")
    print(f"  comments:     {nc:,}")
    print(f"  submissions:  {ns:,}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
