#!/usr/bin/env python3
"""
Script to decompress a given month's folder from PushShift dumps.
Creates a 'Decompressed' subdirectory with comments and submissions folders containing the decompressed files.

Usage:
    python decompress_month.py <month_folder_path>
    
Example:
    python decompress_month.py 2025-06
"""

import zstandard
import os
import sys
import json
from datetime import datetime
import logging.handlers
import argparse


log = logging.getLogger("decompress")
log.setLevel(logging.INFO)
log_formatter = logging.Formatter('%(asctime)s - %(levelname)s: %(message)s')

log_str_handler = logging.StreamHandler()
log_str_handler.setFormatter(log_formatter)
log.addHandler(log_str_handler)


def read_and_decode(reader, chunk_size, max_window_size, previous_chunk=None, bytes_read=0):
    """Recursively decompress and decode a chunk of bytes."""
    chunk = reader.read(chunk_size)
    bytes_read += chunk_size
    if previous_chunk is not None:
        chunk = previous_chunk + chunk
    try:
        return chunk.decode()
    except UnicodeDecodeError:
        if bytes_read > max_window_size:
            raise UnicodeError(f"Unable to decode frame after reading {bytes_read:,} bytes")
        log.info(f"Decoding error with {bytes_read:,} bytes, reading another chunk")
        return read_and_decode(reader, chunk_size, max_window_size, chunk, bytes_read)


def read_lines_zst(file_name):
    """Read lines from a zst compressed file."""
    with open(file_name, 'rb') as file_handle:
        buffer = ''
        reader = zstandard.ZstdDecompressor(max_window_size=2**31).stream_reader(file_handle)
        while True:
            chunk = read_and_decode(reader, 2**27, (2**29) * 2)

            if not chunk:
                break
            lines = (buffer + chunk).split("\n")

            for line in lines[:-1]:
                yield line.strip(), file_handle.tell()

            buffer = lines[-1]

        reader.close()


def decompress_file(input_path, output_path):
    """Decompress a single zst file to a text file."""
    log.info(f"Decompressing {input_path} to {output_path}")
    
    file_size = os.stat(input_path).st_size
    file_lines = 0
    file_bytes_processed = 0
    created = None
    
    with open(output_path, 'w', encoding='utf-8') as output_file:
        for line, file_bytes_processed in read_lines_zst(input_path):
            if line:
                try:
                    obj = json.loads(line)
                    created = datetime.utcfromtimestamp(int(obj['created_utc']))
                except (KeyError, json.JSONDecodeError, ValueError):
                    pass  # Continue processing even if we can't parse the timestamp
                
                output_file.write(line + '\n')
                file_lines += 1
                
                if file_lines % 100000 == 0:
                    log.info(f"{created.strftime('%Y-%m-%d %H:%M:%S') if created else 'Unknown'} : {file_lines:,} : {(file_bytes_processed / file_size) * 100:.0f}%")
    
    log.info(f"Completed {input_path}: {file_lines:,} lines")
    return file_lines


def decompress_month_folder(month_folder_path):
    """Decompress all zst files in a month folder structure."""
    if not os.path.exists(month_folder_path):
        log.error(f"Month folder does not exist: {month_folder_path}")
        return False
    
    decompressed_path = os.path.join(month_folder_path, "Decompressed")
    comments_path = os.path.join(decompressed_path, "comments")
    submissions_path = os.path.join(decompressed_path, "submissions")
    
    os.makedirs(comments_path, exist_ok=True)
    os.makedirs(submissions_path, exist_ok=True)
    
    log.info(f"Created decompressed directory structure: {decompressed_path}")
    
    total_files = 0
    total_lines = 0
    
    for root, dirs, files in os.walk(month_folder_path):
        for file in files:
            if file.endswith('.zst'):
                input_path = os.path.join(root, file)
                
                if 'comments' in root:
                    output_dir = comments_path
                elif 'submissions' in root:
                    output_dir = submissions_path
                else:
                    if file.startswith('RC_'):
                        output_dir = comments_path
                    elif file.startswith('RS_'):
                        output_dir = submissions_path
                    else:
                        log.warning(f"Could not determine output directory for {file}, skipping")
                        continue
                
                output_filename = file[:-4] + '.txt'
                output_path = os.path.join(output_dir, output_filename)
                
                try:
                    lines = decompress_file(input_path, output_path)
                    total_files += 1
                    total_lines += lines
                except Exception as e:
                    log.error(f"Failed to decompress {input_path}: {e}")
    
    log.info(f"Decompression complete: {total_files} files, {total_lines:,} total lines")
    log.info(f"Output directory: {decompressed_path}")
    return True


def main():
    parser = argparse.ArgumentParser(description="Decompress a month's PushShift dump folder")
    parser.add_argument("month_folder", help="Path to the month folder (e.g., '2025-06' or '/path/to/2025-06')")
    parser.add_argument("--debug", help="Enable debug logging", action='store_true')
    
    args = parser.parse_args()
    
    if args.debug:
        log.setLevel(logging.DEBUG)
    
    month_folder_path = args.month_folder
    if not os.path.isabs(month_folder_path):
        month_folder_path = os.path.abspath(month_folder_path)
    
    log.info(f"Starting decompression of: {month_folder_path}")
    
    success = decompress_month_folder(month_folder_path)
    
    if success:
        log.info("Decompression completed successfully!")
    else:
        log.error("Decompression failed!")
        sys.exit(1)


if __name__ == "__main__":
    main()
