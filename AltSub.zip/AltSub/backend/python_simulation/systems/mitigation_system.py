#!/usr/bin/env python3
"""
Mitigation System: Duplicate detection, rate limiting, coordination detection

Ports functionality from reddit_mitigation_agents.cpp
"""

import logging
import math
from typing import Dict, List, Set, Optional, Any, Tuple
from collections import defaultdict
from ..core.simulation_data import SimulationState, MediaEvent, EventType

try:
    from sentence_transformers import SentenceTransformer

    _SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SentenceTransformer = None  # type: ignore[misc, assignment]
    _SENTENCE_TRANSFORMERS_AVAILABLE = False

log = logging.getLogger(__name__)


class MitigationSystem:
    """Manages mitigation agents: duplicate detection, rate limiting, coordination detection"""

    def __init__(
        self,
        duplicate_detection_enabled: bool = False,
        rate_limiting_enabled: bool = False,
        coordinated_detection_enabled: bool = False,
        scan_frequency: int = 10,
        duplicate_similarity_threshold: float = 0.85,
        rate_limit_window: int = 24,
        rate_limit_threshold: int = 10,
        ban_threshold: int = 3,
        use_embedding_similarity_for_duplicates: bool = False,
        duplicate_lookback_window: int = 100,
        coordination_lookback_window: int = 144,
        duplicate_embedder_model: str = "all-MiniLM-L6-v2",
        coordination_sync_window: int = 6,
        coordination_min_shared_targets: int = 3,
        coordination_similarity_threshold: float = 0.3,
        coordination_content_similarity_threshold: float = 0.8,
        coordination_min_content_matches: int = 2,
        coordination_min_amplifications: int = 3,
        coordination_significance: float = 0.01,
        use_embedding_similarity_for_coordination: bool = False,
        step_s: float = 300.0,
    ):
        """
        Initialize mitigation system.

        Args:
            duplicate_detection_enabled: Enable duplicate content detection
            rate_limiting_enabled: Enable rate limiting
            coordinated_detection_enabled: Enable coordinated behavior detection
            scan_frequency: Timesteps between scans
            duplicate_similarity_threshold: Similarity threshold for duplicates (0-1)
            rate_limit_window: Time window for rate limiting (timesteps)
            rate_limit_threshold: Max actions per window
            ban_threshold: Number of flags before ban
            use_embedding_similarity_for_duplicates: If True, use embedding cosine similarity
                for duplicate detection (requires sentence-transformers). If False, use Jaccard.
            duplicate_lookback_window: Timesteps considered for duplicate detection.
            coordination_lookback_window: Timesteps considered for coordination checks.
            duplicate_embedder_model: Sentence-transformers model name used for embeddings.
            coordination_sync_window: Max timesteps between two actions for them to
                count as synchronised (co-engagement, co-content, fast amplification).
            coordination_min_shared_targets: Co-engagement: min synchronised shared targets.
            coordination_similarity_threshold: Co-engagement: min TF-IDF cosine score.
            coordination_content_similarity_threshold: Co-content: min text similarity.
            coordination_min_content_matches: Co-content: min matching text pairs.
            coordination_min_amplifications: Fast amplification: min distinct items one
                account quickly engaged from the other.
            coordination_significance: Family-wise significance level for
                co-engagement and fast-amplification edges: each pair's one-sided
                p-value against an independent-engagement null (hypergeometric
                for co-engagement, binomial for fast amplification) must be
                <= coordination_significance / (pairs tested in that scan), i.e.
                Bonferroni-corrected (lower = stricter).
            use_embedding_similarity_for_coordination: Co-content uses embedding cosine
                (sentence-transformers) instead of Jaccard.
            step_s: Seconds per reference timestep. Windows and frequencies above
                are in timesteps; detection compares simulated times in seconds
                (window * step_s), so both engines use the same windows.
        """
        self.duplicate_detection_enabled = duplicate_detection_enabled
        self.rate_limiting_enabled = rate_limiting_enabled
        self.coordinated_detection_enabled = coordinated_detection_enabled
        self.scan_frequency = scan_frequency
        self.duplicate_similarity_threshold = duplicate_similarity_threshold
        self.rate_limit_window = rate_limit_window
        self.rate_limit_threshold = rate_limit_threshold
        self.ban_threshold = ban_threshold
        self.use_embedding_similarity_for_duplicates = (
            use_embedding_similarity_for_duplicates
        )
        self.duplicate_lookback_window = duplicate_lookback_window
        self.coordination_lookback_window = coordination_lookback_window
        self.duplicate_embedder_model = duplicate_embedder_model
        self.coordination_sync_window = coordination_sync_window
        self.coordination_min_shared_targets = coordination_min_shared_targets
        self.coordination_similarity_threshold = coordination_similarity_threshold
        self.coordination_content_similarity_threshold = (
            coordination_content_similarity_threshold
        )
        self.coordination_min_content_matches = coordination_min_content_matches
        self.coordination_min_amplifications = coordination_min_amplifications
        self.coordination_significance = coordination_significance
        self.use_embedding_similarity_for_coordination = (
            use_embedding_similarity_for_coordination
        )
        self.step_s = float(step_s)

        # Lazy-loaded embedder for duplicate similarity (when use_embedding_similarity_for_duplicates)
        self._embedder: Optional[Any] = None
        self._embedder_model = duplicate_embedder_model

        self.last_scan_time = -999
        self.mitigation_flags: Dict[int, int] = {}  # agent_id -> flag count
        # Every flag raised, for per-day analysis (written into daily snapshots)
        self.flag_log: List[Dict[str, Any]] = []

        # Evidence already used for a flag, per mitigation: event_id -> event time (s).
        # Lookback windows span several scans, so without this the same posts
        # would be re-flagged every scan and one incident would reach the ban
        # threshold. Each mitigation flags only on evidence it hasn't counted.
        self._flagged_evidence: Dict[str, Dict[int, float]] = {
            "duplicate": {},
            "rate_limit": {},
            "coordination": {},
        }
        # Coordination edges that led to a flag, for analysis (snapshots / final output)
        self.coordination_edges: List[Dict[str, Any]] = []
        # Co-content embeddings by event_id (pruned to the lookback window)
        self._coordination_embeddings: Dict[int, Any] = {}

        log.info(
            f"MitigationSystem initialized (duplicate={duplicate_detection_enabled}, "
            f"rate_limit={rate_limiting_enabled}, coordination={coordinated_detection_enabled}, "
            f"embedding_similarity={use_embedding_similarity_for_duplicates}, "
            f"duplicate_lookback={duplicate_lookback_window}, "
            f"coordination_lookback={coordination_lookback_window}, "
            f"coordination_sync_window={coordination_sync_window}, "
            f"coordination_min_shared_targets={coordination_min_shared_targets}, "
            f"coordination_similarity_threshold={coordination_similarity_threshold}, "
            f"coordination_content_similarity_threshold={coordination_content_similarity_threshold}, "
            f"coordination_min_content_matches={coordination_min_content_matches}, "
            f"coordination_min_amplifications={coordination_min_amplifications}, "
            f"coordination_significance={coordination_significance}, "
            f"coordination_embedding_similarity={use_embedding_similarity_for_coordination})"
        )

    def should_scan(self, timestep: int) -> bool:
        """Check if mitigation should scan at this timestep"""
        return (timestep - self.last_scan_time) >= self.scan_frequency

    def scan(
        self, timestep: int, state: SimulationState, now_s: Optional[float] = None
    ) -> None:
        """Run all enabled mitigation scans.

        Discrete engine: called every timestep; scans every scan_frequency.
        Event engine: called by a scheduled scan event with now_s (no
        should_scan check). Each scan sees events committed up to now_s.
        """
        if now_s is None:
            if not self.should_scan(timestep):
                return
            now_s = timestep * self.step_s

        self.last_scan_time = timestep

        if self.duplicate_detection_enabled:
            self.detect_duplicates(timestep, state, now_s)

        if self.rate_limiting_enabled:
            self.rate_limit_check(timestep, state, now_s)

        if self.coordinated_detection_enabled:
            self.detect_coordination(timestep, state, now_s)

    @property
    def scan_interval_s(self) -> float:
        return self.scan_frequency * self.step_s

    def _is_agent_banned(self, agent_id: int, state: SimulationState) -> bool:
        """Check if agent is banned in its (first) subreddit"""
        subreddit_id = list(
            state.subreddit_membership.memberships.get(agent_id, set())
        )
        if not subreddit_id:
            return False
        return state.banned_agent_network.is_banned(agent_id, subreddit_id[0])

    def flag_agent(
        self,
        agent_id: int,
        reason: str,
        state: SimulationState,
        timestep: Optional[int] = None,
        source: str = "unknown",
        time_s: Optional[float] = None,
    ) -> None:
        """Flag an agent for suspicious behavior.

        Args:
            timestep: When the flag was raised (defaults to the last scan time)
            time_s: Same in simulated seconds (defaults to timestep * step_s)
            source: Which mitigation raised it ("duplicate", "rate_limit",
                "coordination", "rule_moderator"); recorded in flag_log
        """
        # Seed content accounts (pre-existing Reddit content) are not moderated
        if agent_id in getattr(state, "seed_author_ids", ()):
            return
        # Banned agents are no longer reviewed, so further flags are not counted
        if self._is_agent_banned(agent_id, state):
            return

        current_flags = self.mitigation_flags.get(agent_id, 0)
        self.mitigation_flags[agent_id] = current_flags + 1

        log.info(
            f"[Mitigation] Flagged agent {agent_id} (reason: {reason}, "
            f"total flags: {current_flags + 1})"
        )

        self.check_and_ban(agent_id, state)
        flag_timestep = self.last_scan_time if timestep is None else timestep
        self.flag_log.append(
            {
                "timestep": flag_timestep,
                "time_s": time_s if time_s is not None else flag_timestep * self.step_s,
                "agent_id": agent_id,
                "source": source,
                "reason": reason,
                "total_flags": current_flags + 1,
                "banned": self._is_agent_banned(agent_id, state),
            }
        )

    def _is_flagged_evidence(self, mitigation: str, event: MediaEvent) -> bool:
        return event.event_id in self._flagged_evidence[mitigation]

    def _mark_flagged_evidence(
        self, mitigation: str, events: List[MediaEvent], state: SimulationState
    ) -> None:
        ledger = self._flagged_evidence[mitigation]
        for e in events:
            ledger[e.event_id] = state.event_time(e)

    def _prune_flagged_evidence(self, mitigation: str, window_start: float) -> None:
        """Forget evidence older than the mitigation's lookback; it can't be scanned again."""
        ledger = self._flagged_evidence[mitigation]
        for eid in [eid for eid, ts in ledger.items() if ts <= window_start]:
            del ledger[eid]

    def check_and_ban(self, agent_id: int, state: SimulationState) -> None:
        """Check if agent should be banned based on flag count"""
        total_flags = self.mitigation_flags.get(agent_id, 0)

        if total_flags >= self.ban_threshold:
            subreddit_id = list(
                state.subreddit_membership.memberships.get(agent_id, set())
            )
            if subreddit_id:
                state.banned_agent_network.increment_ban(agent_id, subreddit_id[0])

            log.info(f"[Mitigation] BANNED agent {agent_id} after {total_flags} flags")

    def _window(
        self, state: SimulationState, window_start: float, now_s: float
    ) -> List[MediaEvent]:
        """Events committed in (window_start, now_s]"""
        return [
            e for e in state.events if window_start < state.event_time(e) <= now_s
        ]

    def detect_duplicates(
        self, timestep: int, state: SimulationState, now_s: Optional[float] = None
    ) -> None:
        """Detect duplicate/similar content"""
        if now_s is None:
            now_s = timestep * self.step_s
        # Get recent events from configured lookback window.
        window_start = now_s - self.duplicate_lookback_window * self.step_s
        recent_events = [
            e
            for e in self._window(state, window_start, now_s)
            if e.type in (EventType.POST, EventType.REPLY) and e.content
        ]

        self._prune_flagged_evidence("duplicate", window_start)

        recent_content: Dict[int, List[MediaEvent]] = defaultdict(list)
        for event in recent_events:
            recent_content[event.user_id].append(event)

        _pairs = sum((len(c) * (len(c) - 1)) // 2 for c in recent_content.values() if len(c) >= 2)
        try:
            import os
            if os.environ.get("SIM_PROFILE_VERBOSE") != "1":
                raise RuntimeError("profiling disabled")
            import json
            import os
            from pathlib import Path
            import time as _time
            _p = Path(os.environ["DEBUG_LOG_PATH"]) if os.environ.get("DEBUG_LOG_PATH") else Path(__file__).resolve().parent.parent.parent.parent / "profiling.log"
            _payload = {"sessionId": "977fa7", "location": "mitigation_system.py:detect_duplicates", "message": "detect_duplicates", "data": {"state_events_count": len(state.events), "recent_events_count": len(recent_events), "agents_with_content": len(recent_content), "duplicate_pairs_compared": _pairs}, "timestamp": int(_time.time() * 1000), "hypothesisId": "B,D"}
            with open(_p, "a", encoding="utf-8") as _f:
                _f.write(json.dumps(_payload) + "\n")
        except Exception:
            pass

        already_flagged: Set[int] = set()

        for agent_id, contents in recent_content.items():
            if len(contents) < 2:
                continue
            if agent_id in already_flagged:
                continue

            # Compare all pairs of posts from this agent; a pair whose posts were
            # both already counted in an earlier flag is not new evidence
            found_duplicate = False
            for i in range(len(contents)):
                if found_duplicate:
                    break
                for j in range(i + 1, len(contents)):
                    pair = [contents[i], contents[j]]
                    if all(self._is_flagged_evidence("duplicate", e) for e in pair):
                        continue
                    similarity = self._calculate_text_similarity(
                        contents[i].content, contents[j].content
                    )

                    if similarity >= self.duplicate_similarity_threshold:
                        self.flag_agent(
                            agent_id,
                            f"duplicate content (similarity: {similarity:.2f})",
                            state,
                            timestep=timestep,
                            source="duplicate",
                            time_s=now_s,
                        )
                        self._mark_flagged_evidence("duplicate", pair, state)
                        already_flagged.add(agent_id)
                        found_duplicate = True
                        break  # Only flag once per scan

    def _init_embedder(self) -> bool:
        """Lazy initialization of sentence transformer for embedding similarity."""
        if self._embedder is not None:
            return True
        if not _SENTENCE_TRANSFORMERS_AVAILABLE:
            log.warning("sentence-transformers not available, falling back to Jaccard")
            return False
        try:
            self._embedder = SentenceTransformer(self._embedder_model)
            log.info(f"MitigationSystem: loaded embedder {self._embedder_model}")
            return True
        except Exception as e:
            log.warning(
                f"MitigationSystem: failed to load embedder: {e}, falling back to Jaccard"
            )
            return False

    def _embedding_similarity(self, text1: str, text2: str) -> float:
        """
        Compute similarity by encoding texts to embeddings, then cosine similarity.
        Returns 0.0 on failure.
        """
        if not text1 or not text2:
            return 0.0
        if not self._init_embedder() or self._embedder is None:
            return 0.0
        try:
            t1 = " ".join(text1.lower().split())
            t2 = " ".join(text2.lower().split())
            emb = self._embedder.encode([t1, t2], convert_to_numpy=True)
            dot = float((emb[0] * emb[1]).sum())
            n1 = float((emb[0] ** 2).sum() ** 0.5)
            n2 = float((emb[1] ** 2).sum() ** 0.5)
            if n1 > 0 and n2 > 0:
                return dot / (n1 * n2)
        except Exception as e:
            log.debug(f"Embedding similarity failed: {e}")
        return 0.0

    def _jaccard_similarity(self, text1: str, text2: str) -> float:
        """Calculate text similarity using Jaccard similarity on words."""

        def tokenize(text: str) -> Set[str]:
            """Tokenize text into lowercase words"""
            words = set()
            for word in text.lower().split():
                word = "".join(c for c in word if c.isalnum())
                if word:
                    words.add(word)
            return words

        words1 = tokenize(text1)
        words2 = tokenize(text2)
        if not words1 or not words2:
            return 0.0
        intersection = words1 & words2
        union = words1 | words2
        return len(intersection) / len(union) if union else 0.0

    def _calculate_text_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate text similarity for duplicate detection.
        If use_embedding_similarity_for_duplicates is True and sentence-transformers
        is available, encodes texts to embeddings and computes cosine similarity;
        otherwise uses Jaccard similarity on words.
        """
        if self.use_embedding_similarity_for_duplicates:
            sim = self._embedding_similarity(text1, text2)
            if sim > 0:
                return sim
            # Fallback to Jaccard if embedding failed
        return self._jaccard_similarity(text1, text2)

    def rate_limit_check(
        self, timestep: int, state: SimulationState, now_s: Optional[float] = None
    ) -> None:
        """Check for rate limiting violations"""
        if now_s is None:
            now_s = timestep * self.step_s
        window_start = now_s - self.rate_limit_window * self.step_s

        recent_events = [
            e
            for e in self._window(state, window_start, now_s)
            if e.type in (EventType.POST, EventType.REPLY)
        ]

        self._prune_flagged_evidence("rate_limit", window_start)

        # Count activity per agent, excluding actions already counted in an
        # earlier rate-limit flag (a burst stays in the window across scans)
        uncounted: Dict[int, List[MediaEvent]] = defaultdict(list)
        for event in recent_events:
            if not self._is_flagged_evidence("rate_limit", event):
                uncounted[event.user_id].append(event)

        # Flag agents whose new actions alone exceed the threshold
        for agent_id, events in uncounted.items():
            if len(events) > self.rate_limit_threshold:
                self.flag_agent(
                    agent_id,
                    f"rate limit exceeded ({len(events)} new actions in {self.rate_limit_window} timesteps)",
                    state,
                    timestep=timestep,
                    source="rate_limit",
                    time_s=now_s,
                )
                self._mark_flagged_evidence("rate_limit", events, state)

    # Coordination detection: co-action network
    # Pairs of accounts are linked by shared behavioural traces inside the
    # lookback window, following the co-action network approach of Pacheco et al.
    # (ICWSM 2021, "Uncovering Coordinated Networks on Social Media"), with
    # SynchroTrap-style synchrony (Cao et al., CCS 2014): actions only count as
    # co-actions within coordination_sync_window timesteps of each other
    # (compared in seconds: sync_window * step_s).
    #   T1 co-engagement      both accounts vote on / reply to the same item in
    #                         sync; TF-IDF weighted so popular items count little
    #   T2 co-content         both accounts post near-identical text in sync
    #   T3 fast amplification one account repeatedly engages the other's posts
    #                         soon after they are posted
    # T1 and T3 edges must also be statistically significant against an
    # independent-engagement null (one-sided hypergeometric / binomial tests,
    # Bonferroni-corrected over the pairs tested per scan), the edge-pruning /
    # backbone step used for
    # co-occurrence networks (cf. the disparity filter, Serrano et al., PNAS 2009).
    # In a small simulation everyone reads the same fresh feed, so raw overlap and
    # concentration are high for organic users too; significance compares each pair
    # with what its own engagement rates would produce by chance.
    # Linked accounts form groups (connected components); each member is flagged
    # once per scan, and only when its own evidence includes events not already
    # counted in an earlier coordination flag.

    def detect_coordination(
        self, timestep: int, state: SimulationState, now_s: Optional[float] = None
    ) -> None:
        """Flag groups of accounts linked by synchronised co-actions"""
        if now_s is None:
            now_s = timestep * self.step_s
        window_start = now_s - self.coordination_lookback_window * self.step_s
        self._prune_flagged_evidence("coordination", window_start)
        recent = self._window(state, window_start, now_s)

        # (low_id, high_id) -> {"traces": {name: score}, "evidence": {agent_id: [events]}}
        edges: Dict[Tuple[int, int], Dict[str, Any]] = {}

        def add_edge(
            u: int, v: int, trace: str, score: float,
            evidence: Dict[int, List[MediaEvent]],
        ) -> None:
            key = (u, v) if u < v else (v, u)
            edge = edges.setdefault(key, {"traces": {}, "evidence": defaultdict(list)})
            edge["traces"][trace] = round(float(score), 4)
            for agent_id, events in evidence.items():
                edge["evidence"][agent_id].extend(events)

        by_target, targets = self._coordination_engagements(recent, state)
        self._co_engagement_edges(by_target, targets, window_start, add_edge, state)
        self._co_content_edges(recent, add_edge, state)
        self._fast_amplification_edges(by_target, targets, window_start, add_edge, state)

        if edges:
            self._flag_coordination_groups(edges, timestep, state, now_s)

    def _coordination_engagements(
        self, recent: List[MediaEvent], state: SimulationState
    ) -> Tuple[Dict[int, Dict[int, List[MediaEvent]]], Dict[int, MediaEvent]]:
        """
        Returns (target_id -> engaging user -> their engagement events,
        target_id -> target event). Self-engagement and removed targets are skipped.
        """
        by_target: Dict[int, Dict[int, List[MediaEvent]]] = defaultdict(
            lambda: defaultdict(list)
        )
        targets: Dict[int, MediaEvent] = {}
        for e in recent:
            if e.parent_id is None or e.type not in (
                EventType.UPVOTE,
                EventType.DOWNVOTE,
                EventType.REPLY,
            ):
                continue
            target = state.get_event(e.parent_id)
            if target is None or target.user_id == e.user_id:
                continue
            by_target[e.parent_id][e.user_id].append(e)
            targets[e.parent_id] = target
        return by_target, targets

    @staticmethod
    def _binomial_sf(k: int, n: int, p: float) -> float:
        """P(X >= k) for X ~ Binomial(n, p): chance of k or more successes by luck"""
        if k <= 0:
            return 1.0
        if k > n or p <= 0.0:
            return 0.0
        if p >= 1.0:
            return 1.0
        log_p, log_q = math.log(p), math.log1p(-p)
        total = 0.0
        for i in range(k, n + 1):
            total += math.exp(
                math.lgamma(n + 1) - math.lgamma(i + 1) - math.lgamma(n - i + 1)
                + i * log_p + (n - i) * log_q
            )
        return min(1.0, total)

    @staticmethod
    def _hypergeom_sf(k: int, population: int, n_a: int, n_b: int) -> float:
        """
        P(overlap >= k) when two accounts engage n_a and n_b distinct items chosen
        independently at random from `population` items (hypergeometric tail)
        """
        if k <= 0:
            return 1.0
        hi = min(n_a, n_b)
        if k > hi or population <= 0:
            return 0.0

        def log_comb(n: int, r: int) -> float:
            return math.lgamma(n + 1) - math.lgamma(r + 1) - math.lgamma(n - r + 1)

        denom = log_comb(population, n_b)
        total = 0.0
        for i in range(k, hi + 1):
            if n_b - i > population - n_a:
                continue
            total += math.exp(
                log_comb(n_a, i) + log_comb(population - n_a, n_b - i) - denom
            )
        return min(1.0, total)

    def _co_engagement_edges(
        self, by_target, targets, window_start: float, add_edge, state: SimulationState
    ) -> None:
        """T1: synchronised engagement with the same items, TF-IDF cosine weighted"""
        users = {u for engagers in by_target.values() for u in engagers}
        n_users = len(users)
        if n_users < 2:
            return
        # Rarity weight (standard IDF): an item engaged by every account weighs 0,
        # so a viral post can't link its engagers; rarely engaged items weigh most
        idf = {
            x: math.log(n_users / len(engagers))
            for x, engagers in by_target.items()
        }
        norm_sq: Dict[int, float] = defaultdict(float)
        for x, engagers in by_target.items():
            for u in engagers:
                norm_sq[u] += idf[x] ** 2

        sync = self.coordination_sync_window * self.step_s
        t = state.event_time
        shared: Dict[Tuple[int, int], List[int]] = defaultdict(list)
        evidence: Dict[Tuple[int, int], Dict[int, List[MediaEvent]]] = defaultdict(
            lambda: defaultdict(list)
        )
        for x, engagers in by_target.items():
            if idf[x] <= 0:  # engaged by everyone: no evidence, not a shared target
                continue
            ids = sorted(engagers)
            for i in range(len(ids)):
                for j in range(i + 1, len(ids)):
                    u, v = ids[i], ids[j]
                    eu, ev = engagers[u], engagers[v]
                    if min(abs(t(a) - t(b)) for a in eu for b in ev) > sync:
                        continue
                    shared[(u, v)].append(x)
                    evidence[(u, v)][u].extend(eu)
                    evidence[(u, v)][v].extend(ev)

        # Independent-engagement null: u and v each engaged their observed number of
        # the items posted in the window, picked at random; chance overlap is
        # hypergeometric (fixes each account's activity level)
        window_items = {x for x, tgt in targets.items() if t(tgt) > window_start}
        n_items = len(window_items)
        engaged_in_window: Dict[int, int] = defaultdict(int)
        for x in window_items:
            for u in by_target[x]:
                engaged_in_window[u] += 1

        if n_items == 0 or not shared:
            return
        alpha = self.coordination_significance / len(shared)  # Bonferroni over pairs tested
        for (u, v), items in shared.items():
            if len(items) < self.coordination_min_shared_targets:
                continue
            denom = math.sqrt(norm_sq[u]) * math.sqrt(norm_sq[v])
            score = sum(idf[x] ** 2 for x in items) / denom if denom > 0 else 0.0
            if score < self.coordination_similarity_threshold:
                continue
            k = sum(1 for x in items if x in window_items)
            p_value = self._hypergeom_sf(
                k, n_items, engaged_in_window[u], engaged_in_window[v]
            )
            if p_value > alpha:
                continue
            add_edge(u, v, "co_engagement", score, evidence[(u, v)])

    def _co_content_edges(
        self, recent: List[MediaEvent], add_edge, state: SimulationState
    ) -> None:
        """T2: near-identical text from different accounts posted in sync"""
        t = state.event_time
        items = sorted(
            (
                e for e in recent
                if e.type in (EventType.POST, EventType.REPLY) and e.content
            ),
            key=t,
        )
        if len(items) < 2:
            return
        embeddings = self._coordination_content_embeddings(items)
        sync = self.coordination_sync_window * self.step_s
        matches: Dict[Tuple[int, int], List[Tuple[MediaEvent, MediaEvent]]] = defaultdict(list)
        best: Dict[Tuple[int, int], float] = defaultdict(float)
        for i, a in enumerate(items):
            for b in items[i + 1:]:
                if t(b) - t(a) > sync:
                    break
                if a.user_id == b.user_id:
                    continue
                sim = self._coordination_text_similarity(a, b, embeddings)
                if sim < self.coordination_content_similarity_threshold:
                    continue
                key = (a.user_id, b.user_id) if a.user_id < b.user_id else (b.user_id, a.user_id)
                matches[key].append((a, b))
                best[key] = max(best[key], sim)

        for (u, v), pairs in matches.items():
            if len(pairs) < self.coordination_min_content_matches:
                continue
            ev: Dict[int, List[MediaEvent]] = defaultdict(list)
            for a, b in pairs:
                ev[a.user_id].append(a)
                ev[b.user_id].append(b)
            add_edge(u, v, "co_content", best[(u, v)], ev)

    def _coordination_content_embeddings(self, items: List[MediaEvent]) -> Dict[int, Any]:
        """Normalized embeddings for co-content (one batched encode of new items), if enabled"""
        if not self.use_embedding_similarity_for_coordination or not self._init_embedder():
            return {}
        live = {e.event_id for e in items}
        cache = self._coordination_embeddings
        for eid in [eid for eid in cache if eid not in live]:
            del cache[eid]
        todo = [e for e in items if e.event_id not in cache]
        if todo:
            try:
                vecs = self._embedder.encode(
                    [" ".join(e.content.lower().split()) for e in todo],
                    convert_to_numpy=True,
                    normalize_embeddings=True,
                )
                for e, vec in zip(todo, vecs):
                    cache[e.event_id] = vec
            except Exception as ex:
                log.debug(f"Coordination embedding failed, using Jaccard: {ex}")
                return {}
        return cache

    def _coordination_text_similarity(
        self, a: MediaEvent, b: MediaEvent, embeddings: Dict[int, Any]
    ) -> float:
        va, vb = embeddings.get(a.event_id), embeddings.get(b.event_id)
        if va is not None and vb is not None:
            return float((va * vb).sum())  # normalized vectors -> cosine
        return self._jaccard_similarity(a.content, b.content)

    def _fast_amplification_edges(
        self, by_target, targets, window_start: float, add_edge, state: SimulationState
    ) -> None:
        """
        T3: an account engages another's top-level posts soon after they are posted,
        far more often than its own base rate would explain. For amplifier v and
        author u: k = u's posts in the window that v engaged within the sync window,
        n = u's posts in the window, null rate p_v = share of everyone else's posts
        in the window (other than u's) that v engaged that fast. Edge if
        k >= min_amplifications and P(Binomial(n, p_v) >= k) is significant after
        Bonferroni correction over the (amplifier, author) pairs tested.
        """
        sync = self.coordination_sync_window * self.step_s
        t = state.event_time
        posts = {
            x: tgt for x, tgt in targets.items()
            if tgt.type == EventType.POST and tgt.parent_id is None and t(tgt) > window_start
        }
        if not posts:
            return
        posts_by_author: Dict[int, int] = defaultdict(int)
        for tgt in posts.values():
            posts_by_author[tgt.user_id] += 1
        n_posts = len(posts)

        # (amplifier, author) -> post -> amplifier's engagements within sync of posting
        fast: Dict[Tuple[int, int], Dict[int, List[MediaEvent]]] = defaultdict(
            lambda: defaultdict(list)
        )
        fast_count: Dict[int, int] = defaultdict(int)  # amplifier -> fast-engaged posts
        for x, target in posts.items():
            for v, events in by_target.get(x, {}).items():
                quick = [e for e in events if 0 <= t(e) - t(target) <= sync]
                if quick:
                    fast[(v, target.user_id)][x].extend(quick)
                    fast_count[v] += 1

        if not fast:
            return
        alpha = self.coordination_significance / len(fast)  # Bonferroni over pairs tested
        for (v, u), items in fast.items():
            k = len(items)
            if k < self.coordination_min_amplifications:
                continue
            # v's fast-engagement rate on posts by neither v nor u (the null rate)
            others = n_posts - posts_by_author.get(v, 0) - posts_by_author[u]
            if others <= 0:
                continue
            p_v = (fast_count[v] - k) / others
            p_value = self._binomial_sf(k, posts_by_author[u], p_v)
            if p_value > alpha:
                continue
            ev: Dict[int, List[MediaEvent]] = defaultdict(list)
            for x, events in items.items():
                ev[v].extend(events)
                ev[u].append(targets[x])
            # Score: -log10 p-value (higher = less likely by chance)
            score = -math.log10(max(p_value, 1e-300))
            add_edge(v, u, "fast_amplification", score, ev)

    def _flag_coordination_groups(
        self,
        edges: Dict[Tuple[int, int], Dict[str, Any]],
        timestep: int,
        state: SimulationState,
        now_s: float,
    ) -> None:
        """Flag members of each linked group that have new (uncounted) evidence"""
        parent: Dict[int, int] = {}

        def find(a: int) -> int:
            parent.setdefault(a, a)
            while parent[a] != a:
                parent[a] = parent[parent[a]]
                a = parent[a]
            return a

        for u, v in edges:
            parent[find(u)] = find(v)
        groups: Dict[int, Set[int]] = defaultdict(set)
        for u, v in edges:
            groups[find(u)].update((u, v))

        for members in groups.values():
            group_edges = {k: e for k, e in edges.items() if k[0] in members}
            flagged_now: Set[int] = set()
            for agent_id in sorted(members):
                own: Dict[int, MediaEvent] = {}
                traces: Set[str] = set()
                partners: Set[int] = set()
                for (u, v), edge in group_edges.items():
                    if agent_id not in (u, v):
                        continue
                    traces.update(edge["traces"])
                    partners.add(v if agent_id == u else u)
                    for e in edge["evidence"].get(agent_id, []):
                        own[e.event_id] = e
                new = [
                    e for e in own.values()
                    if not self._is_flagged_evidence("coordination", e)
                ]
                if not new:
                    continue
                self.flag_agent(
                    agent_id,
                    f"coordinated behaviour with {sorted(partners)} "
                    f"({', '.join(sorted(traces))}; {len(new)} new evidence items)",
                    state,
                    timestep=timestep,
                    source="coordination",
                    time_s=now_s,
                )
                self._mark_flagged_evidence("coordination", list(own.values()), state)
                flagged_now.add(agent_id)

            for (u, v), edge in group_edges.items():
                if u in flagged_now or v in flagged_now:
                    self.coordination_edges.append(
                        {
                            "timestep": timestep,
                            "time_s": now_s,
                            "agents": [u, v],
                            "traces": dict(edge["traces"]),
                            "evidence_counts": {
                                str(a): len({e.event_id for e in evs})
                                for a, evs in edge["evidence"].items()
                            },
                        }
                    )
