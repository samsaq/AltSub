#!/usr/bin/env python3
"""
Output System: Generate output compatible with existing analysis tools

Generates daily snapshots and final output in formats expected by analyze_simulation.py
"""

import logging
import json
import os
from pathlib import Path
from typing import Dict, List, Any, Optional
from ..core.simulation_data import SimulationState, MediaEvent, EventType
from ..core.agent_manager import AgentManager
from ..core.time_model import SECONDS_PER_DAY

log = logging.getLogger(__name__)


class OutputManager:
    """Manages simulation output generation"""

    def __init__(self, output_dir: str = "simulation_output"):
        """
        Initialize output manager.

        Args:
            output_dir: Base output directory
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.snapshots_dir = self.output_dir / "daily_snapshots"
        self.snapshots_dir.mkdir(exist_ok=True)

        # Run-level settings written into every snapshot (belief model, axes)
        self.run_meta: Dict[str, Any] = {}

        log.info(f"OutputManager initialized: {self.output_dir}")

    def save_snapshot(
        self,
        timestep: int,
        day: int,
        state: SimulationState,
        agent_manager: AgentManager,
        mitigation_system: Optional[Any] = None,
    ) -> None:
        """
        Save daily snapshot in format compatible with analyze_simulation.py

        Args:
            timestep: Current timestep
            day: Current day (0-indexed)
            state: Current simulation state
            agent_manager: Agent manager for accessing agents
            mitigation_system: If given, the day's flags and current bans are
                written as "mitigation_data"
        """
        belief_states: Dict[str, Dict[str, float]] = {}
        belief_texts: Dict[str, Dict[str, str]] = {}  # agent_id -> {canonical_id: text}
        for agent_id, agent in agent_manager.agents.items():
            agent_beliefs = state.belief_network.get_agent_beliefs(agent_id)
            if agent_beliefs:
                belief_states[str(agent_id)] = agent_beliefs
            
            # Collect belief texts if available (from agent or state registry)
            if hasattr(agent, "belief_texts") and agent.belief_texts:
                belief_texts[str(agent_id)] = agent.belief_texts.copy()
            elif state.belief_text_registry:
                # Fallback: use state registry for all agent beliefs
                agent_texts = {
                    belief_id: state.belief_text_registry.get(belief_id, "")
                    for belief_id in agent_beliefs.keys()
                    if belief_id in state.belief_text_registry
                }
                if agent_texts:
                    belief_texts[str(agent_id)] = agent_texts

        # Collect events for this day (by simulated time, so any timestep length works)
        day_start = day * SECONDS_PER_DAY
        day_end = (day + 1) * SECONDS_PER_DAY

        def in_day(time_s: float) -> bool:
            return day_start <= time_s < day_end

        def record_time(record: Dict[str, Any]) -> float:
            """Seconds of a flag/edge record (time_s, else its timestep)."""
            if record.get("time_s") is not None:
                return float(record["time_s"])
            return float(record.get("timestep", -1)) * step_s

        step_s = state.timestep_duration_seconds
        day_events = [
            {
                "event_id": e.event_id,
                "user_id": e.user_id,
                "parent_id": e.parent_id,
                "type": e.type.value,
                "belief_id": e.belief_id,
                "subreddit_id": e.subreddit_id,
                "timestamp": e.timestamp,
                "time_s": state.event_time(e),
                "score": e.score,
                "content": e.content,
                # Voter IDs so far (same fields as media_events.json)
                "upvotes": list(e.upvotes),
                "downvotes": list(e.downvotes),
            }
            for e in state.events
            if in_day(state.event_time(e))
        ]

        snapshot = {
            "day": day,
            "timestep": timestep,
            # Seconds per reference timestep (timestamp/timestep fields are in
            # reference timesteps; time_s fields are simulated seconds)
            "time_unit_seconds": step_s,
            **self.run_meta,
            "simulation_data": {
                "belief_states": belief_states,
                "events": day_events,
                "total_events": len(day_events),
            },
        }
        
        if belief_texts:
            snapshot["simulation_data"]["belief_texts"] = belief_texts
        
        if state.belief_text_registry:
            snapshot["simulation_data"]["belief_text_registry"] = state.belief_text_registry.copy()

        # Mitigation state: cumulative flags, current bans, and the flags raised today
        if mitigation_system is not None:
            snapshot["mitigation_data"] = {
                "flagged_agents": {
                    str(k): v for k, v in getattr(mitigation_system, "mitigation_flags", {}).items()
                },
                "banned_agents": [
                    str(agent_id)
                    for agent_id, by_sub in state.banned_agent_network.ban_counts.items()
                    if by_sub and sum(by_sub.values()) > 0
                ],
                "flags_today": [
                    f for f in getattr(mitigation_system, "flag_log", [])
                    if in_day(record_time(f))
                ],
                # Co-action network edges behind today's coordination flags
                "coordination_edges_today": [
                    e for e in getattr(mitigation_system, "coordination_edges", [])
                    if in_day(record_time(e))
                ],
            }

        # Biased moderator actions taken today
        biased_mods = agent_manager.get_agents_by_type("biased_moderator")
        if biased_mods:
            snapshot["biased_moderation_log"] = [
                {**vars(action), "moderator_id": mod.agent_id}
                for mod in biased_mods
                for action in getattr(mod, "moderation_log", [])
                if in_day(record_time(vars(action)))
            ]

        snapshot_file = self.snapshots_dir / f"day_{day}_data.json"
        with open(snapshot_file, "w") as f:
            json.dump(snapshot, f, indent=2)

        log.debug(f"Saved snapshot for day {day} to {snapshot_file}")

    def save_media_events(self, state: SimulationState) -> None:
        """
        Save all media events to JSON file.

        Format matches what analyze_simulation.py expects.
        """
        events_file = self.output_dir / "media_events.json"

        events_data = [
            {
                "event_id": e.event_id,
                "user_id": e.user_id,
                "parent_id": e.parent_id,
                "type": e.type.value,
                "belief_id": e.belief_id,
                "subreddit_id": e.subreddit_id,
                "timestamp": e.timestamp,
                "time_s": state.event_time(e),
                "score": e.score,
                "content": e.content,
                "upvotes": e.upvotes,
                "downvotes": e.downvotes,
                "replies": e.replies,
                "seed": bool((e.indexes or {}).get("seed")),
            }
            for e in state.events
        ]

        with open(events_file, "w") as f:
            json.dump(events_data, f, indent=2)

        log.info(f"Saved {len(events_data)} media events to {events_file}")

    def save_final_output(
        self,
        state: SimulationState,
        agent_manager: AgentManager,
        mitigation_system: Optional[Any] = None,
        total_run_time_seconds: Optional[float] = None,
        orchestrator: Optional[Any] = None,
        run_info: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Save final simulation state for analysis.

        Includes:
        - Final belief states
        - Final event counts
        - Agent statistics
        - Mitigation summary (bans, flag counts by agent) if mitigation_system provided
        - Total run time (seconds) if total_run_time_seconds provided
        - Per-day campaign plan source (LLM / repaired / fallback) if orchestrator provided
        - Commit refusals and cascaded removals (integrity counters)
        - run_info: engine settings (time model, seed, resolved durations), merged in
        """
        final_output = {
            "final_belief_states": {
                str(agent_id): state.belief_network.get_agent_beliefs(agent_id)
                for agent_id in agent_manager.agents.keys()
            },
            # Agent activity only; seed content (pre-existing Reddit posts and
            # comments, core/seed_content.py) is counted under seed_events
            "total_events": sum(1 for e in state.events if not (e.indexes or {}).get("seed")),
            "event_counts_by_type": {
                event_type.value: sum(
                    1 for e in state.events
                    if e.type == event_type and not (e.indexes or {}).get("seed")
                )
                for event_type in EventType
            },
            "seed_events": {
                "posts": sum(1 for e in state.events if (e.indexes or {}).get("seed") and e.type == EventType.POST),
                "replies": sum(1 for e in state.events if (e.indexes or {}).get("seed") and e.type == EventType.REPLY),
            },
            "agent_counts_by_type": {
                agent_type: len(agent_manager.get_agents_by_type(agent_type))
                for agent_type in [
                    "llm_user",
                    "llm_attacker",
                    "template_attacker",
                    "biased_moderator",
                ]
            },
            "time_unit_seconds": state.timestep_duration_seconds,
            # Actions refused at commit (target removed, author banned, repeat vote)
            "commit_rejections": dict(getattr(agent_manager, "commit_rejections", {})),
            "removed_by_cascade": getattr(state, "removed_by_cascade", 0),
            "items_read": getattr(agent_manager, "items_read", 0),
        }
        if run_info:
            final_output.update(run_info)

        # Add mitigation summary for analysis readout (bans, flags, attacker vs other)
        if mitigation_system is not None:
            banned_agent_ids = [
                agent_id
                for agent_id, by_sub in state.banned_agent_network.ban_counts.items()
                if by_sub and sum(by_sub.values()) > 0
            ]
            flag_counts = getattr(
                mitigation_system, "mitigation_flags", {}
            )
            agent_type_by_id = {
                str(agent_id): getattr(agent, "agent_type", "unknown")
                for agent_id, agent in agent_manager.agents.items()
            }
            # Per agent: flags by source (duplicate / rate_limit / coordination /
            # rule_moderator), first flag time per source, and when the
            # mitigation system banned it (simulated seconds). Used by the
            # account-level MCC in tools/parameter_tuning.py.
            flags_by_source: Dict[str, Dict[str, int]] = {}
            first_flag_s: Dict[str, Dict[str, float]] = {}
            ban_time_s: Dict[str, float] = {}
            for rec in getattr(mitigation_system, "flag_log", []):
                aid, src = str(rec.get("agent_id")), str(rec.get("source", "unknown"))
                t = rec.get("time_s")
                by_src = flags_by_source.setdefault(aid, {})
                by_src[src] = by_src.get(src, 0) + 1
                if t is not None:
                    firsts = first_flag_s.setdefault(aid, {})
                    firsts[src] = min(firsts.get(src, float(t)), float(t))
                    if rec.get("banned") and aid not in ban_time_s:
                        ban_time_s[aid] = float(t)
            final_output["mitigation_summary"] = {
                "banned_agent_ids": banned_agent_ids,
                "flag_counts_by_agent": {str(k): v for k, v in flag_counts.items()},
                "flag_counts_by_source": flags_by_source,
                "first_flag_time_s_by_source": first_flag_s,
                "mitigation_ban_time_s": ban_time_s,
                "agent_type_by_id": agent_type_by_id,
                "coordination_edges": list(
                    getattr(mitigation_system, "coordination_edges", [])
                ),
            }

        # Attacker amplification counts (scheduled / executed / skipped)
        hub = getattr(agent_manager, "coordination_hub", None)
        if hub is not None:
            final_output["attacker_coordination"] = {
                "coordination_strength": hub.coordination_strength,
                "comment_prob": hub.comment_prob,
                "delay_min": hub.delay_min,
                "delay_max": hub.delay_max,
                **hub.stats,
            }

        if total_run_time_seconds is not None:
            final_output["total_run_time_seconds"] = round(total_run_time_seconds, 2)

        # Which campaign days ran on a fallback plan (1 generic post) vs an LLM plan
        if orchestrator is not None:
            final_output["campaign_plans"] = [
                {
                    "day": plan.date,
                    "source": getattr(plan, "source", "ok"),
                    "num_posts": len(plan.target_posts),
                    "fallback_reason": getattr(plan, "fallback_reason", ""),
                }
                for plan in getattr(orchestrator, "daily_plans", [])
            ]

        final_file = self.output_dir / "final_output.json"
        with open(final_file, "w") as f:
            json.dump(final_output, f, indent=2)

        log.info(f"Saved final output to {final_file}")
