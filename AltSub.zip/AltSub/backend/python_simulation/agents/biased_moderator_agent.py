#!/usr/bin/env python3
"""
Biased Moderator Agent: LLM-powered biased moderator

"""

import logging
import json
import math
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Set

if TYPE_CHECKING:
    from ..core.feed_system import FeedManager
from dataclasses import dataclass
import numpy as np
from ..core.simulation_data import SimulationState, MediaEvent, EventType
from ..core.belief_axes import ACCEPTANCE_SCALE, format_acceptance
from .base_agent import BaseAgent
from ..services.llm_json import require_unit_floats

try:
    from ..services.llm_reddit_service import LLMRedditService, LLMServiceConfig
except ImportError:
    LLMRedditService = None
    LLMServiceConfig = None

log = logging.getLogger(__name__)


def _content_preview(content: Optional[str], max_len: int = 120) -> str:
    if not content:
        return ""
    one_line = content.replace("\n", " ").strip()
    if len(one_line) <= max_len:
        return one_line
    return one_line[: max_len - 3] + "..."

@dataclass
class ContentAnalysis:
    """Result of content analysis"""

    contradicts_beliefs: bool = False
    contradiction_score: float = 0.0
    public_justification: str = ""
    private_reasoning: str = ""
    # False when the LLM call or JSON parse failed (result is the default "keep")
    succeeded: bool = False


@dataclass
class ModerationAction:
    """Record of a moderation action"""

    timestep: int
    target_agent_id: int
    event_id: int
    content: str
    public_justification: str
    private_reasoning: str
    contradiction_score: float
    action_type: str  # "remove_post", "remove_comment", "ban_user"
    time_s: Optional[float] = None  # simulated time of the scan in seconds


class BiasedModeratorAgent(BaseAgent):
    """LLM-powered biased moderator"""

    def __init__(
        self,
        agent_id: int,
        beliefs: Dict[str, float],
        subreddit_id: str,
        activity_weights: Dict[str, float],
        activity_schedule: np.ndarray,
        risk_tolerance: float = 0.5,
        detection_threshold: float = 0.7,
        subreddit_rules_text: str = "Be civil. No personal attacks. Stay on topic.",
        biased_mod_beliefs_file: str = "biased_moderator_beliefs.json",
        llm_service: Optional[LLMRedditService] = None,
        scan_frequency: int = 12,  # every hour for 5 min timesteps
        feed_manager: Optional["FeedManager"] = None,
        target_narrative: str = "",
        campaign_belief_texts: Optional[Dict[str, str]] = None,
    ):
        """
        Initialize biased moderator agent.

        Args:
            agent_id: Unique agent identifier
            beliefs: Campaign-distilled beliefs from agent profile (preferred)
            subreddit_id: Subreddit this agent moderates
            activity_weights: Dict of action -> probability/weight
            activity_schedule: Boolean array (moderators are always active)
            risk_tolerance: Risk tolerance (0-1, higher = more aggressive)
            detection_threshold: Minimum contradiction score to consider action
            subreddit_rules_text: Text of subreddit rules
            biased_mod_beliefs_file: Fallback JSON when profile beliefs are empty
            llm_service: LLMRedditService instance
            scan_frequency: Timesteps between scans
            target_narrative: Campaign narrative (same as attackers)
            campaign_belief_texts: belief_id -> text from initializer (for LLM prompts)
        """
        file_beliefs = self._load_beliefs(biased_mod_beliefs_file)
        if beliefs:
            moderator_beliefs = dict(beliefs)
        elif file_beliefs:
            moderator_beliefs = file_beliefs
            log.info(
                "Biased moderator %s: using beliefs from file (profile had none)",
                agent_id,
            )
        else:
            moderator_beliefs = {}
            log.warning(
                "Biased moderator %s: no profile beliefs and no readable file %s",
                agent_id,
                biased_mod_beliefs_file,
            )

        super().__init__(
            agent_id=agent_id,
            agent_type="biased_moderator",
            beliefs=moderator_beliefs,
            subreddit_id=subreddit_id,
            activity_weights=activity_weights,
            activity_schedule=activity_schedule,
        )

        self.risk_tolerance = risk_tolerance
        self.detection_threshold = detection_threshold
        self.subreddit_rules_text = subreddit_rules_text
        self.scan_frequency = scan_frequency
        self.last_scan_time = -999
        self._last_scan_s: Optional[float] = None  # seconds, for the lookback
        self.feed_manager = feed_manager
        self.target_narrative = (target_narrative or "").strip()
        self.campaign_belief_texts = dict(campaign_belief_texts or {})
        # Belief axes model: campaign target position per axis (axes set by run_simulation)
        self.campaign_targets: Dict[str, float] = {}

        self.moderation_log: List[ModerationAction] = []

        # Events already judged; the overlapping scan lookback would otherwise judge them twice
        self.judged_event_ids: Set[int] = set()

        if llm_service is None:
            if LLMRedditService is None:
                log.warning(f"LLMRedditService not available for moderator {agent_id}")
                self.llm_service = None
            else:
                config = LLMServiceConfig()
                self.llm_service = LLMRedditService(config)
        else:
            self.llm_service = llm_service

        log.debug(
            "BiasedModeratorAgent %s initialized "
            "(risk_tolerance=%s, threshold=%s, narrative_chars=%s, belief_count=%s)",
            agent_id,
            risk_tolerance,
            detection_threshold,
            len(self.target_narrative),
            len(self.beliefs),
        )

    def _load_beliefs(self, beliefs_file: str) -> Dict[str, float]:
        """Load moderator beliefs from JSON file"""
        try:
            with open(beliefs_file, "r") as f:
                beliefs_json = json.load(f)

            beliefs = {}
            for belief_id, strength in beliefs_json.items():
                if isinstance(strength, (int, float)):
                    beliefs[belief_id] = float(strength)

            log.info(f"Loaded {len(beliefs)} moderator beliefs from {beliefs_file}")
            return beliefs
        except Exception as e:
            log.error(f"Error loading moderator beliefs from {beliefs_file}: {e}")
            return {}

    def should_scan(self, timestep: int) -> bool:
        """Check if moderator should scan at this timestep"""
        return (timestep - self.last_scan_time) >= self.scan_frequency

    def moderate(
        self,
        timestep: int,
        state: SimulationState,
        now_s: Optional[float] = None,
        executor: Optional[Any] = None,
    ) -> None:
        """
        Moderate content: scan recent posts and remove/ban if needed.

        Discrete engine: called from the cleanup phase (main thread) when the
        moderator is active; scans every scan_frequency timesteps. Event engine:
        called (with now_s, bypassing should_scan) by a scheduled scan event.
        Items are judged as soon as a scan sees them (no moderation delay);
        judged_event_ids prevents re-judging items seen by an earlier,
        overlapping scan. The lookback reaches back to one scan interval before
        the previous scan, so nothing is missed after a period of inactivity.

        executor: optional thread pool; the LLM reviews then run in parallel
        and decisions are still applied in event order.
        """
        if now_s is None:
            if not self.should_scan(timestep):
                return
            now_s = timestep * state.timestep_duration_seconds

        self.last_scan_time = timestep
        interval_s = self.scan_frequency * state.timestep_duration_seconds
        window_start = (
            self._last_scan_s - interval_s if self._last_scan_s is not None else -math.inf
        )
        self._last_scan_s = now_s

        recent_events = [
            e
            for e in state.events
            if state.event_time(e) > window_start
            and state.event_time(e) <= now_s
            and e.subreddit_id == self.subreddit_id
            and e.type in (EventType.POST, EventType.REPLY)
        ]

        log.info(
            "Biased moderator %s: scan at timestep=%s - %s posts/comments in lookback window "
            "(will evaluate those not already judged)",
            self.agent_id,
            timestep,
            len(recent_events),
        )

        # Skip empty content and content already judged in an earlier scan
        to_judge = [
            e for e in recent_events
            if e.content and e.event_id not in self.judged_event_ids
        ]
        for event in to_judge:
            log.info(
                "Biased moderator %s: analyzing %s for narrative alignment - event_id=%s "
                "author=%s r/%s timestep=%s preview=%r",
                self.agent_id,
                "post" if event.type == EventType.POST else "comment",
                event.event_id,
                event.user_id,
                self.subreddit_id,
                timestep,
                _content_preview(event.content),
            )
        contents = [e.content for e in to_judge]
        if executor is not None:
            analyses = list(executor.map(self.analyze_content, contents))
        else:
            analyses = [self.analyze_content(c) for c in contents]

        action_threshold = 0.9 - (self.risk_tolerance * 0.4)
        for event, analysis in zip(to_judge, analyses):
            # Failed analyses stay unjudged so a later scan can retry them
            if analysis.succeeded:
                self.judged_event_ids.add(event.event_id)
            # Removed earlier in this scan (part of a removed thread)
            if state.get_event(event.event_id) is None:
                continue

            if analysis.contradicts_beliefs and self.should_take_action(
                analysis.contradiction_score
            ):
                action_type = (
                    "remove_post" if event.type == EventType.POST else "remove_comment"
                )

                action = ModerationAction(
                    timestep=timestep,
                    target_agent_id=event.user_id,
                    event_id=event.event_id,
                    content=event.content,
                    public_justification=analysis.public_justification,
                    private_reasoning=analysis.private_reasoning,
                    contradiction_score=analysis.contradiction_score,
                    action_type=action_type,
                    time_s=now_s,
                )

                self.moderation_log.append(action)

                log.info(
                    "Biased moderator %s: REMOVING %s - event_id=%s author=%s "
                    "contradiction_score=%.2f (detection_threshold=%.2f, action_threshold=%.2f) "
                    "public_justification=%r",
                    self.agent_id,
                    action_type,
                    event.event_id,
                    event.user_id,
                    analysis.contradiction_score,
                    self.detection_threshold,
                    action_threshold,
                    analysis.public_justification,
                )

                # Remove event (and its thread) from state and unread feeds
                removed = state.remove_event(event.event_id)
                if self.feed_manager is not None:
                    self.feed_manager.remove_events_from_all_feeds(removed)

                # Check if user should be banned (3 strikes rule)
                violation_count = sum(
                    1 for a in self.moderation_log if a.target_agent_id == event.user_id
                )

                if violation_count >= 3 and not state.banned_agent_network.is_banned(
                    event.user_id, self.subreddit_id
                ):
                    state.banned_agent_network.increment_ban(
                        event.user_id, self.subreddit_id
                    )

                    ban_action = ModerationAction(
                        timestep=timestep,
                        target_agent_id=event.user_id,
                        event_id=event.event_id,
                        content=event.content,
                        public_justification=analysis.public_justification,
                        private_reasoning=analysis.private_reasoning,
                        contradiction_score=analysis.contradiction_score,
                        action_type="ban_user",
                        time_s=now_s,
                    )
                    self.moderation_log.append(ban_action)

                    log.info(
                        "Biased moderator %s: BANNED user %s after %s moderation strikes on r/%s",
                        self.agent_id,
                        event.user_id,
                        violation_count,
                        self.subreddit_id,
                    )

            else:
                log.info(
                    "Biased moderator %s: no removal - event_id=%s contradicts_beliefs=%s "
                    "score=%.2f (need contradicts=true, score≥detection %.2f and ≥action %.2f)",
                    self.agent_id,
                    event.event_id,
                    analysis.contradicts_beliefs,
                    analysis.contradiction_score,
                    self.detection_threshold,
                    action_threshold,
                )

        log.info(
            "Biased moderator %s: scan complete timestep=%s - LLM-evaluated items=%s",
            self.agent_id,
            timestep,
            len(to_judge),
        )

    def analyze_content(self, content: str) -> ContentAnalysis:
        """Analyze content using LLM"""
        result = ContentAnalysis()

        if self.llm_service is None:
            log.info(
                "Biased moderator %s: skip LLM content analysis (no LLM service)",
                self.agent_id,
            )
            return result

        belief_lines: List[str] = []
        if self.axes:
            # Belief statements: the campaign's target acceptance, with the scale
            belief_lines.append(f"  (acceptance: {ACCEPTANCE_SCALE})")
            for axis in self.axes:
                if axis.id in self.campaign_targets:
                    belief_lines.append(
                        f"  - {format_acceptance(axis, self.campaign_targets[axis.id])}"
                    )
        else:
            for belief_id, strength in self.beliefs.items():
                label = self.campaign_belief_texts.get(belief_id, belief_id)
                belief_lines.append(f"  - {label} (weight {strength:.2f})")
        beliefs_block = "\n".join(belief_lines) if belief_lines else "  (none)"
        narrative_block = self.target_narrative or "(not specified)"

        try:
            prompt = f"""Analyze this Reddit content for moderation.

The moderator enforces alignment with this campaign narrative (same side as astroturfing attackers):
\"\"\"{narrative_block}\"\"\"

Distilled commitments derived from that narrative (treat opposing or undermining content as contradicting):
{beliefs_block}

Content to evaluate:
\"\"\"{content}\"\"\"

Subreddit Rules: {self.subreddit_rules_text}

Determine if this content contradicts the narrative/commitments above strongly enough that a biased moderator aligned with that narrative would remove it (not merely disagree).

Return ONLY valid JSON (no markdown, no backticks, no commentary) with the exact keys:
{{
    "contradicts_beliefs": true/false,
    "contradiction_score": 0.0-1.0,
    "public_justification": "Public reason for removal",
    "private_reasoning": "Private reasoning for decision"
}}"""

            parsed = self.llm_service._complete_json(
                prompt,
                temperature=0.1,
                max_tokens=self.llm_service.config.max_tokens,
                validate=require_unit_floats(
                    "contradiction_score", defaults={"contradiction_score": 0.0}
                ),
                label=f"Biased moderator {self.agent_id}",
            )
            if not parsed.ok:
                raise ValueError(
                    f"{parsed.error}. Response preview={_content_preview(parsed.raw, 160)!r}"
                )
            analysis_data = parsed.data

            raw_contradicts = analysis_data.get("contradicts_beliefs", False)
            if isinstance(raw_contradicts, bool):
                result.contradicts_beliefs = raw_contradicts
            else:
                result.contradicts_beliefs = (
                    str(raw_contradicts).strip().lower() in ("true", "1", "yes")
                )
            result.contradiction_score = analysis_data["contradiction_score"]
            result.public_justification = analysis_data.get("public_justification", "")
            result.private_reasoning = analysis_data.get("private_reasoning", "")
            result.succeeded = True

        except Exception as e:
            # Keep logs readable; don't dump entire LLM response.
            log.error(
                "[Biased Mod] Error analyzing content (json parse/extract failed): %s | content_preview=%r",
                e,
                _content_preview(content, 120),
            )

        return result

    def should_take_action(self, contradiction_score: float) -> bool:
        """Determine if moderator should take action based on contradiction score"""
        # Must exceed detection threshold
        if contradiction_score < self.detection_threshold:
            return False

        # Risk tolerance affects aggressiveness
        # High tolerance = more willing to act on borderline content
        # Low tolerance = only act on clear violations
        action_threshold = 0.9 - (self.risk_tolerance * 0.4)

        return contradiction_score >= action_threshold

    def generate_post_events(
        self, timestep: int, state: SimulationState
    ) -> List[MediaEvent]:
        """Moderators don't generate posts.

        Moderation runs from run_simulation's cleanup phase on the main thread,
        not here: the think phase may run agents in worker threads, and removing
        events there would race with other agents reading state.
        """
        return []

    def parse(self, event: MediaEvent, state: SimulationState) -> None:
        """Moderators don't parse events for belief updates"""
        pass

    def reads_feed(self) -> bool:
        """The biased moderator works by periodic scans, not by reading a feed
        (in the discrete engine its feed pass does nothing)."""
        return False

    def reply(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """Moderators don't reply"""
        return None

    def upvote(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """Moderators don't vote"""
        return None

    def downvote(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[MediaEvent]:
        """Moderators don't vote"""
        return None
