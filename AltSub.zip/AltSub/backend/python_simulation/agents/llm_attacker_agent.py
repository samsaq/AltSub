#!/usr/bin/env python3
"""
LLM Attacker Agent: LLM-powered attacker with campaign coordination

Ports functionality from the old attacker_reddit_integration.cpp
"""

import logging
from typing import Dict, List, Optional, Any
import numpy as np
from ..core.simulation_data import SimulationState, MediaEvent, EventType
from ..core.thread_context import thread_context
from ..core.belief_axes import strongest_axis
from .base_agent import BaseAgent, Job
from .attacker_activity import AttackerActivityMixin

try:
    from ..services.llm_reddit_service import LLMRedditService, LLMServiceConfig
except ImportError:
    LLMRedditService = None
    LLMServiceConfig = None

try:
    from ..services.attacker_campaign_orchestrator import (
        AttackerCampaignOrchestrator,
        CampaignInstruction,
    )
except ImportError:
    AttackerCampaignOrchestrator = None
    CampaignInstruction = None

log = logging.getLogger(__name__)


class LLMAttackerAgent(AttackerActivityMixin, BaseAgent):
    """LLM-powered attacker with campaign coordination"""

    def __init__(
        self,
        agent_id: int,
        beliefs: Dict[str, float],
        subreddit_id: str,
        activity_weights: Dict[str, float],
        activity_schedule: np.ndarray,
        campaign_id: str = "default_campaign",
        coordination_strength: float = 0.8,
        attack_intensity: float = 0.6,
        llm_service: Optional[LLMRedditService] = None,
        orchestrator: Optional[AttackerCampaignOrchestrator] = None,
        campaign_brief: str = "",
        canonicalizer: Optional[Any] = None,
        session_duration: str = "medium",
    ):
        """
        Initialize LLM attacker agent.

        Args:
            agent_id: Unique agent identifier
            beliefs: Initial beliefs dict[belief_id, strength] (campaign-aligned)
            subreddit_id: Subreddit this agent belongs to
            activity_weights: Dict of action -> probability/weight
            activity_schedule: Boolean array indicating natural activity times
            campaign_id: Campaign identifier
            coordination_strength: How much attackers support each other (0-1)
            attack_intensity: How direct and forceful attacks are (0-1)
            llm_service: LLMRedditService instance
            orchestrator: AttackerCampaignOrchestrator instance for instructions
            session_duration: Session category (short/medium/long) for campaign
                sessions after instruction posts
        """
        super().__init__(
            agent_id=agent_id,
            agent_type="llm_attacker",
            beliefs=beliefs,
            subreddit_id=subreddit_id,
            activity_weights=activity_weights,
            activity_schedule=activity_schedule,
        )

        self.campaign_id = campaign_id
        self.coordination_strength = coordination_strength
        self.attack_intensity = attack_intensity
        self.natural_activity_schedule = activity_schedule.copy()

        # Campaign instructions; coordination targets live in AttackerActivityMixin
        self.pending_instructions: List[CampaignInstruction] = []
        self._init_attacker_activity(session_duration)

        if llm_service is None:
            if LLMRedditService is None:
                log.warning(f"LLMRedditService not available for attacker {agent_id}")
                self.llm_service = None
            else:
                config = LLMServiceConfig()
                self.llm_service = LLMRedditService(config)
        else:
            self.llm_service = llm_service

        self.orchestrator = orchestrator
        # Campaign narrative given to the LLM when this attacker writes its own
        # posts and replies (campaign posts come from the orchestrator)
        self.campaign_brief = campaign_brief or ""
        self.canonicalizer = canonicalizer

        log.debug(f"LLMAttackerAgent {agent_id} initialized (campaign: {campaign_id})")

    def _strongest_belief(self) -> str:
        if self.axes:
            return strongest_axis(self.beliefs)
        return (
            max(self.beliefs.items(), key=lambda x: x[1])[0] if self.beliefs else "default"
        )

    def _make_post(self, content: str, belief_id: str) -> MediaEvent:
        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=None,
            type=EventType.POST,
            belief_id=belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
            content=content,
        )

    def instruction_post(self, instruction: Any) -> Optional[MediaEvent]:
        """The post for a campaign instruction (content written by the
        orchestrator), or None if the instruction has no content."""
        content = getattr(instruction, "content", None)
        if not content:
            log.warning(
                f"LLMAttackerAgent {self.agent_id}: instruction for campaign "
                f"{self.campaign_id} has no content; skipped"
            )
            return None
        return self._make_post(content, self._strongest_belief())

    def generate_post_events(
        self, timestep: int, state: SimulationState
    ) -> List[MediaEvent]:
        """Generate new post events for this timestep"""
        # Check for a due campaign instruction first (is_active / AttackerActivityMixin)
        instruction = self._due_instruction(timestep)

        if instruction:
            # Campaign-activated: use post content directly from orchestrator instruction
            post = self.instruction_post(instruction)
            if post is None:
                instruction.executed = True  # nothing to post; don't retry it
                return []
            # Post once per instruction, then browse for a campaign session
            self._complete_instruction(instruction, timestep)
            return [post]

        if (
            self.natural_activity_schedule[timestep]
            if timestep < len(self.natural_activity_schedule)
            else False
        ):
            post_prob = self.get_action_probability("post")
            if self.rng.random() < post_prob:
                post = self.natural_post_job(state)()
                return [post] if post is not None else []

        return []

    def natural_post_job(self, state: SimulationState) -> Job:
        """Job writing a natural (non-campaign) post from a belief snapshot."""
        beliefs = dict(self.beliefs)
        belief_id = self._strongest_belief()
        if self.llm_service is None:
            content = f"Natural post from attacker {self.agent_id}"
            return lambda: self._make_post(content, belief_id)
        text_map = dict(getattr(state, "belief_text_registry", {}))

        def run() -> MediaEvent:
            content = self.llm_service.generate_post_content(
                agent_beliefs=beliefs,
                trust_network={},
                subreddit=self.subreddit_id,
                context_posts=None,
                agent_id=self.agent_id,
                belief_id_to_text=text_map,
                axes=self.axes,
                campaign_brief=self.campaign_brief,
            )
            return self._make_post(content, belief_id)

        return run

    def parse(self, event: MediaEvent, state: SimulationState) -> None:
        """
        Parse an event from feed.

        NOTE: Attackers do NOT update their beliefs based on content they see.
        They maintain fixed campaign-aligned beliefs to act as stubborn advocates.
        This is a key distinction from regular LLM users who update beliefs.
        """
        # Attackers maintain fixed beliefs - no updates

    def reply(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """
        Generate a reply to an event. Used for natural replies (probability
        rolled by should_reply) and for coordinated comments (CoordinationHub).
        """
        return self.reply_job(event, state)()

    def reply_job(self, event: MediaEvent, state: SimulationState) -> Job:
        """Job writing a reply from a snapshot of beliefs and the parent."""
        beliefs = dict(self.beliefs)
        belief_id = self._strongest_belief()
        text_map = dict(getattr(state, "belief_text_registry", {}))
        parent_id, parent_content = event.event_id, event.content
        thread = thread_context(event, state)

        def run() -> MediaEvent:
            if self.llm_service is None:
                content = "Interesting point!"
            else:
                content = self.llm_service.generate_reply_content(
                    parent_content=parent_content,
                    agent_beliefs=beliefs,
                    subreddit=self.subreddit_id,
                    agent_id=self.agent_id,
                    belief_id_to_text=text_map,
                    axes=self.axes,
                    thread=thread,
                    campaign_brief=self.campaign_brief,
                )
            return MediaEvent(
                event_id=0,
                user_id=self.agent_id,
                parent_id=parent_id,
                type=EventType.REPLY,
                belief_id=belief_id,
                subreddit_id=self.subreddit_id,
                timestamp=self.clock_timestep,  # Set at commit
                content=content,
            )

        return run

    def upvote(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """
        Generate an upvote event (vote probability is rolled by choose_vote).
        Coordinated and natural upvotes produce the same event.
        """
        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.UPVOTE,
            belief_id=event.belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
        )

    def downvote(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[MediaEvent]:
        """
        Generate a downvote event (vote probability is rolled by choose_vote).
        Stance-blind like regular users, so attacker voting blends in.
        """
        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.DOWNVOTE,
            belief_id=event.belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
        )
