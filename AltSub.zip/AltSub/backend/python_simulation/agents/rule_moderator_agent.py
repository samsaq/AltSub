#!/usr/bin/env python3
"""
Rule Moderator Agent: LLM reviews feed items against subreddit rules only;
escalates via MitigationSystem.flag_agent (shared ban threshold with other mitigations).
"""

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Tuple

if TYPE_CHECKING:
    from ..core.feed_system import FeedManager

import numpy as np

from ..core.simulation_data import EventType, MediaEvent, SimulationState
from .base_agent import BaseAgent
from ..services.llm_json import require_unit_floats

try:
    from ..services.llm_reddit_service import LLMRedditService, LLMServiceConfig
except ImportError:
    LLMRedditService = None
    LLMServiceConfig = None

log = logging.getLogger(__name__)


def _content_preview(content: Optional[str], max_len: int = 120) -> str:
    if not content:
        return ""
    one_line = content.replace("\n", " ").strip()
    if len(one_line) <= max_len:
        return one_line
    return one_line[: max_len - 3] + "..."

@dataclass
class RuleAnalysis:
    violates_rules: bool = False
    confidence: float = 0.0
    reason: str = ""


class RuleModeratorAgent(BaseAgent):
    """Feed-driven moderator: rules-only LLM check; flags feed authors via MitigationSystem."""

    def __init__(
        self,
        agent_id: int,
        beliefs: Dict[str, float],
        subreddit_id: str,
        activity_weights: Dict[str, float],
        activity_schedule: np.ndarray,
        mitigation_system: Any,
        subreddit_rules_text: str = "Be civil. No harassment. Stay on topic.",
        detection_threshold: float = 0.7,
        llm_service: Optional["LLMRedditService"] = None,
    ):
        super().__init__(
            agent_id=agent_id,
            agent_type="rule_moderator",
            beliefs=beliefs,
            subreddit_id=subreddit_id,
            activity_weights=activity_weights,
            activity_schedule=activity_schedule,
        )
        self.mitigation_system = mitigation_system
        self.subreddit_rules_text = subreddit_rules_text
        self.detection_threshold = detection_threshold
        # Violations found while reading, applied by flush_pending_moderation:
        # (event_id, author_id, reason)
        self._pending_violations: List[Tuple[int, int, str]] = []
        # Items this moderator removed (each also produced one author flag)
        self.removed_event_ids: List[int] = []

        if llm_service is None:
            if LLMRedditService is None:
                log.warning("LLMRedditService not available for rule moderator %s", agent_id)
                self.llm_service = None
            else:
                self.llm_service = LLMRedditService(LLMServiceConfig())
        else:
            self.llm_service = llm_service

    def set_communicate_timestep(self, timestep: int) -> None:
        """Called by AgentManager before processing this agent's feed."""
        self.set_clock(timestep)

    def flush_pending_moderation(
        self, state: SimulationState, feed_manager: Optional["FeedManager"]
    ) -> None:
        """For each violation found while reading: if the item still exists,
        remove it (with its thread) from state and all feeds, then flag its
        author. An item already removed (by another moderator, or as part of a
        removed thread) is not flagged again, so one item counts as one flag."""
        while self._pending_violations:
            eid, author_id, reason = self._pending_violations.pop(0)
            if state.get_event(eid) is None:
                continue
            log.info(
                "Rule moderator %s: removing event_id=%s from all feeds and simulation state",
                self.agent_id,
                eid,
            )
            removed = state.remove_event(eid)
            self.removed_event_ids.append(eid)
            if feed_manager is not None:
                feed_manager.remove_events_from_all_feeds(removed)
            log.info(
                "Rule moderator %s: applying MitigationSystem flag -> user %s (%s)",
                self.agent_id,
                author_id,
                reason,
            )
            self.mitigation_system.flag_agent(
                author_id,
                reason,
                state,
                timestep=self.clock_timestep,
                source="rule_moderator",
                time_s=self.clock_s,
            )

    def flush_pending_flags(self, state: SimulationState) -> None:
        """Apply queued violations without a feed manager (feeds are purged of
        removed events by the engines)."""
        self.flush_pending_moderation(state, None)

    def _analyze_rules(self, content: str) -> RuleAnalysis:
        out = RuleAnalysis()
        if self.llm_service is None or not content.strip():
            return out
        prompt = f"""You are a subreddit moderator. Judge ONLY whether the content violates the rules below.

Subreddit rules:
{self.subreddit_rules_text}

Content:
\"\"\"{content}\"\"\"

Return ONLY valid JSON (no markdown, no code fences, no commentary). Use exact keys:
{{
  "violates_rules": true or false,
  "confidence": 0.0 to 1.0,
  "reason": "short reason if violation, else empty string"
}}"""
        try:
            result = self.llm_service._complete_json(
                prompt,
                temperature=0.1,
                max_tokens=self.llm_service.config.max_tokens,
                validate=require_unit_floats("confidence", defaults={"confidence": 0.0}),
                label=f"Rule moderator {self.agent_id}",
            )
            if not result.ok:
                raise ValueError(result.error)
            data = result.data

            raw_violates = data.get("violates_rules", False)
            if isinstance(raw_violates, bool):
                out.violates_rules = raw_violates
            else:
                out.violates_rules = (
                    str(raw_violates).strip().lower() in ("true", "1", "yes")
                )
            out.confidence = data["confidence"]
            out.reason = str(data.get("reason", "") or "").strip()
        except Exception as e:
            log.error(
                "Rule moderator %s LLM error (json parse/extract failed): %s | content_preview=%r",
                self.agent_id,
                e,
                _content_preview(content, 120),
            )
        return out

    def _reviewable(self, event: MediaEvent) -> bool:
        # Seed content is real Reddit content that was already moderated there
        return (
            event.subreddit_id == self.subreddit_id
            and event.type in (EventType.POST, EventType.REPLY)
            and bool(event.content and event.content.strip())
            and not (event.indexes or {}).get("seed")
        )

    def parse(self, event: MediaEvent, state: SimulationState) -> None:
        if not self._reviewable(event):
            return
        job = self.parse_job(event, state)
        self.apply_parse_result(job(), state)

    def parse_job(self, event: MediaEvent, state: SimulationState):
        """LLM review of one item (pure; the verdict is applied at review end)."""
        if not self._reviewable(event):
            return None
        kind = "post" if event.type == EventType.POST else "comment"
        log.info(
            "Rule moderator %s: checking %s for rule violations - event_id=%s author=%s "
            "r/%s timestep=%s preview=%r",
            self.agent_id,
            kind,
            event.event_id,
            event.user_id,
            self.subreddit_id,
            self.clock_timestep,
            _content_preview(event.content),
        )
        event_id, author_id, content = event.event_id, event.user_id, event.content
        return lambda: (event_id, author_id, self._analyze_rules(content))

    def apply_parse_result(self, result, state: SimulationState) -> None:
        """Queue a violation (applied by flush_pending_moderation)."""
        if result is None:
            return
        event_id, author_id, analysis = result
        if (
            analysis.violates_rules
            and analysis.confidence >= self.detection_threshold
        ):
            reason = analysis.reason or "rule violation (LLM)"
            log.info(
                "Rule moderator %s: VIOLATION - event_id=%s author=%s confidence=%.2f "
                "(threshold=%.2f) reason=%r -> queued flag + content removal",
                self.agent_id,
                event_id,
                author_id,
                analysis.confidence,
                self.detection_threshold,
                reason,
            )
            self._pending_violations.append((event_id, author_id, reason))
        else:
            log.info(
                "Rule moderator %s: no action - event_id=%s violates_rules=%s "
                "confidence=%.2f (threshold=%.2f)",
                self.agent_id,
                event_id,
                analysis.violates_rules,
                analysis.confidence,
                self.detection_threshold,
            )

    def generate_post_events(
        self, timestep: int, state: SimulationState
    ) -> List[MediaEvent]:
        return []

    def reply(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        return None

    def upvote(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        return None

    def downvote(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[MediaEvent]:
        return None

    def should_reply(self, event: MediaEvent, state: SimulationState) -> bool:
        return False

    def expected_action_probs(self):
        return 0.0, 0.0  # reviews only

    def choose_vote(self, event: MediaEvent, state: SimulationState) -> Optional[str]:
        return None
