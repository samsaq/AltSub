#!/usr/bin/env python3
"""
Attacker activity: when attacker agents are active.

An attacker is active:
  - on its natural schedule (same kind of schedule users get),
  - at the timestep chosen to execute a due instruction, and
  - for a campaign session after each instruction post (log in, post, browse),
    with length drawn from the attacker's session_duration like user sessions.

Instructions are LLM attackers' CampaignInstruction objects or template
attackers' dicts; both carry start_timestep / end_timestep / executed.

An attacker is also active at a timestep where a coordination target (an
amplification of a fellow attacker's post, scheduled by CoordinationHub) is due.
That is a single "log in" step; it does not start a campaign session.
"""

from dataclasses import dataclass
from typing import Any, List, Optional

import numpy as np

from ..core.activity_sessions import session_length_timesteps
from .base_agent import BaseAgent


def _iget(instruction: Any, key: str, default: Any = None) -> Any:
    if isinstance(instruction, dict):
        return instruction.get(key, default)
    return getattr(instruction, key, default)


def _iset(instruction: Any, key: str, value: Any) -> None:
    if isinstance(instruction, dict):
        instruction[key] = value
    else:
        setattr(instruction, key, value)


@dataclass
class CoordinationTarget:
    """A fellow attacker's post to amplify once due_timestep is reached"""

    event_id: int
    action: str  # "upvote" or "comment"
    due_timestep: int
    due_time_s: Optional[float] = None  # event engine: when the action commits


class AttackerActivityMixin:
    """Activity gating and instruction timing for attacker agents.

    Expects self.activity_schedule (natural schedule) and self.pending_instructions.
    """

    def _init_attacker_activity(self, session_duration: str) -> None:
        self.session_duration = session_duration
        self._campaign_session_until = -1  # last timestep of current campaign session
        self.coordination_targets: List[CoordinationTarget] = []

    def is_active(self, timestep: int) -> bool:
        if BaseAgent.is_active(self, timestep):  # natural schedule
            return True
        if timestep <= self._campaign_session_until:
            return True
        if self._has_due_coordination(timestep):
            return True
        return self._due_instruction(timestep) is not None

    def add_instruction(self, instruction: Any) -> None:
        """Receive a campaign instruction. Its execution timestep is chosen now
        (not lazily inside is_active), so the choice uses the agent's RNG at a
        fixed point in the run."""
        self.pending_instructions.append(instruction)
        self._execution_timestep(instruction)

    def add_coordination_target(self, target: CoordinationTarget) -> None:
        self.coordination_targets.append(target)

    def _has_due_coordination(self, timestep: int) -> bool:
        return any(t.due_timestep <= timestep for t in self.coordination_targets)

    def pop_due_coordination_targets(self, timestep: int) -> List[CoordinationTarget]:
        """Remove and return targets whose due timestep has arrived"""
        due = [t for t in self.coordination_targets if t.due_timestep <= timestep]
        if due:
            self.coordination_targets = [
                t for t in self.coordination_targets if t.due_timestep > timestep
            ]
        return due

    def _execution_timestep(self, instruction: Any) -> int:
        """Timestep this instruction posts at, chosen once: a random naturally
        active timestep within its window if there is one, else any timestep in
        the window. Avoids every instruction posting at its window start."""
        chosen = _iget(instruction, "execute_timestep")
        if chosen is not None:
            return chosen
        start = int(_iget(instruction, "start_timestep", 0))
        end = int(_iget(instruction, "end_timestep", start))
        end = max(end, start)
        window = np.arange(start, end + 1)
        natural = [
            int(t) for t in window
            if t < len(self.activity_schedule) and self.activity_schedule[t]
        ]
        pool = natural if natural else window
        chosen = int(pool[self.rng.integers(len(pool))])
        _iset(instruction, "execute_timestep", chosen)
        return chosen

    def _due_instruction(self, timestep: int) -> Optional[Any]:
        """First unexecuted instruction whose execution timestep has arrived and
        whose window has not closed. Executed and expired instructions are
        dropped from the pending list."""
        due = None
        keep = []
        for instruction in self.pending_instructions:
            if _iget(instruction, "executed", False):
                continue
            end = int(_iget(instruction, "end_timestep", timestep))
            execute_at = self._execution_timestep(instruction)
            if timestep > max(end, execute_at):
                continue  # window closed without executing
            keep.append(instruction)
            if due is None and execute_at <= timestep:
                due = instruction
        self.pending_instructions[:] = keep
        return due

    def _complete_instruction(self, instruction: Any, timestep: int) -> None:
        """Mark an instruction executed and start a campaign session from this timestep."""
        _iset(instruction, "executed", True)
        length = session_length_timesteps(self.session_duration, self.rng)
        self._campaign_session_until = max(
            self._campaign_session_until, timestep + length - 1
        )
