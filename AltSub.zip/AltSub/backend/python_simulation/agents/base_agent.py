#!/usr/bin/env python3
"""
Base Agent: Abstract base class for all agent types

Defines the interface that all agents must implement.
"""

import logging
from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional, Tuple
import numpy as np
from ..core.simulation_data import SimulationState, MediaEvent, EventType

log = logging.getLogger(__name__)

# A deferred piece of agent work for the event-driven engine. Jobs run on worker
# threads, so they may only call the LLM: every input they need is copied when
# the job is created (main thread), and they never touch shared state or RNG.
Job = Callable[[], Any]


def pick_vote(
    p_upvote: float, p_downvote: float, rng: Optional[np.random.Generator] = None
) -> Optional[str]:
    """
    One roll over upvote / downvote / no vote. If the two probabilities sum past 1
    they are scaled down to sum to 1 (no "no vote" outcome left).
    """
    p_up = max(0.0, float(p_upvote))
    p_down = max(0.0, float(p_downvote))
    total = p_up + p_down
    if total > 1.0:
        p_up, p_down = p_up / total, p_down / total
    r = rng.random() if rng is not None else np.random.random()
    if r < p_up:
        return "upvote"
    if r < p_up + p_down:
        return "downvote"
    return None


class BaseAgent(ABC):
    """Abstract base class for all agent types"""

    def __init__(
        self,
        agent_id: int,
        agent_type: str,
        beliefs: Dict[str, float],
        subreddit_id: str,
        activity_weights: Dict[str, float],
        activity_schedule: np.ndarray,
    ):
        """
        Initialize base agent.

        Args:
            agent_id: Unique agent identifier
            agent_type: Type of agent (llm_user, llm_attacker, template_attacker, biased_moderator)
            beliefs: Initial beliefs dict[belief_id, strength] (0-1)
            subreddit_id: Subreddit this agent belongs to
            activity_weights: Dict of action -> probability/weight
            activity_schedule: Boolean array indicating when agent is active (per timestep)
        """
        self.agent_id = agent_id
        self.agent_type = agent_type
        self.beliefs = beliefs.copy()
        self.belief_history: List[Dict[str, float]] = (
            []
        )  # Track belief changes per timestep
        self.subreddit_id = subreddit_id
        self.activity_weights = activity_weights.copy()
        self.activity_schedule = activity_schedule.copy()

        self.banned_count = 0
        self.read_count = int(activity_weights.get("read", 10))

        # Per-agent random stream (seed_rng makes it reproducible per run seed)
        self.rng: np.random.Generator = np.random.default_rng()

        # Belief axes (belief model "axes"; beliefs are then axis positions).
        # None = free-text beliefs. Set by run_simulation.
        self.axes = None

        # Simulated clock as of the agent's current action (set by the engines)
        self.clock_timestep: int = 0
        self.clock_s: Optional[float] = None  # seconds, when the engine provides them

        log.debug(f"Created {agent_type} agent {agent_id} with {len(beliefs)} beliefs")

    def seed_rng(self, run_seed: int) -> None:
        """Give the agent its own reproducible stream derived from the run seed."""
        self.rng = np.random.default_rng([int(run_seed), int(self.agent_id)])

    def set_clock(self, timestep: int, time_s: Optional[float] = None) -> None:
        """Record the current simulated time for the agent's next actions."""
        self.clock_timestep = int(timestep)
        self.clock_s = float(time_s) if time_s is not None else None

    def is_active(self, timestep: int) -> bool:
        """Check if agent is active at given timestep"""
        if timestep < 0 or timestep >= len(self.activity_schedule):
            return False
        return bool(self.activity_schedule[timestep])

    def is_banned(self, state: SimulationState, threshold: int = 1) -> bool:
        """Check if agent is banned"""
        return state.banned_agent_network.is_banned(
            self.agent_id, self.subreddit_id, threshold
        )

    def get_action_probability(self, action: str) -> float:
        """Get probability/weight for an action"""
        return self.activity_weights.get(action, 0.0)

    def update_beliefs(self, new_beliefs: Dict[str, float], timestep: int) -> None:
        """
        Update beliefs and record in history.

        Args:
            new_beliefs: Updated belief strengths
            timestep: Current timestep for history tracking
        """
        for belief_id, strength in new_beliefs.items():
            self.beliefs[belief_id] = max(0.0, min(1.0, strength))

        self.belief_history.append(
            {"timestep": timestep, "beliefs": self.beliefs.copy()}
        )

    def replace_beliefs(
        self, new_beliefs: Dict[str, float], timestep: int
    ) -> None:
        """
        Replace the full belief set (e.g. after consolidation). Clamps strengths to 0-1 and records in history.

        Args:
            new_beliefs: New belief dict (belief_id -> strength)
            timestep: Current timestep for history tracking
        """
        self.beliefs = {
            k: max(0.0, min(1.0, float(v))) for k, v in new_beliefs.items()
        }
        self.belief_history.append(
            {"timestep": timestep, "beliefs": self.beliefs.copy()}
        )

    @abstractmethod
    def generate_post_events(
        self, timestep: int, state: SimulationState
    ) -> List[MediaEvent]:
        """
        Generate new post events for this timestep.

        Returns:
            List of new MediaEvent objects (posts/comments)
        """
        pass

    @abstractmethod
    def parse(self, event: MediaEvent, state: SimulationState) -> None:
        """
        Parse an event from feed (read and potentially update beliefs).

        Args:
            event: Event to parse
            state: Current simulation state
        """
        pass

    @abstractmethod
    def reply(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """
        Generate a reply to an event.

        Returns:
            MediaEvent for reply, or None if no reply
        """
        pass

    @abstractmethod
    def upvote(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """
        Generate an upvote event.

        Returns:
            MediaEvent for upvote, or None if no upvote
        """
        pass

    @abstractmethod
    def downvote(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[MediaEvent]:
        """
        Generate a downvote event.

        Returns:
            MediaEvent for downvote, or None if no downvote
        """
        pass

    def should_reply(self, event: MediaEvent, state: SimulationState) -> bool:
        """Check if agent should reply to event"""
        if self.is_banned(state):
            return False
        return self.rng.random() < self.get_action_probability("reply")

    def choose_vote(self, event: MediaEvent, state: SimulationState) -> Optional[str]:
        """
        Choose at most one vote for an event: "upvote", "downvote" or None.

        The upvote and downvote probabilities split one roll; the remainder is no vote.
        """
        if self.is_banned(state):
            return None
        return pick_vote(
            self.get_action_probability("upvote"),
            self.get_action_probability("downvote"),
            self.rng,
        )

    # Event-driven engine hooks. Defaults suit agents whose actions are cheap
    # and use no LLM; LLM agents override them to move LLM calls into jobs.

    def reads_feed(self) -> bool:
        """Whether the agent takes part in the event engine's read stream."""
        return self.read_count > 0

    def parse_job(self, event: MediaEvent, state: SimulationState) -> Optional[Job]:
        """LLM work for reading an item, or None to have the engine call parse()
        on the main thread when reading finishes."""
        return None

    def apply_parse_result(self, result: Any, state: SimulationState) -> None:
        """Apply a parse_job result on the main thread."""

    def reply_job(self, event: MediaEvent, state: SimulationState) -> Job:
        """Job returning the reply MediaEvent (or None). Default: built now."""
        reply = self.reply(event, state)
        return lambda: reply

    def vote_probabilities_job(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[Job]:
        """Job returning (p_upvote, p_downvote) from an LLM, or None to use the
        profile probabilities."""
        return None

    def vote_probabilities(self) -> Tuple[float, float]:
        return (
            self.get_action_probability("upvote"),
            self.get_action_probability("downvote"),
        )

    def expected_action_probs(self) -> Tuple[float, float]:
        """(reply probability, vote probability) per item read, used to size
        the event engine's reading time so the whole item cycle matches the
        discrete model."""
        p_up, p_down = self.vote_probabilities()
        return self.get_action_probability("reply"), min(1.0, p_up + p_down)

    def natural_post_job(self, state: SimulationState) -> Optional[Job]:
        """Job returning a natural (non-campaign) post, called when the engine's
        post process fires (the post probability is already applied). None if
        the agent never posts naturally."""
        return None

    def make_vote_event(self, event: MediaEvent, choice: str) -> Optional[MediaEvent]:
        """Build an upvote/downvote event for choice."""
        if choice == "upvote":
            return self.upvote(event, None)
        if choice == "downvote":
            return self.downvote(event, None)
        return None
