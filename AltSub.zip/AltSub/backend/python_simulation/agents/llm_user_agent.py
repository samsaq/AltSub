#!/usr/bin/env python3
"""
LLM User Agent: LLM-powered regular user agent

Ports functionality from old llm_reddit_integration.cpp
"""

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any, Tuple
import numpy as np
from ..core.belief_axes import BeliefAxis, strongest_axis
from ..core.simulation_data import SimulationState, MediaEvent, EventType
from ..core.thread_context import ThreadEntry, thread_context
from .base_agent import BaseAgent, Job, pick_vote

try:
    from ..services.llm_reddit_service import LLMRedditService, LLMServiceConfig
except ImportError:
    LLMRedditService = None
    LLMServiceConfig = None

log = logging.getLogger(__name__)


@dataclass
class ParseInput:
    """Everything the LLM step of reading needs, copied on the main thread."""

    content: str
    author: str
    base_beliefs: Dict[str, float]  # beliefs when reading started
    text_map: Dict[str, str]
    should_extract: bool
    # For a comment: the post and comments above it (prompt context only)
    thread: List[ThreadEntry] = field(default_factory=list)


@dataclass
class ParseResult:
    """LLM output of reading one item (no shared state touched yet)."""

    base_beliefs: Dict[str, float]
    llm_updated: Dict[str, float]  # full belief dict as the LLM updated it
    claims: Dict[str, float] = field(default_factory=dict)  # new claim text -> strength


class LLMUserAgent(BaseAgent):
    """LLM-powered regular user agent"""

    def __init__(
        self,
        agent_id: int,
        beliefs: Dict[str, float],
        subreddit_id: str,
        activity_weights: Dict[str, float],
        activity_schedule: np.ndarray,
        llm_service: Optional[LLMRedditService] = None,
        llm_voting_enabled: bool = False,
        canonicalizer: Optional[Any] = None,
        belief_cap_enabled: bool = False,
        belief_cap: int = 60,
        protect_attacker_beliefs: bool = False,
        campaign_belief_texts: Optional[Dict[str, str]] = None,
        attacker_similarity_threshold: float = 0.6,
        belief_texts: Optional[Dict[str, str]] = None,
        axes: Optional[List[BeliefAxis]] = None,
    ):
        """
        Initialize LLM user agent.

        Args:
            agent_id: Unique agent identifier
            beliefs: Initial beliefs dict[belief_id, strength]
            subreddit_id: Subreddit this agent belongs to
            activity_weights: Dict of action -> probability/weight
            activity_schedule: Boolean array indicating when agent is active
            llm_service: LLMRedditService instance (if None, creates default)
            llm_voting_enabled: Whether to use LLM for voting decisions
            belief_cap_enabled: If True, cull beliefs to belief_cap when over cap
            belief_cap: Max beliefs when belief capping is enabled
            protect_attacker_beliefs: If True, never drop/merge attacker-related beliefs with non-attacker
            campaign_belief_texts: Campaign reference texts for classifying attacker-related beliefs (id -> text)
            attacker_similarity_threshold: Similarity threshold for semantic attacker-related classification
            belief_texts: This user's own wording of initial beliefs (id -> text)
            axes: Belief axes (belief model "axes"): beliefs are then positions
                on these axes, moved by one LLM call per item read; None = the
                free-text belief model (extraction, canonicalisation, capping)
        """
        super().__init__(
            agent_id=agent_id,
            agent_type="llm_user",
            beliefs=beliefs,
            subreddit_id=subreddit_id,
            activity_weights=activity_weights,
            activity_schedule=activity_schedule,
        )

        self.llm_voting_enabled = llm_voting_enabled
        self.canonicalizer = canonicalizer

        # Belief capping (bloat mitigation)
        self.belief_cap_enabled = belief_cap_enabled
        self.belief_cap = belief_cap
        self.protect_attacker_beliefs = protect_attacker_beliefs
        self.campaign_belief_texts = campaign_belief_texts or {}
        self.attacker_similarity_threshold = attacker_similarity_threshold

        # Track original belief texts (canonical_id -> human_readable_text)
        self.belief_texts: Dict[str, str] = dict(belief_texts or {})

        # Belief axes model (None = free-text beliefs)
        self.axes: Optional[List[BeliefAxis]] = list(axes) if axes else None

        if llm_service is None:
            if LLMRedditService is None:
                log.warning(
                    f"LLMRedditService not available for agent {agent_id}, using fallback"
                )
                self.llm_service = None
            else:
                config = LLMServiceConfig()
                self.llm_service = LLMRedditService(config)
        else:
            self.llm_service = llm_service

        log.debug(
            f"LLMUserAgent {agent_id} initialized (LLM voting: {llm_voting_enabled})"
        )

    def replace_beliefs(
        self, new_beliefs: Dict[str, float], timestep: int
    ) -> None:
        """Replace full belief set and trim belief_texts to only keys in new_beliefs."""
        super().replace_beliefs(new_beliefs, timestep)
        self.belief_texts = {k: v for k, v in self.belief_texts.items() if k in self.beliefs}

    def _belief_text_map(self, state: SimulationState) -> Dict[str, str]:
        """belief_id -> text for prompts: this agent's own wording over canonical text."""
        texts = dict(getattr(state, "belief_text_registry", {}))
        texts.update(self.belief_texts)
        return texts

    def _strongest_belief(self, beliefs: Dict[str, float]) -> str:
        """Belief tag for content: the strongest belief (free text) or the axis
        with the strongest stance (axes)."""
        if self.axes:
            return strongest_axis(beliefs)
        return max(beliefs.items(), key=lambda x: x[1])[0] if beliefs else "default"

    def generate_post_events(
        self, timestep: int, state: SimulationState
    ) -> List[MediaEvent]:
        """Generate new post events for this timestep"""
        post_prob = self.get_action_probability("post")
        if self.rng.random() >= post_prob:
            return []
        post = self.natural_post_job(state)()
        return [post] if post is not None else []

    def natural_post_job(self, state: SimulationState) -> Job:
        """Job writing a post from a snapshot of beliefs and recent posts."""
        beliefs = dict(self.beliefs)
        belief_id = self._strongest_belief(beliefs)
        if self.llm_service is None:
            # Fallback: simple post
            content = f"Discussion happening in r/{self.subreddit_id} today!"
            fallback_id = (
                str(self.rng.choice(list(beliefs.keys()))) if beliefs else "default"
            )
            return lambda: self._make_post(content, fallback_id)

        recent_events = [
            e
            for e in state.events[-10:]
            if e.type == EventType.POST and e.subreddit_id == self.subreddit_id
        ]
        context_posts = [e.content for e in recent_events[-3:]]
        text_map = self._belief_text_map(state)

        def run() -> MediaEvent:
            content = self.llm_service.generate_post_content(
                agent_beliefs=beliefs,
                trust_network={},
                subreddit=self.subreddit_id,
                context_posts=context_posts,
                agent_id=self.agent_id,
                belief_id_to_text=text_map,
                axes=self.axes,
            )
            return self._make_post(content, belief_id)

        return run

    def _make_post(self, content: str, belief_id: str) -> MediaEvent:
        return MediaEvent(
            event_id=0,  # Set at commit
            user_id=self.agent_id,
            parent_id=None,
            type=EventType.POST,
            belief_id=belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
            content=content,
        )

    def parse(self, event: MediaEvent, state: SimulationState) -> None:
        """Parse an event from feed (read and potentially update beliefs)"""
        inp = self.prepare_parse(event, state)
        if inp is None:
            return
        self.apply_parse(self.compute_parse(inp), state)

    def parse_job(self, event: MediaEvent, state: SimulationState) -> Optional[Job]:
        inp = self.prepare_parse(event, state)
        if inp is None:
            return None
        return lambda: self.compute_parse(inp)

    def apply_parse_result(self, result: Any, state: SimulationState) -> None:
        # Event engine: canonical metadata is written in batches at day end
        self.apply_parse(result, state, write_metadata=False)

    def prepare_parse(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[ParseInput]:
        """Main thread: copy what the LLM step of reading needs."""
        if self.llm_service is None:
            return None
        content = (event.content or "").strip()
        return ParseInput(
            content=content,
            author=str(event.user_id),
            base_beliefs=dict(self.beliefs),
            text_map=self._belief_text_map(state),
            # Extraction is expensive and low-value on non-text interaction events.
            # Restrict to substantive post/reply content to avoid unnecessary LLM calls.
            should_extract=(
                not self.axes
                and event.type in (EventType.POST, EventType.REPLY)
                and len(content) >= 20
            ),
            thread=thread_context(event, state),
        )

    def compute_parse(self, inp: ParseInput) -> ParseResult:
        """LLM calls of reading an item; pure, safe on a worker thread."""
        if self.axes:
            # Belief axes: one call moves the positions (no claim extraction)
            llm_updated = self.llm_service.update_axis_positions(
                content=inp.content,
                positions=inp.base_beliefs,
                axes=self.axes,
                author=inp.author,
                agent_id=self.agent_id,
                thread=inp.thread,
            )
            return ParseResult(base_beliefs=inp.base_beliefs, llm_updated=llm_updated)
        # Step 1: Update existing beliefs from content
        llm_updated = self.llm_service.update_beliefs_from_content(
            content=inp.content,
            current_beliefs=inp.base_beliefs,
            author=inp.author,
            agent_id=self.agent_id,
            belief_id_to_text=inp.text_map,
            thread=inp.thread,
        )
        # Step 2: Extract new claims from content (canonicalised in apply_parse)
        claims = {}
        if inp.should_extract:
            claims = self.llm_service.extract_new_belief_claims(
                content=inp.content,
                existing_beliefs=inp.base_beliefs,
                subreddit=self.subreddit_id,
                belief_id_to_text=inp.text_map,
            )
        return ParseResult(
            base_beliefs=inp.base_beliefs, llm_updated=llm_updated, claims=claims
        )

    def _merge_llm_update(self, result: ParseResult) -> Dict[str, float]:
        """Current beliefs with the LLM's changes applied.

        Changes are deltas against the beliefs reading started from, applied
        only to beliefs still held, so a belief set replaced in the meantime
        (e.g. day-end consolidation) is not rolled back. A belief unchanged since
        then takes the LLM's value exactly.
        """
        updated = dict(self.beliefs)
        for belief_id, new_strength in result.llm_updated.items():
            if belief_id not in updated or belief_id not in result.base_beliefs:
                continue
            base = result.base_beliefs[belief_id]
            if new_strength == base:
                continue
            if updated[belief_id] == base:
                updated[belief_id] = new_strength
            else:
                updated[belief_id] = max(0.0, min(1.0, updated[belief_id] + new_strength - base))
        return updated

    def apply_parse(
        self, result: ParseResult, state: SimulationState, write_metadata: bool = True
    ) -> None:
        """Main thread: apply the result of reading an item to the agent's beliefs.

        Canonicalisation (first-come canonical IDs) and the belief network are
        shared state, so this always runs in a deterministic order.
        """
        updated_beliefs = self._merge_llm_update(result)
        belief_id_to_text = self._belief_text_map(state)

        new_beliefs = {}
        if result.claims:
            new_beliefs = self.llm_service.canonicalize_claims(
                result.claims,
                existing_beliefs=self.beliefs,
                canonicalizer=self.canonicalizer,
                timestep=self.clock_timestep,
                write_metadata=write_metadata,
            )

        # Step 2b: New claims that contradict a held belief weaken it instead of
        # being adopted alongside it
        if new_beliefs:
            new_beliefs = self._resolve_contradictions(
                new_beliefs, updated_beliefs, belief_id_to_text
            )

        # Step 3: Add new beliefs to updated_beliefs dict
        for canonical_id, (human_readable_text, strength) in new_beliefs.items():
            updated_beliefs[canonical_id] = strength
            self.belief_texts[canonical_id] = human_readable_text
            if hasattr(state, "belief_text_registry"):
                if canonical_id not in state.belief_text_registry:
                    state.belief_text_registry[canonical_id] = human_readable_text

        # Step 3b: If belief capping enabled and over cap, cull to cap
        if (
            self.belief_cap_enabled
            and not self.axes
            and len(updated_beliefs) > self.belief_cap
            and self.canonicalizer is not None
        ):
            try:
                from ..services.belief_consolidation import (
                    cull_to_cap,
                    get_protected_belief_ids,
                )
            except ImportError:
                pass
            else:
                belief_text_source = dict(getattr(state, "belief_text_registry", {}))
                belief_text_source.update(self.belief_texts)
                protected = get_protected_belief_ids(
                    updated_beliefs,
                    belief_text_source,
                    self.campaign_belief_texts,
                    self.canonicalizer,
                    self.attacker_similarity_threshold,
                    self.protect_attacker_beliefs,
                )
                updated_beliefs = cull_to_cap(
                    updated_beliefs, self.belief_cap, protected
                )

        # Step 4: Update beliefs and record in history
        if updated_beliefs != self.beliefs:
            # updated_beliefs is the full set; replace whenever any belief was
            # removed (cull or contradiction), else removed beliefs would survive
            if set(self.beliefs) - set(updated_beliefs):
                self.replace_beliefs(updated_beliefs, self.clock_timestep)
                state.belief_network.replace_agent_beliefs(
                    self.agent_id, updated_beliefs
                )
            else:
                self.update_beliefs(updated_beliefs, self.clock_timestep)
                for belief_id, strength in updated_beliefs.items():
                    state.belief_network.set_belief(
                        self.agent_id, belief_id, strength
                    )

    def _resolve_contradictions(
        self,
        new_beliefs: Dict[str, Any],
        updated_beliefs: Dict[str, float],
        belief_id_to_text: Dict[str, str],
    ) -> Dict[str, Any]:
        """Apply contradiction pressure from newly extracted claims.

        A new claim that contradicts a held belief above contradiction_hold_threshold
        is not adopted; the held belief is pushed down instead, so its total change
        this read is at most belief_update_max_change (an LLM update already applied
        this read counts toward that). Once every belief a claim contradicts is at or
        below the threshold, the claim is adopted and those beliefs are dropped, so
        repeated exposure replaces an old view rather than holding both.

        Mutates updated_beliefs; returns the new beliefs to adopt.
        """
        nli = getattr(self.canonicalizer, "nli", None)
        if nli is None or not updated_beliefs:
            return new_beliefs

        config = self.llm_service.config
        bound = config.belief_update_max_change
        hold = config.contradiction_hold_threshold

        held_ids = list(updated_beliefs)
        held_texts = [belief_id_to_text.get(b, b) for b in held_ids]
        new_ids = list(new_beliefs)
        new_texts = [new_beliefs[n][0] for n in new_ids]

        # Contradictions are topically close, so only NLI-check similar pairs
        sims = self.canonicalizer._embed(new_texts) @ self.canonicalizer._embed(held_texts).T
        pairs = [
            (i, j) for i in range(len(new_ids)) for j in range(len(held_ids))
            if sims[i, j] >= 0.5
        ]
        flags = nli.contradicts_many([(new_texts[i], held_texts[j]) for i, j in pairs])
        contradicted: Dict[str, List[str]] = {}
        for (i, j), is_contra in zip(pairs, flags):
            if is_contra:
                contradicted.setdefault(new_ids[i], []).append(held_ids[j])

        adopted = {}
        for n in new_ids:
            # An earlier claim this read may already have dropped a target
            targets = [h for h in contradicted.get(n, []) if h in updated_beliefs]
            strong =[h for h in targets if updated_beliefs[h] > hold]
            if strong:
                for h in strong:
                    floor = self.beliefs.get(h, updated_beliefs[h]) - bound
                    updated_beliefs[h] = max(0.0, min(updated_beliefs[h], floor))
                log.debug(
                    f"Agent {self.agent_id}: '{new_beliefs[n][0][:50]}' contradicts held "
                    f"belief(s) {strong}; weakened them instead of adopting"
                )
                continue
            for h in targets:
                updated_beliefs.pop(h, None)
            adopted[n] = new_beliefs[n]
        return adopted

    def reply(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """Generate a reply to an event"""
        return self.reply_job(event, state)()

    def reply_job(self, event: MediaEvent, state: SimulationState) -> Job:
        """Job writing a reply from a snapshot of beliefs and the parent."""
        beliefs = dict(self.beliefs)
        text_map = self._belief_text_map(state)
        parent_id, parent_content = event.event_id, event.content
        thread = thread_context(event, state)

        def run() -> MediaEvent:
            if self.llm_service is None:
                # Fallback: simple reply
                content = "Interesting point!"
            else:
                content = self.llm_service.generate_reply_content(
                    parent_content=parent_content,
                    agent_beliefs=beliefs,
                    subreddit=self.subreddit_id,
                    agent_id=self.agent_id,
                    belief_id_to_text=text_map,
                    axes=self.axes,
                    thread=thread,
                )
            return MediaEvent(
                event_id=0,  # Set at commit
                user_id=self.agent_id,
                parent_id=parent_id,
                type=EventType.REPLY,
                belief_id=self._strongest_belief(beliefs),
                subreddit_id=self.subreddit_id,
                timestamp=self.clock_timestep,  # Set at commit
                content=content,
            )

        return run

    def choose_vote(self, event: MediaEvent, state: SimulationState) -> Optional[str]:
        """
        Choose at most one vote. With LLM voting, the LLM's upvote/downvote/no_vote
        probabilities replace the profile probabilities (one LLM call per item read).
        """
        job = self.vote_probabilities_job(event, state)
        if job is None:
            return super().choose_vote(event, state)
        if self.is_banned(state):
            return None
        p_up, p_down = job()
        return pick_vote(p_up, p_down, self.rng)

    def vote_probabilities_job(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[Job]:
        if not (self.llm_voting_enabled and self.llm_service is not None):
            return None
        beliefs = dict(self.beliefs)
        text_map = self._belief_text_map(state)
        content = event.content
        thread = thread_context(event, state)

        def run() -> Tuple[float, float]:
            voting_probs = self.llm_service.analyze_voting_decision(
                content=content,
                agent_beliefs=beliefs,
                subreddit=self.subreddit_id,
                agent_id=self.agent_id,
                belief_id_to_text=text_map,
                axes=self.axes,
                thread=thread,
            )
            return voting_probs.get("upvote", 0.0), voting_probs.get("downvote", 0.0)

        return run

    def upvote(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """Generate an upvote event (vote choice is made by choose_vote)"""
        upvote_event = MediaEvent(
            event_id=0,  # Set at commit
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.UPVOTE,
            belief_id=event.belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
        )

        return upvote_event

    def downvote(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[MediaEvent]:
        """Generate a downvote event (vote choice is made by choose_vote)"""
        downvote_event = MediaEvent(
            event_id=0,  # Set at commit
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.DOWNVOTE,
            belief_id=event.belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
        )

        return downvote_event
