#!/usr/bin/env python3
"""
Template Attacker Agent: Template-based attacker using campaign templates

Ports functionality from template_attacker_integration.cpp
"""

import logging
import json
import os
import re
from typing import Any, Dict, List, Optional, Set
import numpy as np
from ..core.simulation_data import SimulationState, MediaEvent, EventType
from ..core.belief_axes import strongest_axis
from .base_agent import BaseAgent, Job
from .attacker_activity import AttackerActivityMixin

log = logging.getLogger(__name__)

# Used only when the template file defines no reply templates for error catching
GENERIC_REPLIES = [
    "I agree with this!",
    "This is an important point.",
    "Thanks for sharing this.", # hope you dont sound like this
]


class TemplateAttackerAgent(AttackerActivityMixin, BaseAgent):
    """Template-based attacker using campaign templates"""

    def __init__(
        self,
        agent_id: int,
        beliefs: Dict[str, float],
        subreddit_id: str,
        activity_weights: Dict[str, float],
        activity_schedule: np.ndarray,
        campaign_id: str = "default_campaign",
        campaign_templates_dir: str = "campaign_templates",
        coordination_strength: float = 0.8,
        attack_intensity: float = 0.6,
        session_duration: str = "medium",
        attacker_agent_ids: Optional[Set[int]] = None,
    ):
        """
        Initialize template attacker agent.

        Args:
            agent_id: Unique agent identifier
            beliefs: Initial beliefs dict[belief_id, strength]
            subreddit_id: Subreddit this agent belongs to
            activity_weights: Dict of action -> probability/weight
            activity_schedule: Boolean array indicating natural activity times
            campaign_id: Campaign identifier
            campaign_templates_dir: Directory containing template JSON files
            coordination_strength: How much attackers support each other (0-1)
            attack_intensity: How direct and forceful attacks are (0-1)
            session_duration: Session category (short/medium/long) for campaign
                sessions after instruction posts
            attacker_agent_ids: IDs of all attacker agents (any type), used to pick
                the "fellow_attacker_post" reply context
        """
        super().__init__(
            agent_id=agent_id,
            agent_type="template_attacker",
            beliefs=beliefs,
            subreddit_id=subreddit_id,
            activity_weights=activity_weights,
            activity_schedule=activity_schedule,
        )

        self.campaign_id = campaign_id
        self.coordination_strength = coordination_strength
        self.attack_intensity = attack_intensity
        self.natural_activity_schedule = activity_schedule.copy()
        self.attacker_agent_ids: Set[int] = set(attacker_agent_ids or ())

        # Load campaign templates: posts and replies are kept in separate pools
        self.campaign_templates: List[Dict] = []  # post templates
        self.reply_templates: List[Dict] = []
        self.downvote_keywords: List[str] = []  # lowercased, marks opposing content
        self._load_templates(campaign_templates_dir)

        self.pending_instructions: List[Dict] = []
        self._init_attacker_activity(session_duration)

        log.debug(
            f"TemplateAttackerAgent {agent_id} initialized with "
            f"{len(self.campaign_templates)} post / {len(self.reply_templates)} reply templates"
        )

    def _load_templates(self, templates_dir: str) -> None:
        """Load campaign templates from JSON files"""
        template_file = os.path.join(templates_dir, f"{self.campaign_id}.json")

        if not os.path.exists(template_file):
            log.warning(f"Template file not found: {template_file}")
            return

        try:
            with open(template_file, "r", encoding="utf-8") as f:
                template_data = json.load(f)

            campaign_name = template_data.get("campaign_name", self.campaign_id)
            templates_raw = template_data.get("templates", {})

            if isinstance(templates_raw, dict):
                self.campaign_templates = list(templates_raw.get("posts", []))
                self.reply_templates = list(templates_raw.get("replies", []))
                # voting_rules lives under "templates" in current files; accept top level too
                voting_rules = (
                    templates_raw.get("voting_rules")
                    or template_data.get("voting_rules")
                    or {}
                )
                self.downvote_keywords = [
                    str(k).lower()
                    for k in voting_rules.get("downvote_keywords", [])
                    if str(k).strip()
                ]
            else:
                log.warning(
                    f"Unexpected templates format in {template_file}, expected dict with 'posts' and 'replies'"
                )
                self.campaign_templates = []
                self.reply_templates = []

            log.info(
                f"Loaded {len(self.campaign_templates)} post templates and "
                f"{len(self.reply_templates)} reply templates for campaign {campaign_name}"
            )
        except Exception as e:
            log.error(f"Error loading templates from {template_file}: {e}")
            self.campaign_templates = []
            self.reply_templates = []

    def _fill_template(self, template: Dict) -> str:
        """
        Fill template variables with values.

        Template format: "Text with {variable_name} placeholders"
        Variables are filled from the template's "variables" dict, selecting randomly from options.
        """
        # Get template text (supports both "template" and "content" field names)
        content = template.get("template", template.get("content", ""))

        template_variables = template.get("variables", {})

        # Extract variables from template text (single braces: {var})
        variables = re.findall(r"\{(\w+)\}", content)

        filled_content = content
        for var in variables:
            if var in template_variables:
                options = template_variables[var]
                if isinstance(options, list) and options:
                    value = str(options[self.rng.integers(len(options))])
                else:
                    value = str(options) if options else var
            elif var == "narrative":
                value = self.campaign_id
            elif var == "subreddit":
                value = self.subreddit_id
            else:
                # Default: use variable name as value
                value = var

            filled_content = filled_content.replace(f"{{{var}}}", value)

        return filled_content

    def _select_template(self, instruction: Optional[Dict] = None) -> Optional[Dict]:
        """Select a post template based on instruction or randomly"""
        if not self.campaign_templates:
            return None

        if instruction and "template_id" in instruction:
            template_id = instruction["template_id"]
            for template in self.campaign_templates:
                if template.get("id") == template_id:
                    return template

        return self.campaign_templates[self.rng.integers(len(self.campaign_templates))]

    def _reply_context(self, event: MediaEvent) -> str:
        """Reply context for a parent event: fellow attacker, opposing, or neutral"""
        if event.user_id in self.attacker_agent_ids:
            return "fellow_attacker_post"
        content = (event.content or "").lower()
        if content and any(k in content for k in self.downvote_keywords):
            return "opposing_viewpoint"
        return "neutral"

    def _select_reply_template(self, event: MediaEvent) -> Optional[Dict]:
        """Pick a reply template matching the parent's context, else any reply template"""
        if not self.reply_templates:
            return None
        context = self._reply_context(event)
        pool = [t for t in self.reply_templates if t.get("context") == context]
        pool = pool or self.reply_templates
        return pool[self.rng.integers(len(pool))]

    def generate_post_events(
        self, timestep: int, state: SimulationState
    ) -> List[MediaEvent]:
        """Generate new post events for this timestep"""
        events = []

        # Check for a due campaign instruction first (is_active / AttackerActivityMixin)
        instruction = self._due_instruction(timestep)

        if instruction:
            # Campaign-activated: select template matching instruction. Executed once.
            template = self._select_template(instruction)
            self._complete_instruction(instruction, timestep)
            if template:
                content = self._fill_template(template)

                belief_id = self._belief_tag()

                post_event = MediaEvent(
                    event_id=0,
                    user_id=self.agent_id,
                    parent_id=None,
                    type=EventType.POST,
                    belief_id=belief_id,
                    subreddit_id=self.subreddit_id,
                    timestamp=timestep,
                    content=content,
                )
                events.append(post_event)

        elif (
            self.natural_activity_schedule[timestep]
            if timestep < len(self.natural_activity_schedule)
            else False
        ):
            template = self._select_template()
            if template:
                post_prob = self.get_action_probability("post")
                if self.rng.random() < post_prob:
                    content = self._fill_template(template)

                    belief_id = self._belief_tag()

                    post_event = MediaEvent(
                        event_id=0,
                        user_id=self.agent_id,
                        parent_id=None,
                        type=EventType.POST,
                        belief_id=belief_id,
                        subreddit_id=self.subreddit_id,
                        timestamp=timestep,
                        content=content,
                    )
                    events.append(post_event)

        return events

    def _belief_tag(self) -> str:
        """Belief tag for content: strongest belief (free text) or the axis
        with the strongest stance (axes)."""
        if self.axes:
            return strongest_axis(self.beliefs)
        return max(self.beliefs.items(), key=lambda x: x[1])[0] if self.beliefs else "default"

    def _template_post(self, template: Dict) -> MediaEvent:
        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=None,
            type=EventType.POST,
            belief_id=self._belief_tag(),
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
            content=self._fill_template(template),
        )

    def instruction_post(self, instruction: Any) -> Optional[MediaEvent]:
        """Post for a campaign instruction (event engine), or None without templates."""
        template = self._select_template(instruction)
        return self._template_post(template) if template else None

    def natural_post_job(self, state: SimulationState) -> Optional[Job]:
        """Template filled now (main thread, agent RNG); the job just returns it."""
        template = self._select_template()
        if not template:
            return None
        post = self._template_post(template)
        return lambda: post

    def parse(self, event: MediaEvent, state: SimulationState) -> None:
        """Parse an event from feed (template attackers don't update beliefs)"""
        # Template attackers have fixed beliefs - no updates
        pass

    def reply(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """Generate a reply to an event (reply probability is rolled by should_reply)"""
        template = self._select_reply_template(event)
        if template:
            content = self._fill_template(template)
        else:
            content = GENERIC_REPLIES[self.rng.integers(len(GENERIC_REPLIES))]

        belief_id = self._belief_tag()

        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.REPLY,
            belief_id=belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
            content=content,
        )

    def upvote(self, event: MediaEvent, state: SimulationState) -> Optional[MediaEvent]:
        """Generate an upvote event (vote probability is rolled by choose_vote)"""
        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.UPVOTE,
            belief_id=event.belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
        )

    def downvote(
        self, event: MediaEvent, state: SimulationState
    ) -> Optional[MediaEvent]:
        """
        Generate a downvote event (vote probability is rolled by choose_vote).
        Stance-blind like regular users, so attacker voting blends in.
        """
        return MediaEvent(
            event_id=0,
            user_id=self.agent_id,
            parent_id=event.event_id,
            type=EventType.DOWNVOTE,
            belief_id=event.belief_id,
            subreddit_id=self.subreddit_id,
            timestamp=self.clock_timestep,  # Set at commit
        )
