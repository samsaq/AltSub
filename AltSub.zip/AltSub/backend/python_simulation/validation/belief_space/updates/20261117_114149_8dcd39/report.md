# Belief update tests: 20261117_114149_8dcd39

- Kind: development  |  model: mistral-small-latest  |  reps: 5  |  starts: [0.5, 0.25, 0.75]
- Git: 5b38f99f6c6663aeb4ed72ad8bd3b502f1eb937d (dirty)
- Movement threshold 0.02, neutral band 0.05, cap 0.15
- Criteria: `{"direction_min_rate": 0.8, "neutral_min_rate": 0.8, "off_target_max_rate": 0.2, "social_min_diff": 0.03, "social_max_other_diff": 0.03}`

## targets: 93/117 pass
- FAIL scenario=destiny2, item_id=C1-neutral, statement_id=C1, expected=neutral, start=0.5, reps=5, mean_delta=0.05, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C2-neutral, statement_id=C2, expected=neutral, start=0.5, reps=5, mean_delta=-0.06, sd=0.0224, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C3-neutral, statement_id=C3, expected=neutral, start=0.5, reps=5, mean_delta=-0.12, sd=0.0274, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C4-neutral, statement_id=C4, expected=neutral, start=0.25, reps=5, mean_delta=-0.01, sd=0.0548, ok_rate=0.4
- FAIL scenario=destiny2, item_id=C4-neutral, statement_id=C4, expected=neutral, start=0.5, reps=5, mean_delta=-0.07, sd=0.0274, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C5-low, statement_id=C5, expected=low, start=0.25, reps=5, mean_delta=0.1, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C5-low, statement_id=C5, expected=low, start=0.5, reps=5, mean_delta=0.12, sd=0.0274, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C5-neutral, statement_id=C5, expected=neutral, start=0.5, reps=5, mean_delta=0.07, sd=0.0274, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C5-neutral, statement_id=C5, expected=neutral, start=0.75, reps=5, mean_delta=0.05, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C6-low, statement_id=C6, expected=low, start=0.75, reps=5, mean_delta=-0.06, sd=0.1084, ok_rate=0.6
- FAIL scenario=destiny2, item_id=C6-neutral, statement_id=C6, expected=neutral, start=0.5, reps=5, mean_delta=0.05, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C7-low, statement_id=C7, expected=low, start=0.25, reps=5, mean_delta=0.15, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C7-low, statement_id=C7, expected=low, start=0.5, reps=5, mean_delta=0.15, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C7-low, statement_id=C7, expected=low, start=0.75, reps=5, mean_delta=0.11, sd=0.0224, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C7-neutral, statement_id=C7, expected=neutral, start=0.5, reps=5, mean_delta=0.1, sd=0.0, ok_rate=0.0
- FAIL scenario=destiny2, item_id=C7-neutral, statement_id=C7, expected=neutral, start=0.75, reps=5, mean_delta=0.09, sd=0.0224, ok_rate=0.0
- FAIL scenario=politics, item_id=P1-low, statement_id=P1, expected=low, start=0.25, reps=5, mean_delta=0.01, sd=0.0548, ok_rate=0.4
- FAIL scenario=politics, item_id=P2-neutral, statement_id=P2, expected=neutral, start=0.5, reps=5, mean_delta=-0.03, sd=0.0274, ok_rate=0.4
- FAIL scenario=politics, item_id=P3-neutral, statement_id=P3, expected=neutral, start=0.5, reps=5, mean_delta=0.05, sd=0.0, ok_rate=0.0
- FAIL scenario=politics, item_id=P4-neutral, statement_id=P4, expected=neutral, start=0.5, reps=5, mean_delta=0.05, sd=0.0, ok_rate=0.0
- FAIL scenario=politics, item_id=P5-low, statement_id=P5, expected=low, start=0.25, reps=5, mean_delta=0.11, sd=0.0418, ok_rate=0.0
- FAIL scenario=politics, item_id=P5-low, statement_id=P5, expected=low, start=0.5, reps=5, mean_delta=0.03, sd=0.0758, ok_rate=0.2
- FAIL scenario=politics, item_id=P5-neutral, statement_id=P5, expected=neutral, start=0.5, reps=5, mean_delta=0.05, sd=0.0, ok_rate=0.0
- FAIL scenario=politics, item_id=P6-low, statement_id=P6, expected=low, start=0.25, reps=5, mean_delta=-0.07, sd=0.1151, ok_rate=0.6

## spillover: 39/85 pass
- FAIL scenario=destiny2, item_target=C1, other_statement=C2, updates=45, moved=23, rate=0.511, mean_delta=0.0167
- FAIL scenario=destiny2, item_target=C1, other_statement=C3, updates=45, moved=20, rate=0.444, mean_delta=0.0133
- FAIL scenario=destiny2, item_target=C1, other_statement=C4, updates=45, moved=38, rate=0.844, mean_delta=0.0011
- FAIL scenario=destiny2, item_target=C1, other_statement=C5, updates=45, moved=25, rate=0.556, mean_delta=0.0333
- FAIL scenario=destiny2, item_target=C1, other_statement=C6, updates=45, moved=25, rate=0.556, mean_delta=0.0456
- FAIL scenario=destiny2, item_target=C2, other_statement=C1, updates=45, moved=22, rate=0.489, mean_delta=-0.0222
- FAIL scenario=destiny2, item_target=C2, other_statement=C3, updates=45, moved=10, rate=0.222, mean_delta=0.0111
- FAIL scenario=destiny2, item_target=C2, other_statement=C4, updates=45, moved=31, rate=0.689, mean_delta=-0.0233
- FAIL scenario=destiny2, item_target=C2, other_statement=C5, updates=45, moved=20, rate=0.444, mean_delta=0.0222
- FAIL scenario=destiny2, item_target=C2, other_statement=C6, updates=45, moved=27, rate=0.6, mean_delta=0.0256
- FAIL scenario=destiny2, item_target=C3, other_statement=C1, updates=45, moved=15, rate=0.333, mean_delta=-0.0167
- FAIL scenario=destiny2, item_target=C3, other_statement=C2, updates=45, moved=15, rate=0.333, mean_delta=-0.0167
- FAIL scenario=destiny2, item_target=C3, other_statement=C4, updates=45, moved=45, rate=1.0, mean_delta=-0.0011
- FAIL scenario=destiny2, item_target=C3, other_statement=C5, updates=45, moved=26, rate=0.578, mean_delta=0.0411
- FAIL scenario=destiny2, item_target=C3, other_statement=C6, updates=45, moved=30, rate=0.667, mean_delta=0.0589
- FAIL scenario=destiny2, item_target=C4, other_statement=C1, updates=45, moved=33, rate=0.733, mean_delta=-0.0289
- FAIL scenario=destiny2, item_target=C4, other_statement=C2, updates=45, moved=24, rate=0.533, mean_delta=-0.0344
- FAIL scenario=destiny2, item_target=C4, other_statement=C3, updates=45, moved=38, rate=0.844, mean_delta=-0.0144
- FAIL scenario=destiny2, item_target=C4, other_statement=C5, updates=45, moved=25, rate=0.556, mean_delta=0.0367
- FAIL scenario=destiny2, item_target=C4, other_statement=C6, updates=45, moved=30, rate=0.667, mean_delta=0.0633
- FAIL scenario=destiny2, item_target=C5, other_statement=C4, updates=45, moved=13, rate=0.289, mean_delta=-0.0156
- FAIL scenario=destiny2, item_target=C5, other_statement=C6, updates=45, moved=43, rate=0.956, mean_delta=0.05
- FAIL scenario=destiny2, item_target=C5, other_statement=C7, updates=45, moved=18, rate=0.4, mean_delta=0.0089
- FAIL scenario=destiny2, item_target=C6, other_statement=C5, updates=45, moved=39, rate=0.867, mean_delta=0.0358
- FAIL scenario=destiny2, item_target=C7, other_statement=C5, updates=45, moved=45, rate=1.0, mean_delta=0.0667
- FAIL scenario=destiny2, item_target=C7, other_statement=C6, updates=45, moved=45, rate=1.0, mean_delta=0.0556
- FAIL scenario=politics, item_target=P1, other_statement=P2, updates=45, moved=30, rate=0.667, mean_delta=0.0311
- FAIL scenario=politics, item_target=P1, other_statement=P3, updates=45, moved=28, rate=0.622, mean_delta=0.0167
- FAIL scenario=politics, item_target=P1, other_statement=P6, updates=45, moved=26, rate=0.578, mean_delta=0.0444
- FAIL scenario=politics, item_target=P2, other_statement=P1, updates=45, moved=38, rate=0.844, mean_delta=0.0289
- FAIL scenario=politics, item_target=P2, other_statement=P3, updates=45, moved=36, rate=0.8, mean_delta=-0.01
- FAIL scenario=politics, item_target=P2, other_statement=P6, updates=45, moved=37, rate=0.822, mean_delta=0.0411
- FAIL scenario=politics, item_target=P3, other_statement=P1, updates=45, moved=19, rate=0.422, mean_delta=0.0222
- FAIL scenario=politics, item_target=P3, other_statement=P2, updates=45, moved=19, rate=0.422, mean_delta=0.0211
- FAIL scenario=politics, item_target=P3, other_statement=P6, updates=45, moved=26, rate=0.578, mean_delta=0.04
- FAIL scenario=politics, item_target=P4, other_statement=P1, updates=45, moved=35, rate=0.778, mean_delta=0.0567
- FAIL scenario=politics, item_target=P4, other_statement=P2, updates=45, moved=29, rate=0.644, mean_delta=0.0478
- FAIL scenario=politics, item_target=P4, other_statement=P3, updates=45, moved=18, rate=0.4, mean_delta=0.0111
- FAIL scenario=politics, item_target=P4, other_statement=P6, updates=45, moved=35, rate=0.778, mean_delta=0.0667
- FAIL scenario=politics, item_target=P5, other_statement=P1, updates=45, moved=25, rate=0.556, mean_delta=0.0356
- FAIL scenario=politics, item_target=P5, other_statement=P2, updates=45, moved=24, rate=0.533, mean_delta=0.0289
- FAIL scenario=politics, item_target=P5, other_statement=P3, updates=45, moved=12, rate=0.267, mean_delta=-0.0044
- FAIL scenario=politics, item_target=P5, other_statement=P6, updates=45, moved=33, rate=0.733, mean_delta=0.0467
- FAIL scenario=politics, item_target=P6, other_statement=P1, updates=45, moved=20, rate=0.444, mean_delta=0.0444
- FAIL scenario=politics, item_target=P6, other_statement=P2, updates=45, moved=20, rate=0.444, mean_delta=0.0333
- FAIL scenario=politics, item_target=P6, other_statement=P3, updates=45, moved=20, rate=0.444, mean_delta=0.0089

## cap: 2/2 pass

## social: 6/10 pass
- FAIL scenario=destiny2, item_id=C5-low, climate_statement=C7, expected=-, reps=5, climate_popular=0.09, climate_ignored=0.04, climate_diff=0.05, mean_abs_diff_others=0.0
- FAIL scenario=destiny2, item_id=C6-low, climate_statement=C7, expected=-, reps=5, climate_popular=0.05, climate_ignored=0.0, climate_diff=0.05, mean_abs_diff_others=0.0233
- FAIL scenario=politics, item_id=P1-low, climate_statement=P5, expected=-, reps=5, climate_popular=0.05, climate_ignored=0.0, climate_diff=0.05, mean_abs_diff_others=0.016
- FAIL scenario=politics, item_id=P4-high, climate_statement=P5, expected=-, reps=5, climate_popular=0.024, climate_ignored=0.0, climate_diff=0.024, mean_abs_diff_others=0.0268
