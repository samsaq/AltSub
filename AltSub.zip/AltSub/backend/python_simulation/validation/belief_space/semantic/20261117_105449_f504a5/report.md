# Belief statement semantic check: 20261117_105449_f504a5

- Kind: development  |  model: mistral-small-latest  |  reps: 5
- Git: 5b38f99f6c6663aeb4ed72ad8bd3b502f1eb937d (dirty)
- Scale: 0.0 = complete rejection, 0.5 = neutral, 1.0 = complete acceptance
- Criteria: `{"anchor_choice_min_rate": 0.8, "rating_min_in_range": 0.8, "rating_max_direction_errors": 0, "off_target_max_rate": 0.2, "round_trip_min_spearman": 0.8, "round_trip_max_direction_errors": 0, "expression_campaign_min_side_rate": 0.8, "expression_statement_min_correct": 0.8}`

Paraphrase, anchor descriptions and ambiguity replies are coded by the author in coding_sheet.csv.

## anchor_choice: 0/0 pass

## ratings: 0/0 pass

## off_target: 0/0 pass

## round_trip: 0/0 pass

## expression_campaign: 22/26 pass
- FAIL scenario=destiny2, kind=post, statement_id=C7, target=1.0, texts=5, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None
- FAIL scenario=destiny2, kind=reply, statement_id=C3, target=0.0, texts=35, positions_taken=6, campaign_side=4, against_campaign=2, campaign_side_rate=0.667, mean_rating=0.462
- FAIL scenario=politics, kind=post, statement_id=P5, target=0.0, texts=5, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None
- FAIL scenario=politics, kind=reply, statement_id=P5, target=0.0, texts=30, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None

## expression_statement: 0/13 pass
- FAIL scenario=destiny2, statement_id=C1, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.5, mean_at_0.9=0.82
- FAIL scenario=destiny2, statement_id=C2, replies=10, nulls=0, correct=4, correct_rate=0.4, mean_at_0.1=0.1, mean_at_0.9=0.36
- FAIL scenario=destiny2, statement_id=C3, replies=10, nulls=0, correct=6, correct_rate=0.6, mean_at_0.1=0.4, mean_at_0.9=0.94
- FAIL scenario=destiny2, statement_id=C4, replies=10, nulls=0, correct=2, correct_rate=0.2, mean_at_0.1=0.5, mean_at_0.9=0.58
- FAIL scenario=destiny2, statement_id=C5, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.64, mean_at_0.9=1.0
- FAIL scenario=destiny2, statement_id=C6, replies=10, nulls=6, correct=0, correct_rate=0.0, mean_at_0.1=None, mean_at_0.9=0.5
- FAIL scenario=destiny2, statement_id=C7, replies=10, nulls=3, correct=2, correct_rate=0.2, mean_at_0.1=0.375, mean_at_0.9=0.167
- FAIL scenario=politics, statement_id=P1, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.78, mean_at_0.9=0.88
- FAIL scenario=politics, statement_id=P2, replies=10, nulls=0, correct=6, correct_rate=0.6, mean_at_0.1=0.46, mean_at_0.9=0.78
- FAIL scenario=politics, statement_id=P3, replies=10, nulls=0, correct=3, correct_rate=0.3, mean_at_0.1=0.4, mean_at_0.9=0.58
- FAIL scenario=politics, statement_id=P4, replies=10, nulls=0, correct=6, correct_rate=0.6, mean_at_0.1=0.26, mean_at_0.9=0.68
- FAIL scenario=politics, statement_id=P5, replies=10, nulls=3, correct=3, correct_rate=0.3, mean_at_0.1=0.55, mean_at_0.9=0.733
- FAIL scenario=politics, statement_id=P6, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.78, mean_at_0.9=0.96
