# Belief statement semantic check: 20261117_115841_10fb0c

- Kind: development  |  model: mistral-small-latest  |  reps: 5
- Git: 5b38f99f6c6663aeb4ed72ad8bd3b502f1eb937d (dirty)
- Scale: 0.0 = complete rejection, 0.5 = neutral, 1.0 = complete acceptance
- Criteria: `{"anchor_choice_min_rate": 0.8, "rating_min_in_range": 0.8, "rating_max_direction_errors": 0, "off_target_max_rate": 0.2, "round_trip_min_spearman": 0.8, "round_trip_max_direction_errors": 0, "expression_campaign_min_side_rate": 0.8, "expression_statement_min_correct": 0.8}`

Paraphrase, anchor descriptions and ambiguity replies are coded by the author in coding_sheet.csv.

## anchor_choice: 0/0 pass

## ratings: 0/0 pass

## off_target: 0/0 pass

## round_trip: 0/0 pass

## expression_campaign: 31/39 pass
- FAIL scenario=destiny2, kind=post, statement_id=C2, target=0.0, texts=5, positions_taken=5, campaign_side=3, against_campaign=2, campaign_side_rate=0.6, mean_rating=0.4
- FAIL scenario=destiny2, kind=post, statement_id=C7, target=1.0, texts=5, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None
- FAIL scenario=destiny2, kind=reply-opposing, statement_id=C2, target=0.0, texts=35, positions_taken=33, campaign_side=26, against_campaign=7, campaign_side_rate=0.788, mean_rating=0.229
- FAIL scenario=destiny2, kind=reply-opposing, statement_id=C3, target=0.0, texts=35, positions_taken=19, campaign_side=14, against_campaign=5, campaign_side_rate=0.737, mean_rating=0.364
- FAIL scenario=politics, kind=post, statement_id=P4, target=1.0, texts=5, positions_taken=2, campaign_side=1, against_campaign=1, campaign_side_rate=0.5, mean_rating=0.5
- FAIL scenario=politics, kind=post, statement_id=P5, target=0.0, texts=5, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None
- FAIL scenario=politics, kind=reply-neutral, statement_id=P5, target=0.0, texts=30, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=0.5
- FAIL scenario=politics, kind=reply-opposing, statement_id=P4, target=1.0, texts=30, positions_taken=9, campaign_side=6, against_campaign=3, campaign_side_rate=0.667, mean_rating=0.554

## expression_statement: 0/0 pass
