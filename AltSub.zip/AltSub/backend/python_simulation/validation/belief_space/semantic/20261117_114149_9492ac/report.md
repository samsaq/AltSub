# Belief statement semantic check: 20261117_114149_9492ac

- Kind: development  |  model: mistral-small-latest  |  reps: 5
- Git: 5b38f99f6c6663aeb4ed72ad8bd3b502f1eb937d (dirty)
- Scale: 0.0 = complete rejection, 0.5 = neutral, 1.0 = complete acceptance
- Criteria: `{"anchor_choice_min_rate": 0.8, "rating_min_in_range": 0.8, "rating_max_direction_errors": 0, "off_target_max_rate": 0.2, "round_trip_min_spearman": 0.8, "round_trip_max_direction_errors": 0, "expression_campaign_min_side_rate": 0.8, "expression_statement_min_correct": 0.8}`

Paraphrase, anchor descriptions and ambiguity replies are coded by the author in coding_sheet.csv.

## anchor_choice: 13/13 pass

## ratings: 34/39 pass
- FAIL scenario=destiny2, item_id=C2-neutral, statement_id=C2, expected=neutral, reps=5, nulls=0, mean=0.1, sd=0.224, in_range_rate=0.2, direction_errors=0
- FAIL scenario=destiny2, item_id=C7-low, statement_id=C7, expected=low, reps=5, nulls=0, mean=0.5, sd=0.5, in_range_rate=0.4, direction_errors=2
- FAIL scenario=destiny2, item_id=C7-neutral, statement_id=C7, expected=neutral, reps=5, nulls=2, mean=0.5, sd=0.0, in_range_rate=0.6, direction_errors=0
- FAIL scenario=politics, item_id=P1-neutral, statement_id=P1, expected=neutral, reps=5, nulls=4, mean=0.5, sd=0.0, in_range_rate=0.2, direction_errors=0
- FAIL scenario=politics, item_id=P5-low, statement_id=P5, expected=low, reps=5, nulls=0, mean=0.4, sd=0.224, in_range_rate=0.2, direction_errors=0

## off_target: 43/85 pass
- FAIL scenario=destiny2, item_target=C1, other_statement=C2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C1, other_statement=C4, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C2, other_statement=C1, readings=15, positions_taken=6, rate=0.4
- FAIL scenario=destiny2, item_target=C2, other_statement=C4, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C3, other_statement=C4, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C4, other_statement=C1, readings=15, positions_taken=8, rate=0.533
- FAIL scenario=destiny2, item_target=C4, other_statement=C2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C4, other_statement=C3, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C5, other_statement=C1, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=destiny2, item_target=C5, other_statement=C3, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C5, other_statement=C4, readings=15, positions_taken=9, rate=0.6
- FAIL scenario=destiny2, item_target=C5, other_statement=C6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C6, other_statement=C1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C4, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C5, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=destiny2, item_target=C7, other_statement=C2, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C7, other_statement=C4, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C7, other_statement=C5, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C1, readings=10, positions_taken=9, rate=0.9
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C3, readings=10, positions_taken=9, rate=0.9
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C4, readings=10, positions_taken=9, rate=0.9
- FAIL scenario=politics, item_target=P1, other_statement=P2, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P1, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P1, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P2, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P2, other_statement=P3, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=politics, item_target=P2, other_statement=P6, readings=15, positions_taken=6, rate=0.4
- FAIL scenario=politics, item_target=P3, other_statement=P1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P3, other_statement=P2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P3, other_statement=P6, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P4, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P4, other_statement=P2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P4, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P4, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P5, other_statement=P1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P6, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P6, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P6, other_statement=P2, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P6, other_statement=P3, readings=15, positions_taken=10, rate=0.667

## round_trip: 0/0 pass
