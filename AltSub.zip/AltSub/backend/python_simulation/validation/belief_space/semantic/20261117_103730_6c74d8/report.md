# Belief statement semantic check: 20261117_103730_6c74d8

- Kind: development  |  model: mistral-small-latest  |  reps: 5
- Git: 5b38f99f6c6663aeb4ed72ad8bd3b502f1eb937d (dirty)
- Scale: 0.0 = complete rejection, 0.5 = neutral, 1.0 = complete acceptance
- Criteria: `{"anchor_choice_min_rate": 0.8, "rating_min_in_range": 0.8, "rating_max_direction_errors": 0, "off_target_max_rate": 0.2, "round_trip_min_spearman": 0.8, "round_trip_max_direction_errors": 0, "expression_campaign_min_side_rate": 0.8, "expression_statement_min_correct": 0.8}`

Paraphrase, anchor descriptions and ambiguity replies are coded by the author in coding_sheet.csv.

## anchor_choice: 0/0 pass

## ratings: 34/39 pass
- FAIL scenario=destiny2, item_id=C2-neutral, statement_id=C2, expected=neutral, reps=5, nulls=0, mean=0.0, sd=0.0, in_range_rate=0.0, direction_errors=0
- FAIL scenario=destiny2, item_id=C7-low, statement_id=C7, expected=low, reps=5, nulls=0, mean=0.2, sd=0.447, in_range_rate=0.8, direction_errors=1
- FAIL scenario=politics, item_id=P1-neutral, statement_id=P1, expected=neutral, reps=5, nulls=3, mean=0.5, sd=0.0, in_range_rate=0.4, direction_errors=0
- FAIL scenario=politics, item_id=P5-low, statement_id=P5, expected=low, reps=5, nulls=0, mean=0.3, sd=0.274, in_range_rate=0.4, direction_errors=0
- FAIL scenario=politics, item_id=P6-neutral, statement_id=P6, expected=neutral, reps=5, nulls=0, mean=0.7, sd=0.274, in_range_rate=0.6, direction_errors=0

## off_target: 44/85 pass
- FAIL scenario=destiny2, item_target=C1, other_statement=C2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C1, other_statement=C4, readings=15, positions_taken=9, rate=0.6
- FAIL scenario=destiny2, item_target=C2, other_statement=C1, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=destiny2, item_target=C2, other_statement=C4, readings=15, positions_taken=6, rate=0.4
- FAIL scenario=destiny2, item_target=C3, other_statement=C4, readings=15, positions_taken=12, rate=0.8
- FAIL scenario=destiny2, item_target=C4, other_statement=C1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C4, other_statement=C2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C4, other_statement=C3, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C4, other_statement=C5, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C4, other_statement=C6, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C5, other_statement=C1, readings=15, positions_taken=6, rate=0.4
- FAIL scenario=destiny2, item_target=C5, other_statement=C4, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=destiny2, item_target=C5, other_statement=C6, readings=15, positions_taken=11, rate=0.733
- FAIL scenario=destiny2, item_target=C6, other_statement=C1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C4, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C5, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=destiny2, item_target=C7, other_statement=C5, readings=15, positions_taken=9, rate=0.6
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C1, readings=10, positions_taken=8, rate=0.8
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C3, readings=10, positions_taken=8, rate=0.8
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C4, readings=10, positions_taken=8, rate=0.8
- FAIL scenario=politics, item_target=P1, other_statement=P2, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P1, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P1, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P2, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P2, other_statement=P3, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=politics, item_target=P2, other_statement=P6, readings=15, positions_taken=8, rate=0.533
- FAIL scenario=politics, item_target=P3, other_statement=P1, readings=15, positions_taken=11, rate=0.733
- FAIL scenario=politics, item_target=P3, other_statement=P2, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=politics, item_target=P3, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P4, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P4, other_statement=P2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P4, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P4, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P5, other_statement=P1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P6, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P6, other_statement=P1, readings=15, positions_taken=12, rate=0.8
- FAIL scenario=politics, item_target=P6, other_statement=P2, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P6, other_statement=P3, readings=15, positions_taken=10, rate=0.667

## round_trip: 0/0 pass

## expression_campaign: 13/26 pass
- FAIL scenario=destiny2, kind=post, statement_id=C3, target=0.0, texts=5, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=0.5
- FAIL scenario=destiny2, kind=reply, statement_id=C1, target=0.0, texts=35, positions_taken=12, campaign_side=9, against_campaign=3, campaign_side_rate=0.75, mean_rating=0.4
- FAIL scenario=destiny2, kind=reply, statement_id=C3, target=0.0, texts=35, positions_taken=9, campaign_side=6, against_campaign=3, campaign_side_rate=0.667, mean_rating=0.448
- FAIL scenario=destiny2, kind=reply, statement_id=C7, target=1.0, texts=35, positions_taken=8, campaign_side=5, against_campaign=3, campaign_side_rate=0.625, mean_rating=0.6
- FAIL scenario=politics, kind=post, statement_id=P1, target=0.0, texts=5, positions_taken=4, campaign_side=2, against_campaign=2, campaign_side_rate=0.5, mean_rating=0.5
- FAIL scenario=politics, kind=post, statement_id=P2, target=0.0, texts=5, positions_taken=4, campaign_side=2, against_campaign=2, campaign_side_rate=0.5, mean_rating=0.5
- FAIL scenario=politics, kind=post, statement_id=P5, target=0.0, texts=5, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None
- FAIL scenario=politics, kind=post, statement_id=P6, target=0.0, texts=5, positions_taken=4, campaign_side=3, against_campaign=1, campaign_side_rate=0.75, mean_rating=0.3
- FAIL scenario=politics, kind=reply, statement_id=P1, target=0.0, texts=30, positions_taken=17, campaign_side=4, against_campaign=13, campaign_side_rate=0.235, mean_rating=0.628
- FAIL scenario=politics, kind=reply, statement_id=P2, target=0.0, texts=30, positions_taken=11, campaign_side=5, against_campaign=6, campaign_side_rate=0.455, mean_rating=0.472
- FAIL scenario=politics, kind=reply, statement_id=P4, target=1.0, texts=30, positions_taken=15, campaign_side=11, against_campaign=4, campaign_side_rate=0.733, mean_rating=0.611
- FAIL scenario=politics, kind=reply, statement_id=P5, target=0.0, texts=30, positions_taken=0, campaign_side=0, against_campaign=0, campaign_side_rate=None, mean_rating=None
- FAIL scenario=politics, kind=reply, statement_id=P6, target=0.0, texts=30, positions_taken=23, campaign_side=1, against_campaign=22, campaign_side_rate=0.043, mean_rating=0.83

## expression_statement: 0/13 pass
- FAIL scenario=destiny2, statement_id=C1, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.6, mean_at_0.9=0.82
- FAIL scenario=destiny2, statement_id=C2, replies=10, nulls=0, correct=7, correct_rate=0.7, mean_at_0.1=0.0, mean_at_0.9=0.54
- FAIL scenario=destiny2, statement_id=C3, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.56, mean_at_0.9=1.0
- FAIL scenario=destiny2, statement_id=C4, replies=10, nulls=0, correct=3, correct_rate=0.3, mean_at_0.1=0.5, mean_at_0.9=0.74
- FAIL scenario=destiny2, statement_id=C5, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.6, mean_at_0.9=0.95
- FAIL scenario=destiny2, statement_id=C6, replies=10, nulls=5, correct=0, correct_rate=0.0, mean_at_0.1=1.0, mean_at_0.9=0.5
- FAIL scenario=destiny2, statement_id=C7, replies=10, nulls=7, correct=1, correct_rate=0.1, mean_at_0.1=None, mean_at_0.9=0.433
- FAIL scenario=politics, statement_id=P1, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.78, mean_at_0.9=0.88
- FAIL scenario=politics, statement_id=P2, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.62, mean_at_0.9=0.74
- FAIL scenario=politics, statement_id=P3, replies=10, nulls=0, correct=6, correct_rate=0.6, mean_at_0.1=0.26, mean_at_0.9=0.64
- FAIL scenario=politics, statement_id=P4, replies=10, nulls=0, correct=7, correct_rate=0.7, mean_at_0.1=0.16, mean_at_0.9=0.62
- FAIL scenario=politics, statement_id=P5, replies=10, nulls=7, correct=3, correct_rate=0.3, mean_at_0.1=None, mean_at_0.9=0.767
- FAIL scenario=politics, statement_id=P6, replies=10, nulls=0, correct=5, correct_rate=0.5, mean_at_0.1=0.76, mean_at_0.9=0.98
