# Belief statement semantic check: 20261117_102633_76e6da

- Kind: development  |  model: mistral-small-latest  |  reps: 5
- Git: 5b38f99f6c6663aeb4ed72ad8bd3b502f1eb937d (dirty)
- Scale: 0.0 = complete rejection, 0.5 = neutral, 1.0 = complete acceptance
- Criteria: `{"anchor_choice_min_rate": 0.8, "rating_min_in_range": 0.8, "rating_max_direction_errors": 0, "off_target_max_rate": 0.2, "round_trip_min_spearman": 0.8, "round_trip_max_direction_errors": 0}`

Paraphrase, anchor descriptions and ambiguity replies are coded by the author in coding_sheet.csv.

## anchor_choice: 13/13 pass

## ratings: 33/39 pass
- FAIL scenario=destiny2, item_id=C2-neutral, statement_id=C2, expected=neutral, reps=5, nulls=0, mean=0.0, sd=0.0, in_range_rate=0.0, direction_errors=0
- FAIL scenario=destiny2, item_id=C7-neutral, statement_id=C7, expected=neutral, reps=5, nulls=3, mean=0.0, sd=0.0, in_range_rate=0.0, direction_errors=0
- FAIL scenario=politics, item_id=P1-neutral, statement_id=P1, expected=neutral, reps=5, nulls=5, mean=None, sd=None, in_range_rate=0.0, direction_errors=0
- FAIL scenario=politics, item_id=P4-neutral, statement_id=P4, expected=neutral, reps=5, nulls=5, mean=None, sd=None, in_range_rate=0.0, direction_errors=0
- FAIL scenario=politics, item_id=P5-neutral, statement_id=P5, expected=neutral, reps=5, nulls=5, mean=None, sd=None, in_range_rate=0.0, direction_errors=0
- FAIL scenario=politics, item_id=P6-neutral, statement_id=P6, expected=neutral, reps=5, nulls=0, mean=0.9, sd=0.224, in_range_rate=0.2, direction_errors=0

## off_target: 42/85 pass
- FAIL scenario=destiny2, item_target=C1, other_statement=C2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C1, other_statement=C4, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C2, other_statement=C1, readings=15, positions_taken=11, rate=0.733
- FAIL scenario=destiny2, item_target=C2, other_statement=C4, readings=15, positions_taken=6, rate=0.4
- FAIL scenario=destiny2, item_target=C3, other_statement=C1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C3, other_statement=C4, readings=15, positions_taken=11, rate=0.733
- FAIL scenario=destiny2, item_target=C3, other_statement=C5, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C3, other_statement=C6, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C4, other_statement=C1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C4, other_statement=C2, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C4, other_statement=C3, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C5, other_statement=C1, readings=15, positions_taken=8, rate=0.533
- FAIL scenario=destiny2, item_target=C5, other_statement=C3, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=destiny2, item_target=C5, other_statement=C4, readings=15, positions_taken=8, rate=0.533
- FAIL scenario=destiny2, item_target=C5, other_statement=C6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=C6, other_statement=C1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C4, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=destiny2, item_target=C6, other_statement=C5, readings=15, positions_taken=8, rate=0.533
- FAIL scenario=destiny2, item_target=C7, other_statement=C5, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C1, readings=10, positions_taken=7, rate=0.7
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C3, readings=10, positions_taken=7, rate=0.7
- FAIL scenario=destiny2, item_target=off-topic, other_statement=C4, readings=10, positions_taken=7, rate=0.7
- FAIL scenario=politics, item_target=P1, other_statement=P2, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P1, other_statement=P3, readings=15, positions_taken=4, rate=0.267
- FAIL scenario=politics, item_target=P1, other_statement=P6, readings=15, positions_taken=9, rate=0.6
- FAIL scenario=politics, item_target=P2, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P2, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P2, other_statement=P6, readings=15, positions_taken=6, rate=0.4
- FAIL scenario=politics, item_target=P3, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P3, other_statement=P2, readings=15, positions_taken=8, rate=0.533
- FAIL scenario=politics, item_target=P3, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P4, other_statement=P1, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P4, other_statement=P2, readings=15, positions_taken=7, rate=0.467
- FAIL scenario=politics, item_target=P4, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P4, other_statement=P6, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P5, other_statement=P1, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P2, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P3, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P5, other_statement=P6, readings=15, positions_taken=5, rate=0.333
- FAIL scenario=politics, item_target=P6, other_statement=P1, readings=15, positions_taken=13, rate=0.867
- FAIL scenario=politics, item_target=P6, other_statement=P2, readings=15, positions_taken=10, rate=0.667
- FAIL scenario=politics, item_target=P6, other_statement=P3, readings=15, positions_taken=10, rate=0.667

## round_trip: 0/13 pass
- FAIL scenario=destiny2, statement_id=C1, pairs=15, nulls=0, spearman=0.0, direction_errors=4, mean_at_0.1=0.86, mean_at_0.5=0.96, mean_at_0.9=0.86
- FAIL scenario=destiny2, statement_id=C2, pairs=15, nulls=0, spearman=0.0, direction_errors=4, mean_at_0.1=0.5, mean_at_0.5=0.4, mean_at_0.9=0.5
- FAIL scenario=destiny2, statement_id=C3, pairs=15, nulls=0, spearman=0.294, direction_errors=4, mean_at_0.1=0.84, mean_at_0.5=0.6, mean_at_0.9=1.0
- FAIL scenario=destiny2, statement_id=C4, pairs=15, nulls=0, spearman=0.439, direction_errors=4, mean_at_0.1=0.72, mean_at_0.5=0.6, mean_at_0.9=1.0
- FAIL scenario=destiny2, statement_id=C5, pairs=15, nulls=0, spearman=-0.057, direction_errors=5, mean_at_0.1=0.7, mean_at_0.5=0.9, mean_at_0.9=0.6
- FAIL scenario=destiny2, statement_id=C6, pairs=15, nulls=0, spearman=-0.062, direction_errors=5, mean_at_0.1=0.88, mean_at_0.5=0.66, mean_at_0.9=0.84
- FAIL scenario=destiny2, statement_id=C7, pairs=15, nulls=13, spearman=None, direction_errors=1, mean_at_0.1=None, mean_at_0.5=0.0, mean_at_0.9=0.0
- FAIL scenario=politics, statement_id=P1, pairs=15, nulls=0, spearman=0.356, direction_errors=3, mean_at_0.1=0.6, mean_at_0.5=0.32, mean_at_0.9=1.0
- FAIL scenario=politics, statement_id=P2, pairs=15, nulls=0, spearman=0.755, direction_errors=1, mean_at_0.1=0.14, mean_at_0.5=0.0, mean_at_0.9=0.96
- FAIL scenario=politics, statement_id=P3, pairs=15, nulls=0, spearman=0.529, direction_errors=1, mean_at_0.1=0.4, mean_at_0.5=0.3, mean_at_0.9=0.96
- FAIL scenario=politics, statement_id=P4, pairs=15, nulls=11, spearman=-0.577, direction_errors=1, mean_at_0.1=None, mean_at_0.5=0.5, mean_at_0.9=0.25
- FAIL scenario=politics, statement_id=P5, pairs=15, nulls=14, spearman=None, direction_errors=1, mean_at_0.1=None, mean_at_0.5=None, mean_at_0.9=0.0
- FAIL scenario=politics, statement_id=P6, pairs=15, nulls=0, spearman=None, direction_errors=5, mean_at_0.1=1.0, mean_at_0.5=1.0, mean_at_0.9=1.0
