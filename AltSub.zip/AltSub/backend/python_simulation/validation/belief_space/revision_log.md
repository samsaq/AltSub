# Belief statement revision log

One entry per change to a statement or to the scale wording, with the run that
motivated it. Statement text lives in `core/belief_axes.py`.

| Date | Statement | Old wording | New wording | Reason | Evidence (run id) |
|---|---|---|---|---|---|
| 2026-11-17 | Scale | 0 = complete non-acceptance | 0 = complete rejection | "Non-acceptance" also covers undecided users, so doubt could read as rejection; rejection makes 0 the opposite of 1 | (design review, before probing) |
| 2026-11-17 | P5 | "Most r/poltiics redditors…" | "Most r/politics redditors…" | Typo | (design review) |
| 2026-11-17 | C7 | "…believes Warframe the best alternative…" | "…believes Warframe is the best alternative…" | Grammar | (design review) |
| 2026-11-17 | C7 | "The wider r/Destiny2 community believes Warframe is the best alternative to Destiny 2." | "Most people in r/Destiny2 think Warframe is a worthwhile alternative to Destiny 2." | Ambiguity probe: "the wider community" (majority / vocal users / all subscribers) and "the best"; update tests: rejecting posts raised C7 to the cap and popularity only ever raised it. Now the perceived-majority counterpart of C5 | semantic 20261117_102633_76e6da; updates 20261117_112131_71f7eb, 20261117_113052_017a40 |
| 2026-11-17 | P5 | "Most r/politics redditors believe the strike was carried out by Russian forces." | "Most people in r/politics think Russian forces carried out the Okhmatdyt hospital strike." | "The strike" read as possibly a labor strike; popularity of skeptical posts never lowered P5. Names the event; perceived-majority counterpart of P1 | semantic 20261117_102633_76e6da; updates 20261117_113052_017a40 |
| 2026-11-17 | P4 | "At the time of the strike, the hospital was being used for military purposes." | "At the time of the strike, the Okhmatdyt hospital was being used for military purposes." | Not self-contained: "the strike" read as a labor strike / protest | semantic 20261117_102633_76e6da |
| 2026-11-17 | P6 | "Russian authorities should be held accountable for the attack." | "Russian authorities should be held accountable for the strike on the Okhmatdyt hospital." | Not self-contained: "the attack" read as the 2016 election interference / any Russian attack | semantic 20261117_102633_76e6da |
| 2026-11-17 | Narrative (politics) | "More and more people here aren't buying the official story." | "Most people on this sub aren't convinced Russia did it." | Expression probe: attackers never voiced P5 because the sentence did not mention Russia | semantic 20261117_112131_a37175 |
| 2026-11-17 | P5 | "Most people in r/politics think Russian forces carried out the Okhmatdyt hospital strike." | "Most people in r/worldnews think Russian forces carried out the Okhmatdyt hospital strike." | Political scenario moved from r/politics to r/worldnews (r/politics' rules require U.S. focus, so the rule moderator removed on-topic scenario content as off-topic) | smoke run ~/smoke_test_week (WSL) |
