# Belief space validation

Artifacts for the thesis section "Belief Space Validation": checks that the
scenario belief statements (`core/belief_axes.py`, C1–C7 and P1–P6) and the
acceptance scale (0.0 = complete rejection, 0.5 = neutral, 1.0 = complete
acceptance) work as intended in the simulation.

## Semantic check

Probes the simulation's own model, through its own LLM client and with the
same framing, about each statement: paraphrase, scale anchors, an anchor
multiple choice, ambiguity, ratings of the scenario posts in
`scenario_items.json`, and a generate-then-rate round trip. See the docstring of
`tools/validate_belief_semantics.py` for the probes and pass criteria.

From `backend/`:

```bash
python -m python_simulation.tools.validate_belief_semantics run --dry-run            # number of calls
python -m python_simulation.tools.validate_belief_semantics run --kind development   # iterate
python -m python_simulation.tools.validate_belief_semantics run --kind record        # run cited in the thesis
python -m python_simulation.tools.validate_belief_semantics chat --scenario politics --statement P4
```

Each run writes `semantic/<run_id>/`:

| File | Contents |
|---|---|
| `manifest.json` | git commit, model, temperatures, repetitions, hashes of statements, scenario items and prompts |
| `calls.jsonl` | every LLM call: probe, statement / item, repetition, messages sent, raw reply, parsed result |
| `summary/*.csv` | automatic scoring: anchor choice, ratings, off-target readings, round trip |
| `coding_sheet.csv` | paraphrase / anchor / ambiguity replies to code by hand (pass / flag / fail + note) |
| `report.md` | pass / fail against the fixed criteria |

Follow-up conversations (`chat`) are logged turn by turn in `semantic/conversations/`.

## Workflow

1. Review and edit `scenario_items.json` (drafted; expected range per post).
2. Development runs until the statements pass; code `coding_sheet.csv`.
3. A statement that fails is reworded in `core/belief_axes.py`; record the
   change in `revision_log.md` (old wording -> new wording, reason, run id).
4. A final `--kind record` run on a clean git tree is the one the thesis cites.
