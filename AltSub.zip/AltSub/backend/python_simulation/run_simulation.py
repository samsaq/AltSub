#!/usr/bin/env python3
"""
Main Simulation Runner: Entry point for running Python simulations

Loads configuration from reddit_agent_initializer.py output and runs the simulation.
"""

import json
import logging
import os
import random
import sys
import time
import numpy as np
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Any
from dotenv import load_dotenv

# Look for .env in common locations:
# 1. Current directory
# 2. backend/python_simulation/
# 3. Simulation_Setups/ (for simulation runs)
_env_paths = [
    Path.cwd() / ".env",
    Path(__file__).parent.parent / ".env",
    Path(__file__).parent.parent.parent / "Simulation_Setups" / ".env",
]

for env_path in _env_paths:
    if env_path.exists():
        load_dotenv(env_path, override=False)
        logging.getLogger(__name__).debug(f"Loaded .env from {env_path}")
        break

from .core import (
    SimulationEngine,
    SimulationConfig,
    SimulationState,
    BeliefNetwork,
    SubredditMembership,
    BannedAgentNetwork,
    ActivityWeights,
    FeedManager,
    FeedOrderingStrategy,
    DefaultFeedOrderingStrategy,
    ChronologicalFeedOrderingStrategy,
    ScoreBasedFeedOrderingStrategy,
    EngagementWeightedFeedOrderingStrategy,
    RedditHotFeedOrderingStrategy,
    RedditAllHotFeedOrderingStrategy,
    AgentManager,
)
from .systems import MitigationSystem, OutputManager

from .agents import (
    LLMUserAgent,
    LLMAttackerAgent,
    TemplateAttackerAgent,
    BiasedModeratorAgent,
    RuleModeratorAgent,
)
from .core.rule_moderator_schedule import generate_rule_moderator_schedules
from .core.time_model import TimeModel
from .core.belief_axes import (
    BELIEF_MODELS,
    BeliefConfig,
    campaign_positions,
    complete_positions,
    default_belief_config,
)
from .core.attacker_coordination import (
    CoordinationHub,
    DEFAULT_COORDINATION_COMMENT_PROB,
    DEFAULT_COORDINATION_DELAY_MAX,
    DEFAULT_COORDINATION_DELAY_MIN,
)

try:
    from .services.llm_reddit_service import LLMRedditService, LLMServiceConfig
except ImportError:
    LLMRedditService = None
    LLMServiceConfig = None

try:
    from .services.attacker_campaign_orchestrator import (
        AttackerCampaignOrchestrator,
        CampaignConfig,
        CampaignObjective,
    )
except ImportError:
    AttackerCampaignOrchestrator = None
    CampaignConfig = None
    CampaignObjective = None

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
log = logging.getLogger(__name__)

def _debug_log_path() -> Path:
    """Resolve profiling log path: EXPERIMENT_DIR/profiling.log if set, else repo root."""
    if os.environ.get("DEBUG_LOG_PATH"):
        return Path(os.environ["DEBUG_LOG_PATH"])
    return Path(__file__).resolve().parent.parent.parent / "profiling.log"


def _debug_log(location: str, message: str, data: dict, hypothesis_id: str = ""):
    import json
    p = _debug_log_path()
    payload = {"sessionId": "977fa7", "location": location, "message": message, "data": data, "timestamp": int(time.time() * 1000), "hypothesisId": hypothesis_id}
    try:
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(payload) + "\n")
    except Exception:
        pass


def load_config(config_path: str) -> Dict:
    """Load simulation configuration from JSON file"""
    with open(config_path, "r") as f:
        config = json.load(f)
    return config


def load_agent_profiles(profiles_path: str) -> List[Dict]:
    """Load agent profiles from JSON file"""
    with open(profiles_path, "r") as f:
        profiles = json.load(f)
    return profiles


def fill_campaign_narrative_from_default_template(
    config: Dict[str, Any], config_dir: Path
) -> None:
    """
    When template attackers or a biased moderator need a narrative but fields were
    never written (e.g. older init), read narrative from
    campaign_templates/default_campaign.json so in-run config matches the template
    campaign. Does not regenerate agent_profiles; re-run initialization to refresh
    beliefs and campaign_belief_texts.
    """
    sim = config.get("simulation_config", {})
    cc = config.setdefault("campaign_config", {})
    existing = (
        cc.get("target_narrative") or sim.get("attacker_target_narrative") or ""
    ).strip()
    if existing:
        return
    biased_on = bool(
        config.get("biased_moderator_config", {}).get("enable_biased_moderator", False)
    )
    if int(sim.get("num_template_attacker", 0) or 0) <= 0 and not biased_on:
        return

    raw_dir = cc.get("campaign_templates_dir", "campaign_templates")
    base = Path(raw_dir)
    if not base.is_absolute():
        base = config_dir / base
    template_path = base / "default_campaign.json"
    if not template_path.is_file():
        log.debug("Narrative fallback skipped; not found: %s", template_path)
        return
    try:
        with open(template_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError) as e:
        log.warning("Could not read narrative from %s: %s", template_path, e)
        return

    narrative = (data.get("narrative") or "").strip()
    if not narrative:
        narrative = (data.get("description") or "").strip()
    if not narrative:
        narrative = (data.get("campaign_name") or "").strip()
    if not narrative:
        return

    cc["target_narrative"] = narrative
    sim["attacker_target_narrative"] = narrative
    log.info(
        "Filled attacker narrative from %s for this run (re-init to persist in JSON)",
        template_path.name,
    )


def _parse_bool(value: Any) -> bool:
    """Parse common truthy string/bool values."""
    if isinstance(value, bool):
        return value
    if value is None:
        return False
    return str(value).strip().lower() in ("true", "yes", "on", "1")


def apply_mitigation_env_overrides(config: Dict[str, Any]) -> None:
    """Optional env overrides for mitigation_config (same precedence pattern as runtime_config)."""
    mit = config.setdefault("mitigation_config", {})
    env_int = os.getenv("MITIGATION_RULE_MODERATOR_COUNT")
    if env_int is not None and env_int.strip() != "":
        try:
            mit["rule_moderator_count"] = int(env_int)
            if int(env_int) > 0:
                mit["enable_rule_moderators"] = True
        except ValueError:
            log.warning("Invalid MITIGATION_RULE_MODERATOR_COUNT: %s", env_int)
    env_frac = os.getenv("MITIGATION_RULE_MODERATOR_ACTIVE_FRACTION")
    if env_frac is not None and env_frac.strip() != "":
        try:
            mit["rule_moderator_active_fraction"] = float(env_frac)
        except ValueError:
            log.warning("Invalid MITIGATION_RULE_MODERATOR_ACTIVE_FRACTION: %s", env_frac)
    env_rd = os.getenv("MITIGATION_RULE_MODERATOR_READ_DENSITY")
    if env_rd is not None and env_rd.strip() != "":
        try:
            mit["rule_moderator_read_density"] = int(env_rd)
        except ValueError:
            log.warning("Invalid MITIGATION_RULE_MODERATOR_READ_DENSITY: %s", env_rd)
    env_seed = os.getenv("MITIGATION_RULE_MODERATOR_SCHEDULE_SEED")
    if env_seed is not None and env_seed.strip() != "":
        try:
            mit["rule_moderator_schedule_seed"] = int(env_seed)
        except ValueError:
            log.warning("Invalid MITIGATION_RULE_MODERATOR_SCHEDULE_SEED: %s", env_seed)
    env_en = os.getenv("MITIGATION_ENABLE_RULE_MODERATORS")
    if env_en is not None and env_en.strip() != "":
        mit["enable_rule_moderators"] = _parse_bool(env_en)


def ensure_rule_moderator_schedules(
    config: Dict[str, Any], agent_profiles: List[Dict[str, Any]]
) -> None:
    """Fill agent_activity_schedules for rule_moderator indices if missing or wrong length."""
    mit = config.setdefault("mitigation_config", {})
    sim = config.get("simulation_config", {})
    interval = int(sim.get("interval_minutes", 5))
    timesteps_per_day = (24 * 60) // interval
    total_days = int(sim.get("duration_days", 14))
    num_timesteps = timesteps_per_day * total_days
    rule_indices = [
        i
        for i, p in enumerate(agent_profiles)
        if p.get("user_type") == "rule_moderator"
    ]
    n = len(rule_indices)
    if n == 0:
        return
    schedules = config.setdefault("agent_activity_schedules", {})
    need = False
    for i in rule_indices:
        s = schedules.get(str(i))
        if not s or len(s) != num_timesteps:
            need = True
            break
    if not need:
        return
    seed = int(mit.get("rule_moderator_schedule_seed", 42))
    fraction = float(mit.get("rule_moderator_active_fraction", 0.25))
    generated = generate_rule_moderator_schedules(
        num_timesteps, timesteps_per_day, n, fraction, seed
    )
    for j, idx in enumerate(rule_indices):
        schedules[str(idx)] = generated[j].astype(int).tolist()
    log.info(
        "Generated rule_moderator activity schedules (%d moderators, %d timesteps)",
        n,
        num_timesteps,
    )


OBSOLETE_COORDINATION_KEYS = (
    "coordination_min_group_size",
    "coordination_score_scale",
    "coordination_amplification_concentration",
)


def build_mitigation_system(config: Dict[str, Any]) -> MitigationSystem:
    mitigation_config = config.get("mitigation_config", {})
    interval_minutes = config.get("simulation_config", {}).get("interval_minutes", 5)
    for key in OBSOLETE_COORDINATION_KEYS:
        if key in mitigation_config:
            log.warning(
                "mitigation_config.%s is ignored (coordination detection was replaced "
                "by the co-action network detector)",
                key,
            )
    # Old name for the co-engagement score threshold
    similarity_threshold = mitigation_config.get(
        "coordination_similarity_threshold",
        mitigation_config.get("coordination_suspicion_threshold", 0.3),
    )
    return MitigationSystem(
        duplicate_detection_enabled=mitigation_config.get(
            "enable_duplicate_detection", False
        ),
        rate_limiting_enabled=mitigation_config.get("enable_rate_limiting", False),
        coordinated_detection_enabled=mitigation_config.get(
            "enable_coordinated_detection", False
        ),
        scan_frequency=mitigation_config.get("mitigation_scan_frequency", 10),
        duplicate_similarity_threshold=mitigation_config.get(
            "duplicate_similarity_threshold", 0.85
        ),
        rate_limit_window=mitigation_config.get("rate_limit_window", 24),
        rate_limit_threshold=mitigation_config.get("rate_limit_threshold", 10),
        ban_threshold=mitigation_config.get("mitigation_ban_threshold", 3),
        use_embedding_similarity_for_duplicates=mitigation_config.get(
            "use_embedding_similarity_for_duplicates", False
        ),
        duplicate_lookback_window=mitigation_config.get(
            "duplicate_lookback_window", 100
        ),
        coordination_lookback_window=mitigation_config.get(
            "coordination_lookback_window", 144
        ),
        duplicate_embedder_model=mitigation_config.get(
            "duplicate_embedder_model", "all-MiniLM-L6-v2"
        ),
        coordination_sync_window=mitigation_config.get("coordination_sync_window", 6),
        coordination_min_shared_targets=mitigation_config.get(
            "coordination_min_shared_targets", 3
        ),
        coordination_similarity_threshold=similarity_threshold,
        coordination_content_similarity_threshold=mitigation_config.get(
            "coordination_content_similarity_threshold", 0.8
        ),
        coordination_min_content_matches=mitigation_config.get(
            "coordination_min_content_matches", 2
        ),
        coordination_min_amplifications=mitigation_config.get(
            "coordination_min_amplifications", 3
        ),
        coordination_significance=mitigation_config.get(
            "coordination_significance", 0.01
        ),
        use_embedding_similarity_for_coordination=mitigation_config.get(
            "use_embedding_similarity_for_coordination", False
        ),
        step_s=float(interval_minutes) * 60.0,
    )


# Campaign defaults when campaign_config omits them (match the orchestrator's)
DEFAULT_COORDINATION_STRENGTH = 0.8
DEFAULT_ATTACK_INTENSITY = 0.7


def create_agents(
    agent_profiles: List[Dict],
    config: Dict,
    state: SimulationState,
    llm_service: LLMRedditService = None,
    orchestrator: AttackerCampaignOrchestrator = None,
    feed_ordering_strategy: Optional[FeedOrderingStrategy] = None,
    canonicalizer: Optional[Any] = None,
    belief_cap_enabled: bool = False,
    belief_cap: int = 60,
    protect_attacker_beliefs: bool = False,
    campaign_belief_texts: Optional[Dict[str, str]] = None,
    attacker_similarity_threshold: float = 0.6,
    weak_belief_threshold: float = 0.2,
    enable_timestep_parallelism: bool = False,
    max_llm_concurrency: int = 4,
    mitigation_system: Optional[MitigationSystem] = None,
    belief_config: Optional[BeliefConfig] = None,
) -> AgentManager:
    """
    Create agents from profiles.

    Args:
        agent_profiles: List of agent profile dictionaries
        config: Simulation configuration dictionary
        state: SimulationState instance
        llm_service: Optional LLM service for LLM agents
        orchestrator: Optional campaign orchestrator for attackers
        feed_ordering_strategy: Optional feed ordering strategy (defaults to DefaultFeedOrderingStrategy)
        canonicalizer: Belief canonicalizer for new beliefs and consolidation
        belief_cap_enabled: Enable belief capping for LLM users
        belief_cap: Max beliefs per agent when capping enabled
        protect_attacker_beliefs: Protect attacker-related beliefs during cull/consolidation
        campaign_belief_texts: Campaign reference texts for attacker classification
        attacker_similarity_threshold: Similarity threshold for attacker-related classification
        weak_belief_threshold: Drop non-protected beliefs below this strength during consolidation
    """
    feed_manager = FeedManager(ordering_strategy=feed_ordering_strategy)
    agent_manager = AgentManager(
        state,
        feed_manager,
        enable_timestep_parallelism=enable_timestep_parallelism,
        max_llm_concurrency=max_llm_concurrency,
    )

    activity_schedules = config.get("agent_activity_schedules", {})
    campaign_cfg = config.get("campaign_config", {})
    sim_cfg = config.get("simulation_config", {})
    num_timesteps = (24 * 60 // int(sim_cfg.get("interval_minutes", 5))) * int(
        sim_cfg.get("duration_days", 14)
    )
    campaign_target_narrative = (
        campaign_cfg.get("target_narrative")
        or sim_cfg.get("attacker_target_narrative")
        or ""
    )
    campaign_belief_texts_map = campaign_cfg.get("campaign_belief_texts") or {}

    # Campaign settings shared by both attacker types (same defaults as the orchestrator)
    attack_coordination_strength = float(
        campaign_cfg.get("coordination_strength", DEFAULT_COORDINATION_STRENGTH)
    )
    attack_intensity = float(
        campaign_cfg.get("attack_intensity", DEFAULT_ATTACK_INTENSITY)
    )
    attacker_agent_ids = {
        idx
        for idx, p in enumerate(agent_profiles)
        if p.get("user_type") in ("attacker", "template_attacker")
    }
    if attacker_agent_ids:
        log.info(
            "Attacker campaign settings: coordination_strength=%s (%s), "
            "attack_intensity=%s (%s), attackers=%s",
            attack_coordination_strength,
            "config" if "coordination_strength" in campaign_cfg else "default",
            attack_intensity,
            "config" if "attack_intensity" in campaign_cfg else "default",
            len(attacker_agent_ids),
        )

    # Attackers amplify each other's posts (agent ids are profile indices)
    if len(attacker_agent_ids) >= 2:
        coordination_keys = (
            "coordination_comment_prob",
            "coordination_delay_min",
            "coordination_delay_max",
        )
        agent_manager.coordination_hub = CoordinationHub(
            attacker_agent_ids,
            coordination_strength=attack_coordination_strength,
            comment_prob=float(
                campaign_cfg.get(
                    "coordination_comment_prob", DEFAULT_COORDINATION_COMMENT_PROB
                )
            ),
            delay_min=int(
                campaign_cfg.get("coordination_delay_min", DEFAULT_COORDINATION_DELAY_MIN)
            ),
            delay_max=int(
                campaign_cfg.get("coordination_delay_max", DEFAULT_COORDINATION_DELAY_MAX)
            ),
        )
        log.info(
            "Attacker coordination settings from %s",
            {k: ("config" if k in campaign_cfg else "default") for k in coordination_keys},
        )

    missing_axis_positions: List[int] = []
    for agent_idx, profile in enumerate(agent_profiles):
        agent_id = agent_idx

        schedule_data = activity_schedules.get(str(agent_idx), [])
        if schedule_data:
            activity_schedule = np.array(schedule_data, dtype=bool)
        else:
            log.warning(
                "Agent %s has no activity schedule in config; it will be active "
                "for the whole run",
                agent_idx,
            )
            activity_schedule = np.ones(num_timesteps, dtype=bool)

        behavioral_params = profile.get("behavioral_params", {})
        activity_weights = {
            "read": behavioral_params.get("read_density", 5),  # no published value: https://arxiv.org/pdf/1703.05267 does not give one
            "post": behavioral_params.get("post_probability", 0.1),
            "reply": behavioral_params.get("pr_comment", 0.1),
            "upvote": behavioral_params.get("pr_upvote", 0.15),
            "downvote": behavioral_params.get("pr_downvote", 0.05),
        }

        user_type = profile.get("user_type", "regular")
        mitigation_cfg = config.get("mitigation_config", {})
        if user_type == "rule_moderator":
            rd = mitigation_cfg.get("rule_moderator_read_density")
            if rd is not None:
                activity_weights["read"] = int(rd)

        # Get beliefs. Belief axes model: positions
        # on the axes (campaign agents hold the campaign targets)
        beliefs = profile.get("beliefs", {})
        user_type = profile.get("user_type", "regular")
        if belief_config is not None:
            if user_type in ("attacker", "template_attacker", "biased_moderator"):
                beliefs = complete_positions(
                    belief_config,
                    profile.get("axis_positions") or campaign_positions(belief_config),
                )
            elif user_type == "rule_moderator":
                beliefs = {}
            else:
                if not profile.get("axis_positions"):
                    missing_axis_positions.append(agent_idx)
                beliefs = complete_positions(belief_config, profile.get("axis_positions"))

        # Session category; attackers use it for campaign sessions after instruction posts
        session_duration = profile.get("activity_patterns", {}).get(
            "session_duration", "medium"
        )

        subreddit_id = profile.get(
            "subreddit", config["simulation_config"]["target_subreddit"]
        )

        state.subreddit_membership.add_member(agent_id, subreddit_id)

        for action, weight in activity_weights.items():
            state.activity_weights.set_weight(agent_id, action, weight)

        for belief_id, strength in beliefs.items():
            state.belief_network.set_belief(agent_id, belief_id, strength)

        llm_config = config.get("llm_config", {})

        if user_type == "rule_moderator":
            if mitigation_system is None:
                log.warning(
                    "Skipping agent %s (rule_moderator): mitigation_system not provided",
                    agent_id,
                )
                continue
            biased_cfg = config.get("biased_moderator_config", {})
            rules_text = mitigation_cfg.get("subreddit_rules") or biased_cfg.get(
                "subreddit_rules", "Be civil."
            )
            agent = RuleModeratorAgent(
                agent_id=agent_id,
                beliefs=beliefs,
                subreddit_id=subreddit_id,
                activity_weights=activity_weights,
                activity_schedule=activity_schedule,
                mitigation_system=mitigation_system,
                subreddit_rules_text=str(rules_text),
                detection_threshold=float(
                    mitigation_cfg.get("rule_moderator_detection_threshold", 0.7)
                ),
                llm_service=llm_service,
            )
            log.info(
                "Initialized rule_moderator agent_%s for r/%s (read_density=%s, detection_threshold=%s)",
                agent_id,
                subreddit_id,
                activity_weights.get("read"),
                mitigation_cfg.get("rule_moderator_detection_threshold", 0.7),
            )
            if "rule_moderator_moderation_delay_timesteps" in mitigation_cfg:
                log.warning(
                    "rule_moderator_moderation_delay_timesteps is set in config but no "
                    "longer used; rule moderators review items as soon as they read them"
                )
        elif user_type == "llm_user":
            agent = LLMUserAgent(
                agent_id=agent_id,
                beliefs=beliefs,
                subreddit_id=subreddit_id,
                activity_weights=activity_weights,
                activity_schedule=activity_schedule,
                llm_service=llm_service,
                llm_voting_enabled=llm_config.get("llm_voting_enabled", False),
                canonicalizer=canonicalizer,
                belief_cap_enabled=belief_cap_enabled,
                belief_cap=belief_cap,
                protect_attacker_beliefs=protect_attacker_beliefs,
                campaign_belief_texts=campaign_belief_texts or {},
                attacker_similarity_threshold=attacker_similarity_threshold,
                belief_texts=profile.get("belief_texts"),
            )
        elif user_type == "attacker":
            agent = LLMAttackerAgent(
                agent_id=agent_id,
                beliefs=beliefs,
                subreddit_id=subreddit_id,
                activity_weights=activity_weights,
                activity_schedule=activity_schedule,
                campaign_id="default_campaign",
                coordination_strength=attack_coordination_strength,
                attack_intensity=attack_intensity,
                llm_service=llm_service,
                orchestrator=orchestrator,
                canonicalizer=canonicalizer,
                session_duration=session_duration,
                campaign_brief=campaign_target_narrative or "",
            )
        elif user_type == "template_attacker":
            campaign_config = config.get("campaign_config", {})
            campaign_templates_dir = campaign_config.get(
                "campaign_templates_dir", "campaign_templates"
            )
            agent = TemplateAttackerAgent(
                agent_id=agent_id,
                beliefs=beliefs,
                subreddit_id=subreddit_id,
                activity_weights=activity_weights,
                activity_schedule=activity_schedule,
                campaign_id="default_campaign",
                campaign_templates_dir=campaign_templates_dir,
                coordination_strength=attack_coordination_strength,
                attack_intensity=attack_intensity,
                session_duration=session_duration,
                attacker_agent_ids=attacker_agent_ids,
            )
        elif user_type == "biased_moderator":
            biased_mod_config = config.get("biased_moderator_config", {})
            agent = BiasedModeratorAgent(
                agent_id=agent_id,
                beliefs=beliefs,
                subreddit_id=subreddit_id,
                activity_weights=activity_weights,
                activity_schedule=activity_schedule,
                risk_tolerance=biased_mod_config.get("biased_mod_risk_tolerance", 0.5),
                detection_threshold=biased_mod_config.get(
                    "biased_mod_detection_threshold", 0.7
                ),
                subreddit_rules_text=biased_mod_config.get(
                    "subreddit_rules", "Be civil."
                ),
                biased_mod_beliefs_file=biased_mod_config.get(
                    "biased_mod_beliefs_file", "biased_moderator_beliefs.json"
                ),
                llm_service=llm_service,
                scan_frequency=biased_mod_config.get("biased_mod_scan_frequency", 12),
                feed_manager=agent_manager.feed_manager,
                target_narrative=campaign_target_narrative,
                campaign_belief_texts=campaign_belief_texts_map,
            )
            log.info(
                "Initialized biased_moderator agent_%s for r/%s (scan_frequency=%s, belief_count=%s, narrative_chars=%s)",
                agent_id,
                subreddit_id,
                biased_mod_config.get("biased_mod_scan_frequency", 12),
                len(beliefs or {}),
                len(campaign_target_narrative or ""),
            )
        else:
            # Skip regular users for now
            log.warning(
                f"Skipping agent {agent_id} with type {user_type} (not implemented)"
            )
            continue

        if belief_config is not None:
            agent.axes = list(belief_config.axes)
            if user_type == "biased_moderator":
                agent.campaign_targets = dict(belief_config.campaign_targets)
        agent_manager.add_agent(agent)

    if missing_axis_positions:
        log.warning(
            "Belief axes: %d agents have no axis_positions in agent_profiles.json "
            "(profiles from an older initializer); they start at the axis priors. "
            "Re-run the initializer for positions placed from the users' beliefs.",
            len(missing_axis_positions),
        )
    return agent_manager


TIME_MODELS = ("discrete", "event")


@dataclass
class SimulationRun:
    """Everything a run needs, built by build_simulation."""

    config: Dict[str, Any]
    config_dir: Path
    output_dir: Path
    sim_config: Dict[str, Any]
    state: SimulationState
    agent_manager: AgentManager
    mitigation_system: MitigationSystem
    output_manager: OutputManager
    time_model: TimeModel
    time_model_name: str
    seed: int
    max_llm_concurrency: int
    orchestrator: Optional[Any] = None
    canonicalizer: Optional[Any] = None
    belief_cap_enabled: bool = False
    belief_cap: int = 60
    protect_attacker_beliefs: bool = False
    weak_belief_threshold: float = 0.2
    attacker_similarity_threshold: float = 0.6
    campaign_belief_texts: Dict[str, str] = field(default_factory=dict)
    # Belief axes config (None = free-text belief model)
    belief_config: Optional[BeliefConfig] = None

    @property
    def belief_model(self) -> str:
        return "axes" if self.belief_config is not None else "free_text"

    @property
    def step_s(self) -> float:
        return self.time_model.reference_step_s

    @property
    def timesteps_per_day(self) -> int:
        return int(round(86400.0 / self.step_s))


def _resolve_seed(runtime_config: Dict[str, Any]) -> int:
    """Run seed: SIM_SEED env > runtime_config.seed > a fresh random seed
    (logged and written to final_output.json, so any run can be repeated)."""
    raw = os.getenv("SIM_SEED", runtime_config.get("seed"))
    if raw is not None and str(raw).strip() != "":
        try:
            return int(raw)
        except (TypeError, ValueError):
            log.warning("Invalid seed %r; using a random seed", raw)
    return int(np.random.SeedSequence().entropy % (2**31))


def resolve_run_belief_config(
    config: Dict[str, Any], runtime_config: Dict[str, Any]
) -> Optional[BeliefConfig]:
    """The run's belief axes config, or None for the free-text belief model.

    Model: SIM_BELIEF_MODEL env > runtime_config.belief_model (also set by
    --belief-model) > belief_config.model > "free_text" when the config has no
    belief_config block (setups made before the axes model run unchanged).
    Axes mode without axes in the config uses the built-in set for the subreddit.
    """
    data = config.get("belief_config")
    model = (
        os.getenv("SIM_BELIEF_MODEL")
        or runtime_config.get("belief_model")
        or (data or {}).get("model")
        or "free_text"
    )
    model = str(model).strip().lower()
    if model not in BELIEF_MODELS:
        log.error(f"Unknown belief model {model!r}; expected one of {BELIEF_MODELS}")
        sys.exit(1)
    if model == "free_text":
        return None
    if data and data.get("axes"):
        return BeliefConfig.from_dict({**data, "model": "axes"})
    subreddit = config.get("simulation_config", {}).get("target_subreddit", "")
    log.warning(
        "Belief model 'axes' but no axes in simulation_config.belief_config; using "
        "the built-in set for r/%s", subreddit,
    )
    return default_belief_config(subreddit)


def build_simulation(
    config_dir: Path,
    output_dir: Path,
    config_overrides: Optional[Dict[str, Dict[str, Any]]] = None,
) -> SimulationRun:
    """Load configuration and profiles and build every simulation component.

    config_overrides: {section: {key: value}} merged over simulation_config.json
    (used by tests and comparison tools).
    """
    config_path = config_dir / "simulation_config.json"
    if not config_path.exists():
        log.error(f"Configuration file not found: {config_path}")
        log.error(
            "Please run reddit_agent_initializer.py first to generate configuration"
        )
        sys.exit(1)
    output_dir.mkdir(parents=True, exist_ok=True)

    config = load_config(str(config_path))
    # campaign_templates_dir may be relative to the config folder
    from .core.config_paths import resolve_config_paths
    resolve_config_paths(config, config_dir)
    for section, values in (config_overrides or {}).items():
        config.setdefault(section, {}).update(values)
    fill_campaign_narrative_from_default_template(config, config_dir)
    sim_config = config["simulation_config"]

    profiles_path = config_dir / "agent_profiles.json"
    if not profiles_path.exists():
        log.error(f"Agent profiles file not found: {profiles_path}")
        sys.exit(1)

    agent_profiles = load_agent_profiles(str(profiles_path))

    apply_mitigation_env_overrides(config)
    ensure_rule_moderator_schedules(config, agent_profiles)

    # Time model and run seed
    runtime_config = config.get("runtime_config", {})
    time_model_name = str(
        os.getenv("SIM_TIME_MODEL", runtime_config.get("time_model", "discrete"))
    ).strip().lower()
    if time_model_name not in TIME_MODELS:
        log.error(f"Unknown time_model {time_model_name!r}; expected one of {TIME_MODELS}")
        sys.exit(1)
    interval_minutes = sim_config["interval_minutes"]
    time_model = TimeModel.from_config(
        config.get("time_model_config"), reference_step_s=interval_minutes * 60.0
    )
    seed = _resolve_seed(runtime_config)
    np.random.seed(seed % (2**32))
    random.seed(seed)

    log.info(
        f"Loaded configuration: {len(agent_profiles)} agents, "
        f"{sim_config['duration_days']} days, {interval_minutes} min timesteps, "
        f"time_model={time_model_name}, seed={seed}"
    )

    state = SimulationState()

    # Seconds per reference timestep (timestep-valued config, feed decay, outputs)
    state.timestep_duration_seconds = interval_minutes * 60.0

    llm_config_data = config.get("llm_config", {})

    # Belief model: explicit override > belief_config.model > free_text for
    # configs without a belief_config block (older setups run unchanged)
    belief_config = resolve_run_belief_config(config, runtime_config)
    log.info(
        "Belief model: %s%s",
        "axes" if belief_config else "free_text",
        f" ({len(belief_config.axes)} axes, {belief_config.source}, "
        f"campaign targets on {sorted(belief_config.campaign_targets)})"
        if belief_config else "",
    )

    # Initialize belief canonicalizer (free-text belief model only)
    canonicalizer = None
    try:
        if belief_config is not None:
            raise ImportError("not used by the belief axes model")
        if not _parse_bool(runtime_config.get("enable_belief_canonicalizer", True)):
            raise ImportError("disabled by runtime_config.enable_belief_canonicalizer")
        from .services.belief_canonicalizer import BeliefCanonicalizer

        metadata_file = config_dir / "belief_clustering_metadata.json"
        if metadata_file.exists():
            canonicalizer = BeliefCanonicalizer(
                metadata_file=metadata_file,
                embedding_model="all-MiniLM-L6-v2",
                similarity_threshold=0.75,
                output_dir=output_dir,
            )
            log.info("Belief canonicalizer initialized with existing metadata")

            # Initialize state's belief_text_registry with existing canonical beliefs
            for belief in canonicalizer.canonical_beliefs:
                state.belief_text_registry[belief["belief_id"]] = belief[
                    "canonical_text"
                ]
            log.info(
                f"Initialized belief_text_registry with {len(state.belief_text_registry)} canonical beliefs"
            )
        else:
            # Create canonicalizer without metadata (will create new metadata file)
            canonicalizer = BeliefCanonicalizer(
                metadata_file=None,
                embedding_model="all-MiniLM-L6-v2",
                similarity_threshold=0.75,
                output_dir=output_dir,
            )
            log.info(
                "Belief canonicalizer initialized (no existing metadata, will create new)"
            )
    except ImportError as e:
        log.warning(f"BeliefCanonicalizer not available ({e}), new belief formation disabled")
    except Exception as e:
        log.error(
            f"Failed to initialize belief canonicalizer (embedder or NLI model): {e}. "
            "New belief formation and belief consolidation are DISABLED for this run."
        )

    # Merge campaign belief texts so attacker natural posts use narrative text
    campaign_belief_texts = config.get("campaign_config", {}).get(
        "campaign_belief_texts", {}
    )
    if campaign_belief_texts:
        state.belief_text_registry.update(campaign_belief_texts)
        log.info(
            f"Merged {len(campaign_belief_texts)} campaign belief texts into belief_text_registry"
        )

    # Belief capping (bloat mitigation)
    belief_capping_config = config.get("belief_capping_config", {})
    # Consolidation/capping apply to free-text beliefs only
    belief_cap_enabled = belief_capping_config.get("enabled", False) and belief_config is None
    belief_cap = belief_capping_config.get("belief_cap", 60)
    protect_attacker_beliefs = belief_capping_config.get(
        "protect_attacker_beliefs", False
    )
    attacker_similarity_threshold = belief_capping_config.get(
        "attacker_similarity_threshold", 0.6
    )
    weak_belief_threshold = belief_capping_config.get("weak_belief_threshold", 0.2)

    # Parallelism and LLM concurrency configuration.
    # Precedence: environment variable override > simulation_config.json runtime_config > default.
    enable_timestep_parallelism = _parse_bool(
        os.getenv(
            "ENABLE_TIMESTEP_PARALLELISM",
            runtime_config.get("enable_timestep_parallelism", False),
        )
    )

    try:
        max_llm_concurrency = int(
            os.getenv("LLM_MAX_CONCURRENCY", runtime_config.get("llm_max_concurrency", 8))
        )
    except (ValueError, TypeError):
        max_llm_concurrency = 8

    try:
        llm_rate_limit_qps = float(
            os.getenv("LLM_RATE_LIMIT_QPS", runtime_config.get("llm_rate_limit_qps", 0))
        )
    except (ValueError, TypeError):
        llm_rate_limit_qps = 0.0

    log.info(
        "Parallelism config: timestep_parallelism=%s (discrete engine), "
        "max_llm_concurrency=%d, llm_rate_limit_qps=%s",
        enable_timestep_parallelism,
        max_llm_concurrency,
        llm_rate_limit_qps,
    )

    llm_service = None
    if LLMRedditService is not None:
        llm_service_config = LLMServiceConfig()
        # Prefer explicit config values when provided; env still controls provider internals.
        if llm_config_data.get("provider"):
            llm_service_config.provider = str(llm_config_data.get("provider"))
        if llm_config_data.get("model"):
            llm_service_config.model = str(llm_config_data.get("model"))
        if llm_config_data.get("new_belief_strength_mode"):
            llm_service_config.new_belief_strength_mode = str(
                llm_config_data["new_belief_strength_mode"]
            )
        for key in (
            "new_belief_low_strength",
            "belief_update_max_change",
            "contradiction_hold_threshold",
        ):
            if llm_config_data.get(key) is not None:
                setattr(llm_service_config, key, float(llm_config_data[key]))
        if llm_config_data.get("attacker_avoid_confrontation") is not None:
            llm_service_config.attacker_avoid_confrontation = bool(
                llm_config_data["attacker_avoid_confrontation"]
            )
        if llm_config_data.get("verbal_acceptance_labels") is not None:
            llm_service_config.verbal_acceptance_labels = bool(
                llm_config_data["verbal_acceptance_labels"]
            )
        llm_service_config.llm_rate_limit_qps = llm_rate_limit_qps
        llm_service_config.max_concurrent_calls = max_llm_concurrency
        log.info(
            "New belief adoption strength: mode=%s%s",
            llm_service_config.new_belief_strength_mode,
            f" ({llm_service_config.new_belief_low_strength})"
            if llm_service_config.new_belief_strength_mode == "low"
            else "",
        )
        llm_service = LLMRedditService(llm_service_config)
        log.info("LLM service initialized")

    orchestrator = None
    if (
        AttackerCampaignOrchestrator is not None
        and sim_config.get("num_attacker", 0) > 0
    ):
        campaign_config_section = config.get("campaign_config", {})
        target_narrative = campaign_config_section.get(
            "target_narrative", sim_config.get("attacker_target_narrative", "default")
        )

        campaign_config = CampaignConfig(
            objective=(
                CampaignObjective.AMPLIFY_NARRATIVE
                if campaign_config_section.get("objective", "amplify_narrative")
                == "amplify_narrative"
                else CampaignObjective.DISRUPT_DISCOURSE
            ),
            target_narrative=target_narrative,
            target_subreddit=sim_config["target_subreddit"],
            coordination_strength=campaign_config_section.get(
                "coordination_strength", DEFAULT_COORDINATION_STRENGTH
            ),
            intensity=campaign_config_section.get(
                "attack_intensity", DEFAULT_ATTACK_INTENSITY
            ),
            daily_post_target=campaign_config_section.get("daily_post_target", 5),
        )
        log.info(
            "Campaign config: objective=%s (%s), coordination_strength=%s (%s), "
            "attack_intensity=%s (%s), daily_post_target=%s (%s)",
            campaign_config.objective,
            "config" if "objective" in campaign_config_section else "default",
            campaign_config.coordination_strength,
            "config" if "coordination_strength" in campaign_config_section else "default",
            campaign_config.intensity,
            "config" if "attack_intensity" in campaign_config_section else "default",
            campaign_config.daily_post_target,
            "config" if "daily_post_target" in campaign_config_section else "default",
        )
        orchestrator = AttackerCampaignOrchestrator(
            config=campaign_config,
            output_dir=str(output_dir),
        )
        orchestrator.rng = np.random.default_rng([seed, 1_000_003])
        if llm_service is not None and llm_service_config.provider == "stub":
            orchestrator.llm_provider = llm_service.llm_provider
        log.info(
            f"Attacker campaign orchestrator initialized with narrative: {target_narrative}"
        )

        # Day-0 planning context: real recent subreddit discussion as "day -1"
        from .services.subreddit_seed_context import (
            SEED_CONTEXT_FILENAME,
            load_seed_context,
        )

        seed_context = load_seed_context(config_dir)
        if seed_context:
            orchestrator.store_simulation_data(-1, seed_context)
            log.info(
                f"Loaded orchestrator seed context: {len(seed_context.get('posts', []))} posts, "
                f"{len(seed_context.get('comments', []))} comments"
            )
        else:
            log.warning(
                f"No {SEED_CONTEXT_FILENAME} in {config_dir}; the day-0 campaign plan "
                "will have no subreddit context (create it with "
                "python -m python_simulation.services.subreddit_seed_context)"
            )

    mitigation_system = build_mitigation_system(config)

    feed_config = config.get("feed_config", {})
    feed_strategy_name = feed_config.get("feed_strategy", "default")

    strategy_map = {
        "default": DefaultFeedOrderingStrategy(),
        "chronological": ChronologicalFeedOrderingStrategy(),
        "score-based": ScoreBasedFeedOrderingStrategy(),
        "engagement-weighted": EngagementWeightedFeedOrderingStrategy(),
        "reddit-hot": RedditHotFeedOrderingStrategy(),
        "reddit-all-hot": RedditAllHotFeedOrderingStrategy(),
    }
    feed_strategy = strategy_map.get(feed_strategy_name, DefaultFeedOrderingStrategy())
    log.info(f"Using feed ordering strategy from config: {feed_strategy_name}")

    agent_manager = create_agents(
        agent_profiles,
        config,
        state,
        llm_service,
        orchestrator,
        feed_strategy,
        canonicalizer,
        belief_cap_enabled=belief_cap_enabled,
        belief_cap=belief_cap,
        protect_attacker_beliefs=protect_attacker_beliefs,
        campaign_belief_texts=campaign_belief_texts,
        attacker_similarity_threshold=attacker_similarity_threshold,
        weak_belief_threshold=weak_belief_threshold,
        enable_timestep_parallelism=enable_timestep_parallelism,
        max_llm_concurrency=max_llm_concurrency,
        mitigation_system=mitigation_system,
        belief_config=belief_config,
    )
    log.info(f"Created {len(agent_manager.agents)} agents")

    # Seeded random streams: one per agent, plus the feed shuffle and the hub
    for agent in agent_manager.agents.values():
        agent.seed_rng(seed)
    agent_manager.feed_manager.set_rng(np.random.default_rng([seed, 1_000_001]))
    if agent_manager.coordination_hub is not None:
        agent_manager.coordination_hub.rng = np.random.default_rng([seed, 1_000_002])

    if orchestrator:
        attacker_ids = [
            agent_id
            for agent_id, agent in agent_manager.agents.items()
            if agent.agent_type == "llm_attacker"
        ]
        if attacker_ids:
            orchestrator.register_attacker_agents(attacker_ids)
            log.info(
                f"Registered {len(attacker_ids)} LLM attacker agents with orchestrator"
            )

    # Seed the feed with the setup's real "last 24 hours" posts and their top
    # comments (core/seed_content.py); runtime_config.seed_initial_posts=false skips it
    seed_counts = {"posts": 0, "replies": 0}
    if _parse_bool(runtime_config.get("seed_initial_posts", True)):
        from .core.seed_content import inject_seed_content
        from .services.subreddit_seed_context import load_seed_context

        seed_counts = inject_seed_content(
            state, agent_manager, load_seed_context(config_dir), sim_config["target_subreddit"]
        )

    output_manager = OutputManager(str(output_dir))
    output_manager.run_meta = {
        "belief_model": "axes" if belief_config else "free_text",
        **({"belief_config": belief_config.to_dict()} if belief_config else {}),
        "seed_content": seed_counts,
    }

    return SimulationRun(
        config=config,
        config_dir=config_dir,
        output_dir=output_dir,
        sim_config=sim_config,
        state=state,
        agent_manager=agent_manager,
        mitigation_system=mitigation_system,
        output_manager=output_manager,
        time_model=time_model,
        time_model_name=time_model_name,
        seed=seed,
        max_llm_concurrency=max_llm_concurrency,
        orchestrator=orchestrator,
        canonicalizer=canonicalizer,
        belief_cap_enabled=belief_cap_enabled,
        belief_cap=belief_cap,
        protect_attacker_beliefs=protect_attacker_beliefs,
        weak_belief_threshold=weak_belief_threshold,
        attacker_similarity_threshold=attacker_similarity_threshold,
        campaign_belief_texts=campaign_belief_texts or {},
        belief_config=belief_config,
    )


def plan_campaign_day(
    run: SimulationRun, day: int, deliver: Optional[Any] = None
) -> None:
    """Plan the day's campaign (uses the previous day's data; day 0 uses the
    seeded real subreddit context stored as day -1) and hand instructions to
    the LLM attackers."""
    if run.orchestrator is None:
        return
    log.info(f"Day boundary detected: planning campaign for day {day}")
    plan = run.orchestrator.plan_daily_campaign(day)
    run.orchestrator.distribute_instructions_to_agents(
        plan=plan,
        agent_manager=run.agent_manager,
        timesteps_per_day=run.timesteps_per_day,
        current_day=day,
        deliver=deliver,
    )


def end_of_day(run: SimulationRun, day: int, timestep: int, now_s: float) -> None:
    """Day-end work shared by both engines: snapshot, the day's posts and
    comments for the orchestrator, canonical metadata, belief consolidation."""
    state = run.state
    agent_manager = run.agent_manager
    orchestrator = run.orchestrator
    canonicalizer = run.canonicalizer
    _n_events = len(state.events)
    _t0_snap = time.perf_counter()
    run.output_manager.save_snapshot(
        timestep, day, state, agent_manager, mitigation_system=run.mitigation_system
    )

    # Store simulation data for orchestrator planning
    _day_scan_ms = 0.0
    if orchestrator:
        def _root_post_id(e):
            """Top-level post a reply belongs to (None if its thread was removed)."""
            while e.parent_id is not None:
                e = state.get_event(e.parent_id)
                if e is None:
                    return None
            return e.event_id

        day_events = []
        _t0_day = time.perf_counter()
        day_start_s = day * 86400.0
        for e in state.events:
            if day_start_s <= state.event_time(e) < day_start_s + 86400.0:
                agent = agent_manager.agents.get(e.user_id)
                author_type = agent.agent_type if agent else "regular"
                day_events.append(
                    {
                        "event_id": e.event_id,
                        "user_id": e.user_id,
                        "parent_id": e.parent_id,
                        # Lets the orchestrator show each post's comments
                        "root_post_id": _root_post_id(e),
                        "type": e.type.value,
                        "content": e.content,
                        "score": e.score,
                        "timestamp": e.timestamp,
                        "author_type": author_type,
                    }
                )
        _day_scan_ms = (time.perf_counter() - _t0_day) * 1000
        posts = [e for e in day_events if e["type"] == "post"]
        comments = [e for e in day_events if e["type"] == "reply"]

        orchestrator.store_simulation_data(
            day,
            {
                "posts": posts,
                "comments": comments,
            },
        )

    # Batch update metadata file with new beliefs created during the day
    if canonicalizer:
        canonicalizer.batch_update_metadata()

    # Belief capping: end-of-day consolidation for LLM user agents. In the event
    # engine, reads still in flight merge their changes into the consolidated
    # set (LLMUserAgent.apply_parse), so consolidation is not rolled back.
    _num_llm_users = 0
    _belief_consolidation_ms = 0.0
    if run.belief_cap_enabled and canonicalizer:
        try:
            from .services.belief_consolidation import consolidate_beliefs
        except ImportError:
            pass
        else:
            _t0_belief = time.perf_counter()
            for agent in agent_manager.get_agents_by_type("llm_user"):
                _num_llm_users += 1
                agent_id = agent.agent_id
                beliefs = state.belief_network.get_agent_beliefs(agent_id)
                if not beliefs:
                    continue
                belief_text_source = dict(state.belief_text_registry)
                if hasattr(agent, "belief_texts"):
                    belief_text_source.update(agent.belief_texts)
                consolidated = consolidate_beliefs(
                    beliefs,
                    belief_text_source=belief_text_source,
                    canonicalizer=canonicalizer,
                    belief_cap=run.belief_cap,
                    protect_attacker_beliefs=run.protect_attacker_beliefs,
                    weak_belief_threshold=run.weak_belief_threshold,
                    campaign_belief_texts=run.campaign_belief_texts,
                    attacker_similarity_threshold=run.attacker_similarity_threshold,
                )
                state.belief_network.replace_agent_beliefs(agent_id, consolidated)
                agent.replace_beliefs(consolidated, timestep)
            _belief_consolidation_ms = (time.perf_counter() - _t0_belief) * 1000
    _debug_log("run_simulation.py:snapshot_callback_end", "snapshot", {"state_events_count": _n_events, "day_events_scan_ms": _day_scan_ms, "num_llm_users": _num_llm_users, "belief_consolidation_ms": _belief_consolidation_ms, "snapshot_total_ms": (time.perf_counter() - _t0_snap) * 1000}, "B,E")


def run_discrete(run: SimulationRun) -> None:
    """Fixed-timestep engine: think -> communicate -> cleanup each timestep."""
    state = run.state
    agent_manager = run.agent_manager
    mitigation_system = run.mitigation_system

    engine_config = SimulationConfig(
        duration_days=run.sim_config["duration_days"],
        interval_minutes=run.sim_config["interval_minutes"],
        snapshot_frequency_days=1,
    )
    engine = SimulationEngine(engine_config)

    previous_day = -1

    def think_phase(timestep: int):
        nonlocal previous_day
        current_day = engine.current_day
        state.now_s = timestep * run.step_s
        _t0 = time.perf_counter()
        _n_events_before = len(state.events)
        _debug_log("run_simulation.py:think_phase_start", "step_start", {"timestep": timestep, "total_timesteps": engine.total_timesteps, "state_events_count": _n_events_before}, "B")

        if run.orchestrator and current_day > previous_day:
            plan_campaign_day(run, current_day)
            previous_day = current_day

        agent_manager.think_phase(timestep)
        _debug_log("run_simulation.py:think_phase_end", "think_phase", {"think_duration_ms": (time.perf_counter() - _t0) * 1000, "new_events_count": len(state.events) - _n_events_before, "state_events_count": len(state.events)}, "A")

    def communicate_phase(timestep: int):
        _t0 = time.perf_counter()
        agent_manager.communicate_phase(timestep)
        _debug_log("run_simulation.py:communicate_phase_end", "communicate_phase", {"communicate_duration_ms": (time.perf_counter() - _t0) * 1000}, "A")

    def cleanup_phase(timestep: int):
        _t0 = time.perf_counter()
        agent_manager.cleanup_phase(timestep)
        mitigation_system.scan(timestep, state)

        # Run biased moderator moderation (only here, on the main thread; it
        # removes events, so it must not run inside the parallel think phase)
        for agent in agent_manager.get_agents_by_type("biased_moderator"):
            if agent.is_active(timestep):
                agent.moderate(timestep, state)
        agent_manager.feed_manager.purge_orphaned_feed_events(state)
        _debug_log("run_simulation.py:cleanup_phase_end", "cleanup_phase", {"cleanup_duration_ms": (time.perf_counter() - _t0) * 1000}, "A")

    def snapshot_callback(timestep: int):
        end_of_day(run, engine.current_day, timestep, (timestep + 1) * run.step_s)

    engine.set_callbacks(
        think=think_phase,
        communicate=communicate_phase,
        cleanup=cleanup_phase,
        snapshot=snapshot_callback,
    )
    engine.run()


def run_event(run: SimulationRun) -> Dict[str, Any]:
    """Continuous-time engine (core/event_engine.py); returns its counters."""
    from .core.event_engine import EventEngine

    engine = EventEngine(
        agent_manager=run.agent_manager,
        time_model=run.time_model,
        duration_days=run.sim_config["duration_days"],
        mitigation_system=run.mitigation_system,
        max_workers=run.max_llm_concurrency,
        on_day_start=lambda day, eng: plan_campaign_day(
            run, day, deliver=eng.deliver_instruction
        ),
        on_day_end=lambda day, timestep, now_s: end_of_day(run, day, timestep, now_s),
    )
    engine.run()
    return engine.summary()


def run_simulation_from_config(
    config_dir: Path,
    output_dir: Path,
    config_overrides: Optional[Dict[str, Dict[str, Any]]] = None,
) -> SimulationRun:
    """Build and run a simulation and write its outputs."""
    run = build_simulation(config_dir, output_dir, config_overrides)

    _profiling_log = Path(config_dir) / "profiling.log"
    os.environ["DEBUG_LOG_PATH"] = str(_profiling_log)
    log.info(f"Profiling log (scaling debug): {_profiling_log}")

    log.info("Starting simulation (time_model=%s)...", run.time_model_name)
    simulation_start_time = time.perf_counter()
    engine_summary: Dict[str, Any] = {}
    try:
        if run.time_model_name == "event":
            engine_summary = run_event(run)
        else:
            run_discrete(run)
    except KeyboardInterrupt:
        log.warning("Simulation interrupted by user")
    except Exception as e:
        log.error(f"Simulation error: {e}", exc_info=True)
        raise

    log.info("Saving final output...")
    run.output_manager.save_media_events(run.state)
    total_run_time_seconds = time.perf_counter() - simulation_start_time
    run_info: Dict[str, Any] = {
        "time_model": run.time_model_name,
        "seed": run.seed,
        **run.output_manager.run_meta,
    }
    if run.time_model_name == "event":
        run_info["time_model_settings"] = run.time_model.to_dict()
        run_info["event_engine"] = engine_summary
    run.output_manager.save_final_output(
        run.state, run.agent_manager, run.mitigation_system,
        total_run_time_seconds=total_run_time_seconds,
        orchestrator=run.orchestrator,
        run_info=run_info,
    )

    # Final batch update of metadata file with any remaining new beliefs
    if run.canonicalizer:
        run.canonicalizer.batch_update_metadata()
        log.info("Final metadata update complete")

    log.info(f"Simulation complete! Output saved to {run.output_dir}")
    return run


def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(description="Run Reddit simulation in Python")
    parser.add_argument(
        "--config-dir",
        default="simulation_output",
        help="Directory containing simulation configuration files",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Output directory (defaults to <config-dir>/simulation_output)",
    )
    parser.add_argument(
        "--time-model",
        choices=TIME_MODELS,
        default=None,
        help="Override runtime_config.time_model (discrete timesteps or event-driven)",
    )
    parser.add_argument(
        "--seed",
        type=int,
        default=None,
        help="Override runtime_config.seed (random stream for the whole run)",
    )
    parser.add_argument(
        "--belief-model",
        choices=BELIEF_MODELS,
        default=None,
        help="Override the belief model (belief axes or free-text beliefs)",
    )

    args = parser.parse_args()

    config_dir = Path(args.config_dir)
    # Default to a subfolder so outputs (e.g. belief_clustering_metadata.json)
    # never overwrite the input files in config_dir
    output_dir = (
        Path(args.output_dir) if args.output_dir else config_dir / "simulation_output"
    )
    log.info(
        "Output directory: %s%s",
        output_dir,
        "" if args.output_dir else " (default: <config-dir>/simulation_output)",
    )
    overrides: Dict[str, Dict[str, Any]] = {}
    if args.time_model:
        overrides.setdefault("runtime_config", {})["time_model"] = args.time_model
    if args.seed is not None:
        overrides.setdefault("runtime_config", {})["seed"] = args.seed
    if args.belief_model:
        overrides.setdefault("runtime_config", {})["belief_model"] = args.belief_model

    run_simulation_from_config(config_dir, output_dir, overrides)


if __name__ == "__main__":
    # Allow running as script: python -m python_simulation.run_simulation
    # or: python backend/python_simulation/run_simulation.py
    import sys
    from pathlib import Path

    backend_dir = Path(__file__).parent.parent
    if str(backend_dir) not in sys.path:
        sys.path.insert(0, str(backend_dir))

    main()
