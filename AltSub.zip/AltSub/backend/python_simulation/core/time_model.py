#!/usr/bin/env python3
"""
Time model: every duration and rate the simulation uses, in one place.

The discrete engine advances in fixed reference timesteps (interval_minutes,
5 minutes by default). The event-driven engine (core/event_engine.py) runs on a
continuous clock in which each action takes a sampled amount of simulated time.
Both read their timing from here.

Calibration mode "match_discrete" picks reading times so an agent's expected
activity per session equals the discrete model's: read_density items and
post_probability posts per reference timestep of activity, with the same
session lengths.

Simplifications:
  - Composing a post does not block reading (an agent may write a post while it
    keeps browsing); reading, voting and replying to one feed item are
    sequential.
  - All agents share one set of durations.

Overrides: an optional "time_model_config" block in simulation_config.json,
e.g. {"reply_compose": {"dist": "lognormal", "mean_s": 90, "sd_s": 60}}.
The resolved values are written to final_output.json ("time_model").
"""

import bisect
import logging
import math
from dataclasses import dataclass, field, fields
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

log = logging.getLogger(__name__)

SECONDS_PER_DAY = 86400.0
DEFAULT_REFERENCE_STEP_S = 300.0


@dataclass
class DurationSpec:
    """A distribution of simulated durations in seconds.

    dist: "fixed" (always mean_s), "exponential" (mean mean_s),
    "lognormal" (mean mean_s, standard deviation sd_s) or "uniform" (min_s..max_s).
    Samples are clipped to [min_s, max_s].
    """

    dist: str = "fixed"
    mean_s: float = 0.0
    sd_s: float = 0.0
    min_s: float = 0.0
    max_s: float = math.inf

    def sample(self, rng: np.random.Generator) -> float:
        if self.dist == "fixed":
            value = self.mean_s
        elif self.dist == "exponential":
            value = rng.exponential(self.mean_s) if self.mean_s > 0 else 0.0
        elif self.dist == "lognormal":
            if self.mean_s <= 0:
                value = 0.0
            else:
                sigma2 = math.log1p((self.sd_s / self.mean_s) ** 2)
                mu = math.log(self.mean_s) - sigma2 / 2
                value = rng.lognormal(mu, math.sqrt(sigma2))
        elif self.dist == "uniform":
            value = rng.uniform(self.min_s, self.max_s)
        else:
            raise ValueError(f"Unknown duration distribution: {self.dist!r}")
        return float(min(self.max_s, max(self.min_s, value)))

    def expected(self) -> float:
        """Mean before clipping (uniform: midpoint)."""
        if self.dist == "uniform":
            return (self.min_s + self.max_s) / 2
        return self.mean_s

    def to_dict(self) -> Dict[str, Any]:
        out = {"dist": self.dist, "mean_s": self.mean_s, "sd_s": self.sd_s,
               "min_s": self.min_s}
        out["max_s"] = None if math.isinf(self.max_s) else self.max_s
        return out

    @classmethod
    def from_dict(cls, data: Dict[str, Any], base: Optional["DurationSpec"] = None) -> "DurationSpec":
        """base with the keys given in data overridden. A fixed duration keeps
        its value in min_s/max_s too, so unless the override sets the bounds
        they follow the new value (fixed) or are reset to [0, inf) when it
        switches a fixed duration to a distribution; otherwise every sample
        would still be clipped to the old fixed value."""
        spec = DurationSpec(**vars(base)) if base else DurationSpec()
        for key in ("dist", "mean_s", "sd_s", "min_s", "max_s"):
            if key in data:
                value = data[key]
                if key == "max_s" and value is None:
                    value = math.inf
                setattr(spec, key, value if key == "dist" else float(value))
        if "min_s" not in data and "max_s" not in data:
            if spec.dist == "fixed":
                spec.min_s = spec.max_s = spec.mean_s
            elif base is not None and base.dist == "fixed":
                spec.min_s, spec.max_s = 0.0, math.inf
        return spec


def _fixed(seconds: float) -> DurationSpec:
    return DurationSpec("fixed", mean_s=seconds, min_s=seconds, max_s=seconds)


def _uniform(lo: float, hi: float) -> DurationSpec:
    return DurationSpec("uniform", min_s=lo, max_s=hi)


@dataclass
class TimeModel:
    """Durations and rates for both engines (see module docstring)."""

    calibration_mode: str = "match_discrete"
    # Length of one discrete timestep; config values given in timesteps
    # (windows, scan frequencies, coordination delays) are multiplied by it
    reference_step_s: float = DEFAULT_REFERENCE_STEP_S

    # Per-action durations (event engine)
    vote: DurationSpec = field(default_factory=lambda: _fixed(1.0))
    # Composition times = mean text length / mobile typing speed (37 words per
    # minute), with lengths from the June 2025 Pushshift data of the two
    # scenario subreddits (tools/reddit_text_length_stats.py; bots, moderators,
    # removed/deleted and empty texts excluded).
    # time to write a reply (after reading and voting): mean comment length of
    # r/destiny2 (30.1 words) and r/worldnews (29.0) -> 29.55 words / 37 wpm = 48 s
    reply_compose: DurationSpec = field(
        default_factory=lambda: _fixed(48.0)
    )
    # time to write a top-level post (title + text): mean title length of both
    # subreddits (7.5 and 12.0 words) + r/destiny2's mean post body (72.4 words;
    # r/worldnews is link-only, 1 of 8,658 posts has body text) = 82.15 words
    # / 37 wpm = 133 s
    post_compose: DurationSpec = field(
        default_factory=lambda: _fixed(133.0)
    )

    min_read_mean_s: float = 5.0
    # how long an agent with an empty feed waits before checking again
    empty_feed_refresh: DurationSpec = field(default_factory=lambda: _fixed(300.0))
    # time for an attacker to submit a campaign post the
    # orchestrator already wrote (paste and post navigation)
    instruction_post: DurationSpec = field(default_factory=lambda: _fixed(30.0))

    # Session lengths from https://arxiv.org/pdf/1703.05267 (short <3 min, medium 3-53 min,
    # long >53 min) quantised to 5-minute steps; short keeps the 5-minute floor
    session_short: DurationSpec = field(default_factory=lambda: _fixed(300.0))
    session_medium: DurationSpec = field(default_factory=lambda: _uniform(600.0, 3000.0))
    session_long: DurationSpec = field(default_factory=lambda: _uniform(3300.0, 7200.0))
    session_default: DurationSpec = field(default_factory=lambda: _fixed(1800.0))

    # The attacker coordination delay lives in campaign_config
    # (coordination_delay_min/max, see core/attacker_coordination.py).

    def read_item_spec(
        self, read_density: float, reply_prob: float, vote_prob: float
    ) -> DurationSpec:
        """Reading-time distribution for an agent.

        match_discrete: the expected time per feed item (read + vote + reply,
        weighted by how often the agent votes and replies) equals
        reference_step_s / read_density, so a session yields the same expected
        number of items as the discrete model.
        """
        if read_density <= 0:
            return _fixed(math.inf)
        cycle = self.reference_step_s / read_density
        mean = cycle - reply_prob * self.reply_compose.expected() - vote_prob * self.vote.expected()
        if mean < self.min_read_mean_s:
            log.warning(
                "Time model: read_density %.1f leaves %.1fs per item after voting/"
                "replying; using the %.1fs minimum read time (fewer items than the "
                "discrete model)", read_density, mean, self.min_read_mean_s,
            )
            mean = self.min_read_mean_s
        return DurationSpec("exponential", mean_s=mean)

    def item_cycle_s(self, read_density: float) -> float:
        """Expected time per feed item for an agent (match_discrete)."""
        return self.reference_step_s / read_density if read_density > 0 else math.inf

    def post_rate_per_s(self, post_probability: float) -> float:
        """Posting rate while active. Discrete: one roll of post_probability per
        active step, so p posts per step on average; rate p / step keeps that
        expected count (a -ln(1-p) conversion would inflate it)."""
        return max(0.0, float(post_probability)) / self.reference_step_s

    def session_spec(self, session_duration: str) -> DurationSpec:
        spec = {
            "short": self.session_short,
            "medium": self.session_medium,
            "long": self.session_long,
        }.get(session_duration)
        if spec is None:
            log.error(
                f"Invalid session duration: {session_duration}, using default ~30 min"
            )
            return self.session_default
        return spec

    def session_length_s(self, session_duration: str, rng: np.random.Generator) -> float:
        return self.session_spec(session_duration).sample(rng)

    def steps_to_s(self, steps: float) -> float:
        return float(steps) * self.reference_step_s

    def to_dict(self) -> Dict[str, Any]:
        out: Dict[str, Any] = {}
        for f in fields(self):
            value = getattr(self, f.name)
            out[f.name] = value.to_dict() if isinstance(value, DurationSpec) else value
        return out

    @classmethod
    def from_config(
        cls,
        overrides: Optional[Dict[str, Any]] = None,
        reference_step_s: float = DEFAULT_REFERENCE_STEP_S,
    ) -> "TimeModel":
        model = cls(reference_step_s=float(reference_step_s))
        for key, value in (overrides or {}).items():
            if not hasattr(model, key):
                log.warning("time_model_config.%s is not a time model setting; ignored", key)
                continue
            current = getattr(model, key)
            if isinstance(current, DurationSpec):
                if not isinstance(value, dict):
                    log.warning("time_model_config.%s must be an object; ignored", key)
                    continue
                setattr(model, key, DurationSpec.from_dict(value, current))
            elif key == "calibration_mode":
                if value != "match_discrete":
                    raise ValueError(
                        f"time_model_config.calibration_mode {value!r} is not implemented "
                        "(only 'match_discrete')"
                    )
            else:
                setattr(model, key, type(current)(value))
        return model


# Discrete session lengths (initializer schedules, discrete attacker sessions)


def session_length_timesteps(
    session_duration: str, rng: Optional[np.random.Generator] = None
) -> int:
    """Sample a session length in timesteps for a session_duration category.

    Based on https://arxiv.org/pdf/1703.05267: short <3 min, medium 3-53 min,
    long >53 min. Assumes 5-minute timesteps (the event engine uses
    TimeModel.session_length_s instead).
    """
    randint = rng.integers if rng is not None else np.random.randint
    if session_duration == "short":
        return 1
    elif session_duration == "medium":
        return int(randint(2, 11))  # 10-50 min
    elif session_duration == "long":
        return int(randint(11, 25))  # 55-120 min (capped at 2 hours)
    else:
        log.error(
            f"Invalid session duration: {session_duration}, using default ~30 min"
        )
        return 6


class ActivityIntervals:
    """Sorted, non-overlapping [start, end) intervals of simulated seconds."""

    def __init__(self, intervals: Sequence[Tuple[float, float]] = ()):
        merged: List[Tuple[float, float]] = []
        for start, end in sorted((float(s), float(e)) for s, e in intervals if e > s):
            if merged and start <= merged[-1][1]:
                merged[-1] = (merged[-1][0], max(merged[-1][1], end))
            else:
                merged.append((start, end))
        self.intervals = merged
        self._starts = [s for s, _ in merged]

    @classmethod
    def from_schedule(cls, schedule: Sequence[bool], step_s: float) -> "ActivityIntervals":
        """Convert a per-timestep 0/1 schedule into intervals (each run of active
        steps t0..t1 becomes [t0 * step_s, (t1 + 1) * step_s))."""
        intervals = []
        run_start = None
        for t, active in enumerate(schedule):
            if active and run_start is None:
                run_start = t
            elif not active and run_start is not None:
                intervals.append((run_start * step_s, t * step_s))
                run_start = None
        if run_start is not None:
            intervals.append((run_start * step_s, len(schedule) * step_s))
        return cls(intervals)

    def contains(self, t: float) -> bool:
        i = bisect.bisect_right(self._starts, t) - 1
        return i >= 0 and t < self.intervals[i][1]

    def clip(self, lo: float, hi: float) -> List[Tuple[float, float]]:
        """Parts of the intervals inside [lo, hi)."""
        out = []
        for start, end in self.intervals:
            if end <= lo or start >= hi:
                continue
            out.append((max(start, lo), min(end, hi)))
        return out

    def total(self) -> float:
        return sum(e - s for s, e in self.intervals)

    def __iter__(self):
        return iter(self.intervals)

    def __len__(self) -> int:
        return len(self.intervals)


def sample_time_in(
    windows: Sequence[Tuple[float, float]], rng: np.random.Generator
) -> Optional[float]:
    """Uniform random time over the union of windows (None if they are empty)."""
    total = sum(e - s for s, e in windows)
    if total <= 0:
        return None
    r = rng.uniform(0.0, total)
    for start, end in windows:
        if r < end - start:
            return start + r
        r -= end - start
    return windows[-1][1]
