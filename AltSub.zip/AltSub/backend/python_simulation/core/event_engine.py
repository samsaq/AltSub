#!/usr/bin/env python3
"""
Event-driven simulation engine (runtime_config.time_model = "event").

Instead of fixed timesteps, simulated time is continuous and every action takes
a sampled duration (core/time_model.py). An agent in a session reads its feed
one item at a time: it starts reading (READ_START), finishes (READ_DONE: its
beliefs update), optionally votes and writes a reply, and each resulting action
appears to others only when it is committed (COMMIT) at the end of its
duration. Posts, attacker instructions and coordinated amplifications, scans and
day boundaries are scheduled events on the same clock.

Simulated time never depends on LLM latency. LLM calls run as jobs on a thread
pool; a job is submitted when its action starts and the main loop waits for it
only when the action's result is needed (at READ_DONE or COMMIT). Every job
whose action starts before the earliest pending commit runs concurrently
(conservative lookahead), while all shared state is changed on the main thread
in (time, kind, agent_id, seq) order. Jobs only call the LLM and get copies of
their inputs, and all random draws use seeded per-agent streams on the main
thread, so a seeded run with a deterministic LLM (the stub) is reproducible for
any thread count.

Integrity rules:
  - an action is checked when it is committed (AgentManager.commit_event):
    refused if its target was removed or its author banned in the meantime;
  - an agent has at most one feed item in flight; reading never starts after
    its session ends, but the item in hand is finished;
  - an item is marked read when reading starts, so it is never read twice;
  - day boundaries happen at their exact time; actions still in flight are
    committed later, stamped with their own commit time.
"""

import logging
import math
import time
from collections import defaultdict
from concurrent.futures import Future, ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from .event_scheduler import EventKind, EventScheduler, ScheduledEvent
from .simulation_data import EventType, MediaEvent
from .time_model import (
    SECONDS_PER_DAY,
    ActivityIntervals,
    DurationSpec,
    TimeModel,
    sample_time_in,
)

log = logging.getLogger(__name__)


@dataclass
class _AgentProc:
    """Event-engine bookkeeping for one agent."""

    agent: Any
    natural: ActivityIntervals
    # End of the latest campaign / login session (extra activity beyond the
    # natural schedule)
    extra_until: float = -math.inf
    reading: bool = False  # read loop scheduled or an item in flight

    def active(self, t: float) -> bool:
        return t < self.extra_until or self.natural.contains(t)


@dataclass
class _Commit:
    """Payload of a COMMIT event."""

    kind: str  # "reply" | "vote" | "post" | "coord_upvote" | "coord_comment"
    event: Optional[MediaEvent] = None
    future: Optional[Future] = None
    # LLM voting: the target to vote on once the probabilities are in
    vote_target: Optional[MediaEvent] = None


@dataclass
class _Read:
    """Payload of a READ_DONE event."""

    event: MediaEvent
    future: Optional[Future]


class EventEngine:
    """Runs a simulation on a continuous clock (see module docstring)."""

    def __init__(
        self,
        agent_manager: Any,
        time_model: TimeModel,
        duration_days: int,
        mitigation_system: Any = None,
        max_workers: int = 4,
        on_day_start: Optional[Callable[[int, "EventEngine"], None]] = None,
        on_day_end: Optional[Callable[[int, int, float], None]] = None,
        biased_scan_interval_s: Optional[float] = None,
    ):
        """
        Args:
            agent_manager: AgentManager with agents, feeds and commit_event
            time_model: durations and rates
            duration_days: length of the run
            mitigation_system: MitigationSystem (scans every scan_frequency timesteps)
            max_workers: thread pool size for LLM jobs
            on_day_start: on_day_start(day, engine) at the start of each day
                (orchestrator planning; it delivers instructions with
                engine.deliver_instruction)
            on_day_end: on_day_end(day, last_timestep, now_s) at each day boundary
                (snapshot, orchestrator data, consolidation)
            biased_scan_interval_s: overrides the biased moderators' scan interval
        """
        self.am = agent_manager
        self.state = agent_manager.state
        self.feeds = agent_manager.feed_manager
        self.tm = time_model
        self.step_s = time_model.reference_step_s
        self.duration_days = int(duration_days)
        self.end_s = self.duration_days * SECONDS_PER_DAY
        self.mitigation = mitigation_system
        self.max_workers = max(1, int(max_workers))
        self.on_day_start = on_day_start
        self.on_day_end = on_day_end
        self.biased_scan_interval_s = biased_scan_interval_s
        self.hub = getattr(agent_manager, "coordination_hub", None)

        self.scheduler = EventScheduler()
        self.pool: Optional[ThreadPoolExecutor] = None
        self.procs: Dict[int, _AgentProc] = {}
        self.stats: Dict[str, Any] = defaultdict(int)
        self.llm_failures: Dict[str, int] = defaultdict(int)
        self._read_specs: Dict[int, DurationSpec] = {}
        self._now = 0.0

    # Setup

    def _step(self, t: float) -> int:
        return int(t // self.step_s)

    def _init_agents(self) -> None:
        for agent_id, agent in sorted(self.am.agents.items()):
            natural_schedule = getattr(agent, "natural_activity_schedule", agent.activity_schedule)
            proc = _AgentProc(
                agent=agent,
                natural=ActivityIntervals.from_schedule(natural_schedule, self.step_s),
            )
            self.procs[agent_id] = proc
            for start, _end in proc.natural:
                if start < self.end_s:
                    self.scheduler.schedule(
                        start, EventKind.SESSION_START, agent_id, ("natural", None)
                    )

    def _schedule_periodic(self) -> None:
        if self.mitigation is not None and (
            self.mitigation.duplicate_detection_enabled
            or self.mitigation.rate_limiting_enabled
            or self.mitigation.coordinated_detection_enabled
        ):
            self.scheduler.schedule(0.0, EventKind.MITIGATION_SCAN)
        for agent in self.am.get_agents_by_type("biased_moderator"):
            self.scheduler.schedule(0.0, EventKind.BIASED_SCAN, agent.agent_id)
        for day in range(1, self.duration_days + 1):
            self.scheduler.schedule(day * SECONDS_PER_DAY, EventKind.DAY_BOUNDARY, payload=day)

    # Main loop

    def run(self) -> None:
        wall_start = time.perf_counter()
        self._init_agents()
        self._schedule_periodic()
        self.pool = ThreadPoolExecutor(max_workers=self.max_workers)
        last_logged_hour = -1
        try:
            self.state.now_s = 0.0
            if self.on_day_start is not None:
                self.on_day_start(0, self)
            while True:
                ev = self.scheduler.pop()
                if ev is None:
                    break
                t = ev.t
                if t > self.end_s:
                    break
                if t == self.end_s and ev.kind not in (
                    EventKind.COMMIT, EventKind.DAY_BOUNDARY
                ):
                    continue  # nothing starts at the very end of the run
                self._now = t
                self.state.now_s = t
                self._dispatch(ev)
                hour = int(t // 3600)
                if hour != last_logged_hour and hour % 6 == 0:
                    last_logged_hour = hour
                    log.info(
                        "Event engine: simulated %.1f h (day %d/%d), %d events committed, "
                        "%d scheduled, %.0f s wall time",
                        t / 3600, int(t // SECONDS_PER_DAY) + 1, self.duration_days,
                        len(self.state.events), len(self.scheduler),
                        time.perf_counter() - wall_start,
                    )
        finally:
            # Actions still in flight at the end are never committed
            self.stats["pending_at_end"] = len(self.scheduler)
            self.pool.shutdown(wait=True, cancel_futures=True)
            self.pool = None
        log.info(
            "Event engine finished: %d events committed, %.1f s wall time",
            len(self.state.events), time.perf_counter() - wall_start,
        )

    def _dispatch(self, ev: ScheduledEvent) -> None:
        handler = {
            EventKind.COMMIT: self._on_commit,
            EventKind.READ_DONE: self._on_read_done,
            EventKind.DAY_BOUNDARY: self._on_day_boundary,
            EventKind.MITIGATION_SCAN: self._on_mitigation_scan,
            EventKind.BIASED_SCAN: self._on_biased_scan,
            EventKind.SESSION_START: self._on_session_start,
            EventKind.INSTRUCTION_DUE: self._on_instruction_due,
            EventKind.COORDINATION_START: self._on_coordination_start,
            EventKind.POST_START: self._on_post_start,
            EventKind.READ_START: self._on_read_start,
        }[ev.kind]
        handler(ev)

    # Jobs

    def _submit(self, job: Optional[Callable[[], Any]]) -> Optional[Future]:
        return self.pool.submit(job) if job is not None else None

    def _result(self, future: Optional[Future], kind: str) -> Any:
        """Wait for a job; a failed job counts as an LLM failure and yields None."""
        if future is None:
            return None
        try:
            return future.result()
        except Exception as e:
            self.llm_failures[kind] += 1
            log.error("Event engine: %s job failed: %s", kind, e)
            return None

    def _set_clock(self, agent: Any, t: float) -> None:
        agent.set_clock(self._step(t), t)

    # Sessions and reading

    def _start_session(self, proc: _AgentProc, start: float, end: Optional[float]) -> None:
        """Begin activity at start (natural interval or extra session ending at
        end) and start the read loop if it isn't running."""
        if end is not None:
            proc.extra_until = max(proc.extra_until, end)
        agent = proc.agent
        if proc.reading or not agent.reads_feed():
            return
        proc.reading = True
        # First read after an initial delay with the item cycle's (approximately
        # exponential) distribution, so the expected number of reads in a
        # session of length L is L / cycle, as in the discrete model
        cycle = self.tm.item_cycle_s(agent.read_count)
        delay = agent.rng.exponential(cycle) if math.isfinite(cycle) else 0.0
        self.scheduler.schedule(start + delay, EventKind.READ_START, agent.agent_id)

    def _on_session_start(self, ev: ScheduledEvent) -> None:
        proc = self.procs[ev.agent_id]
        agent = proc.agent
        t = ev.t
        self.stats["sessions"] += 1
        self._start_session(proc, t, None)
        # Natural posting: a Poisson process at the agent's post rate over this
        # natural interval (posts happen only during natural activity, as in
        # the discrete think phase)
        rate = self.tm.post_rate_per_s(agent.get_action_probability("post"))
        if rate <= 0:
            return
        end = next((e for s, e in proc.natural if s <= t < e), t)
        p = t + agent.rng.exponential(1.0 / rate)
        while p < min(end, self.end_s):
            self.scheduler.schedule(p, EventKind.POST_START, agent.agent_id)
            p += agent.rng.exponential(1.0 / rate)

    def _read_spec(self, agent: Any) -> DurationSpec:
        if agent.is_banned(self.state):
            # A banned agent doesn't vote or reply, so its whole item cycle is reading
            return DurationSpec("exponential", mean_s=self.tm.item_cycle_s(agent.read_count))
        spec = self._read_specs.get(agent.agent_id)
        if spec is None:
            reply_p, vote_p = agent.expected_action_probs()
            spec = self.tm.read_item_spec(agent.read_count, reply_p, vote_p)
            self._read_specs[agent.agent_id] = spec
        return spec

    def _on_read_start(self, ev: ScheduledEvent) -> None:
        proc = self.procs[ev.agent_id]
        agent = proc.agent
        t = ev.t
        if not proc.active(t):
            proc.reading = False
            return
        feed = self.feeds.get_feed(ev.agent_id, max_items=1, state=self.state)
        if not feed:
            self.stats["empty_feed_waits"] += 1
            self.scheduler.schedule(
                t + self.tm.empty_feed_refresh.sample(agent.rng),
                EventKind.READ_START,
                ev.agent_id,
            )
            return
        item = feed[0]
        # Reserve the item now so it can't be read twice
        self.feeds.mark_read(ev.agent_id, item.event_id)
        self._set_clock(agent, t)
        future = self._submit(agent.parse_job(item, self.state))
        self.stats["reads"] += 1
        self.am.items_read += 1
        self.scheduler.schedule(
            t + self._read_spec(agent).sample(agent.rng),
            EventKind.READ_DONE,
            ev.agent_id,
            _Read(item, future),
        )

    def _on_read_done(self, ev: ScheduledEvent) -> None:
        proc = self.procs[ev.agent_id]
        agent = proc.agent
        read: _Read = ev.payload
        t = ev.t
        self._set_clock(agent, t)

        # Beliefs update when reading finishes (the item counts as read even if
        # a moderator removed it meanwhile)
        if read.future is not None:
            result = self._result(read.future, "parse")
            if result is not None:
                agent.apply_parse_result(result, self.state)
        else:
            agent.parse(read.event, self.state)
        if hasattr(agent, "flush_pending_moderation"):
            agent.flush_pending_moderation(self.state, self.feeds)

        # Same decision order as the discrete engine: reply roll, then vote
        busy_until = t
        reply_job = None
        if agent.should_reply(read.event, self.state):
            reply_job = agent.reply_job(read.event, self.state)
        vote_job = None
        vote_event = None
        if not agent.is_banned(self.state):
            vote_job = agent.vote_probabilities_job(read.event, self.state)
            if vote_job is None:
                choice = agent.choose_vote(read.event, self.state)
                if choice is not None:
                    vote_event = agent.make_vote_event(read.event, choice)
        if vote_job is not None or vote_event is not None:
            busy_until += self.tm.vote.sample(agent.rng)
            self.scheduler.schedule(
                busy_until,
                EventKind.COMMIT,
                ev.agent_id,
                _Commit(
                    "vote",
                    event=vote_event,
                    future=self._submit(vote_job),
                    vote_target=read.event if vote_job is not None else None,
                ),
            )
        if reply_job is not None:
            busy_until += self.tm.reply_compose.sample(agent.rng)
            self.scheduler.schedule(
                busy_until,
                EventKind.COMMIT,
                ev.agent_id,
                _Commit("reply", future=self._submit(reply_job)),
            )
        # Next item once this one is done (READ_START stops if the session ended)
        self.scheduler.schedule(busy_until, EventKind.READ_START, ev.agent_id)

    # Posts and commits

    def _on_post_start(self, ev: ScheduledEvent) -> None:
        agent = self.procs[ev.agent_id].agent
        if agent.is_banned(self.state):
            return
        self._set_clock(agent, ev.t)
        job = agent.natural_post_job(self.state)
        if job is None:
            return
        self.scheduler.schedule(
            ev.t + self.tm.post_compose.sample(agent.rng),
            EventKind.COMMIT,
            ev.agent_id,
            _Commit("post", future=self._submit(job)),
        )

    def _on_commit(self, ev: ScheduledEvent) -> None:
        agent = self.procs[ev.agent_id].agent
        commit: _Commit = ev.payload
        t = ev.t
        self._set_clock(agent, t)

        event = commit.event
        if commit.future is not None:
            result = self._result(commit.future, commit.kind)
            if commit.vote_target is not None:
                # LLM voting: roll the vote now that the probabilities are in
                if result is None or agent.is_banned(self.state):
                    return
                from ..agents.base_agent import pick_vote

                choice = pick_vote(result[0], result[1], agent.rng)
                event = agent.make_vote_event(commit.vote_target, choice) if choice else None
            else:
                event = result
        if event is None:
            return

        committed = self.am.commit_event(event, self._step(t), t)
        if commit.kind.startswith("coord_") and self.hub is not None:
            self._count_coordination(commit.kind, event, committed)
        if committed is None:
            return
        self.stats[f"committed_{commit.kind}"] += 1
        if committed.type == EventType.POST and self.hub is not None:
            self._schedule_amplifications(committed)

    # Attacker campaign: instructions and coordination

    def deliver_instruction(self, agent: Any, instruction: Any) -> None:
        """Give an attacker a campaign instruction: its posting time is chosen
        now, uniformly over the agent's natural activity inside the window
        (or anywhere in the window if it is never naturally active then)."""
        proc = self.procs.get(agent.agent_id)
        if proc is None:
            return
        start = instruction.start_s
        end = instruction.end_s
        if start is None or end is None:
            start = instruction.start_timestep * self.step_s
            end = (instruction.end_timestep + 1) * self.step_s
        t = sample_time_in(proc.natural.clip(start, end), agent.rng)
        if t is None:
            t = float(agent.rng.uniform(start, end))
        instruction.execute_time_s = t
        instruction.execute_timestep = self._step(t)
        self.stats["instructions_delivered"] += 1
        self.scheduler.schedule(t, EventKind.INSTRUCTION_DUE, agent.agent_id, instruction)

    def _on_instruction_due(self, ev: ScheduledEvent) -> None:
        proc = self.procs[ev.agent_id]
        agent = proc.agent
        instruction = ev.payload
        t = ev.t
        instruction.executed = True
        if agent.is_banned(self.state):
            self.stats["instructions_skipped_banned"] += 1
            return
        self._set_clock(agent, t)
        post = agent.instruction_post(instruction)
        if post is None:
            self.stats["instructions_without_content"] += 1
            return
        self.scheduler.schedule(
            t + self.tm.instruction_post.sample(agent.rng),
            EventKind.COMMIT,
            ev.agent_id,
            _Commit("post", event=post),
        )
        # Post, then browse for a campaign session
        length = self.tm.session_length_s(getattr(agent, "session_duration", "medium"), agent.rng)
        self._start_session(proc, t, t + length)

    def _schedule_amplifications(self, post: MediaEvent) -> None:
        """Fellow attackers schedule amplifications of a new attacker post. Each
        amplification commits at its sampled due time; work on it (casting the
        vote, writing the comment) starts that long before."""
        scheduled = self.hub.on_new_events(
            [post], self._step(self.state.event_time(post)), self.am.agents,
            self.state, step_s=self.step_s,
        )
        post_time = self.state.event_time(post)
        for attacker_id, target in scheduled:
            agent = self.procs[attacker_id].agent
            lead = (self.tm.reply_compose if target.action == "comment" else self.tm.vote).sample(agent.rng)
            start = max(post_time, target.due_time_s - lead)
            self.scheduler.schedule(start, EventKind.COORDINATION_START, attacker_id, target)

    def _on_coordination_start(self, ev: ScheduledEvent) -> None:
        proc = self.procs[ev.agent_id]
        agent = proc.agent
        target = ev.payload
        t = ev.t
        hub = self.hub
        if agent.is_banned(self.state):
            hub.stats["skipped_banned"] += 1
            return
        event = self.state.get_event(target.event_id)
        if event is None:  # removed by a moderator
            hub.stats["skipped_removed"] += 1
            return
        # One vote per item: skip if it already voted while browsing
        if target.action == "upvote" and (
            ev.agent_id in event.upvotes or ev.agent_id in event.downvotes
        ):
            hub.stats["skipped_already_voted"] += 1
            return
        self._set_clock(agent, t)
        due = max(t, target.due_time_s)
        if target.action == "comment":
            commit = _Commit("coord_comment", future=self._submit(agent.reply_job(event, self.state)))
        else:
            commit = _Commit("coord_upvote", event=agent.upvote(event, self.state))
        self.scheduler.schedule(due, EventKind.COMMIT, ev.agent_id, commit)
        # The target is handled; the attacker's browsing shouldn't vote on it again.
        # Like the discrete engine, logging in just to amplify doesn't start a
        # browsing session (there the due targets are cleared before the feed pass).
        self.feeds.mark_read(ev.agent_id, target.event_id)

    def _count_coordination(
        self, kind: str, event: MediaEvent, committed: Optional[MediaEvent]
    ) -> None:
        stats = self.hub.stats
        if committed is not None:
            stats["comments_executed" if kind == "coord_comment" else "upvotes_executed"] += 1
            return
        # Refused at commit: map the reason onto the hub's skip counters
        author = self.am.agents.get(event.user_id)
        if author is not None and author.is_banned(self.state):
            stats["skipped_banned"] += 1
        elif self.state.get_event(event.parent_id) is None:
            stats["skipped_removed"] += 1
        else:
            stats["skipped_already_voted"] += 1

    # Moderation, mitigation and day boundaries

    def _on_mitigation_scan(self, ev: ScheduledEvent) -> None:
        t = ev.t
        self.mitigation.scan(self._step(t), self.state, now_s=t)
        self.feeds.purge_orphaned_feed_events(self.state)
        self.scheduler.schedule(
            t + self.mitigation.scan_interval_s, EventKind.MITIGATION_SCAN
        )

    def _on_biased_scan(self, ev: ScheduledEvent) -> None:
        proc = self.procs.get(ev.agent_id)
        t = ev.t
        if proc is None:
            return
        agent = proc.agent
        if proc.active(t):
            self._set_clock(agent, t)
            agent.moderate(self._step(t), self.state, now_s=t, executor=self.pool)
            self.feeds.purge_orphaned_feed_events(self.state)
        interval = self.biased_scan_interval_s or agent.scan_frequency * self.step_s
        self.scheduler.schedule(t + interval, EventKind.BIASED_SCAN, ev.agent_id)

    def _on_day_boundary(self, ev: ScheduledEvent) -> None:
        day = int(ev.payload)
        t = ev.t
        if self.on_day_end is not None:
            # Last reference timestep of the day that just ended
            self.on_day_end(day - 1, self._step(t) - 1, t)
        if day < self.duration_days and self.on_day_start is not None:
            self.on_day_start(day, self)

    def summary(self) -> Dict[str, Any]:
        """Engine counters for final_output.json."""
        return {
            **{k: v for k, v in sorted(self.stats.items())},
            "llm_failures": dict(self.llm_failures),
        }
