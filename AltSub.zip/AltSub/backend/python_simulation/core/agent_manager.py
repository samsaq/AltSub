#!/usr/bin/env python3
"""
Agent Manager: Manage all agents and coordinate agent actions

Holds the agents and the feed manager, runs the discrete engine's think and
communicate phases, and owns commit_event, the single path by which any engine
adds an agent action to the simulation state.
"""

import logging
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List, Optional, Tuple
from .simulation_data import EventType, MediaEvent, SimulationState
from .feed_system import FeedManager

log = logging.getLogger(__name__)


class AgentManager:
    """Manages all agents and coordinates their actions"""

    def __init__(
        self,
        state: SimulationState,
        feed_manager: FeedManager,
        enable_timestep_parallelism: bool = False,
        max_llm_concurrency: int = 4,
        coordination_hub=None,
    ):
        self.state = state
        # Optional CoordinationHub: attackers amplify each other's posts
        self.coordination_hub = coordination_hub
        self.feed_manager = feed_manager
        self.agents: Dict[int, any] = {}  # agent_id -> BaseAgent
        self.agents_by_type: Dict[str, List[any]] = {}  # agent_type -> list of agents
        self.enable_timestep_parallelism = enable_timestep_parallelism
        self.max_llm_concurrency = max(1, int(max_llm_concurrency))
        # Actions refused at commit, by reason (written to final_output.json)
        self.commit_rejections: Dict[str, int] = defaultdict(int)
        # Feed items read, by any engine (written to final_output.json)
        self.items_read = 0

    def add_agent(self, agent) -> None:
        """Add an agent to the manager"""
        agent_id = agent.agent_id
        self.agents[agent_id] = agent

        agent_type = agent.agent_type
        if agent_type not in self.agents_by_type:
            self.agents_by_type[agent_type] = []
        self.agents_by_type[agent_type].append(agent)

        self.feed_manager.initialize_agent(agent_id)

        log.debug(f"Added agent {agent_id} (type: {agent_type})")

    def get_agent(self, agent_id: int):
        """Get agent by ID"""
        return self.agents.get(agent_id)

    def get_agents_by_type(self, agent_type: str) -> List:
        """Get all agents of a specific type"""
        return self.agents_by_type.get(agent_type, []).copy()

    # Committing actions

    def _rejection_reason(self, event: MediaEvent) -> Optional[str]:
        """Why an action can't be committed now, or None if it can."""
        author = self.agents.get(event.user_id)
        if author is not None and author.is_banned(self.state):
            return "author_banned"
        if event.parent_id is not None:
            parent = self.state.get_event(event.parent_id)
            if parent is None:
                return "target_removed"
            if event.type in (EventType.UPVOTE, EventType.DOWNVOTE) and (
                event.user_id in parent.upvotes or event.user_id in parent.downvotes
            ):
                return "duplicate_vote"
        return None

    def commit_event(
        self, event: MediaEvent, timestep: int, time_s: Optional[float] = None
    ) -> Optional[MediaEvent]:
        """
        Add an agent action to the simulation, or refuse it.

        Refused (counted in commit_rejections) if the author is banned, the
        replied-to / voted-on item no longer exists, or the author already voted
        on that item. Otherwise the event gets its ID and commit time (timestep,
        and time_s in seconds, defaulting to timestep * step length), is added to
        state, and posts/replies enter the other agents' feeds.

        Returns:
            The committed event, or None if refused
        """
        reason = self._rejection_reason(event)
        if reason is not None:
            self.commit_rejections[reason] += 1
            log.debug(
                "Refused %s by agent %s (target %s): %s",
                event.type.value, event.user_id, event.parent_id, reason,
            )
            return None
        event.event_id = self.state.get_new_event_id()
        event.timestamp = int(timestep)
        event.time_s = (
            float(time_s)
            if time_s is not None
            else timestep * self.state.timestep_duration_seconds
        )
        self.state.add_event(event)
        if event.type in (EventType.POST, EventType.REPLY):
            self.feed_manager.update_feeds([event], self.state)
        return event

    def _cast_vote(self, agent, event):
        """Ask the agent for a single vote choice on event and build that vote event (or None)."""
        choice = agent.choose_vote(event, self.state)
        if choice == "upvote":
            return agent.upvote(event, self.state)
        if choice == "downvote":
            return agent.downvote(event, self.state)
        return None

    def _set_clocks(self, timestep: int) -> None:
        time_s = timestep * self.state.timestep_duration_seconds
        for agent in self.agents.values():
            agent.set_clock(timestep, time_s)

    def _schedule_coordination(self, new_events: List[any], timestep: int) -> None:
        """Let the coordination hub schedule amplifications of new attacker posts"""
        if self.coordination_hub is not None and new_events:
            self.coordination_hub.on_new_events(
                new_events, timestep, self.agents, self.state
            )

    def _run_coordination_actions(self, timestep: int) -> None:
        """
        Carry out due coordination targets (main thread, before feeds are read).
        Deliberate actions: they bypass should_reply / choose_vote. The target is
        then marked read so the attacker's normal feed pass doesn't vote on it again.
        """
        hub = self.coordination_hub
        if hub is None:
            return
        for agent_id in sorted(hub.attacker_ids):
            agent = self.agents.get(agent_id)
            if agent is None or not hasattr(agent, "pop_due_coordination_targets"):
                continue
            due = agent.pop_due_coordination_targets(timestep)
            if not due:
                continue
            if agent.is_banned(self.state):
                hub.stats["skipped_banned"] += len(due)
                continue
            for target in due:
                event = self.state.get_event(target.event_id)
                if event is None:  # removed by a moderator
                    hub.stats["skipped_removed"] += 1
                    continue
                # One vote per item: skip if it already voted while browsing
                if target.action == "upvote" and (
                    agent_id in event.upvotes or agent_id in event.downvotes
                ):
                    hub.stats["skipped_already_voted"] += 1
                    continue
                try:
                    if target.action == "comment":
                        new_event = agent.reply(event, self.state)
                    else:
                        new_event = agent.upvote(event, self.state)
                except Exception as e:
                    log.error(
                        f"Error in coordination action for agent {agent_id} "
                        f"on event {target.event_id}: {e}"
                    )
                    continue
                if new_event is None:
                    continue
                if self.commit_event(new_event, timestep) is None:
                    continue
                if new_event.type == EventType.REPLY:
                    hub.stats["comments_executed"] += 1
                else:
                    hub.stats["upvotes_executed"] += 1
                self.feed_manager.mark_read(agent_id, target.event_id)

    # Discrete engine phases

    def think_phase(self, timestep: int) -> None:
        """
        Think phase: Agents generate new posts/events.

        This is where agents decide what content to create.
        """
        self._set_clocks(timestep)
        new_events: List[MediaEvent] = []

        # Sequential path (default / flag disabled)
        if not self.enable_timestep_parallelism or self.max_llm_concurrency <= 1:
            for agent_id, agent in self.agents.items():
                try:
                    if not agent.is_active(timestep):
                        continue

                    # Banned agents cannot create top-level posts
                    if agent.is_banned(self.state):
                        continue

                    for event in agent.generate_post_events(timestep, self.state) or []:
                        if self.commit_event(event, timestep) is not None:
                            new_events.append(event)
                except Exception as e:
                    log.error(f"Error in think_phase for agent {agent_id}: {e}")

            if new_events:
                log.debug(
                    f"Generated {len(new_events)} new events at timestep {timestep}"
                )
            self._schedule_coordination(new_events, timestep)
            return

        # Parallel path: compute per-agent events in a thread pool, then apply on
        # the main thread in agent_id order (deterministic event IDs)
        def _compute_think_for_agent(agent_id: int, agent) -> Tuple[int, List[any]]:
            if not agent.is_active(timestep):
                return agent_id, []
            # Banned agents cannot create top-level posts
            if agent.is_banned(self.state):
                return agent_id, []
            try:
                events = agent.generate_post_events(timestep, self.state)
                return agent_id, events or []
            except Exception as e:
                log.error(f"Error in parallel think_phase for agent {agent_id}: {e}")
                return agent_id, []

        with ThreadPoolExecutor(max_workers=self.max_llm_concurrency) as executor:
            futures = [
                executor.submit(_compute_think_for_agent, agent_id, agent)
                for agent_id, agent in sorted(self.agents.items())
            ]
            results = []
            for future in futures:
                try:
                    results.append(future.result())
                except Exception as e:
                    log.error(f"Unhandled error in think_phase future: {e}")

        for _agent_id, events in results:
            for event in events:
                if self.commit_event(event, timestep) is not None:
                    new_events.append(event)

        if new_events:
            log.debug(
                f"[parallel] Generated {len(new_events)} new events at timestep {timestep}"
            )
        self._schedule_coordination(new_events, timestep)

    def communicate_phase(self, timestep: int) -> None:
        """
        Communicate phase: Agents process feeds and interact.

        This is where agents read, reply, upvote, downvote.
        """
        self._set_clocks(timestep)
        # Attacker amplifications that are due run first, on the main thread
        self._run_coordination_actions(timestep)

        # Sequential path (default / flag disabled)
        if not self.enable_timestep_parallelism or self.max_llm_concurrency <= 1:
            for agent_id, agent in self.agents.items():
                try:
                    # Check if agent is active at this timestep
                    if not agent.is_active(timestep):
                        continue

                    feed = self.feed_manager.get_feed(
                        agent_id, max_items=agent.read_count, state=self.state
                    )

                    self.items_read += len(feed)
                    for event in feed:
                        agent.parse(event, self.state)

                        if agent.should_reply(event, self.state):
                            reply_event = agent.reply(event, self.state)
                            if reply_event:
                                self.commit_event(reply_event, timestep)

                        # At most one vote per item
                        vote_event = self._cast_vote(agent, event)
                        if vote_event:
                            self.commit_event(vote_event, timestep)

                        self.feed_manager.mark_read(agent_id, event.event_id)

                    if hasattr(agent, "flush_pending_moderation"):
                        agent.flush_pending_moderation(self.state, self.feed_manager)
                except Exception as e:
                    log.error(f"Error in communicate_phase for agent {agent_id}: {e}")
            self.feed_manager.purge_orphaned_feed_events(self.state)
            return

        # Parallel path: snapshot feeds per agent, process in threads, then apply results on main thread
        def _snapshot_feed(agent_id: int, agent):
            if not agent.is_active(timestep):
                return agent_id, []
            feed = self.feed_manager.get_feed(
                agent_id, max_items=agent.read_count, state=self.state
            )
            return agent_id, list(feed)

        def _compute_communicate_for_agent(
            agent_id: int, agent, feed_snapshot: List[any]
        ) -> Tuple[int, List[any], List[int]]:
            new_events: List[any] = []
            read_ids: List[int] = []
            try:
                for event in feed_snapshot:
                    agent.parse(event, self.state)

                    if agent.should_reply(event, self.state):
                        reply_event = agent.reply(event, self.state)
                        if reply_event:
                            new_events.append(reply_event)

                    # At most one vote per item
                    vote_event = self._cast_vote(agent, event)
                    if vote_event:
                        new_events.append(vote_event)

                    read_ids.append(event.event_id)
            except Exception as e:
                log.error(
                    f"Error in parallel communicate_phase for agent {agent_id}: {e}"
                )
            return agent_id, new_events, read_ids

        feeds_by_agent: Dict[int, List[any]] = {}
        for agent_id, agent in self.agents.items():
            try:
                aid, feed_snapshot = _snapshot_feed(agent_id, agent)
                feeds_by_agent[aid] = feed_snapshot
                self.items_read += len(feed_snapshot)
            except Exception as e:
                log.error(f"Error snapshotting feed for agent {agent_id}: {e}")

        # Run communicate logic in parallel
        with ThreadPoolExecutor(max_workers=self.max_llm_concurrency) as executor:
            futures = [
                executor.submit(
                    _compute_communicate_for_agent,
                    agent_id,
                    self.agents[agent_id],
                    feeds_by_agent.get(agent_id, []),
                )
                for agent_id in sorted(self.agents.keys())
            ]
            per_agent_results: List[Tuple[int, List[any], List[int]]] = []
            for future in futures:
                try:
                    per_agent_results.append(future.result())
                except Exception as e:
                    log.error(f"Unhandled error in communicate_phase future: {e}")

        # Apply events and mark read in a deterministic order (by agent_id);
        # commit_event refuses actions on items removed or by agents banned
        # since the feeds were snapshotted
        for agent_id, new_events, read_ids in per_agent_results:
            agent = self.agents.get(agent_id)
            for event in new_events:
                self.commit_event(event, timestep)
            for event_id in read_ids:
                self.feed_manager.mark_read(agent_id, event_id)
            if agent is not None and hasattr(agent, "flush_pending_moderation"):
                agent.flush_pending_moderation(self.state, self.feed_manager)
        self.feed_manager.purge_orphaned_feed_events(self.state)

    def cleanup_phase(self, timestep: int) -> None:
        """
        Cleanup phase: Update feeds, run moderation, run mitigations.

        This happens after all agents have acted.
        """
        pass

    def initialize_agents(self, agent_profiles: List[dict]) -> None:
        """
        Initialize agents from agent profiles.

        Args:
            agent_profiles: List of agent profile dicts from reddit_agent_initializer.py
        """
        log.info(
            f"initialize_agents called with {len(agent_profiles)} profiles (not yet implemented)"
        )
