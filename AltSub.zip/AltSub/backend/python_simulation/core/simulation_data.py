#!/usr/bin/env python3
"""
Simulation Data Structures: Network and state data structures

Defines core data structures for the simulation including MediaEvent,
networks, and agent state.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Set, Optional
from enum import Enum
import numpy as np


class EventType(Enum):
    """Types of media events"""

    POST = "post"
    REPLY = "reply"
    UPVOTE = "upvote"
    DOWNVOTE = "downvote"


@dataclass
class MediaEvent:
    """Represents a post, comment, or interaction event"""

    event_id: int
    user_id: int
    parent_id: Optional[int]  # None for top-level posts
    type: EventType
    belief_id: str
    subreddit_id: str
    # Reference timestep when the event was committed (floor(time_s / step) in
    # the event-driven engine); kept as an int so outputs and tools stay compatible
    timestamp: int
    score: int = 0
    content: str = ""

    upvotes: List[int] = field(default_factory=list)
    downvotes: List[int] = field(default_factory=list)
    replies: List[int] = field(default_factory=list)  # Child REPLY event_ids (not votes)

    indexes: Dict[str, any] = field(default_factory=dict)

    # Simulated commit time in seconds since the start of the run. Set by
    # AgentManager.commit_event; None for events built outside a run (tests),
    # where SimulationState.event_time falls back to timestamp * step length.
    time_s: Optional[float] = None

    def __post_init__(self):
        """Validate event data"""
        if self.type == EventType.POST and self.parent_id is not None:
            raise ValueError("Posts cannot have a parent_id")
        if (
            self.type in (EventType.UPVOTE, EventType.DOWNVOTE)
            and self.parent_id is None
        ):
            raise ValueError("Votes must have a parent_id")


@dataclass
class BeliefNetwork:
    """
    Belief network: dict[agent_id, dict[belief_id, strength]]

    Input: Loaded from reddit_agent_initializer.py per agent as (belief_id, belief_strength)
    Output: Tracked per timestep for belief shift analysis
    """

    beliefs: Dict[int, Dict[str, float]] = field(default_factory=dict)

    def get_belief(self, agent_id: int, belief_id: str) -> float:
        """Get belief strength for an agent (returns 0.0 if not found)"""
        return self.beliefs.get(agent_id, {}).get(belief_id, 0.0)

    def set_belief(self, agent_id: int, belief_id: str, strength: float) -> None:
        """Set belief strength for an agent (clamped to 0-1)"""
        if agent_id not in self.beliefs:
            self.beliefs[agent_id] = {}
        self.beliefs[agent_id][belief_id] = max(0.0, min(1.0, strength))

    def update_belief(self, agent_id: int, belief_id: str, delta: float) -> None:
        """Update belief strength by delta (clamped to 0-1)"""
        current = self.get_belief(agent_id, belief_id)
        self.set_belief(agent_id, belief_id, current + delta)

    def get_agent_beliefs(self, agent_id: int) -> Dict[str, float]:
        """Get all beliefs for an agent"""
        return self.beliefs.get(agent_id, {}).copy()

    def replace_agent_beliefs(
        self, agent_id: int, new_beliefs: Dict[str, float]
    ) -> None:
        """Replace an agent's full belief set (e.g. after consolidation). Clamps strengths to 0-1."""
        self.beliefs[agent_id] = {
            k: max(0.0, min(1.0, float(v))) for k, v in new_beliefs.items()
        }


@dataclass
class SubredditMembership:
    """Subreddit membership: dict[agent_id, set[subreddit_id]]"""

    memberships: Dict[int, Set[str]] = field(default_factory=dict)

    def add_member(self, agent_id: int, subreddit_id: str) -> None:
        """Add agent to subreddit"""
        if agent_id not in self.memberships:
            self.memberships[agent_id] = set()
        self.memberships[agent_id].add(subreddit_id)

    def is_member(self, agent_id: int, subreddit_id: str) -> bool:
        """Check if agent is member of subreddit"""
        return subreddit_id in self.memberships.get(agent_id, set())

    def get_subreddits(self, agent_id: int) -> Set[str]:
        """Get all subreddits agent belongs to"""
        return self.memberships.get(agent_id, set()).copy()


@dataclass
class BannedAgentNetwork:
    """Banned agent network: dict[agent_id, dict[subreddit_id, ban_count]]"""

    ban_counts: Dict[int, Dict[str, int]] = field(default_factory=dict)

    def increment_ban(self, agent_id: int, subreddit_id: str) -> None:
        """Increment ban count for agent in subreddit"""
        if agent_id not in self.ban_counts:
            self.ban_counts[agent_id] = {}
        self.ban_counts[agent_id][subreddit_id] = (
            self.ban_counts[agent_id].get(subreddit_id, 0) + 1
        )

    def get_ban_count(self, agent_id: int, subreddit_id: str) -> int:
        """Get ban count for agent in subreddit"""
        return self.ban_counts.get(agent_id, {}).get(subreddit_id, 0)

    def is_banned(self, agent_id: int, subreddit_id: str, threshold: int = 1) -> bool:
        """Check if agent is banned (ban_count >= threshold)"""
        return self.get_ban_count(agent_id, subreddit_id) >= threshold


@dataclass
class ActivityWeights:
    """Activity weights: dict[agent_id, dict[action, weight]]"""

    weights: Dict[int, Dict[str, float]] = field(default_factory=dict)

    def get_weight(self, agent_id: int, action: str) -> float:
        """Get activity weight for agent and action"""
        return self.weights.get(agent_id, {}).get(action, 0.0)

    def set_weight(self, agent_id: int, action: str, weight: float) -> None:
        """Set activity weight for agent and action"""
        if agent_id not in self.weights:
            self.weights[agent_id] = {}
        self.weights[agent_id][action] = max(0.0, weight)


@dataclass
class SimulationState:
    """Complete simulation state"""

    belief_network: BeliefNetwork = field(default_factory=BeliefNetwork)
    subreddit_membership: SubredditMembership = field(
        default_factory=SubredditMembership
    )
    banned_agent_network: BannedAgentNetwork = field(default_factory=BannedAgentNetwork)
    activity_weights: ActivityWeights = field(default_factory=ActivityWeights)

    # Length of one reference timestep in seconds (set during initialization).
    # Config windows and frequencies given in timesteps are multiplied by this.
    timestep_duration_seconds: float = 300.0

    # Current simulated time in seconds, maintained by the running engine (used
    # by feed ranking as "now")
    now_s: float = 0.0

    events: List[MediaEvent] = field(default_factory=list)
    events_by_id: Dict[int, MediaEvent] = field(default_factory=dict)
    events_by_user: Dict[int, List[MediaEvent]] = field(default_factory=dict)
    # Vote events by the event they target (so removals can cascade)
    votes_by_target: Dict[int, List[MediaEvent]] = field(default_factory=dict)

    next_event_id: int = 0

    # Events removed only because an ancestor (or a voted-on item) was removed
    removed_by_cascade: int = 0

    # Belief text registry: maps canonical_id -> canonical_text (shared across all agents)
    belief_text_registry: Dict[str, str] = field(default_factory=dict)

    # Placeholder accounts that wrote the seed content (core/seed_content.py):
    # not agents, exempt from moderation flags and bans
    seed_author_ids: Set[int] = field(default_factory=set)

    def event_time(self, event: MediaEvent) -> float:
        """Simulated time of an event in seconds."""
        if event.time_s is not None:
            return event.time_s
        return event.timestamp * self.timestep_duration_seconds

    def add_event(self, event: MediaEvent) -> None:
        """
        Add event to state.

        Validation (parent exists, author not banned, one vote per item) is done
        by AgentManager.commit_event before this is called. Votes are recorded in
        the parent's voter lists (not in replies), and score is always
        len(upvotes) - len(downvotes).
        """
        self.events.append(event)
        self.events_by_id[event.event_id] = event

        if event.user_id not in self.events_by_user:
            self.events_by_user[event.user_id] = []
        self.events_by_user[event.user_id].append(event)

        parent = (
            self.events_by_id.get(event.parent_id)
            if event.parent_id is not None
            else None
        )
        if parent is None:
            return

        if event.type == EventType.REPLY:
            if event.event_id not in parent.replies:
                parent.replies.append(event.event_id)
        elif event.type in (EventType.UPVOTE, EventType.DOWNVOTE):
            self.votes_by_target.setdefault(parent.event_id, []).append(event)
            voters = parent.upvotes if event.type == EventType.UPVOTE else parent.downvotes
            if event.user_id not in voters:
                voters.append(event.user_id)
            parent.score = len(parent.upvotes) - len(parent.downvotes)

    def get_event(self, event_id: int) -> Optional[MediaEvent]:
        """Get event by ID"""
        return self.events_by_id.get(event_id)

    def get_user_events(self, user_id: int) -> List[MediaEvent]:
        """Get all events by a user"""
        return self.events_by_user.get(user_id, []).copy()

    def remove_event(self, event_id: int) -> List[int]:
        """
        Remove an event and everything that depends on it: votes on it and,
        recursively, its replies (and votes on those). A removed post takes its
        thread with it, so nothing is left with a dangling parent_id.

        Returns:
            IDs of every removed event (empty if event_id was not present)
        """
        if event_id not in self.events_by_id:
            return []

        removed: List[int] = []
        stack = [event_id]
        while stack:
            eid = stack.pop()
            event = self.events_by_id.pop(eid, None)
            if event is None:
                continue
            removed.append(eid)
            stack.extend(v.event_id for v in self.votes_by_target.pop(eid, []))
            stack.extend(event.replies)

            parent = (
                self.events_by_id.get(event.parent_id)
                if event.parent_id is not None
                else None
            )
            if parent is not None:
                if event.type == EventType.REPLY and eid in parent.replies:
                    parent.replies.remove(eid)
                elif event.type in (EventType.UPVOTE, EventType.DOWNVOTE):
                    voters = (
                        parent.upvotes if event.type == EventType.UPVOTE else parent.downvotes
                    )
                    if event.user_id in voters:
                        voters.remove(event.user_id)
                    parent.score = len(parent.upvotes) - len(parent.downvotes)
                    siblings = self.votes_by_target.get(parent.event_id)
                    if siblings is not None:
                        siblings[:] = [v for v in siblings if v.event_id != eid]

        self.removed_by_cascade += len(removed) - 1
        gone = set(removed)
        self.events = [e for e in self.events if e.event_id not in gone]
        for user_id, evs in list(self.events_by_user.items()):
            if any(e.event_id in gone for e in evs):
                self.events_by_user[user_id] = [e for e in evs if e.event_id not in gone]
        return removed

    def get_new_event_id(self) -> int:
        """Get next available event ID"""
        event_id = self.next_event_id
        self.next_event_id += 1
        return event_id
