#!/usr/bin/env python3
"""
Thread context for comments read from the flat feed.

Feeds hold posts and comments as separate items, so a comment reaches a reader
without the post or the comments above it. thread_context() collects that
chain (original post first, then the comments down to the item's parent) so
reply, vote and belief-update prompts can show what the comment is answering.

Call it on the main thread when a job is created: it reads shared state, and
the returned tuples are plain copies safe to hand to worker threads.

Long threads keep the original post plus the nearest max_ancestors - 1
comments above the item; each text is cut to a character budget. A removed
ancestor ends the chain at that point (it is shown as "[removed]").
"""

from typing import List, Optional, Tuple

from .simulation_data import EventType, MediaEvent

# (kind, author, text): kind is "post" or "comment"
ThreadEntry = Tuple[str, str, str]

DEFAULT_MAX_ANCESTORS = 4
DEFAULT_POST_CHARS = 800
DEFAULT_COMMENT_CHARS = 400
REMOVED_TEXT = "[removed]"


def _clip(text: str, limit: int) -> str:
    text = (text or "").strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)].rstrip() + "..."


def thread_context(
    event: MediaEvent,
    state,
    max_ancestors: int = DEFAULT_MAX_ANCESTORS,
    post_chars: int = DEFAULT_POST_CHARS,
    comment_chars: int = DEFAULT_COMMENT_CHARS,
) -> List[ThreadEntry]:
    """Ancestors of a REPLY event, original post first (empty for a post)."""
    if event is None or event.type != EventType.REPLY or state is None:
        return []

    chain: List[Optional[MediaEvent]] = []  # nearest parent first
    seen = {event.event_id}
    parent_id = event.parent_id
    while parent_id is not None and parent_id not in seen:
        seen.add(parent_id)
        parent = state.get_event(parent_id)
        chain.append(parent)
        if parent is None:
            break
        parent_id = parent.parent_id
    if not chain:
        return []

    root = chain[-1]
    if root is not None and root.type == EventType.POST and max_ancestors >= 1:
        between = chain[:-1][: max(0, max_ancestors - 1)]
        kept = [root] + list(reversed(between))
        skipped = len(chain) - 1 - len(between)
    else:
        # Chain broken by a removed ancestor: keep the nearest ones
        kept = list(reversed(chain[: max(1, max_ancestors)]))
        skipped = 0

    out: List[ThreadEntry] = []
    for i, ev in enumerate(kept):
        if ev is None:
            out.append(("comment", "unknown", REMOVED_TEXT))
            continue
        is_post = ev.type == EventType.POST
        out.append((
            "post" if is_post else "comment",
            str(ev.user_id),
            _clip(ev.content, post_chars if is_post else comment_chars),
        ))
        if i == 0 and is_post and skipped:
            out.append(("comment", "", f"[... {skipped} earlier comment(s) omitted ...]"))
    return out


def format_thread(thread: List[ThreadEntry]) -> str:
    """Prompt text for a thread (one line per entry, indented by depth)."""
    lines = []
    depth = 0
    for kind, author, text in thread:
        if kind == "post":
            lines.append(f'[Original post by user {author}] "{text}"')
            depth = 1
            continue
        indent = "  " * depth
        if not author:  # omission marker
            lines.append(f"{indent}{text}")
        else:
            lines.append(f'{indent}[Comment by user {author}] "{text}"')
        depth += 1
    return "\n".join(lines)
