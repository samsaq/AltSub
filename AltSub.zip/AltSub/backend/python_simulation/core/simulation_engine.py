#!/usr/bin/env python3
"""
Simulation Engine: Core timestep management and simulation loop

Manages the main simulation loop and timestep progression.
"""

import logging
from typing import Optional, Callable
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass
class SimulationConfig:
    """Configuration for simulation engine"""
    duration_days: int = 14
    interval_minutes: int = 5
    snapshot_frequency_days: int = 1
    start_time: float = 0.0  # Starting time in hours


class SimulationEngine:
    """Core simulation engine managing timesteps and main loop"""
    
    def __init__(self, config: SimulationConfig):
        self.config = config
        
        total_minutes = config.duration_days * 24 * 60
        self.total_timesteps = int(total_minutes // config.interval_minutes)
        self.timesteps_per_day = int(24 * 60 // config.interval_minutes)
        self.timesteps_per_snapshot = int(config.snapshot_frequency_days * self.timesteps_per_day)
        
        self.current_timestep = 0
        self.current_time = config.start_time  # hours
        self.state = "stopped"  # stopped, running, paused
        
        self.think_callback: Optional[Callable[[int], None]] = None
        self.communicate_callback: Optional[Callable[[int], None]] = None
        self.cleanup_callback: Optional[Callable[[int], None]] = None
        self.snapshot_callback: Optional[Callable[[int], None]] = None
        
        log.info(f"SimulationEngine initialized: {self.total_timesteps} timesteps "
                f"({config.duration_days} days @ {config.interval_minutes} min intervals)")
    
    @property
    def current_day(self) -> int:
        """Get current day (0-indexed)"""
        return self.current_timestep // self.timesteps_per_day
    
    @property
    def timestep_duration_hours(self) -> float:
        """Get timestep duration in hours"""
        return self.config.interval_minutes / 60.0
    
    def step(self) -> bool:
        """
        Execute one timestep.
        
        Returns:
            True if simulation should continue, False if should stop
        """
        if self.current_timestep >= self.total_timesteps:
            return False
        
        self.current_time = self.current_timestep * self.timestep_duration_hours
        
        if self.think_callback:
            self.think_callback(self.current_timestep)
        
        if self.communicate_callback:
            self.communicate_callback(self.current_timestep)
        
        if self.cleanup_callback:
            self.cleanup_callback(self.current_timestep)
        
        if self.snapshot_callback and (self.current_timestep + 1) % self.timesteps_per_snapshot == 0:
            self.snapshot_callback(self.current_timestep)
        
        self.current_timestep += 1
        return True
    
    def run(self) -> None:
        """Run the complete simulation"""
        if self.state == "running":
            log.warning("Simulation already running")
            return
        
        self.state = "running"
        log.info(f"Starting simulation: {self.total_timesteps} timesteps")
        
        try:
            while self.step():
                # Log progress every 50 steps
                if self.current_timestep % 50 == 0:
                    log.info(f"Timestep {self.current_timestep}/{self.total_timesteps} "
                           f"(Day {self.current_day + 1}/{self.config.duration_days})")
                # Log progress every day
                elif self.current_timestep % self.timesteps_per_day == 0:
                    log.info(f"Timestep {self.current_timestep}/{self.total_timesteps} "
                           f"(Day {self.current_day + 1}/{self.config.duration_days})")
        except KeyboardInterrupt:
            log.warning("Simulation interrupted by user")
            self.state = "paused"
            raise
        except Exception as e:
            log.error(f"Simulation error at timestep {self.current_timestep}: {e}")
            self.state = "stopped"
            raise
        finally:
            if self.state == "running":
                self.state = "stopped"
                log.info(f"Simulation completed: {self.current_timestep} timesteps")
    
    def pause(self) -> None:
        """Pause the simulation"""
        if self.state == "running":
            self.state = "paused"
            log.info("Simulation paused")
    
    def resume(self) -> None:
        """Resume the simulation"""
        if self.state == "paused":
            self.state = "running"
            log.info("Simulation resumed")
    
    def stop(self) -> None:
        """Stop the simulation"""
        self.state = "stopped"
        log.info("Simulation stopped")
    
    def set_callbacks(
        self,
        think: Optional[Callable[[int], None]] = None,
        communicate: Optional[Callable[[int], None]] = None,
        cleanup: Optional[Callable[[int], None]] = None,
        snapshot: Optional[Callable[[int], None]] = None,
    ) -> None:
        """Set callbacks for simulation phases"""
        if think is not None:
            self.think_callback = think
        if communicate is not None:
            self.communicate_callback = communicate
        if cleanup is not None:
            self.cleanup_callback = cleanup
        if snapshot is not None:
            self.snapshot_callback = snapshot

