"""
Path settings in simulation_config.json that may be written relative to the
config's own folder (so a setup can be moved or shared). Resolve them against
that folder whenever a config is loaded from disk, before it is used or copied
into another directory.
"""

from pathlib import Path
from typing import Any, Dict, Union


def resolve_config_paths(config: Dict[str, Any], config_dir: Union[str, Path]) -> Dict[str, Any]:
    """Make campaign_config.campaign_templates_dir absolute (relative to config_dir).

    Absolute paths and a missing setting are left unchanged. Returns config.
    """
    cc = config.get("campaign_config")
    raw = cc.get("campaign_templates_dir") if isinstance(cc, dict) else None
    if raw and not Path(raw).is_absolute():
        cc["campaign_templates_dir"] = str((Path(config_dir) / raw).resolve())
    return config
