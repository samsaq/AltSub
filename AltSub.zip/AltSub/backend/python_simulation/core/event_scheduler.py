#!/usr/bin/env python3
"""
Event scheduler: a priority queue of simulated events for the event engine.

Times are integer milliseconds, so equal times compare exactly (sync windows,
day boundaries). Events at the same time run in a fixed order:
kind priority, then agent_id, then insertion order. That order is what makes a
seeded run reproducible regardless of how fast LLM calls return.
"""

import heapq
import itertools
from dataclasses import dataclass, field
from enum import IntEnum
from typing import Any, List, Optional, Tuple


class EventKind(IntEnum):
    """Event types; the value is the priority at equal times (lower first).

    Commits come first, so anything committed at time t is visible to scans,
    snapshots and reads that happen at t (as in the discrete engine, where a
    cleanup-phase scan sees that timestep's actions).
    """

    COMMIT = 0
    READ_DONE = 1
    DAY_BOUNDARY = 2
    MITIGATION_SCAN = 3
    BIASED_SCAN = 4
    SESSION_START = 5
    INSTRUCTION_DUE = 6
    COORDINATION_START = 7
    POST_START = 8
    READ_START = 9


@dataclass(order=True)
class ScheduledEvent:
    t_ms: int
    kind: EventKind
    agent_id: int
    seq: int
    payload: Any = field(compare=False, default=None)

    @property
    def t(self) -> float:
        return self.t_ms / 1000.0


def to_ms(t: float) -> int:
    return int(round(t * 1000.0))


class EventScheduler:
    """Min-heap of ScheduledEvents ordered by (time, kind, agent_id, seq)."""

    GLOBAL = -1  # agent_id for events that belong to no agent

    def __init__(self):
        self._heap: List[ScheduledEvent] = []
        self._seq = itertools.count()

    def schedule(
        self, t: float, kind: EventKind, agent_id: int = GLOBAL, payload: Any = None
    ) -> ScheduledEvent:
        event = ScheduledEvent(to_ms(t), kind, int(agent_id), next(self._seq), payload)
        heapq.heappush(self._heap, event)
        return event

    def pop(self) -> Optional[ScheduledEvent]:
        return heapq.heappop(self._heap) if self._heap else None

    def peek_time(self) -> Optional[float]:
        return self._heap[0].t if self._heap else None

    def __len__(self) -> int:
        return len(self._heap)
