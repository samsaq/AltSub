#!/usr/bin/env python3
"""
Seed the simulated subreddit with real recent content at the start of a run.

The simulation otherwise starts empty, and with few posting agents the feed
stays nearly empty for much of a run (most reads find nothing). This commits
the setup's seed sample (subreddit_seed_context.json: the top posts of the last
24 hours of the subreddit's Reddit data, each with its top top-level comments)
as pre-existing content at time 0, so agents have posts and threads to read and
react to from the first session ("next morning" content).

Seed items:
  - are written by placeholder seed accounts (negative user ids, one per item)
    that are not agents: they never act, vote or get counted in agent metrics,
    MCC, bans or campaign alignment;
  - are exempt from moderation flags and bans (MitigationSystem.flag_agent and
    the rule moderator skip them: they were already moderated on Reddit);
  - start with score 0 (their real Reddit scores would rank above every
    simulated post for the whole run);
  - are tagged (indexes["seed"] = True) so outputs report them separately.
"""

import logging
from typing import Any, Dict, List, Optional

from .simulation_data import EventType, MediaEvent

log = logging.getLogger(__name__)

SEED_AUTHOR_BASE = -1000  # seed accounts are -1000, -1001, ...
SEED_BELIEF_ID = "seed"


def is_seed_event(event: Optional[MediaEvent]) -> bool:
    return event is not None and bool((event.indexes or {}).get("seed"))


def inject_seed_content(
    state, agent_manager, seed_context: Optional[Dict[str, Any]], subreddit_id: str,
    max_posts: int = 10, comments_per_post: int = 5,
) -> Dict[str, int]:
    """Commit seed posts and their top comments at time 0; returns counts."""
    if not seed_context:
        return {"posts": 0, "replies": 0}
    posts = [p for p in seed_context.get("posts", []) if (p.get("content") or "").strip()][:max_posts]
    comments_by_post: Dict[str, List[Dict[str, Any]]] = {}
    for c in seed_context.get("comments", []):
        if (c.get("content") or "").strip():
            comments_by_post.setdefault(c.get("root_post_id"), []).append(c)

    next_author = SEED_AUTHOR_BASE
    counts = {"posts": 0, "replies": 0}

    def commit(content: str, etype: EventType, parent_id: Optional[int], source_id: str) -> Optional[MediaEvent]:
        nonlocal next_author
        author = next_author
        next_author -= 1
        state.seed_author_ids.add(author)
        event = MediaEvent(
            event_id=0, user_id=author, parent_id=parent_id, type=etype,
            belief_id=SEED_BELIEF_ID, subreddit_id=subreddit_id, timestamp=0,
            content=content.strip(), indexes={"seed": True, "source_id": source_id},
        )
        return agent_manager.commit_event(event, 0, 0.0)

    for post in posts:
        committed = commit(post["content"], EventType.POST, None, str(post.get("event_id", "")))
        if committed is None:
            continue
        counts["posts"] += 1
        for c in comments_by_post.get(post.get("event_id"), [])[:comments_per_post]:
            if commit(c["content"], EventType.REPLY, committed.event_id, str(post.get("event_id", ""))):
                counts["replies"] += 1
    log.info(
        "Seeded the feed with %d real posts and %d of their top comments (score 0, "
        "seed accounts exempt from moderation)", counts["posts"], counts["replies"],
    )
    return counts
