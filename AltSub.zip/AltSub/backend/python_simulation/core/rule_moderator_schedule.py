#!/usr/bin/env python3
"""
Staggered contiguous daily activity blocks for rule moderators, and adding
rule moderator agents to a run's config and profiles (used by auto_runner's
rule moderator scenarios and by parameter_tuning's rule moderation stage).
"""

from typing import Any, Dict, List, Tuple

import numpy as np


def generate_rule_moderator_schedules(
    num_timesteps: int,
    timesteps_per_day: int,
    num_moderators: int,
    active_fraction: float,
    seed: int,
) -> List[np.ndarray]:
    """
    One schedule per moderator: each simulated day has a single contiguous active block
    of length round(active_fraction * timesteps_per_day) (at least 1). When
    N * block_len <= day_len, blocks are placed with random gaps (non-overlapping).
    Otherwise each moderator gets an independent random contiguous block (may overlap).
    """
    if num_moderators <= 0 or num_timesteps <= 0:
        return []

    rng = np.random.default_rng(int(seed))
    tpd = max(1, int(timesteps_per_day))
    block = max(1, int(round(float(active_fraction) * tpd)))
    block = min(block, tpd)

    schedules = [np.zeros(num_timesteps, dtype=bool) for _ in range(num_moderators)]
    num_days = (num_timesteps + tpd - 1) // tpd

    for day in range(num_days):
        day_start = day * tpd
        if day_start >= num_timesteps:
            break
        day_end = min(day_start + tpd, num_timesteps)
        day_len = day_end - day_start
        eff_block = min(block, day_len)

        slack = day_len - num_moderators * eff_block

        if slack >= 0:
            gaps = rng.multinomial(
                slack, np.ones(num_moderators + 1) / (num_moderators + 1)
            )
            pos = 0
            starts: List[int] = []
            for k in range(num_moderators):
                pos += int(gaps[k])
                starts.append(pos)
                pos += eff_block
            for mod_idx in range(num_moderators):
                s = starts[mod_idx]
                schedules[mod_idx][day_start + s : day_start + s + eff_block] = True
        else:
            for mod_idx in range(num_moderators):
                if day_len <= eff_block:
                    s = 0
                else:
                    s = int(rng.integers(0, day_len - eff_block + 1))
                schedules[mod_idx][day_start + s : day_start + s + eff_block] = True

    return schedules


# mitigation_config defaults for runs that add rule moderators
RULE_MODERATOR_MITIGATION_DEFAULTS: Dict[str, Any] = {
    "rule_moderator_count": 1,
    "rule_moderator_active_fraction": 0.25,
    "rule_moderator_read_density": 25,
    "rule_moderator_schedule_seed": 42,
    "rule_moderator_detection_threshold": 0.7,
}


def ensure_rule_moderator_mitigation_defaults(m: Dict[str, Any]) -> None:
    """Turn rule moderators on in a mitigation_config and fill missing settings."""
    m["enable_rule_moderators"] = True
    for key, value in RULE_MODERATOR_MITIGATION_DEFAULTS.items():
        m.setdefault(key, value)


def inject_rule_moderator_agents(
    cfg: Dict[str, Any], profiles: List[Dict[str, Any]]
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Append rule_moderator profiles and activity schedules (aligned with reddit_agent_initializer).
    Base universe configs typically have no rule_moderator rows; this adds them.
    """
    mit = cfg.setdefault("mitigation_config", {})
    count = max(1, int(mit.get("rule_moderator_count", 1)))
    mit["rule_moderator_count"] = count

    sim = cfg.get("simulation_config") or {}
    interval = int(sim.get("interval_minutes", 5))
    timesteps_per_day = (24 * 60) // interval
    total_days = int(sim.get("duration_days", 14))
    num_timesteps = timesteps_per_day * total_days
    seed = int(mit.get("rule_moderator_schedule_seed", 42))
    fraction = float(mit.get("rule_moderator_active_fraction", 0.25))
    read_density = float(mit.get("rule_moderator_read_density", 25))
    sub = str(sim.get("target_subreddit", "unknown"))

    base_idx = len(profiles)
    generated = generate_rule_moderator_schedules(
        num_timesteps, timesteps_per_day, count, fraction, seed
    )
    for i in range(count):
        profiles.append(
            {
                "username": f"rule_moderator_{i}",
                "subreddit": sub,
                "behavioral_params": {
                    "read_density": read_density,
                    "post_probability": 0.0,
                    "pr_comment": 0.0,
                    "pr_upvote": 0.0,
                    "pr_downvote": 0.0,
                },
                "activity_patterns": {
                    "activity_level": "reader",
                    "frequency_of_use": "daily",
                    "session_duration": "long",
                    "active_time_slots": ["12am-12am"],
                },
                "content_metrics": {
                    "total_posts": 0,
                    "total_comments": 0,
                    "avg_score": 0.0,
                    "controversiality": 0.0,
                },
                "beliefs": {},
                "trust_network": {},
                "user_type": "rule_moderator",
            }
        )
    sched = cfg.setdefault("agent_activity_schedules", {})
    for j in range(count):
        row = generated[j]
        sched[str(base_idx + j)] = [int(x) for x in row.tolist()]

    if isinstance(cfg.get("simulation_config"), dict):
        cfg["simulation_config"]["total_agents"] = len(profiles)

    return cfg, profiles
