#!/usr/bin/env python3
"""
Belief statements: the belief model's definitions, in one place.

Two belief models exist (simulation_config.json "belief_config.model"):

  "axes"      (default for new setups) A fixed set of belief statements per
              scenario, each grouped under a conceptual domain. Every agent
              holds an acceptance value in [0, 1] for each statement:
              0 = complete rejection, 0.5 = neutral, 1 = complete
              acceptance. The LLM updates the values for each item an agent
              reads, each change bounded by
              LLMServiceConfig.belief_update_max_change. (The model keeps its
              historical name "axes"; each statement is a BeliefAxis.)
  "free_text" (previous model) Beliefs are claims extracted from content,
              canonicalised, consolidated and capped. Configs without a
              belief_config block run in this mode, unchanged.

The value semantics (acceptance, 0..1) live only in this module: prompts, the
initializer and the analysis use format_acceptance / strongest_axis /
alignment from here.

The destiny2 and politics sets are the thesis belief spaces (Constructing the
Belief Space: C1-C7, P1-P6). Campaign targets sit at the extremes: 0 for
statements the campaign argues against, 1 for statements it argues for.
Organic users start neutral (the 0.5 prior). The generic set is a fallback for
other subreddits.

Prompts show agents the numeric acceptance of each statement together with the
scale (ACCEPTANCE_SCALE, format_acceptance); the LLM returns new values and the
change is clamped to the per-update cap.

Configuring an experiment: write an axes file (same shape as
BeliefConfig.to_dict(), e.g. Simulation_Setups/belief_axes/destiny2.json) and
pass it to the initializer (--belief-axes-file, or BELIEF_AXES_FILE in
experiment_config.sh). Without a file the built-in set for the subreddit is
used (DEFAULT_AXIS_SETS), falling back to "generic".

campaign_targets: the attacker campaign's target acceptance of each
statement (0 = it argues against the statement, 1 = for it). Attackers hold
these values, the biased moderator defends them, and analysis measures how far
organic users move toward them (alignment()). Statements without a target are
tracked but left out of the alignment measure.
"""

import json
import logging
import math
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

log = logging.getLogger(__name__)

BELIEF_MODELS = ("axes", "free_text")
NEUTRAL = 0.5


@dataclass
class BeliefAxis:
    """One belief statement. Value = acceptance: 0 = complete rejection,
    0.5 = neutral, 1 = complete acceptance."""

    id: str
    statement: str
    # Conceptual domain the statement belongs to (for grouping and analysis)
    domain: str = ""
    # Starting acceptance for agents with no evidence on this statement (and
    # the spread of a sampled start, 0 = always prior_mean)
    prior_mean: float = NEUTRAL
    prior_sd: float = 0.0


@dataclass
class BeliefConfig:
    """Belief model, axes and campaign targets for a simulation."""

    model: str = "axes"
    axes: List[BeliefAxis] = field(default_factory=list)
    campaign_targets: Dict[str, float] = field(default_factory=dict)
    # Where the axes came from ("default:destiny2", "file:<path>", ...)
    source: str = ""

    def axis(self, axis_id: str) -> Optional[BeliefAxis]:
        return next((a for a in self.axes if a.id == axis_id), None)

    @property
    def axis_ids(self) -> List[str]:
        return [a.id for a in self.axes]

    def validate(self) -> "BeliefConfig":
        if self.model not in BELIEF_MODELS:
            raise ValueError(f"belief model {self.model!r} must be one of {BELIEF_MODELS}")
        if self.model == "axes" and not self.axes:
            raise ValueError("belief model 'axes' needs at least one axis")
        ids = [a.id for a in self.axes]
        if len(ids) != len(set(ids)):
            raise ValueError(f"duplicate belief axis ids: {ids}")
        for a in self.axes:
            if not a.id or not str(a.statement).strip():
                raise ValueError(f"belief {a.id!r} needs an id and a statement")
            if not 0.0 <= a.prior_mean <= 1.0 or a.prior_sd < 0:
                raise ValueError(f"belief axis {a.id!r}: prior_mean must be in [0, 1], prior_sd >= 0")
        for axis_id, target in self.campaign_targets.items():
            if axis_id not in ids:
                raise ValueError(f"campaign target for unknown axis {axis_id!r}")
            if not 0.0 <= float(target) <= 1.0:
                raise ValueError(f"campaign target for {axis_id!r} must be in [0, 1]")
        return self

    def to_dict(self) -> Dict[str, Any]:
        return {
            "model": self.model,
            "axes": [asdict(a) for a in self.axes],
            "campaign_targets": dict(self.campaign_targets),
            "source": self.source,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BeliefConfig":
        if any("pole_0" in a or "pole_1" in a for a in data.get("axes", [])):
            raise ValueError(
                "belief_config uses the old two-pole axes (pole_0 / pole_1). Beliefs are "
                "now single statements with an acceptance value (fields: id, statement, "
                "domain, prior_mean, prior_sd): regenerate the setup with the initializer "
                "or rewrite the axes file"
            )
        return cls(
            model=data.get("model", "axes"),
            axes=[BeliefAxis(**a) for a in data.get("axes", [])],
            campaign_targets={k: float(v) for k, v in (data.get("campaign_targets") or {}).items()},
            source=data.get("source", ""),
        ).validate()


# Built-in axis sets

def _belief(belief_id: str, domain: str, statement: str) -> BeliefAxis:
    return BeliefAxis(belief_id, statement, domain)


# Commercial scenario (r/destiny2): thesis Table "Commercial Scenario Beliefs".
# Campaign narrative: "The latest Destiny 2 Final Shape expansion is
# disappointing and marks the end of meaningful content. The story is complete
# and there's nothing left to do. Players should move on to other games like
# Warframe, which offers better content and more engaging gameplay."
_DESTINY2_AXES = [
    _belief("C1", "Continuance intention",
            "Destiny 2 has a meaningful future beyond The Final Shape."),
    _belief("C2", "Game satisfaction",
            "The Final Shape provides a satisfying conclusion to Destiny 2's main story."),
    _belief("C3", "Game satisfaction",
            "Destiny 2's core gameplay remains engaging."),
    _belief("C4", "Continuance intention",
            "Continuing to spend time on Destiny 2 is worthwhile."),
    _belief("C5", "Switching intention",
            "Warframe is a worthwhile alternative to Destiny 2."),
    _belief("C6", "Switching intention",
            "I intend to shift some of my gaming time from Destiny 2 to Warframe."),
    _belief("C7", "Community perception",
            "Most people in r/Destiny2 think Warframe is a worthwhile alternative to Destiny 2."),
]

# Political scenario (r/worldnews; originally r/politics): thesis Table "Beliefs for the political scenario".
# Campaign narrative: "The July 8 Kyiv hospital bombing is being exploited as
# propaganda with no real evidence. Witness reports conflict, casualty numbers
# are unverified, and the site may have been a legitimate military target.
# Media ignores context. Don't buy the outrage without proof."
_POLITICS_AXES = [
    _belief("P1", "Attribution of responsibility",
            "Russian armed forces were responsible for the missile strike that hit the "
            "Okhmatdyt hospital complex."),
    _belief("P2", "Evidential sufficiency",
            "Available evidence is sufficient to attribute the strike to Russian forces."),
    _belief("P3", "Media credibility",
            "Mainstream media reporting on the hospital strike is credible."),
    _belief("P4", "Civilian-military distinction",
            "At the time of the strike, the Okhmatdyt hospital was being used for military purposes."),
    _belief("P5", "Perceived opinion climate",
            "Most people in r/worldnews think Russian forces carried out the Okhmatdyt hospital strike."),
    _belief("P6", "Accountability",
            "Russian authorities should be held accountable for the strike on the Okhmatdyt hospital."),
]

# Generic fallback for subreddits without a set of their own
_GENERIC_AXES = [
    _belief("gen_community_sentiment", "Community sentiment",
            "Things in this community are going well."),
    _belief("gen_authority_trust", "Trust in those in charge",
            "The people in charge here (developers, officials, moderators) can be trusted."),
    _belief("gen_recent_changes", "Recent changes",
            "Recent changes are improvements."),
    _belief("gen_media_trust", "Trust in coverage",
            "News and coverage of this topic are accurate."),
]

# Built-in sets: statements plus campaign targets. The campaign agents hold
# and push the extreme of each statement: 0 for statements against the
# campaign, 1 for statements in its favour.
DEFAULT_AXIS_SETS: Dict[str, Dict[str, Any]] = {
    "destiny2": {
        "axes": _DESTINY2_AXES,
        "campaign_targets": {
            "C1": 0.0, "C2": 0.0, "C3": 0.0, "C4": 0.0,
            "C5": 1.0, "C6": 1.0, "C7": 1.0,
        },
    },
    "politics": {
        "axes": _POLITICS_AXES,
        "campaign_targets": {
            "P1": 0.0, "P2": 0.0, "P3": 0.0, "P4": 1.0, "P5": 0.0, "P6": 0.0,
        },
    },
    "generic": {"axes": _GENERIC_AXES, "campaign_targets": {}},
}

# Subreddit name fragments -> built-in set
_SUBREDDIT_SETS = (("destiny", "destiny2"), ("worldnews", "politics"), ("politic", "politics"))


def default_set_name(subreddit: str) -> str:
    name = (subreddit or "").lower()
    return next((key for fragment, key in _SUBREDDIT_SETS if fragment in name), "generic")


def default_belief_config(subreddit: str, model: str = "axes") -> BeliefConfig:
    return belief_config_for_set(default_set_name(subreddit), model)


def belief_config_for_set(key: str, model: str = "axes") -> BeliefConfig:
    """A built-in axis set (DEFAULT_AXIS_SETS[key]) as a BeliefConfig."""
    entry = DEFAULT_AXIS_SETS[key]
    return BeliefConfig(
        model=model,
        axes=[BeliefAxis(**asdict(a)) for a in entry["axes"]],
        campaign_targets=dict(entry["campaign_targets"]),
        source=f"default:{key}",
    ).validate()


def load_belief_config(path: Path, model: Optional[str] = None) -> BeliefConfig:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    if model:
        data["model"] = model
    config = BeliefConfig.from_dict(data)
    config.source = f"file:{Path(path).name}"
    return config


def resolve_belief_config(
    subreddit: str, axes_file: Optional[str] = None, model: str = "axes"
) -> BeliefConfig:
    """Axes file if given, else the built-in set for the subreddit (else generic)."""
    if axes_file:
        return load_belief_config(Path(axes_file), model)
    return default_belief_config(subreddit, model)


# Value semantics (used by prompts, initializer and analysis)


def clamp_unit(value: float) -> float:
    return max(0.0, min(1.0, float(value)))


# Meaning of the acceptance values, stated wherever prompts show them
ACCEPTANCE_SCALE = "0.0 = complete rejection, 0.5 = neutral, 1.0 = complete acceptance"

# Optional Likert-style labels (LLMServiceConfig.verbal_acceptance_labels):
# each value is shown with the label of the nearest anchor
LIKERT_ANCHORS = (
    (0.0, "completely rejects"),
    (0.25, "rejects"),
    (0.5, "neutral"),
    (0.75, "accepts"),
    (1.0, "completely accepts"),
)
LIKERT_SCALE = ", ".join(f"{v:.2f} = {label}" for v, label in LIKERT_ANCHORS)


def acceptance_label(value: float) -> str:
    """Label of the nearest Likert anchor (ties go to the more neutral one)."""
    value = clamp_unit(value)
    return min(LIKERT_ANCHORS, key=lambda a: (abs(a[0] - value), abs(a[0] - NEUTRAL)))[1]


def acceptance_scale(verbal: bool = False) -> str:
    return LIKERT_SCALE if verbal else ACCEPTANCE_SCALE


def format_value(value: float, verbal: bool = False) -> str:
    """An acceptance value as shown in prompts: "0.62" or "0.62, neutral"."""
    value = clamp_unit(value)
    return f"{value:.2f}, {acceptance_label(value)}" if verbal else f"{value:.2f}"


def format_acceptance(axis: BeliefAxis, value: float, verbal: bool = False) -> str:
    """A statement with its acceptance value, as shown in prompts."""
    return f'"{axis.statement}" (acceptance: {format_value(value, verbal)})'


def strongest_axis(positions: Dict[str, float]) -> str:
    """The statement the agent holds the strongest stance on (furthest from neutral)."""
    if not positions:
        return "default"
    return max(positions.items(), key=lambda kv: (abs(kv[1] - NEUTRAL), kv[0]))[0]


def alignment(positions: Dict[str, float], targets: Dict[str, float]) -> Optional[float]:
    """1 - mean distance to the campaign targets over targeted statements (1 =
    at the targets, 0 = maximally far from them); None without targets."""
    axes = [a for a in targets if a in positions]
    if not axes:
        return None
    return 1.0 - sum(abs(positions[a] - targets[a]) for a in axes) / len(axes)


def prior_positions(config: BeliefConfig, rng=None) -> Dict[str, float]:
    """Starting acceptance from each statement's prior (sampled when prior_sd > 0
    and an rng is given)."""
    out = {}
    for axis in config.axes:
        value = axis.prior_mean
        if axis.prior_sd > 0 and rng is not None:
            value = rng.normal(axis.prior_mean, axis.prior_sd)
        out[axis.id] = clamp_unit(value)
    return out


def campaign_positions(config: BeliefConfig) -> Dict[str, float]:
    """Fixed acceptance of campaign agents: the targets, neutral elsewhere."""
    return {a.id: clamp_unit(config.campaign_targets.get(a.id, NEUTRAL)) for a in config.axes}


def write_default_sets(out_dir: Path) -> List[Path]:
    """Write every built-in set as an editable axes file (<name>.json)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = []
    for key in DEFAULT_AXIS_SETS:
        data = belief_config_for_set(key).to_dict()
        data["source"] = f"built-in set '{key}' (core/belief_axes.py); edit to customise"
        path = out_dir / f"{key}.json"
        path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
        paths.append(path)
    return paths


def complete_positions(
    config: BeliefConfig, positions: Optional[Dict[str, Any]], rng=None
) -> Dict[str, float]:
    """Acceptance for every statement: given values (clamped) where valid, the prior elsewhere."""
    prior = prior_positions(config, rng)
    out = {}
    for axis_id, default in prior.items():
        value = (positions or {}).get(axis_id)
        try:
            out[axis_id] = clamp_unit(value) if value is not None and math.isfinite(float(value)) else default
        except (TypeError, ValueError):
            out[axis_id] = default
    return out


if __name__ == "__main__":
    # python -m python_simulation.core.belief_axes <out_dir>: write the built-in
    # axis sets as editable JSON files
    import sys

    for written in write_default_sets(Path(sys.argv[1] if len(sys.argv) > 1 else "belief_axes")):
        print(f"Wrote {written}")
