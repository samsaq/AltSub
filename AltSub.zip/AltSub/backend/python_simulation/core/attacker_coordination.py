#!/usr/bin/env python3
"""
Attacker coordination: attackers amplify each other's posts.

When an attacker's top-level post enters the simulation, every other non-banned
attacker, with probability coordination_strength, schedules an amplification of
it: an upvote, plus a supportive comment with probability coordination_comment_prob.
The amplification is due a few timesteps later (uniform in
[coordination_delay_min, coordination_delay_max]), modelling the fast mutual early
engagement documented for coordinated inauthentic behaviour.

Targets are stored on the attackers (AttackerActivityMixin.coordination_targets);
AgentManager.communicate_phase carries them out when due.
"""

import logging
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

import numpy as np

from ..agents.attacker_activity import CoordinationTarget
from .simulation_data import EventType, MediaEvent, SimulationState

log = logging.getLogger(__name__)

DEFAULT_COORDINATION_COMMENT_PROB = 0.5
DEFAULT_COORDINATION_DELAY_MIN = 1
DEFAULT_COORDINATION_DELAY_MAX = 6  # 5-30 min at 5-min timesteps


class CoordinationHub:
    """Schedules amplification targets between attackers of one campaign"""

    def __init__(
        self,
        attacker_ids: Iterable[int],
        coordination_strength: float,
        comment_prob: float = DEFAULT_COORDINATION_COMMENT_PROB,
        delay_min: int = DEFAULT_COORDINATION_DELAY_MIN,
        delay_max: int = DEFAULT_COORDINATION_DELAY_MAX,
    ):
        self.attacker_ids: Set[int] = set(attacker_ids)
        self.coordination_strength = min(1.0, max(0.0, float(coordination_strength)))
        self.comment_prob = min(1.0, max(0.0, float(comment_prob)))
        self.delay_min = max(0, int(delay_min))
        self.delay_max = max(self.delay_min, int(delay_max))
        # Random stream (seeded by the run)
        self.rng: np.random.Generator = np.random.default_rng()
        # Counts for the run summary
        self.stats: Dict[str, int] = {
            "posts_seen": 0,
            "upvotes_scheduled": 0,
            "comments_scheduled": 0,
            "upvotes_executed": 0,
            "comments_executed": 0,
            "skipped_banned": 0,
            "skipped_removed": 0,
            "skipped_already_voted": 0,
        }
        log.info(
            "CoordinationHub: %d attackers, strength=%.2f, comment_prob=%.2f, delay=%d-%d",
            len(self.attacker_ids),
            self.coordination_strength,
            self.comment_prob,
            self.delay_min,
            self.delay_max,
        )

    def on_new_events(
        self,
        events: List[MediaEvent],
        timestep: int,
        agents: Dict[int, Any],
        state: SimulationState,
        step_s: Optional[float] = None,
    ) -> List[Tuple[int, CoordinationTarget]]:
        """Schedule amplifications of any new attacker top-level posts.

        Discrete engine (step_s None): due = timestep + randint(delay_min,
        delay_max), stored on the amplifying attacker.
        Event engine (step_s given): due_time_s = post time + a continuous delay
        uniform in [delay_min, delay_max] timesteps; the delay is to the commit
        of the amplification. Targets are returned for the engine to schedule
        and not stored on the agents.
        """
        scheduled: List[Tuple[int, CoordinationTarget]] = []
        if len(self.attacker_ids) < 2 or self.coordination_strength <= 0:
            return scheduled
        for event in events:
            if (
                event.type != EventType.POST
                or event.parent_id is not None
                or event.user_id not in self.attacker_ids
            ):
                continue
            self.stats["posts_seen"] += 1
            for attacker_id in self.attacker_ids:
                if attacker_id == event.user_id:
                    continue
                agent = agents.get(attacker_id)
                if agent is None or not hasattr(agent, "add_coordination_target"):
                    continue
                if agent.is_banned(state):
                    continue
                if self.rng.random() >= self.coordination_strength:
                    continue
                if step_s is None:
                    due = timestep + int(self.rng.integers(self.delay_min, self.delay_max + 1))
                    due_s = None
                else:
                    due_s = state.event_time(event) + float(
                        self.rng.uniform(self.delay_min * step_s, self.delay_max * step_s)
                    )
                    due = int(due_s // step_s)
                targets = [CoordinationTarget(event.event_id, "upvote", due, due_s)]
                self.stats["upvotes_scheduled"] += 1
                if self.rng.random() < self.comment_prob:
                    targets.append(CoordinationTarget(event.event_id, "comment", due, due_s))
                    self.stats["comments_scheduled"] += 1
                for target in targets:
                    if step_s is None:
                        agent.add_coordination_target(target)
                    scheduled.append((attacker_id, target))
        return scheduled
