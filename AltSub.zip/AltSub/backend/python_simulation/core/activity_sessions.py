#!/usr/bin/env python3
"""
Session length model shared by schedule generation (reddit_agent_initializer)
and runtime sessions (attacker campaign sessions), so both stay consistent.

Kept for existing imports; the model now lives in core/time_model.py together
with the event engine's durations.
"""

from .time_model import session_length_timesteps

__all__ = ["session_length_timesteps"]
