#!/usr/bin/env python3
"""
Feed System: Manage agent feeds and post ordering

Implements feed ordering logic similar to Social_Media_no_followers::update_feeds
with modular/swappable ordering strategies for testing different algorithms.

Time in the strategies is simulated seconds (state.event_time / state.now_s);
recency decay factors are per reference timestep (state.timestep_duration_seconds),
so both engines rank the same way.
"""

import logging
import math
import os
import random
from abc import ABC, abstractmethod
from typing import Dict, Iterable, List, Set, Optional
from .simulation_data import MediaEvent, EventType

log = logging.getLogger(__name__)


def _event_time(event: MediaEvent, state) -> float:
    if state is not None and hasattr(state, "event_time"):
        return state.event_time(event)
    return float(event.time_s if event.time_s is not None else event.timestamp)


def _step_s(state) -> float:
    return float(getattr(state, "timestep_duration_seconds", 300.0) or 300.0)


def _now_s(events: List[MediaEvent], state) -> float:
    """Current simulated time (falls back to the newest event for callers that
    don't maintain state.now_s)."""
    now = getattr(state, "now_s", None)
    if now is not None:
        return float(now)
    return max((_event_time(e, state) for e in events), default=0.0)


def _decayed_rank(base: float, recency: float) -> float:
    """Rank key combining a score with a recency factor in (0, 1]: positive
    scores shrink with age and negative ones grow more negative, so for any
    sign an older item ranks below a newer one with the same score."""
    return base * recency if base >= 0 else base / max(recency, 1e-300)


class FeedOrderingStrategy(ABC):
    """
    Abstract base class for feed ordering strategies.

    Allows swapping different algorithms to test which produces realistic behavior.
    """

    # Random stream for strategies with stochastic ordering (set by FeedManager)
    rng = None

    @abstractmethod
    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """
        Order a list of events for an agent's feed.

        Args:
            events: List of unread events to order
            agent_id: ID of the agent viewing the feed
            state: SimulationState for accessing event relationships
            max_items: Maximum number of items to return (None = all)

        Returns:
            Ordered list of events (most important/relevant first)
        """
        pass


class DefaultFeedOrderingStrategy(FeedOrderingStrategy):
    """
    Default feed ordering strategy matching Construct API behavior in its nofollower_social_media model.

    Feed ordering priority:
    1. Direct replies/mentions first
    2. Events from followed users (not implemented - no follow network)
    3. All other events
    4. Within each category: sort by score = child_size * time (in reference
       timesteps), newer first on ties
    5. 10% stochastic shuffling to avoid determinism
    """

    def __init__(self, shuffle_percentage: float = 0.1):
        """
        Initialize default ordering strategy.

        Args:
            shuffle_percentage: Percentage of feed items to randomly shuffle (0.0-1.0)
        """
        self.shuffle_percentage = shuffle_percentage

    def get_feed_priority(self, event: MediaEvent, user_id: int, state) -> int:
        """
        Calculate priority for feed ordering.

        Lower priority number = higher priority (shown first)

        Priority levels:
        0: Direct replies to user's posts
        1: Other events (all treated equally for now - no follow network)
        """
        if event.type == EventType.REPLY and event.parent_id is not None:
            parent = state.get_event(event.parent_id)
            if parent and parent.user_id == user_id:
                return 0  # High priority: reply to user's content

        return 1

    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """Order feed using default Construct API algorithm."""
        if not events:
            return []

        priority_groups: Dict[int, List[MediaEvent]] = {}
        for event in events:
            priority = self.get_feed_priority(event, agent_id, state)
            if priority not in priority_groups:
                priority_groups[priority] = []
            priority_groups[priority].append(event)

        step = _step_s(state)
        sorted_feed = []
        for priority in sorted(priority_groups.keys()):
            group = priority_groups[priority]
            # Score = child_size * time (higher = more recent/active); `replies`
            # holds child replies only, votes are not children
            group.sort(
                key=lambda e: (
                    (len(e.replies) + 1) * _event_time(e, state) / step,
                    _event_time(e, state),
                ),
                reverse=True,
            )
            sorted_feed.extend(group)

        if len(sorted_feed) > 1 and self.shuffle_percentage > 0:
            rng = self.rng
            n = len(sorted_feed)
            num_to_shuffle = min(n, max(1, int(n * self.shuffle_percentage)))
            if rng is not None:
                indices = sorted(int(i) for i in rng.choice(n, num_to_shuffle, replace=False))
                shuffled = [sorted_feed[i] for i in indices]
                order = rng.permutation(len(shuffled))
                shuffled = [shuffled[i] for i in order]
            else:
                indices = sorted(random.sample(range(n), num_to_shuffle))
                shuffled = [sorted_feed[i] for i in indices]
                random.shuffle(shuffled)
            # Put the shuffled items back into the selected positions
            for pos, event in zip(indices, shuffled):
                sorted_feed[pos] = event

        if max_items is not None:
            sorted_feed = sorted_feed[:max_items]

        return sorted_feed


class ChronologicalFeedOrderingStrategy(FeedOrderingStrategy):
    """
    Simple chronological ordering (newest first).

    Here as a simple baseline.
    """

    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """Order feed chronologically (newest first)."""
        sorted_events = sorted(events, key=lambda e: _event_time(e, state), reverse=True)

        if max_items is not None:
            sorted_events = sorted_events[:max_items]

        return sorted_events


class ScoreBasedFeedOrderingStrategy(FeedOrderingStrategy):
    """
    Order by score only (no priority grouping).

    Score = (upvotes - downvotes) * engagement_factor, aged by a recency factor
    (recency_decay per reference timestep of age). Positive scores decay
    towards zero and negative ones sink further with age; equal scores rank
    newest first.
    """

    def __init__(self, recency_decay: float = 0.95):
        """
        Initialize score-based ordering.

        Args:
            recency_decay: Decay factor for recency per reference timestep
                (0.0-1.0, higher = slower decay)
        """
        self.recency_decay = recency_decay

    def calculate_score(self, event: MediaEvent, age_steps: float) -> float:
        """Calculate score for an event."""
        vote_score = event.score  # upvotes - downvotes

        engagement_factor = 1.0 + len(event.replies) * 0.5

        recency_factor = self.recency_decay ** max(0.0, age_steps)

        return _decayed_rank(vote_score * engagement_factor, recency_factor)

    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """Order feed by calculated score."""
        now = _now_s(events, state)
        step = _step_s(state)

        scored_events = [
            (
                (
                    self.calculate_score(e, (now - _event_time(e, state)) / step),
                    _event_time(e, state),
                ),
                e,
            )
            for e in events
        ]
        scored_events.sort(key=lambda x: x[0], reverse=True)

        sorted_events = [e for _, e in scored_events]

        if max_items is not None:
            sorted_events = sorted_events[:max_items]

        return sorted_events


class EngagementWeightedFeedOrderingStrategy(FeedOrderingStrategy):
    """
    Order by engagement-weighted score with priority boost for replies.

    Similar to default but with more sophisticated scoring that weights
    different types of engagement differently.
    """

    def __init__(
        self,
        reply_priority_boost: float = 2.0,
        upvote_weight: float = 1.0,
        downvote_weight: float = -1.0,
        reply_weight: float = 0.5,
        recency_decay: float = 0.98,
    ):
        """
        Initialize engagement-weighted ordering.

        Args:
            reply_priority_boost: Multiplier for replies to user's content
            upvote_weight: Weight for upvotes
            downvote_weight: Weight for downvotes
            reply_weight: Weight for reply count
            recency_decay: Decay factor for recency per reference timestep
        """
        self.reply_priority_boost = reply_priority_boost
        self.upvote_weight = upvote_weight
        self.downvote_weight = downvote_weight
        self.reply_weight = reply_weight
        self.recency_decay = recency_decay

    def calculate_engagement_score(
        self, event: MediaEvent, agent_id: int, state, age_steps: float
    ) -> float:
        """Calculate engagement-weighted score."""
        upvotes = len(event.upvotes)
        downvotes = len(event.downvotes)
        replies = len(event.replies)

        engagement = (
            upvotes * self.upvote_weight
            + downvotes * self.downvote_weight
            + replies * self.reply_weight
        )

        recency = self.recency_decay ** max(0.0, age_steps)

        priority_multiplier = 1.0
        if event.type == EventType.REPLY and event.parent_id is not None:
            parent = state.get_event(event.parent_id)
            if parent and parent.user_id == agent_id:
                priority_multiplier = self.reply_priority_boost

        return _decayed_rank(engagement * priority_multiplier, recency)

    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """Order feed by engagement-weighted score."""
        now = _now_s(events, state)
        step = _step_s(state)

        scored_events = [
            (
                (
                    self.calculate_engagement_score(
                        e, agent_id, state, (now - _event_time(e, state)) / step
                    ),
                    _event_time(e, state),
                ),
                e,
            )
            for e in events
        ]
        scored_events.sort(key=lambda x: x[0], reverse=True)

        sorted_events = [e for _, e in scored_events]

        if max_items is not None:
            sorted_events = sorted_events[:max_items]

        return sorted_events


class RedditHotFeedOrderingStrategy(FeedOrderingStrategy):
    """
    Reddit's "hot" ranking algorithm from the open-source Reddit codebase.

    Based on: https://github.com/reddit-archive/reddit

    Formula:
        s = ups - downs
        order = log10(max(abs(s), 1))
        sign = 1 if s > 0 else -1 if s < 0 else 0
        seconds = timestamp - reddit_epoch
        hot_score = sign * order + seconds / 45000

    This algorithm balances score (upvotes - downvotes) with recency,
    ensuring that highly-scored posts stay visible longer while newer
    posts can still rise to the top.
    """

    def __init__(self, reddit_epoch: int = 1134028003, time_divisor: float = 45000.0):
        """
        Initialize Reddit hot ranking strategy.

        Args:
            reddit_epoch: Unix timestamp for Reddit's epoch (Dec 8, 2005)
                         Default: 1134028003 (unused: simulated time starts at 0)
            time_divisor: Time scaling factor (default: 45000, from Reddit's formula)
        """
        self.reddit_epoch = reddit_epoch
        self.time_divisor = time_divisor

    def calculate_hot_score(self, event: MediaEvent, event_time_s: float) -> float:
        """
        Calculate Reddit hot score for an event.

        Args:
            event: MediaEvent to score
            event_time_s: When the event was posted, in simulated seconds
                (relative epoch: simulation start = 0)

        Returns:
            Hot score (higher = hotter/more visible)
        """
        ups = len(event.upvotes)
        downs = len(event.downvotes)

        s = ups - downs

        order = math.log10(max(abs(s), 1))

        if s > 0:
            sign = 1
        elif s < 0:
            sign = -1
        else:
            sign = 0

        return sign * order + event_time_s / self.time_divisor

    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """
        Order feed using Reddit's hot algorithm.

        Note: For single-subreddit simulations, this works like r/<subreddit>/hot.
        For multi-subreddit, this would aggregate like r/all/hot.
        """
        if not events:
            return []

        scored_events = [
            (self.calculate_hot_score(e, _event_time(e, state)), e) for e in events
        ]
        scored_events.sort(key=lambda x: x[0], reverse=True)

        sorted_events = [e for _, e in scored_events]

        if max_items is not None:
            sorted_events = sorted_events[:max_items]

        return sorted_events


class RedditAllHotFeedOrderingStrategy(FeedOrderingStrategy):
    """
    Reddit's r/all hot feed algorithm.

    Aggregates posts from all subreddits and ranks them using the hot algorithm.
    In single-subreddit simulations, this behaves identically to RedditHotFeedOrderingStrategy.
    For multi-subreddit simulations, this aggregates across subreddits.

    Based on: https://github.com/reddit-archive/reddit
    """

    def __init__(self, reddit_epoch: int = 1134028003, time_divisor: float = 45000.0):
        """
        Initialize Reddit r/all hot ranking strategy.

        Args:
            reddit_epoch: Unix timestamp for Reddit's epoch (Dec 8, 2005)
            time_divisor: Time scaling factor (default: 45000)
        """
        self.hot_strategy = RedditHotFeedOrderingStrategy(reddit_epoch, time_divisor)

    def order_feed(
        self,
        events: List[MediaEvent],
        agent_id: int,
        state,
        max_items: Optional[int] = None,
    ) -> List[MediaEvent]:
        """
        Order feed using Reddit's r/all hot algorithm.

        For r/all, Reddit aggregates posts from all subreddits and applies hot ranking.
        In our single-subreddit simulation, this is equivalent to hot ranking.
        """
        # For now, single-subreddit simulation, so this is identical to hot
        return self.hot_strategy.order_feed(events, agent_id, state, max_items)


class FeedManager:
    """
    Manages per-agent feeds with swappable ordering strategies.

    The ordering strategy can be swapped to test different algorithms
    and see which produces realistic behavior.

    Each agent's feed holds only its unread items (read items are dropped when
    marked read), in arrival order, keyed by event_id.
    """

    def __init__(self, ordering_strategy: Optional[FeedOrderingStrategy] = None):
        """
        Initialize feed manager.

        Args:
            ordering_strategy: Strategy to use for ordering feeds.
                              Defaults to DefaultFeedOrderingStrategy if None.
        """
        self.users_feed: Dict[int, Dict[int, MediaEvent]] = {}
        self.read_events: Dict[int, Set[int]] = (
            {}
        )  # agent_id -> set of event_ids already read

        self.ordering_strategy = (
            ordering_strategy if ordering_strategy else DefaultFeedOrderingStrategy()
        )

    def set_rng(self, rng) -> None:
        """Random stream for stochastic ordering strategies (run seed)."""
        self.ordering_strategy.rng = rng

    def set_ordering_strategy(self, strategy: FeedOrderingStrategy) -> None:
        """
        Change the feed ordering strategy.

        Args:
            strategy: New ordering strategy to use
        """
        strategy.rng = self.ordering_strategy.rng
        self.ordering_strategy = strategy
        log.info(f"Feed ordering strategy changed to {type(strategy).__name__}")

    def initialize_agent(self, agent_id: int) -> None:
        """Initialize feed for an agent"""
        if agent_id not in self.users_feed:
            self.users_feed[agent_id] = {}
        if agent_id not in self.read_events:
            self.read_events[agent_id] = set()

    def remove_events_from_all_feeds(self, event_ids: Iterable[int]) -> None:
        """Remove events from every agent's queue (e.g. after moderation removal)."""
        ids = list(event_ids)
        if not ids:
            return
        for feed in self.users_feed.values():
            for event_id in ids:
                feed.pop(event_id, None)

    def remove_event_from_all_feeds(self, event_id: int) -> None:
        """Remove an event from every agent's queue (e.g. after moderation removal)."""
        self.remove_events_from_all_feeds([event_id])

    def purge_orphaned_feed_events(self, state) -> None:
        """Remove feed entries not present in state (removed posts/comments, ordering edge cases)."""
        if state is None:
            return
        valid = state.events_by_id
        for agent_id, feed in self.users_feed.items():
            stale = [eid for eid in feed if eid not in valid]
            for eid in stale:
                del feed[eid]

    def update_feeds(self, new_events: List[MediaEvent], state) -> None:
        """
        Add new events to all relevant feeds.

        Args:
            new_events: List of new events to add
            state: SimulationState containing all events and relationships
        """
        if os.environ.get("SIM_PROFILE_VERBOSE") == "1":
            try:
                import json
                import time
                from pathlib import Path
                _p = Path(os.environ["DEBUG_LOG_PATH"]) if os.environ.get("DEBUG_LOG_PATH") else Path(__file__).resolve().parent.parent.parent.parent / "profiling.log"
                _payload = {"sessionId": "977fa7", "location": "feed_system.py:update_feeds", "message": "update_feeds", "data": {"new_events_count": len(new_events), "num_agents": len(self.users_feed)}, "timestamp": int(time.time() * 1000), "hypothesisId": "C"}
                with open(_p, "a", encoding="utf-8") as _f:
                    _f.write(json.dumps(_payload) + "\n")
            except Exception:
                pass
        for event in new_events:
            # For now, single subreddit simulation, so add to all agents
            for agent_id, feed in self.users_feed.items():
                if event.event_id in self.read_events.get(agent_id, set()):
                    continue

                if event.user_id == agent_id:
                    continue

                feed[event.event_id] = event

    def get_feed(
        self, agent_id: int, max_items: Optional[int] = None, state=None
    ) -> List[MediaEvent]:
        """
        Get ordered feed for an agent using the configured ordering strategy.

        Args:
            agent_id: Agent ID
            max_items: Maximum number of items to return (None = all)
            state: SimulationState for calculating priorities

        Returns:
            Ordered list of events
        """
        if agent_id not in self.users_feed:
            return []

        # Unread items still present in global state
        unread = list(self.users_feed[agent_id].values())
        if state is not None:
            unread = [e for e in unread if state.get_event(e.event_id) is not None]

        if state and self.ordering_strategy:
            ordered = self.ordering_strategy.order_feed(
                unread, agent_id, state, max_items
            )
            return ordered
        else:
            # Fallback: no ordering, just limit items
            if max_items is not None:
                return unread[:max_items]
            return unread

    def mark_read(self, agent_id: int, event_id: int) -> None:
        """Mark an event as read by an agent"""
        if agent_id not in self.read_events:
            self.read_events[agent_id] = set()
        self.read_events[agent_id].add(event_id)
        feed = self.users_feed.get(agent_id)
        if feed is not None:
            feed.pop(event_id, None)

    def mark_read_multiple(self, agent_id: int, event_ids: List[int]) -> None:
        """Mark multiple events as read"""
        for event_id in event_ids:
            self.mark_read(agent_id, event_id)

    def clear_feed(self, agent_id: int) -> None:
        """Clear feed for an agent (but keep read tracking)"""
        if agent_id in self.users_feed:
            self.users_feed[agent_id] = {}

    def get_unread_count(self, agent_id: int) -> int:
        """Get count of unread items in feed"""
        return len(self.users_feed.get(agent_id, {}))
