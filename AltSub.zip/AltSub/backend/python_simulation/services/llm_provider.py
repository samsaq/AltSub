#!/usr/bin/env python3
"""
LLM Provider Abstraction Layer

This module provides a unified interface for calling different LLM providers
(OpenAI, Mistral, etc.) with automatic fallback and provider selection.
"""

import os
import logging
import threading
import time
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Dict, Any
from openai import OpenAI
from dotenv import load_dotenv

log = logging.getLogger(__name__)

# Look for .env in common locations:
# 1. Current directory
# 2. backend/python_simulation/
# 3. Simulation_Setups/ (for simulation runs)
_env_paths = [
    Path.cwd() / ".env",
    Path(__file__).parent.parent.parent / ".env",
    Path(__file__).parent.parent.parent.parent / "Simulation_Setups" / ".env",
]

for env_path in _env_paths:
    if env_path.exists():
        load_dotenv(env_path, override=False)  # Don't override existing env vars
        log.debug(f"Loaded .env from {env_path}")
        break
else:
    log.debug("No .env file found in common locations")

# Output-token ceiling per provider: retries that grow max_tokens stop here
# instead of requesting more than the model can return. LLM_MAX_OUTPUT_TOKENS overrides.
_DEFAULT_MAX_OUTPUT_TOKENS = {"openai": 16384, "mistral": 16384, "local": 4096}


@dataclass
class LLMResponse:
    content: str
    finish_reason: Optional[str]  # "length" means the reply was cut off at max_tokens


class LLMProvider:
    """Unified LLM provider interface supporting OpenAI, Mistral, and local endpoints"""

    def __init__(
        self,
        preferred_provider: Optional[str] = None,
        local_base_url: str = "http://localhost:11434/v1",
        local_model: str = "llama2",
        llm_rate_limit_qps: float = 0.0,
        max_concurrent_calls: int = 0,
    ):
        """
        Initialize LLM provider with automatic detection or explicit preference.

        Args:
            preferred_provider: "openai", "mistral", "local", or None for auto-detection
            local_base_url: Base URL for local OpenAI-compatible endpoint
            local_model: Model name for local endpoint
        """
        self.provider = None
        self.client = None
        self.model = None
        self.local_base_url = local_base_url
        self.local_model = local_model

        # Rate limiting / concurrency control
        self.llm_rate_limit_qps = float(llm_rate_limit_qps) if llm_rate_limit_qps else 0.0
        self.max_concurrent_calls = int(max_concurrent_calls) if max_concurrent_calls else 0
        self._rate_lock = threading.Lock()
        self._recent_call_times = deque()
        self._inflight_lock = threading.Lock()
        self._inflight_calls = 0

        if preferred_provider:
            self._init_provider(preferred_provider)
        else:
            # Auto-detect: try Mistral first, then OpenAI, then local
            if not self._init_provider("mistral"):
                if not self._init_provider("openai"):
                    self._init_provider("local")

        if not self.client:
            log.warning("No LLM provider available")

        # JSON mode (response_format json_object) is supported by OpenAI and
        # Mistral; local endpoints vary, so opt in with LLM_LOCAL_JSON_MODE=1.
        # Disabled automatically if the endpoint rejects it.
        self.supports_json_mode = self.provider in ("openai", "mistral") or (
            self.provider == "local"
            and os.getenv("LLM_LOCAL_JSON_MODE", "").strip().lower() in ("1", "true", "yes")
        )
        try:
            self.max_output_tokens = int(
                os.getenv("LLM_MAX_OUTPUT_TOKENS", "")
                or _DEFAULT_MAX_OUTPUT_TOKENS.get(self.provider, 4096)
            )
        except ValueError:
            self.max_output_tokens = _DEFAULT_MAX_OUTPUT_TOKENS.get(self.provider, 4096)

    def _init_provider(self, provider_name: str) -> bool:
        """
        Initialize a specific provider.

        Returns:
            True if successfully initialized, False otherwise
        """
        try:
            if provider_name == "openai":
                api_key = os.getenv("OPENAI_API_KEY")
                if api_key:
                    self.client = OpenAI(api_key=api_key)
                    self.provider = "openai"
                    self.model = "gpt-4o-mini"
                    log.info(f"Initialized OpenAI provider with model {self.model}")
                    return True

            elif provider_name == "mistral":
                api_key = os.getenv("MISTRAL_API_KEY")
                if api_key:
                    self.client = OpenAI(
                        api_key=api_key, base_url="https://api.mistral.ai/v1"
                    )
                    self.provider = "mistral"
                    env_model = os.getenv("LLM_MODEL")
                    self.model = (
                        env_model or "mistral-small-latest"
                    )
                    log.info(f"Initialized Mistral provider with model {self.model}")
                    return True

            elif provider_name == "local":
                # Local OpenAI-compatible endpoint (e.g., Ollama)
                self.client = OpenAI(
                    api_key="not-needed",  # Local endpoints often don't require auth
                    base_url=self.local_base_url,
                )
                self.provider = "local"
                self.model = self.local_model
                log.info(
                    f"Initialized local provider at {self.local_base_url} with model {self.model}"
                )
                return True

        except Exception as e:
            log.error(f"Failed to initialize {provider_name} provider: {e}")

        return False

    def is_available(self) -> bool:
        """Check if an LLM provider is available"""
        return self.client is not None

    def _acquire_rate_limit_slot(self) -> None:
        """Block until both QPS and max concurrency constraints allow a call."""
        # Concurrency limit
        while True:
            with self._inflight_lock:
                if self.max_concurrent_calls <= 0 or self._inflight_calls < self.max_concurrent_calls:
                    self._inflight_calls += 1
                    break
            time.sleep(0.01)

        # QPS limit
        if self.llm_rate_limit_qps > 0:
            while True:
                now = time.time()
                with self._rate_lock:
                    # Drop timestamps older than 1 second
                    cutoff = now - 1.0
                    while self._recent_call_times and self._recent_call_times[0] < cutoff:
                        self._recent_call_times.popleft()
                    if len(self._recent_call_times) < self.llm_rate_limit_qps:
                        self._recent_call_times.append(now)
                        break
                time.sleep(0.01)

    def _release_rate_limit_slot(self) -> None:
        with self._inflight_lock:
            if self._inflight_calls > 0:
                self._inflight_calls -= 1

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 500,
        **kwargs,
    ) -> Optional[str]:
        """
        Get chat completion from the LLM provider.

        Args:
            messages: List of message dicts with 'role' and 'content'
            temperature: Sampling temperature (0.0-1.0)
            max_tokens: Maximum tokens in response
            **kwargs: Additional provider-specific parameters

        Returns:
            Response content string, or None if request fails
        """
        response = self.chat_completion_meta(messages, temperature, max_tokens, **kwargs)
        return response.content if response else None

    def chat_completion_meta(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 500,
        **kwargs,
    ) -> Optional[LLMResponse]:
        """
        Like chat_completion, but also returns the finish_reason, so callers can
        tell a reply cut off at max_tokens ("length") from a malformed one.
        max_tokens is capped at max_output_tokens.
        """
        if not self.client:
            log.error("No LLM provider available")
            return None
        max_tokens = min(int(max_tokens), self.max_output_tokens)
        self._acquire_rate_limit_slot()

        try:
            try:
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kwargs,
                )
            except Exception as e:
                if "response_format" not in kwargs or "response_format" not in str(e):
                    raise
                # Endpoint rejected JSON mode: stop requesting it and retry once
                log.warning(
                    f"{self.provider} rejected response_format (JSON mode); "
                    f"disabling it for this provider: {e}"
                )
                self.supports_json_mode = False
                kwargs = {k: v for k, v in kwargs.items() if k != "response_format"}
                response = self.client.chat.completions.create(
                    model=self.model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    **kwargs,
                )

            if not response or not response.choices:
                log.warning(f"LLM response has no choices ({self.provider})")
                return None

            choice = response.choices[0]
            content = choice.message.content

            if content is None:
                log.warning(f"LLM response content is None ({self.provider})")
                return None

            if not content.strip():
                log.warning(f"LLM response content is empty ({self.provider})")
                return None

            return LLMResponse(content=content, finish_reason=getattr(choice, "finish_reason", None))

        except Exception as e:
            # Surface rate-limit-like issues explicitly in logs
            log.error(f"LLM request failed ({self.provider}): {e}")
            return None
        finally:
            self._release_rate_limit_slot()

    def get_provider_info(self) -> Dict[str, Any]:
        """Get information about the current provider"""
        return {
            "provider": self.provider,
            "model": self.model,
            "available": self.is_available(),
        }


_default_provider = None


def get_llm_provider(
    preferred_provider: Optional[str] = None,
    local_base_url: str = "http://localhost:11434/v1",
    local_model: str = "llama2",
) -> LLMProvider:
    """
    Get or create the default LLM provider instance.

    Args:
        preferred_provider: "openai", "mistral", "local", or None for auto-detection
        local_base_url: Base URL for local OpenAI-compatible endpoint
        local_model: Model name for local endpoint

    Returns:
        LLMProvider instance
    """
    global _default_provider

    # Read rate limiting config from environment so experiment_config.sh can control it
    try:
        llm_rate_limit_qps = float(os.getenv("LLM_RATE_LIMIT_QPS", "0"))
    except ValueError:
        llm_rate_limit_qps = 0.0

    try:
        max_concurrent_calls = int(os.getenv("LLM_MAX_CONCURRENCY", "0"))
    except ValueError:
        max_concurrent_calls = 0

    if _default_provider is None or preferred_provider:
        _default_provider = LLMProvider(
            preferred_provider,
            local_base_url,
            local_model,
            llm_rate_limit_qps=llm_rate_limit_qps,
            max_concurrent_calls=max_concurrent_calls,
        )
    return _default_provider


def chat_completion(
    messages: List[Dict[str, str]],
    temperature: float = 0.3,
    max_tokens: int = 500,
    preferred_provider: Optional[str] = None,
    **kwargs,
) -> Optional[str]:
    """
    Quick chat completion using the default provider.

    Args:
        messages: List of message dicts with 'role' and 'content'
        temperature: Sampling temperature (0.0-1.0)
        max_tokens: Maximum tokens in response
        preferred_provider: Force a specific provider for this call
        **kwargs: Additional provider-specific parameters

    Returns:
        Response content string, or None if request fails
    """
    provider = get_llm_provider(preferred_provider)
    return provider.chat_completion(messages, temperature, max_tokens, **kwargs)
