#!/usr/bin/env python3
"""
Belief Canonicalization Service: Real-time canonicalization of new beliefs

Provides real-time canonicalization of beliefs extracted during simulation,
mapping them to existing canonical beliefs or creating new canonical beliefs.
"""

import copy
import json
import hashlib
import logging
import threading
from pathlib import Path
from typing import Dict, List, Tuple, Optional
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_distances

from .belief_nli import BeliefNLI, get_belief_nli

log = logging.getLogger(__name__)

METADATA_FILENAME = "belief_clustering_metadata.json"
# Used instead when the output directory is the one holding the input metadata,
# so the setup's clustering file is never overwritten
SIMULATION_METADATA_FILENAME = "belief_clustering_metadata_simulation.json"


class BeliefCanonicalizer:
    """
    Real-time belief canonicalization service.
    
    Maintains a cache of canonical beliefs with embeddings and provides
    immediate canonicalization of new beliefs extracted during simulation.
    """

    def __init__(
        self,
        metadata_file: Optional[Path] = None,
        embedding_model: str = "all-MiniLM-L6-v2",
        similarity_threshold: float = 0.75,
        output_dir: Optional[Path] = None,
        nli: Optional[BeliefNLI] = None,
        max_nli_candidates: int = 3,
    ):
        """
        Initialize canonicalizer.

        Args:
            metadata_file: Path to belief_clustering_metadata.json
            embedding_model: Model name for sentence transformers
            similarity_threshold: Minimum similarity for a canonical belief to be a match candidate
            output_dir: Directory for updating metadata file
            nli: NLI checker deciding whether a candidate is the same belief
                (defaults to the shared cross-encoder)
            max_nli_candidates: Most-similar candidates checked with NLI per belief
        """
        self.embedding_model = embedding_model
        self.similarity_threshold = similarity_threshold
        self.output_dir = Path(output_dir) if output_dir else None
        self.metadata_file = Path(metadata_file) if metadata_file else None
        self.max_nli_candidates = max_nli_candidates

        self._embedder = SentenceTransformer(embedding_model)
        log.info(f"BeliefCanonicalizer: Loaded embedder {embedding_model}")

        # Embeddings can't tell "X" from "not X", so matches are confirmed with NLI
        self.nli = nli if nli is not None else get_belief_nli()
        
        self.canonical_beliefs: List[Dict[str, str]] = []  # [{belief_id, canonical_text}]
        self.canonical_embeddings: Optional[np.ndarray] = None
        self.canonical_texts: List[str] = []
        
        self._lock = threading.Lock()
        # Separate lock for the embedder: _embed is also called from outside
        # _lock (contradiction checks, consolidation) by several threads at once
        self._embed_lock = threading.Lock()
        
        self._new_beliefs_created: List[Dict] = []

        # Full input metadata (all original clusters and the real clustering
        # config); seeds the output metadata so it covers the initial beliefs too
        self._input_metadata: Optional[Dict] = None
        self._warned_same_path = False

        if metadata_file and metadata_file.exists():
            self._load_metadata(metadata_file)
        elif metadata_file:
            log.warning(f"Metadata file not found: {metadata_file}, starting with empty canonical beliefs")
        else:
            log.info("No metadata file provided, starting with empty canonical beliefs")

    def _load_metadata(self, metadata_file: Path) -> None:
        """Load canonical beliefs from metadata file"""
        try:
            with open(metadata_file, "r") as f:
                metadata = json.load(f)
            self._input_metadata = metadata

            cluster_details = metadata.get("cluster_details", [])
            for cluster in cluster_details:
                belief_id = cluster.get("belief_id")
                canonical_text = cluster.get("canonical_text", "")
                if belief_id and canonical_text:
                    self.canonical_beliefs.append({
                        "belief_id": belief_id,
                        "canonical_text": canonical_text,
                    })
                    self.canonical_texts.append(canonical_text)
            
            if self.canonical_texts:
                self.canonical_embeddings = self._embed(self.canonical_texts)
                log.info(
                    f"Loaded {len(self.canonical_beliefs)} canonical beliefs from metadata"
                )
            else:
                log.warning("No canonical beliefs found in metadata file")
                
        except Exception as e:
            log.error(f"Error loading metadata file {metadata_file}: {e}")
            log.warning("Starting with empty canonical beliefs")

    def _embed(self, texts: List[str]) -> np.ndarray:
        """Embed texts using sentence transformers"""
        if not texts:
            return np.array([])
        with self._embed_lock:
            embeddings = self._embedder.encode(texts, normalize_embeddings=True)
        return np.array(embeddings)

    def canonicalize_belief_text(
        self, belief_text: str, timestep: Optional[int] = None
    ) -> Tuple[str, str]:
        """
        Canonicalize a belief text to a canonical ID.
        
        Args:
            belief_text: Human-readable belief text
            timestep: Optional timestep when belief was created (for tracking)
            
        Returns:
            Tuple of (canonical_id, canonical_text)
            - If similar to existing: returns existing canonical_id and canonical_text
            - If new: returns new canonical_id (SHA1 hash) and canonical_text (same as input)
        """
        with self._lock:
            if not self.canonical_beliefs:
                canonical_id = hashlib.sha1(belief_text.encode("utf-8")).hexdigest()[:16]
                canonical_text = belief_text
                
                self.canonical_beliefs.append({
                    "belief_id": canonical_id,
                    "canonical_text": canonical_text,
                })
                self.canonical_texts.append(canonical_text)
                self.canonical_embeddings = self._embed([canonical_text])
                
                self._new_beliefs_created.append({
                    "belief_id": canonical_id,
                    "canonical_text": canonical_text,
                    "timestep": timestep,
                    "action": "created_new_canonical",
                })
                
                log.debug(f"Created first canonical belief: {canonical_id[:8]}... = {canonical_text[:50]}...")
                return canonical_id, canonical_text
            
            new_embedding = self._embed([belief_text])[0:1]
            
            similarities = 1 - cosine_distances(new_embedding, self.canonical_embeddings)[0]
            best_similarity = float(np.max(similarities))

            # Similar candidates, most similar first; the first one NLI accepts
            # as the same belief (never a contradiction) is the match
            candidates = [
                int(i)
                for i in np.argsort(-similarities)[: self.max_nli_candidates]
                if similarities[i] >= self.similarity_threshold
            ]
            match_idx = None
            if candidates:
                same = self.nli.same_belief_many(
                    [(belief_text, self.canonical_texts[i]) for i in candidates],
                    [similarities[i] for i in candidates],
                )
                match_idx = next((i for i, ok in zip(candidates, same) if ok), None)

            if match_idx is not None:
                existing_belief = self.canonical_beliefs[match_idx]
                canonical_id = existing_belief["belief_id"]
                canonical_text = existing_belief["canonical_text"]

                log.debug(
                    f"Mapped belief '{belief_text[:50]}...' to existing canonical "
                    f"{canonical_id[:8]}... (similarity: {similarities[match_idx]:.3f})"
                )
                return canonical_id, canonical_text
            else:
                canonical_id = hashlib.sha1(belief_text.encode("utf-8")).hexdigest()[:16]
                canonical_text = belief_text
                
                self.canonical_beliefs.append({
                    "belief_id": canonical_id,
                    "canonical_text": canonical_text,
                })
                self.canonical_texts.append(canonical_text)
                
                self.canonical_embeddings = np.vstack(
                    [self.canonical_embeddings, new_embedding]
                )
                
                self._new_beliefs_created.append({
                    "belief_id": canonical_id,
                    "canonical_text": canonical_text,
                    "timestep": timestep,
                    "similarity": best_similarity,
                    "nli_rejected_candidates": len(candidates),
                    "action": "created_new_canonical",
                })

                log.info(
                    f"Created new canonical belief: {canonical_id[:8]}... = {canonical_text[:50]}... "
                    f"(best similarity: {best_similarity:.3f}, NLI-rejected candidates: {len(candidates)})"
                )
                return canonical_id, canonical_text

    def _output_metadata_path(self) -> Path:
        """Where run metadata is written: output_dir/belief_clustering_metadata.json,
        or a distinct name when that is the input metadata file itself."""
        path = self.output_dir / METADATA_FILENAME
        if self.metadata_file and path.resolve() == self.metadata_file.resolve():
            path = self.output_dir / SIMULATION_METADATA_FILENAME
            if not self._warned_same_path:
                log.warning(
                    f"Output directory holds the input metadata {self.metadata_file}; "
                    f"writing run metadata to {path} instead so the input is not overwritten"
                )
                self._warned_same_path = True
        return path

    def _read_output_metadata(self, metadata_file: Path) -> Dict:
        """Load the run metadata file, or seed it from the full input metadata
        (all original clusters + real config). Original clusters missing from an
        existing file (e.g. one written before seeding existed) are added back."""
        original = (self._input_metadata or {}).get("cluster_details", [])
        if metadata_file.exists():
            with open(metadata_file, "r") as f:
                metadata = json.load(f)
            existing_ids = {c.get("belief_id") for c in metadata.get("cluster_details", [])}
            missing = [c for c in original if c.get("belief_id") not in existing_ids]
            if missing:
                metadata["cluster_details"] = copy.deepcopy(missing) + metadata.get("cluster_details", [])
                log.info(f"Restored {len(missing)} original clusters missing from {metadata_file}")
            return metadata

        if self._input_metadata:
            metadata = copy.deepcopy(self._input_metadata)
            metadata.setdefault("cluster_details", [])
            metadata.setdefault("config", {})
            metadata.setdefault("summary", {})
            return metadata

        return {
            "config": {
                "embedding_model": self.embedding_model,
                "cluster_threshold": 0.18,
                "num_original_beliefs": 0,
                "num_canonical_beliefs": 0,
                "reduction_ratio": 0.0,
            },
            "cluster_details": [],
            "closest_canonical_pairs": [],
            "summary": {
                "singleton_clusters": 0,
                "multi_member_clusters": 0,
                "largest_cluster_size": 0,
                "avg_intra_similarity": None,
            },
        }

    def add_to_metadata(
        self, belief_id: str, canonical_text: str, timestep: Optional[int] = None
    ) -> None:
        """
        Add a new canonical belief to the metadata file.
        
        This method updates belief_clustering_metadata.json incrementally.
        
        Args:
            belief_id: Canonical belief ID
            canonical_text: Canonical belief text
            timestep: Optional timestep when created
        """
        if not self.output_dir:
            log.warning("No output directory set, cannot update metadata file")
            return
        
        with self._lock:
            try:
                metadata_file = self._output_metadata_path()
                # Load existing metadata or seed it from the input metadata
                metadata = self._read_output_metadata(metadata_file)

                existing_ids = {c.get("belief_id") for c in metadata.get("cluster_details", [])}
                if belief_id in existing_ids:
                    log.debug(f"Belief {belief_id[:8]}... already in metadata, skipping")
                    return
                
                new_cluster = {
                    "belief_id": belief_id,
                    "canonical_text": canonical_text,
                    "cluster_size": 1,
                    "member_texts": [canonical_text],
                    "intra_cluster_similarity": None,
                    "created_during_simulation": True,
                    "first_seen_timestep": timestep,
                }
                
                metadata["cluster_details"].append(new_cluster)
                
                metadata["config"]["num_canonical_beliefs"] = len(metadata["cluster_details"])
                
                metadata["summary"]["singleton_clusters"] = sum(
                    1 for c in metadata["cluster_details"] if c.get("cluster_size") == 1
                )
                
                with open(metadata_file, "w") as f:
                    json.dump(metadata, f, indent=2)
                
                log.debug(f"Added belief {belief_id[:8]}... to metadata file")
                
            except Exception as e:
                log.error(f"Error updating metadata file: {e}")

    def batch_update_metadata(self) -> None:
        """
        Batch update metadata file with all new beliefs created during simulation.
        
        This is more efficient than updating on every belief creation.
        Call this periodically (e.g., at end of each day) or at simulation end.
        """
        if not self._new_beliefs_created:
            return
        
        if not self.output_dir:
            log.warning("No output directory set, cannot update metadata file")
            return
        
        with self._lock:
            try:
                metadata_file = self._output_metadata_path()
                # Load existing metadata or seed it from the input metadata
                metadata = self._read_output_metadata(metadata_file)
                
                existing_ids = {c.get("belief_id") for c in metadata.get("cluster_details", [])}
                
                added_count = 0
                for new_belief in self._new_beliefs_created:
                    belief_id = new_belief["belief_id"]
                    if belief_id not in existing_ids:
                        new_cluster = {
                            "belief_id": belief_id,
                            "canonical_text": new_belief["canonical_text"],
                            "cluster_size": 1,
                            "member_texts": [new_belief["canonical_text"]],
                            "intra_cluster_similarity": None,
                            "created_during_simulation": True,
                            "first_seen_timestep": new_belief.get("timestep"),
                        }
                        metadata["cluster_details"].append(new_cluster)
                        existing_ids.add(belief_id)
                        added_count += 1
                
                if added_count > 0:
                    metadata["config"]["num_canonical_beliefs"] = len(metadata["cluster_details"])
                    
                    metadata["summary"]["singleton_clusters"] = sum(
                        1 for c in metadata["cluster_details"] if c.get("cluster_size") == 1
                    )
                    
                    with open(metadata_file, "w") as f:
                        json.dump(metadata, f, indent=2)
                    
                    log.info(f"Batch updated metadata with {added_count} new beliefs")
                    self._new_beliefs_created.clear()
                else:
                    log.debug("No new beliefs to add to metadata")
                    
            except Exception as e:
                log.error(f"Error batch updating metadata file: {e}")

    def get_canonical_text(self, belief_id: str) -> Optional[str]:
        """Get canonical text for a belief ID"""
        for belief in self.canonical_beliefs:
            if belief["belief_id"] == belief_id:
                return belief["canonical_text"]
        return None

