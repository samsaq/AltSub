"""Online Services for simulation: LLM service and campaign orchestrator"""

# These can be imported directly or used as Flask services
from .llm_reddit_service import LLMRedditService, LLMServiceConfig
from .llm_provider import LLMProvider, get_llm_provider

try:
    from .attacker_campaign_orchestrator import (
        AttackerCampaignOrchestrator,
        CampaignConfig,
        CampaignObjective,
        DailyCampaignPlan,
        CampaignMetrics,
    )
except ImportError:
    # Optional dependency
    AttackerCampaignOrchestrator = None
    CampaignConfig = None
    CampaignObjective = None
    DailyCampaignPlan = None
    CampaignMetrics = None

__all__ = [
    "LLMRedditService",
    "LLMServiceConfig",
    "LLMProvider",
    "get_llm_provider",
    "AttackerCampaignOrchestrator",
    "CampaignConfig",
    "CampaignObjective",
    "DailyCampaignPlan",
    "CampaignMetrics",
]
