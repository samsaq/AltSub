#!/usr/bin/env python3
"""
Attacker Campaign Orchestrator for Reddit Simulation

This module provides the orchestrator that manages attacker campaigns by:
1. Analyzing daily discourse to understand current narrative landscape
2. Planning daily attack strategies based on campaign objectives
3. Coordinating with attacker agents to execute campaigns
4. Evaluating campaign effectiveness and adjusting strategies

run_simulation.py uses it in-process; it can also run as a standalone Flask
service.
"""

import json
import logging
import time
import os
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Tuple, Optional, Any
from enum import Enum
import numpy as np
from datetime import datetime, timedelta
from .llm_provider import get_llm_provider
from .llm_json import complete_json, hour_of_day, require_unit_floats, unit_float


log = logging.getLogger(__name__)


class CampaignObjective(Enum):
    """Campaign objectives - high-level strategy"""

    AMPLIFY_NARRATIVE = "amplify_narrative"  # Boost and promote a specific narrative
    DISRUPT_DISCOURSE = "disrupt_discourse"  # Counter and prevent a specific narrative


def _is_attacker(item: Dict[str, Any]) -> bool:
    """Whether a stored post/comment was written by an attacker. author_type is
    the agent type ("llm_attacker", "template_attacker", "llm_user", ...), so a
    plain == "attacker" check never matches."""
    return str(item.get("author_type", "")).endswith("attacker")


@dataclass
class CampaignConfig:
    """Configuration for an attacker campaign"""

    objective: CampaignObjective
    target_narrative: str  # The narrative to amplify or disrupt
    target_subreddit: str = "politics"  # The subreddit being targeted
    coordination_strength: float = (
        0.5  # 0.0-1.0: How much attackers support each other (upvotes, comments, similar posts)
    )
    intensity: float = 0.5  # 0.0-1.0: How direct and forceful the attacks are
    daily_post_target: int = 5  # Target number of posts per day


@dataclass
class DailyCampaignPlan:
    """Plan for a single day's campaign activities"""

    date: str
    target_posts: List[
        Dict[str, Any]
    ]  # Posts to be created (content guidance and timing)
    expected_outcomes: Dict[str, float]  # Expected metrics (sentiment_alignment)
    risk_assessment: float  # 0.0 to 1.0, risk of detection
    # How the plan was obtained: LLM parse status ("ok" / "repaired" / "retried")
    # or "fallback" (LLM planning failed; a minimal 1-post plan was used)
    source: str = "ok"
    fallback_reason: str = ""


def _validate_campaign_plan(data: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], str]:
    """Clean an LLM campaign plan: keep posts with non-empty content and hours
    0-23 (accepting "6", "06:00", "6am"); drop invalid posts individually."""
    posts = data.get("target_posts")
    if not isinstance(posts, list) or not posts:
        return None, '"target_posts" must be a non-empty list'
    clean, dropped = [], 0
    for post in posts:
        content = post.get("content") if isinstance(post, dict) else None
        start = hour_of_day(post.get("start_hour", 0)) if isinstance(post, dict) else None
        end = hour_of_day(post.get("end_hour", 23)) if isinstance(post, dict) else None
        if not isinstance(content, str) or not content.strip() or start is None or end is None:
            dropped += 1
            continue
        if end < start:
            start, end = end, start
        clean.append({"content": content.strip(), "start_hour": start, "end_hour": end})
    if not clean:
        return None, (
            "no valid posts in target_posts (each needs non-empty content and "
            "start_hour/end_hour between 0 and 23)"
        )
    if dropped:
        log.warning(f"Campaign plan: dropped {dropped} invalid post(s), kept {len(clean)}")

    out = dict(data)
    out["target_posts"] = clean
    risk = unit_float(data.get("risk_assessment", 0.5))
    out["risk_assessment"] = 0.5 if risk is None else risk
    outcomes = data.get("expected_outcomes")
    alignment = unit_float(outcomes.get("sentiment_alignment")) if isinstance(outcomes, dict) else None
    out["expected_outcomes"] = {"sentiment_alignment": 0.5 if alignment is None else alignment}
    return out, ""


@dataclass
class CampaignMetrics:
    """Metrics for evaluating campaign effectiveness"""

    sentiment_alignment: float = 0.0  # Alignment with target narrative (0-1)
    detection_risk: float = 0.0
    overall_effectiveness: float = 0.0


@dataclass
class CampaignInstruction:
    """Instruction for an attacker agent to execute"""

    content: str  # Post content or guidance text
    start_timestep: int  # When instruction becomes active
    end_timestep: int  # Last timestep of the window (inclusive)
    priority: float = 1.0  # Priority (0.0-1.0)
    template_id: Optional[str] = None  # For template attackers (optional)
    executed: bool = False  # Set True after agent posts once (prevents posting every timestep in window)
    execute_timestep: Optional[int] = None  # Chosen by the agent within the window (see AttackerActivityMixin)
    # The same window in simulated seconds, [start_s, end_s) (event engine)
    start_s: Optional[float] = None
    end_s: Optional[float] = None
    execute_time_s: Optional[float] = None  # Chosen by the event engine at delivery


class AttackerCampaignOrchestrator:
    """Main orchestrator class for managing attacker campaigns"""

    def __init__(
        self,
        config: CampaignConfig,
        llm_service_url: str = "http://localhost:5000",
        output_dir: str = "simulation_output",
    ):
        self.config = config
        self.llm_service_url = llm_service_url
        self.output_dir = output_dir
        self.snapshots_dir = os.path.join(output_dir, "daily_snapshots")
        self.daily_plans: List[DailyCampaignPlan] = []
        self.campaign_metrics: List[CampaignMetrics] = []
        self.attacker_agents: List[int] = []

        self.current_day = 0
        self.campaign_start_time = None
        self.last_evaluation_time = None

        self.simulation_data_by_day: Dict[int, Dict[str, Any]] = {}

        # Planning provider override (stub runs); None = get_llm_provider()
        self.llm_provider: Optional[Any] = None
        # Random stream for instruction assignment (seeded by the run)
        self.rng: np.random.Generator = np.random.default_rng()

    def register_attacker_agents(self, agent_ids: List[int]):
        """Register the agent IDs that are part of this campaign"""
        self.attacker_agents = agent_ids
        log.info(f"Registered {len(agent_ids)} attacker agents: {agent_ids}")

    def distribute_instructions_to_agents(
        self,
        plan: DailyCampaignPlan,
        agent_manager: Any,
        timesteps_per_day: int,
        current_day: int,
        deliver: Optional[Any] = None,
    ) -> None:
        """
        Convert DailyCampaignPlan.target_posts to CampaignInstruction objects
        and assign them to attacker agents.

        Args:
            plan: DailyCampaignPlan with target_posts
            agent_manager: AgentManager instance
            timesteps_per_day: Number of timesteps per day
            current_day: Current day (0-indexed)
            deliver: deliver(agent, instruction) hands an instruction to an agent;
                defaults to agent.add_instruction (the event engine passes its own)
        """
        if not self.attacker_agents:
            log.warning("No attacker agents registered, cannot distribute instructions")
            return

        # Get only LLM attacker agents (template attackers don't use orchestrator)
        llm_attacker_ids = [
            agent_id
            for agent_id in self.attacker_agents
            if agent_id in agent_manager.agents
            and agent_manager.agents[agent_id].agent_type == "llm_attacker"
        ]

        if not llm_attacker_ids:
            log.warning("No LLM attacker agents found, cannot distribute instructions")
            return

        # Skip banned attackers so their instructions go to agents that can still post
        llm_attacker_ids = [
            agent_id
            for agent_id in llm_attacker_ids
            if not agent_manager.agents[agent_id].is_banned(agent_manager.state)
        ]

        if not llm_attacker_ids:
            log.warning(
                "All LLM attacker agents are banned, cannot distribute instructions"
            )
            return

        day_start_timestep = current_day * timesteps_per_day

        instructions = []
        for target_post in plan.target_posts:
            content = target_post.get("content", "")
            start_hour = target_post.get("start_hour", 0)
            end_hour = target_post.get("end_hour", 23)

            # Hours to timesteps. The window covers end_hour itself (it ends at
            # the last timestep of that hour), so a 23:00 end reaches the day's end.
            timesteps_per_hour = timesteps_per_day / 24
            start_timestep = day_start_timestep + int(start_hour * timesteps_per_hour)
            end_timestep = max(
                start_timestep,
                day_start_timestep + int((end_hour + 1) * timesteps_per_hour) - 1,
            )

            instruction = CampaignInstruction(
                content=content,
                start_timestep=start_timestep,
                end_timestep=end_timestep,
                priority=1.0,
                start_s=current_day * 86400.0 + start_hour * 3600.0,
                end_s=current_day * 86400.0 + (end_hour + 1) * 3600.0,
            )
            instructions.append(instruction)

        def _deliver(agent, instruction):
            if deliver is not None:
                deliver(agent, instruction)
            else:
                agent.add_instruction(instruction)

        def _assign_instructions_to_agents(
            instructions, llm_attacker_ids, agent_manager, random_assignment=True
        ):
            if random_assignment:
                for instruction in instructions:
                    agent_id = llm_attacker_ids[self.rng.integers(len(llm_attacker_ids))]
                    agent = agent_manager.agents[agent_id]

                    if hasattr(agent, "pending_instructions"):
                        _deliver(agent, instruction)
                        log.debug(
                            f"Randomly distributed instruction to agent {agent_id}: "
                            f"timesteps {instruction.start_timestep}-{instruction.end_timestep}"
                        )
                    else:
                        log.warning(
                            f"Agent {agent_id} does not have pending_instructions attribute"
                        )
            else:
                # Distribute instructions evenly across agents (round-robin)
                for idx, instruction in enumerate(instructions):
                    agent_id = llm_attacker_ids[idx % len(llm_attacker_ids)]
                    agent = agent_manager.agents[agent_id]

                    if hasattr(agent, "pending_instructions"):
                        _deliver(agent, instruction)
                        log.debug(
                            f"Distributed instruction to agent {agent_id}: "
                            f"timesteps {instruction.start_timestep}-{instruction.end_timestep}"
                        )
                    else:
                        log.warning(
                            f"Agent {agent_id} does not have pending_instructions attribute"
                        )

        _assign_instructions_to_agents(
            instructions, llm_attacker_ids, agent_manager, random_assignment=False
        )

        log.info(
            f"Distributed {len(instructions)} instructions to {len(llm_attacker_ids)} LLM attacker agents"
        )

    def store_simulation_data(self, day: int, data: Dict[str, Any]):
        """Store simulation data for a specific day"""
        self.simulation_data_by_day[day] = data
        log.info(
            f"Stored simulation data for day {day}: {len(data.get('posts', []))} posts, {len(data.get('comments', []))} comments"
        )

    def get_simulation_data(self, day: int) -> Dict[str, Any]:
        """Retrieve stored simulation data for a specific day"""
        return self.simulation_data_by_day.get(day, {})

    def plan_daily_campaign(self, day: int) -> DailyCampaignPlan:
        """Plan the campaign activities for a specific day"""
        try:
            # Get previous day's simulation data for context. For day 0 this is
            # day -1: real subreddit discussion seeded at startup, if available.
            prev_day_data = self.get_simulation_data(day - 1)

            strategy_prompt = self._build_strategy_prompt(day, prev_day_data)

            llm = self.llm_provider or get_llm_provider()
            if not llm.is_available():
                log.error("No LLM provider available, using fallback plan")
                return self._create_fallback_plan(day, reason="no LLM provider")

            result = complete_json(
                llm,
                [
                    {
                        "role": "system",
                        "content": "You are a covert influence campaign strategist. Return ONLY valid JSON. Do NOT include comments (# or //), explanations, or markdown formatting.",
                    },
                    {"role": "user", "content": strategy_prompt},
                ],
                temperature=0.5,
                max_tokens=10000,
                validate=_validate_campaign_plan,
                label=f"Campaign plan day {day}",
            )
            if not result.ok:
                log.error(
                    f"Campaign planning for day {day} failed ({result.error}); "
                    f"using fallback plan. Raw reply: {result.raw[:500]!r}"
                )
                return self._create_fallback_plan(day, reason=result.error)

            plan_data = result.data
            daily_plan = DailyCampaignPlan(
                date=f"day_{day}",
                target_posts=plan_data["target_posts"],
                expected_outcomes=plan_data.get(
                    "expected_outcomes", {"sentiment_alignment": 0.5}
                ),
                risk_assessment=plan_data.get("risk_assessment", 0.5),
                source=result.status,
            )
            self.daily_plans.append(daily_plan)
            log.info(
                f"Created daily campaign plan for day {day} with LLM "
                f"({len(daily_plan.target_posts)} posts, parse status: {result.status})"
            )
            return daily_plan

        except Exception as e:
            log.error(f"Daily campaign planning failed: {e}")
            return self._create_fallback_plan(day, reason=str(e))

    def _format_posts_with_comments(
        self,
        posts: List[Dict],
        comments: List[Dict],
        num_posts: int = 10,
        comments_per_post: int = 5,
    ) -> str:
        """Format sample posts with their related comments for LLM context"""
        if not posts:
            return "No previous posts available."

        sorted_posts = sorted(posts, key=lambda p: p.get("score", 0), reverse=True)
        sample_posts = sorted_posts[:num_posts]

        formatted_output = []
        for post in sample_posts:
            post_id = post.get("event_id")

            related_comments = [c for c in comments if c.get("root_post_id") == post_id]

            sorted_comments = sorted(
                related_comments,
                key=lambda c: c.get("score", 0),
                reverse=True,
            )[:comments_per_post]

            post_text = f"POST (score: {post.get('score', 0)}, by {post.get('author_type', 'regular')} user):\n"
            post_text += f"  Content: {post.get('content', 'N/A')}\n"

            if sorted_comments:
                post_text += f"  Comments ({len(sorted_comments)}):\n"
                for comment in sorted_comments:
                    post_text += f"    - (score: {comment.get('score', 0)}, by {comment.get('author_type', 'regular')} user): "
                    post_text += f"{comment.get('content', 'N/A')}\n"
            else:
                post_text += "  Comments: None\n"

            formatted_output.append(post_text)

        return "\n".join(formatted_output)

    def _build_strategy_prompt(self, day: int, simulation_data: Dict[str, Any]) -> str:
        """Build the LLM prompt for strategy planning"""
        posts = simulation_data.get("posts", [])
        comments = simulation_data.get("comments", [])

        organic_posts = [p for p in posts if not _is_attacker(p)]
        organic_comments = [c for c in comments if not _is_attacker(c)]

        subreddit_context = self._format_posts_with_comments(
            organic_posts, organic_comments, num_posts=10, comments_per_post=5
        )

        return f"""
        You are an attacker campaign orchestrator planning day {day} of a campaign.
        
        Campaign Objective: {self.config.objective.value}
        Target Narrative: {self.config.target_narrative}
        Intensity: {self.config.intensity} (how direct and forceful the approach is)
        Target Subreddit: {self.config.target_subreddit}
        
        Previous Day Context from r/{self.config.target_subreddit}:
        {subreddit_context}

Campaign Techniques (used together):
- Coordinated posting (similar content across multiple accounts)
- Coordinated voting (supporting each other's content)
- Coordinated commenting (amplifying messages)
- Strategic timing

Your Task:
Generate {self.config.daily_post_target} posts that will fulfill the campaign objective regarding the narrative: "{self.config.target_narrative}".

Guidelines:
- Intensity {self.config.intensity}: 
  * Low (0.0-0.3): Subtle, blend in with organic content
  * Medium (0.4-0.7): Clear stance but measured tone
  * High (0.8-1.0): Direct, forceful advocacy
- Match the style/tone of the subreddit based on the examples above
- Posts should feel organic and contextual to recent discussions

Expected Outcomes:
- Sentiment alignment: How well do you expect the community to align with the target narrative after these posts? (0.0-1.0)
- Risk assessment: How detectable is this coordination likely to be? (0.0-1.0)

Return ONLY valid JSON with this structure:
{{
    "target_posts": [
        {{
            "content": "Full post content text here",
            "start_hour": 6,
            "end_hour": 9
        }}
    ],
    "expected_outcomes": {{
        "sentiment_alignment": 0.5
    }},
    "risk_assessment": 0.3
}}

Generate exactly {self.config.daily_post_target} posts.
"""

    def _create_fallback_plan(self, day: int, reason: str = "") -> DailyCampaignPlan:
        """Create a fallback plan if LLM planning fails. Recorded in daily_plans
        with source="fallback" so a cut-down campaign day is visible."""
        log.warning(
            f"Day {day}: using FALLBACK campaign plan (1 generic post instead of "
            f"{self.config.daily_post_target}). Reason: {reason or 'unknown'}"
        )
        plan = DailyCampaignPlan(
            date=f"day_{day}",
            target_posts=[
                {
                    "content": f"Support campaign narrative: {self.config.target_narrative}",
                    "start_hour": 6,
                    "end_hour": 9,
                }
            ],
            expected_outcomes={
                "sentiment_alignment": 0.5,
            },
            risk_assessment=0.3,
            source="fallback",
            fallback_reason=reason,
        )
        self.daily_plans.append(plan)
        return plan

    def execute_daily_plan(
        self, plan: DailyCampaignPlan, simulation_interface
    ) -> Dict[str, Any]:
        """Execute the daily campaign plan by coordinating with attacker agents"""
        execution_results = {
            "posts_created": 0,
            "success_rate": 0.0,
            "errors": [],
        }

        try:

            execution_results["posts_created"] = len(plan.target_posts)
            execution_results["success_rate"] = (
                1.0
            )

            log.info(f"Daily plan prepared: {execution_results}")
            return execution_results

        except Exception as e:
            log.error(f"Daily plan preparation failed: {e}")
            execution_results["errors"].append(str(e))
            return execution_results

    def evaluate_campaign_effectiveness(
        self,
        day: int,
        execution_results: Dict[str, Any],
        simulation_data: Dict[str, Any],
    ) -> CampaignMetrics:
        """Evaluate the effectiveness of the day's campaign"""
        try:
            sentiment_alignment = self._analyze_sentiment_alignment(
                simulation_data, day
            )
            detection_risk = self._analyze_detection_risk(
                simulation_data, execution_results, day
            )

            # Calculate overall effectiveness (sentiment weighted heavily, penalized by risk)
            overall_effectiveness = sentiment_alignment * (1.0 - detection_risk)

            metrics = CampaignMetrics(
                sentiment_alignment=sentiment_alignment,
                detection_risk=detection_risk,
                overall_effectiveness=overall_effectiveness,
            )

            self.campaign_metrics.append(metrics)
            log.info(f"Campaign metrics for day {day}: {metrics}")
            return metrics

        except Exception as e:
            log.error(f"Campaign evaluation failed: {e}")
            return CampaignMetrics()

    def _analyze_sentiment_alignment(
        self, simulation_data: Dict[str, Any], day: int
    ) -> float:
        """Use LLM to analyze sentiment alignment with target narrative from actual discourse"""
        try:
            posts = simulation_data.get("posts", [])
            comments = simulation_data.get("comments", [])

            if not posts and not comments:
                log.warning(f"No discourse data for day {day}, using neutral sentiment")
                return 0.5

            sample_posts = posts[:20] if len(posts) > 20 else posts
            sample_comments = comments[:30] if len(comments) > 30 else comments

            analysis_prompt = f"""
Analyze the sentiment in this social media discourse toward the following narrative:

Target Narrative: "{self.config.target_narrative}"

Posts from day {day} ({len(sample_posts)} posts):
{json.dumps(sample_posts, indent=2)}

Comments from day {day} ({len(sample_comments)} comments):
{json.dumps(sample_comments[:15], indent=2)}

Total activity: {len(posts)} posts, {len(comments)} comments

Evaluate sentiment alignment with the target narrative on a scale from 0.0 to 1.0:
- 0.0 = Community sentiment is strongly opposed to the narrative
- 0.5 = Neutral or mixed sentiment
- 1.0 = Community sentiment strongly aligns with the narrative

Return ONLY a JSON object:
{{
    "sentiment_alignment": <float 0.0-1.0>,
    "reasoning": "<brief explanation of sentiment observed>"
}}
"""

            llm = self.llm_provider or get_llm_provider()
            if not llm.is_available():
                log.error("No LLM provider available, using neutral sentiment")
                return 0.5

            result = complete_json(
                llm,
                [
                    {
                        "role": "system",
                        "content": "You are a sentiment analyst. Return ONLY valid JSON. Do NOT include comments (# or //), explanations, or markdown formatting.",
                    },
                    {"role": "user", "content": analysis_prompt},
                ],
                temperature=0.3,
                max_tokens=600,
                validate=require_unit_floats("sentiment_alignment"),
                label=f"Sentiment analysis day {day}",
            )
            if not result.ok:
                log.error(
                    f"Sentiment analysis for day {day} failed ({result.error}), using neutral sentiment"
                )
                return 0.5
            value = result.data["sentiment_alignment"]
            log.info(
                f"Sentiment alignment for day {day}: {value:.2f} - {result.data.get('reasoning', 'N/A')}"
            )
            return value

        except Exception as e:
            log.error(f"Sentiment alignment analysis failed: {e}")
            return 0.5  # Neutral fallback

    def _analyze_detection_risk(
        self,
        simulation_data: Dict[str, Any],
        execution_results: Dict[str, Any],
        day: int,
    ) -> float:
        """Use LLM to analyze detection risk from attacker activity patterns"""
        try:
            posts = simulation_data.get("posts", [])
            comments = simulation_data.get("comments", [])

            attacker_posts = [p for p in posts if _is_attacker(p)]
            attacker_comments = [c for c in comments if _is_attacker(c)]

            if not attacker_posts and not attacker_comments:
                log.warning(f"No attacker activity for day {day}, low detection risk")
                return 0.1

            organic_posts = [p for p in posts if not _is_attacker(p)]
            organic_comments = [c for c in comments if not _is_attacker(c)]

            analysis_prompt = f"""
Analyze the following attacker information campaign activity for signs of coordination that might be detected by moderators or community members:

Campaign Configuration:
- Target Narrative: "{self.config.target_narrative}"

Attacker Activity from day {day}:
- {len(attacker_posts)} posts created
- {len(attacker_comments)} comments made

Sample Attacker Posts:
{json.dumps(attacker_posts[:10], indent=2)}

Sample Attacker Comments:
{json.dumps(attacker_comments[:10], indent=2)}

Organic Community Activity (for comparison):
Posts from regular users:
{json.dumps(organic_posts[:10], indent=2)}

Comments from regular users:
{json.dumps(organic_comments[:10], indent=2)}

Assess the detection risk (0.0 to 1.0):
- 0.0 = Activity appears completely organic, no suspicious patterns
- 0.5 = Some coordination visible but plausibly natural
- 1.0 = Obvious coordination, highly suspicious

Consider:
- Content similarity between attackers
- Content similarity between attackers and community activity

Return ONLY a JSON object:
{{
    "detection_risk": <float 0.0-1.0>,
    "reasoning": "<brief explanation of risk factors observed>"
}}
"""

            llm = self.llm_provider or get_llm_provider()
            if not llm.is_available():
                log.warning("No LLM provider available, using default detection risk")
                return 0.3

            result = complete_json(
                llm,
                [
                    {
                        "role": "system",
                        "content": "You are a coordination detection analyst. Return ONLY valid JSON. Do NOT include comments (# or //), explanations, or markdown formatting.",
                    },
                    {"role": "user", "content": analysis_prompt},
                ],
                temperature=0.3,
                max_tokens=600,
                validate=require_unit_floats("detection_risk"),
                label=f"Detection risk analysis day {day}",
            )
            if not result.ok:
                log.error(
                    f"Detection risk analysis for day {day} failed ({result.error}), using default detection risk"
                )
                return 0.3
            value = result.data["detection_risk"]
            log.info(
                f"Detection risk for day {day}: {value:.2f} - {result.data.get('reasoning', 'N/A')}"
            )
            return value

        except Exception as e:
            log.error(f"Detection risk analysis failed: {e}")
            return 0.3  # Moderate fallback

    def adjust_campaign_strategy(self, metrics: CampaignMetrics) -> None:
        """Adjust campaign strategy based on effectiveness metrics"""
        try:
            recent_metrics = (
                self.campaign_metrics[-3:]
                if len(self.campaign_metrics) >= 3
                else self.campaign_metrics
            )

            if not recent_metrics:
                return

            avg_effectiveness = np.mean(
                [m.overall_effectiveness for m in recent_metrics]
            )
            avg_detection_risk = np.mean([m.detection_risk for m in recent_metrics])

            if avg_effectiveness < 0.3:
                self.config.intensity = min(1.0, self.config.intensity + 0.1)
                log.info(f"Increased campaign intensity to {self.config.intensity}")
            elif avg_effectiveness > 0.7:
                self.config.intensity = max(0.1, self.config.intensity - 0.05)
                log.info(f"Decreased campaign intensity to {self.config.intensity}")

            if avg_detection_risk > 0.5:
                self.config.coordination_strength = max(
                    0.3, self.config.coordination_strength - 0.1
                )
                log.info(
                    f"Decreased coordination strength to {self.config.coordination_strength}"
                )
            elif avg_detection_risk < 0.2:
                self.config.coordination_strength = min(
                    1.0, self.config.coordination_strength + 0.05
                )
                log.info(
                    f"Increased coordination strength to {self.config.coordination_strength}"
                )

        except Exception as e:
            log.error(f"Strategy adjustment failed: {e}")

    def get_campaign_summary(self) -> Dict[str, Any]:
        """Get a summary of the campaign's performance"""
        if not self.campaign_metrics:
            return {"status": "no_data"}

        return {
            "campaign_config": {
                "objective": self.config.objective.value,
                "target_narrative": self.config.target_narrative,
                "target_subreddit": self.config.target_subreddit,
                "coordination_strength": self.config.coordination_strength,
                "intensity": self.config.intensity,
                "daily_post_target": self.config.daily_post_target,
            },
            "performance_summary": {
                "total_days": len(self.campaign_metrics),
                "avg_effectiveness": np.mean(
                    [m.overall_effectiveness for m in self.campaign_metrics]
                ),
                "avg_sentiment_alignment": np.mean(
                    [m.sentiment_alignment for m in self.campaign_metrics]
                ),
                "avg_detection_risk": np.mean(
                    [m.detection_risk for m in self.campaign_metrics]
                ),
            },
            "recent_trends": {
                "effectiveness_trend": self._calculate_trend(
                    [m.overall_effectiveness for m in self.campaign_metrics]
                ),
                "detection_risk_trend": self._calculate_trend(
                    [m.detection_risk for m in self.campaign_metrics]
                ),
            },
        }

    def _calculate_trend(self, values: List[float]) -> str:
        """Calculate trend direction from a list of values"""
        if len(values) < 2:
            return "insufficient_data"

        recent_avg = np.mean(values[-3:]) if len(values) >= 3 else values[-1]
        earlier_avg = np.mean(values[:-3]) if len(values) >= 6 else values[0]

        if recent_avg > earlier_avg * 1.1:
            return "improving"
        elif recent_avg < earlier_avg * 0.9:
            return "declining"
        else:
            return "stable"


# Flask service
def create_flask_app(orchestrator: AttackerCampaignOrchestrator):
    """Create the Flask app for the standalone orchestrator service"""
    from flask import Flask, request, jsonify

    app = Flask(__name__)

    @app.route("/health", methods=["GET"])
    def health():
        """Health check endpoint"""
        return jsonify({"status": "ok", "service": "attacker_campaign_orchestrator"})

    @app.route("/ingest_simulation_data", methods=["POST"])
    def ingest_simulation_data():
        """
        Receive and store simulation data. Data for day N is used to plan
        day N+1.
        """
        try:
            data = request.json
            day = data.get("day")
            simulation_data = data.get("data")

            if day is None or simulation_data is None:
                return jsonify({"success": False, "error": "Missing day or data"}), 400

            orchestrator.store_simulation_data(day, simulation_data)
            log.info(
                f"Stored simulation data for day {day} ({len(simulation_data.get('posts', []))} posts, {len(simulation_data.get('comments', []))} comments)"
            )

            os.makedirs(orchestrator.snapshots_dir, exist_ok=True)

            mitigation_data = simulation_data.get(
                "mitigation_data",
                {"flagged_agents": {}, "banned_agents": [], "flags_by_type": {}},
            )

            biased_moderation_log = simulation_data.get("biased_moderation_log", [])

            snapshot_file = os.path.join(
                orchestrator.snapshots_dir, f"day_{day}_data.json"
            )
            snapshot_data = {
                "day": day,
                "timestamp": datetime.now().isoformat(),
                "simulation_data": simulation_data,
                "mitigation_data": mitigation_data,
                "biased_moderation_log": biased_moderation_log,
                "metadata": {
                    "total_posts": len(simulation_data.get("posts", [])),
                    "total_comments": len(simulation_data.get("comments", [])),
                    "total_agents": simulation_data.get("total_agents", 0),
                    "total_events": simulation_data.get("total_events", 0),
                    "belief_states_count": len(
                        simulation_data.get("belief_states", {})
                    ),
                    "agent_activity_count": len(
                        simulation_data.get("agent_activity", {})
                    ),
                    "flagged_agents_count": len(
                        mitigation_data.get("flagged_agents", {})
                    ),
                    "banned_agents_count": len(
                        mitigation_data.get("banned_agents", [])
                    ),
                    "biased_moderation_actions_count": len(biased_moderation_log),
                },
            }

            with open(snapshot_file, "w") as f:
                json.dump(snapshot_data, f, indent=2)

            log.info(f"Saved daily snapshot to {snapshot_file}")

            summary_file = f"{orchestrator.output_dir}/simulation_summary.json"
            if os.path.exists(summary_file):
                with open(summary_file, "r") as f:
                    summary = json.load(f)
            else:
                summary = {"days": []}

            summary["days"].append(
                {
                    "day": day,
                    "total_posts": len(simulation_data.get("posts", [])),
                    "total_comments": len(simulation_data.get("comments", [])),
                    "total_events": simulation_data.get("total_events", 0),
                }
            )

            with open(summary_file, "w") as f:
                json.dump(summary, f, indent=2)

            return jsonify({"success": True, "day": day})
        except Exception as e:
            log.error(f"Error ingesting simulation data: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    @app.route("/plan_daily_campaign", methods=["POST"])
    def plan_daily_campaign():
        """
        Plan daily campaign activities based on previous day's data.

        Called at START of each day (including day 0) from think() phase.
        Uses data from day N-1 to plan activities for day N.
        Day 0 is skipped (observation mode) so campaign starts on day 1.
        """
        try:
            data = request.json
            day = data.get("day")
            attacker_agent_ids = data.get("attacker_agent_ids", [])

            if day is None:
                return jsonify({"success": False, "error": "Missing day"}), 400

            if attacker_agent_ids and not orchestrator.attacker_agents:
                orchestrator.register_attacker_agents(attacker_agent_ids)

            daily_plan = orchestrator.plan_daily_campaign(day)

            plan_dict = {
                "date": daily_plan.date,
                "target_posts": daily_plan.target_posts,
                "expected_outcomes": daily_plan.expected_outcomes,
                "risk_assessment": daily_plan.risk_assessment,
            }

            return jsonify({"success": True, "daily_plan": plan_dict})
        except Exception as e:
            log.error(f"Error planning daily campaign: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    @app.route("/evaluate_effectiveness", methods=["POST"])
    def evaluate_effectiveness():
        """Evaluate campaign effectiveness for a day"""
        try:
            data = request.json
            day = data.get("day")
            simulation_data = data.get("simulation_data", {})
            attacker_activity = data.get("attacker_activity", {})

            if day is None:
                return jsonify({"success": False, "error": "Missing day"}), 400

            execution_results = {
                "posts_created": len(attacker_activity.get("posts", [])),
                "success_rate": 1.0,
                "errors": [],
            }

            metrics = orchestrator.evaluate_campaign_effectiveness(
                day, execution_results, simulation_data
            )

            metrics_dict = {
                "sentiment_alignment": metrics.sentiment_alignment,
                "detection_risk": metrics.detection_risk,
                "overall_effectiveness": metrics.overall_effectiveness,
            }

            return jsonify({"success": True, "metrics": metrics_dict})
        except Exception as e:
            log.error(f"Error evaluating effectiveness: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    return app


def run_orchestrator_service(
    config: CampaignConfig,
    port: int = 5001,
    llm_service_url: str = "http://localhost:5000",
    output_dir: str = "simulation_output",
):
    """Run the orchestrator as a Flask service"""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    orchestrator = AttackerCampaignOrchestrator(config, llm_service_url, output_dir)

    app = create_flask_app(orchestrator)

    log.info(f"Starting Attacker Campaign Orchestrator on port {port}")
    log.info(f"Campaign objective: {config.objective.value}")
    log.info(f"Target narrative: {config.target_narrative}")
    log.info(f"Coordination strength: {config.coordination_strength}")
    log.info(f"Intensity: {config.intensity}")

    app.run(host="0.0.0.0", port=port, debug=False)


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Run Attacker Campaign Orchestrator Service"
    )
    parser.add_argument("--port", type=int, default=5001, help="Port to run service on")
    parser.add_argument(
        "--objective",
        type=str,
        default="amplify_narrative",
        choices=["amplify_narrative", "disrupt_discourse"],
        help="Campaign objective",
    )
    parser.add_argument(
        "--target-narrative",
        type=str,
        default="Climate change requires immediate action",
        help="Target narrative",
    )
    parser.add_argument(
        "--target-subreddit",
        type=str,
        default="politics",
        help="Target subreddit name (without r/)",
    )
    parser.add_argument(
        "--coordination-strength",
        type=float,
        default=0.8,
        help="Coordination strength (0.0-1.0)",
    )
    parser.add_argument(
        "--intensity", type=float, default=0.7, help="Campaign intensity (0.0-1.0)"
    )
    parser.add_argument(
        "--daily-post-target", type=int, default=8, help="Daily post target"
    )
    parser.add_argument(
        "--llm-service-url",
        type=str,
        default="http://localhost:5000",
        help="LLM service URL",
    )
    parser.add_argument(
        "--output-dir",
        type=str,
        default="simulation_output",
        help="Output directory for daily snapshots",
    )

    args = parser.parse_args()

    objective = (
        CampaignObjective.AMPLIFY_NARRATIVE
        if args.objective == "amplify_narrative"
        else CampaignObjective.DISRUPT_DISCOURSE
    )
    config = CampaignConfig(
        objective=objective,
        target_narrative=args.target_narrative,
        target_subreddit=args.target_subreddit,
        coordination_strength=args.coordination_strength,
        intensity=args.intensity,
        daily_post_target=args.daily_post_target,
    )

    run_orchestrator_service(config, args.port, args.llm_service_url, args.output_dir)
