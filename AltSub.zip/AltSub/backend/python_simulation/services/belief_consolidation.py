#!/usr/bin/env python3
"""
Belief consolidation and culling for belief-bloat mitigation.

Provides:
- get_protected_belief_ids: classify attacker-related beliefs (by ID or semantics)
- cull_to_cap: reduce belief set to cap (keep protected + top by strength)
- consolidate_beliefs: drop weak, merge by similarity, then cap (for end-of-day)
"""

import logging
from typing import Any, Dict, Set

import numpy as np
from sklearn.metrics.pairwise import cosine_distances

log = logging.getLogger(__name__)


def get_protected_belief_ids(
    beliefs_dict: Dict[str, float],
    belief_text_source: Dict[str, str],
    campaign_belief_texts: Dict[str, str],
    canonicalizer: Any,
    similarity_threshold: float,
    protect_attacker_beliefs: bool,
) -> Set[str]:
    """
    Return belief IDs that are attacker-related (protected when protect_attacker_beliefs is True).

    Attacker-related = (1) belief_id.startswith("campaign_") or
    (2) belief text is semantically similar to any campaign reference text.

    Similarity is topical, so (2) covers beliefs on the campaign's topic of either
    stance, including counter-campaign beliefs. That is intended: protecting only
    campaign-aligned beliefs would let culling remove the opposing side. Pro and
    anti beliefs are kept apart by the NLI check in consolidate_beliefs' merge.

    Args:
        beliefs_dict: Current beliefs (belief_id -> strength)
        belief_text_source: belief_id -> human-readable text (e.g. registry + agent.belief_texts)
        campaign_belief_texts: Campaign reference texts (id -> text)
        canonicalizer: BeliefCanonicalizer (uses _embed for similarity)
        similarity_threshold: Min similarity (0-1) to classify as attacker-related
        protect_attacker_beliefs: If False, return empty set

    Returns:
        Set of protected belief IDs
    """
    if not protect_attacker_beliefs:
        return set()

    protected: Set[str] = {bid for bid in beliefs_dict if bid.startswith("campaign_")}

    if not campaign_belief_texts:
        return protected

    campaign_texts = list(campaign_belief_texts.values())
    if not campaign_texts:
        return protected

    try:
        campaign_emb = canonicalizer._embed(campaign_texts)
    except Exception as e:
        log.warning(f"Belief consolidation: could not embed campaign texts: {e}")
        return protected

    for bid in beliefs_dict:
        if bid in protected:
            continue
        text = belief_text_source.get(bid, bid)
        try:
            emb = canonicalizer._embed([text])
            sims = 1 - cosine_distances(emb, campaign_emb)[0]
            if np.max(sims) >= similarity_threshold:
                protected.add(bid)
        except Exception as e:
            log.debug(f"Belief consolidation: skip similarity for {bid}: {e}")

    return protected


def cull_to_cap(
    beliefs: Dict[str, float],
    belief_cap: int,
    protected_belief_ids: Set[str],
) -> Dict[str, float]:
    """
    Reduce belief set to at most belief_cap: keep all protected, then top non-protected by strength.

    Args:
        beliefs: belief_id -> strength
        belief_cap: Maximum number of beliefs to keep
        protected_belief_ids: Never drop these

    Returns:
        New dict with at most belief_cap entries (clamped strengths)
    """
    if len(beliefs) <= belief_cap:
        return {k: max(0.0, min(1.0, float(v))) for k, v in beliefs.items()}

    protected_items = [(bid, beliefs[bid]) for bid in protected_belief_ids if bid in beliefs]
    non_protected = [
        (bid, s) for bid, s in beliefs.items() if bid not in protected_belief_ids
    ]
    # Sort by strength descending, take top (belief_cap - len(protected))
    n_slots = belief_cap - len(protected_items)
    non_protected_sorted = sorted(non_protected, key=lambda x: -x[1])
    kept_non = non_protected_sorted[:n_slots] if n_slots > 0 else []

    result = dict(protected_items + kept_non)
    return {k: max(0.0, min(1.0, float(v))) for k, v in result.items()}


def consolidate_beliefs(
    beliefs: Dict[str, float],
    *,
    belief_text_source: Dict[str, str],
    canonicalizer: Any,
    belief_cap: int,
    protect_attacker_beliefs: bool,
    weak_belief_threshold: float,
    campaign_belief_texts: Dict[str, str],
    attacker_similarity_threshold: float,
    merge_similarity_threshold: float = 0.75,
) -> Dict[str, float]:
    """
    Consolidate belief set: drop weak non-protected, merge by semantic similarity, then cap.

    - Protected set = campaign_* + semantic match to campaign (when protect_attacker_beliefs).
    - Drop non-protected beliefs with strength < weak_belief_threshold.
    - Within non-protected (and within protected), merge beliefs that are similar AND that
      NLI accepts as the same belief (never a contradiction); the strongest is kept.
    - If still over belief_cap, keep all protected + top non-protected by strength.

    Args:
        beliefs: belief_id -> strength
        belief_text_source: belief_id -> text for embedding
        canonicalizer: BeliefCanonicalizer for _embed
        belief_cap: Max beliefs after consolidation
        protect_attacker_beliefs: Whether to compute and protect attacker-related beliefs
        weak_belief_threshold: Drop non-protected below this strength
        campaign_belief_texts: For protected classification
        attacker_similarity_threshold: For classifying attacker-related by semantics
        merge_similarity_threshold: Merge beliefs with similarity >= this (0.75)

    Returns:
        New belief dict of size <= belief_cap
    """
    if not beliefs:
        return {}

    protected = get_protected_belief_ids(
        beliefs,
        belief_text_source,
        campaign_belief_texts,
        canonicalizer,
        attacker_similarity_threshold,
        protect_attacker_beliefs,
    )

    # Split and drop weak non-protected
    non_protected_items = [
        (bid, s) for bid, s in beliefs.items() if bid not in protected and s >= weak_belief_threshold
    ]
    protected_items = [(bid, beliefs[bid]) for bid in protected if bid in beliefs]

    # Merge by similarity within non-protected and within protected
    def merge_similar(items: list, text_src: Dict[str, str]) -> Dict[str, float]:
        if not items:
            return {}
        if len(items) == 1:
            return {items[0][0]: max(0.0, min(1.0, items[0][1]))}

        ids = [x[0] for x in items]
        texts = [text_src.get(bid, bid) for bid in ids]
        try:
            embs = canonicalizer._embed(texts)
        except Exception as e:
            log.warning(f"Belief consolidation: merge embedding failed: {e}")
            return {bid: max(0.0, min(1.0, s)) for bid, s in items}

        nli = getattr(canonicalizer, "nli", None)
        if nli is None:
            # Similarity alone would merge opposite claims, so don't merge at all
            log.warning("Belief consolidation: no NLI checker, skipping merge")
            return {bid: max(0.0, min(1.0, s)) for bid, s in items}

        sims = 1 - cosine_distances(embs)

        # Greedy, strongest first: each belief merges into an existing
        # representative only if similar and NLI accepts it as the same belief.
        # Comparing against representatives (not any member) prevents A~B~C chaining.
        order = sorted(range(len(ids)), key=lambda i: -items[i][1])
        reps: list = []
        for i in order:
            candidates = [r for r in reps if sims[i, r] >= merge_similarity_threshold]
            if candidates and any(
                nli.same_belief_many(
                    [(texts[i], texts[r]) for r in candidates],
                    [sims[i, r] for r in candidates],
                )
            ):
                continue
            reps.append(i)

        # Representatives are the strongest of their group, so strength = group max
        return {ids[r]: max(0.0, min(1.0, items[r][1])) for r in reps}

    merged_non = merge_similar(non_protected_items, belief_text_source)
    merged_protected = merge_similar(protected_items, belief_text_source)
    combined = {**merged_non, **merged_protected}

    return cull_to_cap(combined, belief_cap, set(merged_protected.keys()))
