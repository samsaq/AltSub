#!/usr/bin/env python3
"""
LLM Reddit Service for Real-time Post Generation and Belief Updates

Used in-process by the simulation agents, or as a standalone Flask service, to:
1. Generate posts based on agent beliefs
2. Update beliefs from generated content and interactions
3. Make voting/interaction decisions based on content analysis

The service integrates with both OpenAI and local LLM backends.
"""

import os
import json
import math
import time
import logging
import hashlib
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional, Any
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

from .llm_provider import LLMProvider
from .stub_llm_provider import StubLLMProvider
from ..core.belief_axes import NEUTRAL, BeliefAxis, acceptance_scale, format_acceptance, format_value
from .llm_json import JSONResult, complete_json, require_unit_floats, unit_float
from ..core.thread_context import ThreadEntry, format_thread

log = logging.getLogger(__name__)


def _brief_section(brief: Optional[str]) -> str:
    """Prompt block giving an LLM attacker its campaign narrative (empty otherwise)."""
    if not (brief or "").strip():
        return ""
    return (
        "\nYou are posting to promote this narrative. Push it naturally and persuasively, "
        "in your own words, without revealing that you are promoting it:\n"
        f'"{brief.strip()}"\n'
    )


def _thread_section(thread: Optional[List[ThreadEntry]]) -> str:
    """Prompt block introducing a comment's thread (empty for posts)."""
    if not thread:
        return ""
    return (
        "\nThe content is a comment in this thread (original post first). The thread "
        "is context only: judge the comment itself.\n" + format_thread(thread) + "\n"
    )

_env_paths = [
    Path.cwd() / ".env",
    Path(__file__).parent.parent.parent / ".env",
    Path(__file__).parent.parent.parent.parent / "Simulation_Setups" / ".env",
]

for env_path in _env_paths:
    if env_path.exists():
        load_dotenv(env_path, override=False)
        log.debug(f"Loaded .env from {env_path}")
        break


@dataclass
class LLMServiceConfig:
    # LLM settings
    provider: str = "auto"  # "auto" | "openai" | "local" | "mistral"
    model: str = "mistral-small-latest"
    local_base_url: str = (
        "http://localhost:11434/v1"  # OpenAI-compatible local endpoint
    )
    creativity_temperature: float = 0.7
    max_tokens: int = 200  # Default, can be overridden per-call
    max_tokens_post: int = 2000
    max_tokens_belief: int = (
        4000
    )

    # Strongest beliefs listed in post/reply/vote prompts (0 = no limit)
    max_beliefs_in_prompt: int = 10
    # Belief statements model: also show a Likert-style label next to each
    # acceptance value ("0.25, rejects"), in agent context and update prompts
    verbal_acceptance_labels: bool = False
    # Attackers' reply prompt keeps "Avoids being confrontational unless your
    # beliefs strongly oppose" (organic users always keep it); False drops it
    # for agents writing with a campaign brief
    attacker_avoid_confrontation: bool = True

    # Strength at which a reader adopts beliefs extracted from content it reads:
    # "reader" = the LLM estimates how strongly this reader, given its beliefs,
    #            would hold each claim (claims it would reject are omitted);
    # "low"    = every adopted claim starts at new_belief_low_strength
    new_belief_strength_mode: str = "reader"
    new_belief_low_strength: float = 0.35

    # Max change to one belief's strength per item read (LLM updates and
    # contradiction pressure combined)
    belief_update_max_change: float = 0.15
    # A held belief above this strength blocks adoption of a new claim that
    # contradicts it (the held belief is weakened instead); at or below it the
    # new claim is adopted and the weakened belief is dropped
    contradiction_hold_threshold: float = 0.3

    # Client-side limits on agent LLM calls (0 = unlimited)
    llm_rate_limit_qps: float = 0.0
    max_concurrent_calls: int = 0

    # Service settings
    port: int = 5000
    request_timeout_s: int = 30


class LLMRedditService:
    def __init__(self, config: LLMServiceConfig):
        self.config = config
        self._init_llm_client()

    def _init_llm_client(self) -> None:
        if self.config.provider == "stub":
            self._llm_provider = StubLLMProvider()
        else:
            provider = self.config.provider if self.config.provider != "auto" else None
            self._llm_provider = LLMProvider(
                preferred_provider=provider,
                local_base_url=self.config.local_base_url,
                local_model=self.config.model,
                llm_rate_limit_qps=self.config.llm_rate_limit_qps,
                max_concurrent_calls=self.config.max_concurrent_calls,
            )
        log.info(f"LLMRedditService provider: {self._llm_provider.provider}")

    @property
    def llm_provider(self):
        """The underlying provider (shared with the orchestrator in stub runs)."""
        return self._llm_provider

    @staticmethod
    def _stance_label(strength: float) -> str:
        if strength > 0.7:
            return "strongly support"
        if strength > 0.5:
            return "support"
        if strength > 0.3:
            return "somewhat support"
        return "neutral"

    @staticmethod
    def _belief_label(
        belief_id: str, belief_id_to_text: Optional[Dict[str, str]]
    ) -> str:
        """Human-readable text for a belief; falls back to the ID if no text is known."""
        return (belief_id_to_text or {}).get(belief_id) or belief_id

    def _format_belief_context(
        self,
        beliefs: Dict[str, float],
        belief_id_to_text: Optional[Dict[str, str]],
        min_strength: float = 0.3,
    ) -> List[str]:
        """'- {stance}: {text}' lines for beliefs above min_strength, strongest first."""
        held = sorted(
            ((b, s) for b, s in beliefs.items() if s > min_strength),
            key=lambda x: -x[1],
        )
        if self.config.max_beliefs_in_prompt > 0:
            held = held[: self.config.max_beliefs_in_prompt]
        return [
            f"- {self._stance_label(s)}: {self._belief_label(b, belief_id_to_text)}"
            for b, s in held
        ]

    def _format_axis_context(
        self, positions: Dict[str, float], axes: List[BeliefAxis]
    ) -> List[str]:
        """The scale, then one '- "statement" (acceptance: x)' line per statement
        in definition order (belief statements model). With
        max_beliefs_in_prompt > 0, only the statements furthest from neutral
        are listed."""
        shown = list(axes)
        cap = self.config.max_beliefs_in_prompt
        if cap > 0 and len(shown) > cap:
            keep = set(sorted(
                (a.id for a in shown),
                key=lambda i: -abs(positions.get(i, NEUTRAL) - NEUTRAL),
            )[:cap])
            shown = [a for a in shown if a.id in keep]
        verbal = self.config.verbal_acceptance_labels
        return [f"(acceptance of each statement: {acceptance_scale(verbal)})"] + [
            f"- {format_acceptance(a, positions.get(a.id, NEUTRAL), verbal)}" for a in shown
        ]

    def _belief_lines(
        self,
        beliefs: Dict[str, float],
        belief_id_to_text: Optional[Dict[str, str]],
        axes: Optional[List[BeliefAxis]],
    ) -> List[str]:
        if axes:
            return self._format_axis_context(beliefs, axes)
        return self._format_belief_context(beliefs, belief_id_to_text)

    def _complete_json(
        self,
        prompt: str,
        *,
        temperature: float,
        max_tokens: int,
        expect: type = dict,
        wrap_key: Optional[str] = None,
        validate=None,
        label: str = "LLM JSON",
    ) -> JSONResult:
        """JSON-returning LLM call via the shared robust helper (services/llm_json.py)."""
        return complete_json(
            self._llm_provider,
            [{"role": "user", "content": prompt}],
            temperature=temperature,
            max_tokens=max_tokens,
            expect=expect,
            wrap_key=wrap_key,
            validate=validate,
            label=label,
        )

    def _llm_chat(
        self, prompt: str, temperature: float = None, max_tokens: int = None
    ) -> str:
        """LLM chat call using the unified provider abstraction."""
        temp = (
            temperature
            if temperature is not None
            else self.config.creativity_temperature
        )
        tokens = max_tokens if max_tokens is not None else self.config.max_tokens

        response = self._llm_provider.chat_completion(
            messages=[{"role": "user", "content": prompt}],
            temperature=temp,
            max_tokens=tokens,
        )

        if response is None or not response.strip():
            raise Exception(
                "LLM request failed or returned empty response in llm_reddit_service.py"
            )

        return response

    def generate_post_content(
        self,
        agent_beliefs: Dict[str, float],
        trust_network: Dict[str, float],
        subreddit: str,
        context_posts: List[str] = None,
        agent_id: Optional[int] = None,
        belief_id_to_text: Optional[Dict[str, str]] = None,
        axes: Optional[List[BeliefAxis]] = None,
        campaign_brief: Optional[str] = None,
    ) -> str:
        """Generate a Reddit post based on agent's beliefs and trust network.
        campaign_brief: the narrative an attacker promotes (LLM attackers)."""
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        log.info(f"LLM Service: Generating post for {agent_info} in r/{subreddit}")

        belief_context = self._belief_lines(agent_beliefs, belief_id_to_text, axes)

        trusted_users = [user for user, trust in trust_network.items() if trust > 0.6]
        trust_context = (
            f"Trusted users: {', '.join(trusted_users[:3])}"
            if trusted_users
            else "No strong trust relationships"
        )

        recent_context = ""
        if context_posts:
            recent_posts = context_posts[-3:]
            recent_context = f"\nRecent posts in r/{subreddit}:\n" + "\n".join(
                f"- {post}" for post in recent_posts
            )

        prompt = f"""You are a Reddit user in r/{subreddit}. Generate a natural, engaging post that reflects your beliefs and personality.

Your current beliefs and stances:
{chr(10).join(belief_context)}
{_brief_section(campaign_brief)}
{trust_context}
{recent_context}

Generate a Reddit post (title + text) that:
1. Is authentic and conversational
2. Reflects your beliefs naturally (don't explicitly state them)
3. Engages with the community
4. Is appropriate for r/{subreddit}
5. Is 1-3 paragraphs, conversational tone

IMPORTANT: Return ONLY valid JSON. Do NOT include comments, explanations, or markdown formatting.
Format as JSON: {{"title": "...", "text": "..."}}"""

        result = self._complete_json(
            prompt,
            temperature=self.config.creativity_temperature,
            max_tokens=self.config.max_tokens_post,
            label=f"Post generation ({agent_info})",
        )
        title = str(result.data.get("title") or "").strip() if result.ok else ""
        text = str(result.data.get("text") or "").strip() if result.ok else ""
        if not title and not text:
            log.warning(
                f"Post generation failed ({result.error or 'title/text empty'}); "
                f"using fallback post. Raw reply: {result.raw[:200]!r}"
            )
            return f"Interesting discussion happening in r/{subreddit} today!"
        return f"{title}\n\n{text}" if title else text

    def generate_reply_content(
        self,
        parent_content: str,
        agent_beliefs: Dict[str, float],
        subreddit: str,
        agent_id: Optional[int] = None,
        belief_id_to_text: Optional[Dict[str, str]] = None,
        axes: Optional[List[BeliefAxis]] = None,
        thread: Optional[List[ThreadEntry]] = None,
        campaign_brief: Optional[str] = None,
    ) -> str:
        """Generate a reply to a post or comment based on agent's beliefs.
        campaign_brief: the narrative an attacker promotes (LLM attackers).

        thread: when replying to a comment, the post and comments above it
        (core/thread_context.thread_context), shown for context.
        """
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        parent_content = parent_content or ""
        log.info(
            f"LLM Service: Generating reply for {agent_info} in r/{subreddit} (parent: {parent_content[:50]}...)"
        )

        belief_context = self._belief_lines(agent_beliefs, belief_id_to_text, axes)
        # Organic users keep the non-confrontational default; attackers (who
        # write with a campaign brief) drop it when attacker_avoid_confrontation is off
        keep_guard = not campaign_brief or self.config.attacker_avoid_confrontation
        confrontation_line = (
            "\n5. Avoids being confrontational unless your beliefs strongly oppose" if keep_guard else ""
        )

        if thread:
            target = "comment"
            opening = f"""You are replying to a comment in a thread in r/{subreddit}.

Thread so far (original post first):
{format_thread(thread)}

The comment you are replying to:
"{parent_content}\""""
        else:
            target = "post"
            opening = f"""You are replying to this post in r/{subreddit}:

"{parent_content}\""""

        prompt = f"""{opening}

Your beliefs and stances:
{chr(10).join(belief_context)}
{_brief_section(campaign_brief)}
Generate a natural, conversational reply to the {target} in r/{subreddit} that:
1. Engages with the {target} you are replying to{" (in the context of the thread)" if thread else ""}
2. Reflects your beliefs naturally
3. Adds value to the discussion
4. Is 1-2 paragraphs, conversational tone in the style of a r/{subreddit} redditor{confrontation_line}

return ONLY the reply text, no quotes or formatting. Do not include any other text or comments."""

        try:
            return self._llm_chat(
                prompt, temperature=self.config.creativity_temperature
            )
        except Exception as e:
            log.error(f"Reply generation failed: {e}")
            return "Interesting point! I hadn't thought about it that way."

    def analyze_voting_decision(
        self,
        content: str,
        agent_beliefs: Dict[str, float],
        subreddit: str,
        agent_id: Optional[int] = None,
        belief_id_to_text: Optional[Dict[str, str]] = None,
        axes: Optional[List[BeliefAxis]] = None,
        thread: Optional[List[ThreadEntry]] = None,
    ) -> Dict[str, float]:
        """Analyze content and return voting probabilities (thread: context
        above a comment, as in generate_reply_content)."""
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        log.info(
            f"LLM Service: Analyzing voting decision for {agent_info} in r/{subreddit} (content: {content[:50]}...)"
        )

        belief_context = self._belief_lines(agent_beliefs, belief_id_to_text, axes)

        if thread:
            item = f"""Analyze this Reddit comment in r/{subreddit} and determine voting likelihood.

It was posted in this thread (original post first), shown for context; vote on the comment itself:
{format_thread(thread)}

Comment: "{content}\""""
        else:
            item = f"""Analyze this Reddit post in r/{subreddit} and determine voting likelihood:

Post: "{content}\""""

        prompt = f"""{item}

Your beliefs and stances:
{chr(10).join(belief_context)}

Return ONLY JSON with probabilities: {{"upvote": 0.0-1.0, "downvote": 0.0-1.0, "no_vote": 0.0-1.0}}
Consider:
- Alignment with your beliefs
- Quality of content
- Contribution to discussion
- Appropriateness for subreddit"""

        result = self._complete_json(
            prompt,
            temperature=0.1,
            max_tokens=self.config.max_tokens,
            validate=require_unit_floats(
                "upvote", "downvote", "no_vote", defaults={"no_vote": 1.0}
            ),
            label=f"Voting analysis ({agent_info})",
        )
        if not result.ok:
            log.warning(f"Voting analysis failed ({result.error}); using default probabilities")
            return {"upvote": 0.1, "downvote": 0.1, "no_vote": 0.8}
        return {k: result.data[k] for k in ("upvote", "downvote", "no_vote")}

    def update_axis_positions(
        self,
        content: str,
        positions: Dict[str, float],
        axes: List[BeliefAxis],
        author: Optional[str] = None,
        agent_id: Optional[int] = None,
        thread: Optional[List[ThreadEntry]] = None,
    ) -> Dict[str, float]:
        """Update the reader's acceptance of each belief statement after reading
        content (belief statements model). Each change is bounded by
        belief_update_max_change and values stay in [0, 1]; on failure values are
        unchanged. thread: for a comment, the post and comments above it
        (context only)."""
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        log.info(
            f"LLM Service: Updating belief acceptance for {agent_info} (content: {(content or '')[:50]}...)"
        )
        if not (content or "").strip():
            return dict(positions)

        # Statements keyed by short aliases (a1, a2, ...) that the LLM echoes back
        alias_to_id: Dict[str, str] = {}
        axis_lines = []
        for n, axis in enumerate(axes, start=1):
            alias = f"a{n}"
            alias_to_id[alias] = axis.id
            value = positions.get(axis.id, NEUTRAL)
            axis_lines.append(
                f'- [{alias}] "{axis.statement}" '
                f"(your acceptance: {format_value(value, self.config.verbal_acceptance_labels)})"
            )
        bound = self.config.belief_update_max_change
        author_context = f" (posted by {author})" if author else ""
        scale_text = (
            f"from 0.0 to 1.0 ({acceptance_scale(True)})"
            if self.config.verbal_acceptance_labels
            else "from 0.0 (complete rejection) through 0.5 (neutral) to 1.0 (complete acceptance)"
        )

        prompt = f"""You are a Reddit user who just read this content{author_context}. Update how much you accept each of these belief statements.
{_thread_section(thread)}
Content: "{content}"

Belief statements, each with your current acceptance {scale_text}:
{chr(10).join(axis_lines)}

Return JSON with your new acceptance (0.0-1.0) for each statement, keyed by the bracketed key:
{{"a1": new_acceptance, ...}}

Consider:
- Does this content give you reason to accept or reject any statement more, given your current views?
- Is the content persuasive and is the author credible?
- Change realistically: at most {bound:.2f} per statement from your current acceptance
- If the content does not relate to a statement, keep your current acceptance

IMPORTANT: Return ONLY valid JSON. Be concise - no explanations, no comments, no markdown, no extra text."""

        result = self._complete_json(
            prompt,
            temperature=0.1,
            max_tokens=self.config.max_tokens_belief,
            label=f"Axis update ({agent_info})",
        )
        if not result.ok:
            log.warning(f"Axis update failed ({result.error}); positions unchanged")
            return dict(positions)

        updated = dict(positions)
        for key, new_value in result.data.items():
            key = str(key).strip("[] ")
            axis_id = alias_to_id.get(key, key)
            new_value = unit_float(new_value)
            if axis_id not in updated or new_value is None:
                continue
            current = updated[axis_id]
            change = max(-bound, min(bound, new_value - current))
            updated[axis_id] = max(0.0, min(1.0, current + change))
        return updated

    def update_beliefs_from_content(
        self,
        content: str,
        current_beliefs: Dict[str, float],
        author: Optional[str] = None,
        agent_id: Optional[int] = None,
        belief_id_to_text: Optional[Dict[str, str]] = None,
        thread: Optional[List[ThreadEntry]] = None,
    ) -> Dict[str, float]:
        """Update beliefs based on new content using LLM analysis (thread: for
        a comment, the post and comments above it, shown as context only)."""
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        author_info = f" (from author: {author})" if author else ""
        log.info(
            f"LLM Service: Updating beliefs for {agent_info}{author_info} (content: {content[:50]}...)"
        )

        if not content.strip():
            return current_beliefs.copy()

        # Build current belief context. Beliefs are keyed by short aliases (b1, b2, ...)
        # that the LLM echoes back as JSON keys, instead of 16-char hex IDs.
        alias_to_id: Dict[str, str] = {}
        belief_context = []
        for n, (belief_id, strength) in enumerate(current_beliefs.items(), start=1):
            alias = f"b{n}"
            alias_to_id[alias] = belief_id
            label = self._belief_label(belief_id, belief_id_to_text)
            belief_context.append(
                f"- [{alias}] {label}: {self._stance_label(strength)} (strength: {strength:.2f})"
            )

        author_context = f" (posted by {author})" if author else ""

        initial_max_tokens = self.config.max_tokens_belief
        current_max_tokens = initial_max_tokens

        prompt = f"""Analyze this Reddit content{author_context} and update belief strengths:
{_thread_section(thread)}
Content: "{content}"

Current beliefs:
{chr(10).join(belief_context)}

Return JSON with updated belief strengths (0.0-1.0), keyed by the bracketed belief key:
{{"b1": new_strength, ...}}

Consider:
- How does this content affect your confidence in each belief?
- Does it provide new evidence or perspective?
- Is the author trustworthy based on content quality?
- Update strengths realistically (small changes, 0.05-{self.config.belief_update_max_change:.2f} max per belief)
- If content doesn't relate to a belief, keep current strength

IMPORTANT: Return ONLY valid JSON. Be concise - no explanations, no comments, no markdown, no extra text.
The response must be parseable JSON only: {{"b1": strength, ...}}
Do NOT exceed the token limit of {current_max_tokens} tokens."""

        result = self._complete_json(
            prompt,
            temperature=0.1,
            max_tokens=initial_max_tokens,
            label=f"Belief update ({agent_info})",
        )
        if not result.ok:
            log.warning(f"Belief update failed ({result.error}); beliefs unchanged")
            return current_beliefs.copy()

        # Apply updates with bounds checking; skip entries that aren't valid numbers
        updated_beliefs = current_beliefs.copy()
        bound = self.config.belief_update_max_change
        for key, new_strength in result.data.items():
            # Map alias back to the belief ID; accept a raw ID too
            key = str(key).strip("[] ")
            belief_id = alias_to_id.get(key, key)
            new_strength = unit_float(new_strength)
            if belief_id not in updated_beliefs or new_strength is None:
                continue
            current = updated_beliefs[belief_id]
            change = max(-bound, min(bound, new_strength - current))
            updated_beliefs[belief_id] = current + change

        return updated_beliefs

    def extract_new_beliefs(
        self,
        content: str,
        existing_beliefs: Dict[str, float],
        subreddit: str,
        canonicalizer: Optional[Any] = None,
        timestep: Optional[int] = None,
        belief_id_to_text: Optional[Dict[str, str]] = None,
    ) -> Dict[str, Tuple[str, float]]:
        """
        Extract new beliefs from content that aren't in existing beliefs.

        Args:
            content: Content to extract beliefs from
            existing_beliefs: Current beliefs dict (belief_id -> strength)
            subreddit: Subreddit context
            canonicalizer: Optional BeliefCanonicalizer instance for real-time canonicalization
            timestep: Optional timestep for tracking
            belief_id_to_text: belief_id -> text, so existing beliefs are listed as text

        Returns:
            Dict mapping canonical_id -> (human_readable_text, strength)
            If canonicalizer not provided, returns temporary human-readable IDs
        """
        claims = self.extract_new_belief_claims(
            content, existing_beliefs, subreddit, belief_id_to_text
        )
        return self.canonicalize_claims(claims, existing_beliefs, canonicalizer, timestep)

    def canonicalize_claims(
        self,
        claims: Dict[str, float],
        existing_beliefs: Dict[str, float],
        canonicalizer: Optional[Any] = None,
        timestep: Optional[int] = None,
        write_metadata: bool = True,
    ) -> Dict[str, Tuple[str, float]]:
        """
        Map extracted claim texts to belief IDs, dropping claims already held.

        Touches shared canonicalizer state (first-come canonical IDs), so callers
        must apply it in a deterministic order (the event engine calls it on the
        main thread). write_metadata=False leaves the metadata file to
        batch_update_metadata.

        Returns:
            Dict mapping canonical_id -> (human_readable_text, strength)
        """
        filtered = {}
        for belief_text, strength_float in claims.items():
            if canonicalizer:
                canonical_id, canonical_text = canonicalizer.canonicalize_belief_text(
                    belief_text, timestep=timestep
                )
                if canonical_id not in existing_beliefs:
                    filtered[canonical_id] = (belief_text, strength_float)
                    if write_metadata:
                        canonicalizer.add_to_metadata(canonical_id, canonical_text, timestep)
            else:
                # Fallback: use temporary human-readable ID
                temp_id = belief_text.lower().replace(" ", "_")[:50]
                if temp_id not in existing_beliefs:
                    filtered[temp_id] = (belief_text, strength_float)

        return filtered

    def extract_new_belief_claims(
        self,
        content: str,
        existing_beliefs: Dict[str, float],
        subreddit: str,
        belief_id_to_text: Optional[Dict[str, str]] = None,
    ) -> Dict[str, float]:
        """
        LLM step of extract_new_beliefs: claim text -> adoption strength, validated,
        in the order the LLM returned them. Pure (no shared state), so it is safe
        to run on worker threads.
        """

        existing_lines = "\n".join(
            f"- {self._stance_label(s)}: {self._belief_label(b, belief_id_to_text)}"
            for b, s in sorted(existing_beliefs.items(), key=lambda x: -x[1])
        ) or "(none)"

        # Adoption strength: by default the reader's own (belief-dependent) strength,
        # not how strongly the content asserts the claim
        reader_mode = self.config.new_belief_strength_mode != "low"
        if reader_mode:
            strength_instructions = """You are a reader who holds the existing beliefs below. For each new claim in the content,
estimate how strongly YOU would come to hold it after reading this, given your existing beliefs
(0.0-1.0). Claims that fit your beliefs may be adopted strongly; claims that conflict with them
should be weak or omitted. Omit any claim you would reject.

Return JSON with the new beliefs you would hold and your strength (0.0-1.0):
{"belief_text": strength, ...}"""
        else:
            strength_instructions = """Return JSON with new beliefs and their strength (0.0-1.0):
{"belief_text": strength, ...}"""

        prompt = f"""Extract new beliefs/claims from this Reddit content:

Content: "{content}"

Existing beliefs:
{existing_lines}

{strength_instructions}

Only include beliefs that:
1. Are not already in existing beliefs
2. Are specific and testable
3. Are relevant to the subreddit domain of {subreddit}
4. Have strength > 0.3

Return the actual belief text (not IDs), e.g.:
{{"Climate change is caused by human activity": 0.8, "Vaccines are not safe and effective": 0.9}}

Return ONLY JSON. Be concise - no explanations, no comments, no markdown, no extra text."""

        result = self._complete_json(
            prompt,
            temperature=0.2,
            max_tokens=500,
            label="New belief extraction",
        )
        if not result.ok:
            log.warning(f"New belief extraction failed ({result.error})")
            return {}

        claims: Dict[str, float] = {}
        for belief_text, strength in result.data.items():
            try:
                strength_float = float(strength)
            except (ValueError, TypeError):
                continue
            if not math.isfinite(strength_float) or not (0.3 <= strength_float <= 1.0):
                continue
            if not reader_mode:
                strength_float = self.config.new_belief_low_strength

            if not belief_text or len(belief_text.strip()) < 5:
                continue

            claims[belief_text.strip()] = strength_float

        return claims


# Flask service
app = Flask(__name__)
CORS(app)

llm_service = None


@app.route("/health", methods=["GET"])
def health_check():
    return jsonify(
        {
            "status": "healthy",
            "provider": llm_service._llm_provider.provider,
            "model": llm_service._llm_provider.model,
        }
    )


@app.route("/generate_post", methods=["POST"])
def generate_post():
    """Generate a Reddit post based on agent beliefs."""
    try:
        data = request.json
        agent_id = data.get("agent_id")
        agent_beliefs = data.get("agent_beliefs", {})
        trust_network = data.get("trust_network", {})
        subreddit = data.get("subreddit", "politics")
        context_posts = data.get("context_posts", [])
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        log.info(f"Flask POST /generate_post: {agent_info} in r/{subreddit}")

        content = llm_service.generate_post_content(
            agent_beliefs, trust_network, subreddit, context_posts, agent_id=agent_id
        )

        return jsonify({"success": True, "content": content})
    except Exception as e:
        log.error(f"Post generation error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/generate_reply", methods=["POST"])
def generate_reply():
    """Generate a reply to a post."""
    try:
        data = request.json
        agent_id = data.get("agent_id")
        parent_content = data.get("parent_content", "")
        agent_beliefs = data.get("agent_beliefs", {})
        subreddit = data.get("subreddit", "politics")
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        log.info(f"Flask POST /generate_reply: {agent_info} in r/{subreddit}")

        content = llm_service.generate_reply_content(
            parent_content, agent_beliefs, subreddit, agent_id=agent_id
        )

        return jsonify({"success": True, "content": content})
    except Exception as e:
        log.error(f"Reply generation error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/analyze_voting", methods=["POST"])
def analyze_voting():
    """Analyze content for voting decision."""
    try:
        data = request.json
        agent_id = data.get("agent_id")
        content = data.get("content", "")
        agent_beliefs = data.get("agent_beliefs", {})
        subreddit = data.get("subreddit", "politics")
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        log.info(f"Flask POST /analyze_voting: {agent_info} in r/{subreddit}")

        probabilities = llm_service.analyze_voting_decision(
            content, agent_beliefs, subreddit, agent_id=agent_id
        )

        return jsonify({"success": True, "probabilities": probabilities})
    except Exception as e:
        log.error(f"Voting analysis error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/update_beliefs", methods=["POST"])
def update_beliefs():
    """Update beliefs based on content."""
    try:
        data = request.json
        agent_id = data.get("agent_id")
        content = data.get("content", "")
        current_beliefs = data.get("current_beliefs", {})
        author = data.get("author")
        agent_info = f"agent_{agent_id}" if agent_id is not None else "unknown_agent"
        author_info = f" (from author: {author})" if author else ""
        log.info(f"Flask POST /update_beliefs: {agent_info}{author_info}")

        updated_beliefs = llm_service.update_beliefs_from_content(
            content, current_beliefs, author, agent_id=agent_id
        )

        return jsonify({"success": True, "updated_beliefs": updated_beliefs})
    except Exception as e:
        log.error(f"Belief update error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/extract_beliefs", methods=["POST"])
def extract_beliefs():
    """Extract new beliefs from content."""
    try:
        data = request.json
        content = data.get("content", "")
        existing_beliefs = data.get("existing_beliefs", {})
        subreddit = data.get("subreddit", "ERROR: No subreddit provided")
        if subreddit == "ERROR: No subreddit provided":
            log.error("No subreddit provided")
            return jsonify({"success": False, "error": "No subreddit provided"}), 400

        # Extract new beliefs (no canonicalizer for the Flask endpoint)
        new_beliefs_raw = llm_service.extract_new_beliefs(
            content, existing_beliefs, subreddit, canonicalizer=None
        )

        # Convert to backward-compatible format: {belief_id: strength}
        # If canonicalizer was used, new_beliefs_raw is {canonical_id: (text, strength)}
        # Otherwise, it's {temp_id: (text, strength)}
        new_beliefs = {}
        for belief_id, value in new_beliefs_raw.items():
            if isinstance(value, tuple):
                _, strength = value
                new_beliefs[belief_id] = strength
            else:
                new_beliefs[belief_id] = value

        return jsonify({"success": True, "new_beliefs": new_beliefs})
    except Exception as e:
        log.error(f"Belief extraction error: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/moderate_content", methods=["POST"])
def moderate_content():
    """Analyze content for bias-based moderation."""
    try:
        data = request.json
        moderator_id = data.get("moderator_id") or data.get("agent_id")
        content = data.get("content", "")
        moderator_beliefs = data.get("moderator_beliefs", {})
        subreddit_rules = data.get("subreddit_rules", "")
        temperature = data.get("temperature", 0.3)
        max_tokens = data.get("max_tokens", 300)
        moderator_info = (
            f"moderator_{moderator_id}"
            if moderator_id is not None
            else "unknown_moderator"
        )
        log.info(
            f"Flask POST /moderate_content: {moderator_info} analyzing content (length: {len(content)} chars)"
        )

        beliefs_str = json.dumps(moderator_beliefs, indent=2)

        prompt = f"""You are a biased subreddit moderator with the following beliefs:
{beliefs_str}

Subreddit rules:
{subreddit_rules}

Analyze this content:
"{content}"

Determine:
1. Does this content contradict your beliefs? (yes/no)
2. Contradiction score (0.0-1.0, where 1.0 is strong contradiction)
3. Public justification (cite subreddit rules - this is what you would tell the user)
4. Private reasoning (your actual belief-based reason - this is the real reason)

Respond in JSON format:
{{
  "contradicts_beliefs": true/false,
  "contradiction_score": 0.0-1.0,
  "public_justification": "rule-based reason",
  "private_reasoning": "belief-based reason"
}}

Return ONLY JSON. Be concise - no explanations, no comments, no markdown, no extra text."""

        result = llm_service._complete_json(
            prompt,
            temperature=temperature,
            max_tokens=llm_service.config.max_tokens,
            label="Moderation analysis",
        )
        if not result.ok:
            log.error(f"Failed to parse LLM moderation response: {result.error}")
            return jsonify(
                {
                    "success": False,
                    "error": f"Failed to parse LLM response: {result.error}",
                    "contradicts_beliefs": False,
                    "contradiction_score": 0.0,
                    "public_justification": "",
                    "private_reasoning": "",
                }
            )
        data = result.data
        score = unit_float(data.get("contradiction_score", 0.0))
        return jsonify(
            {
                "success": True,
                "contradicts_beliefs": data.get("contradicts_beliefs", False),
                "contradiction_score": 0.0 if score is None else score,
                "public_justification": data.get("public_justification", ""),
                "private_reasoning": data.get("private_reasoning", ""),
            }
        )

    except Exception as e:
        log.error(f"Moderation analysis error: {e}")
        return (
            jsonify(
                {
                    "success": False,
                    "error": str(e),
                    "contradicts_beliefs": False,
                    "contradiction_score": 0.0,
                    "public_justification": "",
                    "private_reasoning": "",
                }
            ),
            500,
        )


def main():
    """Start the LLM service."""
    import argparse

    parser = argparse.ArgumentParser(description="LLM Reddit Service")
    parser.add_argument("--port", type=int, default=5000, help="Service port")
    parser.add_argument(
        "--provider", default="auto", help="LLM provider: auto|openai|local"
    )
    parser.add_argument(
        "--model", default="mistral-small-latest", help="LLM model name"
    )
    parser.add_argument(
        "--local-url", default="http://localhost:11434/v1", help="Local LLM endpoint"
    )
    parser.add_argument(
        "--temperature", type=float, default=0.7, help="Creativity temperature"
    )
    parser.add_argument(
        "--max-tokens", type=int, default=200, help="Max tokens per response"
    )

    args = parser.parse_args()

    logging.basicConfig(level=logging.INFO)

    config = LLMServiceConfig(
        provider=args.provider,
        model=args.model,
        local_base_url=args.local_url,
        creativity_temperature=args.temperature,
        max_tokens=args.max_tokens,
        port=args.port,
    )

    global llm_service
    llm_service = LLMRedditService(config)

    log.info(f"Starting LLM Reddit Service on port {args.port}")
    app.run(host="0.0.0.0", port=args.port, debug=False)


if __name__ == "__main__":
    main()
