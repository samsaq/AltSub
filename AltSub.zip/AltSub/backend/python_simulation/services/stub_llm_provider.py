#!/usr/bin/env python3
"""
Stub LLM provider: deterministic, network-free replies for tests and dry runs.

Selected with llm_config.provider = "stub". It has the LLMProvider interface used
by LLMRedditService, the orchestrator and the moderators (is_available,
chat_completion, chat_completion_meta), recognises each prompt the simulation
sends by a marker phrase, and returns a plausible reply of the right shape.

Replies depend only on the prompt text (SHA-256), never on call order or
threads, so a seeded run with this provider is reproducible end to end. The
content is not meaningful; it only exercises the simulation mechanics.
"""

import hashlib
import json
import re
from typing import Dict, List, Optional

from .llm_provider import LLMResponse

# Claims the extraction stub can "find" in content
_CLAIM_POOL = [
    "The latest patch made the game more balanced",
    "The developers ignore community feedback",
    "Recent changes improved the new player experience",
    "The current meta is dominated by a single strategy",
    "Seasonal content is worth the price",
    "Matchmaking quality has gotten worse",
    "The community is more positive than it used to be",
    "Endgame activities lack meaningful rewards",
]

_WORDS = [
    "honestly", "patch", "update", "community", "think", "experience", "really",
    "change", "players", "discussion", "season", "content", "balance", "feedback",
    "great", "worse", "better", "opinion", "anyone", "else", "noticed", "lately",
]

_BELIEF_LINE = re.compile(r"^- \[(b\d+)\].*\(strength: ([0-9.]+)\)\s*$", re.MULTILINE)
_AXIS_LINE = re.compile(r"^- \[(a\d+)\].*\(your acceptance: ([0-9.]+)\)\s*$", re.MULTILINE)


def _h(text: str, salt: str = "") -> int:
    return int(hashlib.sha256((salt + text).encode("utf-8")).hexdigest(), 16)


def _unit(h: int, salt: int = 0) -> float:
    """Deterministic float in [0, 1) from a hash."""
    return ((h >> (salt * 7)) % 10_000) / 10_000.0


def _sentence(h: int, n_words: int) -> str:
    words = [_WORDS[(h >> (i * 5)) % len(_WORDS)] for i in range(n_words)]
    return " ".join(words).capitalize() + "."


class StubLLMProvider:
    """Deterministic stand-in for LLMProvider (no network)."""

    provider = "stub"
    model = "stub"
    supports_json_mode = False
    max_output_tokens = 4096

    def is_available(self) -> bool:
        return True

    def get_provider_info(self) -> Dict[str, object]:
        return {"provider": self.provider, "model": self.model, "available": True}

    def chat_completion(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 500,
        **kwargs,
    ) -> Optional[str]:
        response = self.chat_completion_meta(messages, temperature, max_tokens, **kwargs)
        return response.content if response else None

    def chat_completion_meta(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 500,
        **kwargs,
    ) -> Optional[LLMResponse]:
        prompt = messages[-1]["content"] if messages else ""
        full = "\n".join(str(m.get("content", "")) for m in messages)
        return LLMResponse(content=self._respond(prompt, full), finish_reason="stop")


    def _respond(self, prompt: str, full: str) -> str:
        h = _h(full)
        if "Update how much you accept each of these belief statements" in prompt:
            return self._axis_update(prompt, h)
        if "update belief strengths" in prompt:
            return self._belief_update(prompt, h)
        if "Extract new beliefs/claims" in prompt:
            return self._extraction(prompt, h)
        if "determine voting likelihood" in prompt:
            up = 0.1 + 0.6 * _unit(h, 1)
            down = 0.4 * _unit(h, 2) * (1 - up)
            return json.dumps(
                {"upvote": round(up, 3), "downvote": round(down, 3),
                 "no_vote": round(max(0.0, 1 - up - down), 3)}
            )
        if '"target_posts"' in prompt:
            return self._campaign_plan(prompt, h)
        if "Judge ONLY whether the content violates the rules" in prompt:
            violates = h % 10 == 0
            return json.dumps(
                {"violates_rules": violates, "confidence": 0.9 if violates else 0.2,
                 "reason": "stub: rule violation" if violates else ""}
            )
        if '"contradicts_beliefs"' in prompt:
            contradicts = h % 7 == 0
            return json.dumps(
                {"contradicts_beliefs": contradicts,
                 "contradiction_score": 0.95 if contradicts else 0.1,
                 "public_justification": "stub: off-topic" if contradicts else "",
                 "private_reasoning": "stub" if contradicts else ""}
            )
        if "Generate a Reddit post" in prompt:
            return json.dumps(
                {"title": _sentence(h, 5).rstrip("."), "text": _sentence(h >> 40, 18)}
            )
        # Post replies ("...to this post") and comment replies ("...to a comment in a thread")
        if "You are replying to this post" in prompt or "You are replying to a comment" in prompt:
            return _sentence(h, 14)
        return "{}"

    @staticmethod
    def _belief_update(prompt: str, h: int) -> str:
        out = {}
        for i, (alias, strength) in enumerate(_BELIEF_LINE.findall(prompt)):
            r = _unit(h, i % 30)
            if r < 0.6:  # most beliefs untouched by any one item
                continue
            delta = 0.1 if r > 0.8 else -0.1
            out[alias] = round(min(1.0, max(0.0, float(strength) + delta)), 3)
        return json.dumps(out)

    @staticmethod
    def _axis_update(prompt: str, h: int) -> str:
        """Moves some axes by up to 0.2 (more than the 0.15 cap, so the cap is
        exercised), leaves the rest out (unchanged)."""
        out = {}
        for i, (alias, value) in enumerate(_AXIS_LINE.findall(prompt)):
            r = _unit(h, i % 30)
            if r < 0.5:
                continue
            delta = (r - 0.75) * 0.8  # -0.2 .. +0.2
            out[alias] = round(min(1.0, max(0.0, float(value) + delta)), 3)
        return json.dumps(out)

    @staticmethod
    def _extraction(prompt: str, h: int) -> str:
        n = h % 3  # 0-2 claims
        out = {}
        for i in range(n):
            claim = _CLAIM_POOL[(h >> (i * 8)) % len(_CLAIM_POOL)]
            out[claim] = round(0.4 + 0.5 * _unit(h, i + 3), 2)
        return json.dumps(out)

    @staticmethod
    def _campaign_plan(prompt: str, h: int) -> str:
        m = re.search(r"Generate exactly (\d+) posts", prompt)
        n = int(m.group(1)) if m else 1
        posts = []
        for i in range(n):
            start = (h >> (i * 5)) % 20
            posts.append(
                {"content": f"Campaign post {i}: {_sentence(h >> i, 12)}",
                 "start_hour": start, "end_hour": start + 3}
            )
        return json.dumps(
            {"target_posts": posts, "expected_outcomes": {"sentiment_alignment": 0.5},
             "risk_assessment": 0.3}
        )
