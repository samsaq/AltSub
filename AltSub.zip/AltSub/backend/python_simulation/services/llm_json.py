#!/usr/bin/env python3
"""
Robust JSON from LLM calls, shared by every caller that asks an LLM for JSON.

Layers:
  1. JSON mode (response_format json_object) when the provider supports it, so
     replies are syntactically valid JSON in the first place.
  2. Truncation from the API's finish_reason ("length"), not guessed from the
     text: only then retry with more tokens, capped at the model's output limit.
  3. Parse (tolerating literal newlines in strings), then repair with
     json_repair (stray quotes, trailing commas, comments, missing brackets),
     then one retry that sends the parse/validation error back to the model.
  4. Optional validate(data) -> (data or None, error) for the expected shape.

Callers get a JSONResult with status "ok" / "repaired" / "retried" / "failed"
and decide their own fallback, logging it rather than failing silently.

Example of the failure this replaced: mistral-small returned
'..."end_hour": 11"}...' (stray quote); the old quote-counting truncation guess
read it as truncated, retried with 20000 then 40000 tokens, then fell back.
"""

import json
import logging
import math
import re
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional, Tuple

import json_repair

log = logging.getLogger(__name__)

Validator = Callable[[Any], Tuple[Optional[Any], str]]


@dataclass
class JSONResult:
    data: Any = None
    status: str = "failed"  # ok | repaired | retried | failed
    raw: str = ""
    error: str = ""

    @property
    def ok(self) -> bool:
        return self.data is not None


def extract_json_text(text: str) -> str:
    """The JSON part of an LLM reply: inside a ``` fence if present (closed or
    not), trimmed to the outermost {...} or [...] span."""
    text = (text or "").strip()
    fence = re.search(r"```(?:json|JSON)?\s*(.*?)(?:```|$)", text, re.S)
    if fence:
        text = fence.group(1).strip()
    starts = [i for i in (text.find("{"), text.find("[")) if i != -1]
    if not starts:
        return text
    start = min(starts)
    end = max(text.rfind("}"), text.rfind("]"))
    return text[start : end + 1] if end > start else text[start:]


def _unwrap(data: Any, expect: type, wrap_key: Optional[str]) -> Any:
    """JSON mode only allows a top-level object, so list results are requested
    as {wrap_key: [...]}; accept either form."""
    if expect is list and isinstance(data, dict):
        if wrap_key and isinstance(data.get(wrap_key), list):
            return data[wrap_key]
        lists = [v for v in data.values() if isinstance(v, list)]
        if len(lists) == 1:
            return lists[0]
    return data


def parse_json_text(
    text: str,
    expect: type = dict,
    wrap_key: Optional[str] = None,
    validate: Optional[Validator] = None,
) -> Tuple[Optional[Any], str, str]:
    """Parse an LLM reply. Returns (data or None, status, error)."""
    candidate = extract_json_text(text)
    status = "ok"
    try:
        data = json.loads(candidate, strict=False)
    except (json.JSONDecodeError, ValueError):
        try:
            data = json_repair.loads(candidate)
        except Exception as e:
            return None, "failed", f"unparseable JSON ({e})"
        status = "repaired"
    data = _unwrap(data, expect, wrap_key)
    if not isinstance(data, expect):
        return None, "failed", (
            f"expected a JSON {'object' if expect is dict else 'array'}, "
            f"got {type(data).__name__}"
        )
    if validate is not None:
        data, err = validate(data)
        if data is None:
            return None, "failed", err or "failed validation"
    return data, status, ""


def complete_json(
    provider: Any,
    messages: List[Dict[str, str]],
    *,
    temperature: float,
    max_tokens: int,
    expect: type = dict,
    wrap_key: Optional[str] = None,
    validate: Optional[Validator] = None,
    json_mode: bool = True,
    feedback_retries: int = 1,
    label: str = "LLM JSON",
) -> JSONResult:
    """Call the LLM and return parsed JSON (see module docstring).

    For list results with json_mode, phrase the prompt as {wrap_key: [...]}.
    """
    if provider is None or not provider.is_available():
        return JSONResult(error="no LLM provider available")

    kwargs: Dict[str, Any] = {}
    if json_mode and getattr(provider, "supports_json_mode", False) and (
        expect is dict or wrap_key
    ):
        kwargs["response_format"] = {"type": "json_object"}

    msgs = list(messages)
    tokens = int(max_tokens)
    cap = int(getattr(provider, "max_output_tokens", tokens))
    used_feedback = False
    while True:
        response = provider.chat_completion_meta(msgs, temperature, tokens, **kwargs)
        if response is None:
            return JSONResult(error="LLM request failed or returned no content")

        data, status, err = parse_json_text(response.content, expect, wrap_key, validate)

        if response.finish_reason == "length":
            bigger = min(tokens * 2, cap)
            if bigger > tokens:
                log.warning(f"{label}: reply cut off at {tokens} tokens, retrying with {bigger}")
                tokens = bigger
                continue
            if data is not None:
                log.warning(f"{label}: reply cut off at the {cap}-token limit; using repaired partial JSON")
                return JSONResult(data, "repaired", response.content)
            err = err or f"reply cut off at the {cap}-token limit"

        if data is not None:
            if status == "repaired":
                log.info(f"{label}: repaired malformed JSON")
            return JSONResult(data, "retried" if used_feedback else status, response.content)

        if feedback_retries > 0:
            feedback_retries -= 1
            used_feedback = True
            log.warning(f"{label}: invalid reply ({err}); asking the model to correct it")
            msgs = list(messages) + [
                {"role": "assistant", "content": response.content},
                {
                    "role": "user",
                    "content": f"That reply was not valid: {err}. "
                    "Return ONLY the corrected JSON, with no other text.",
                },
            ]
            continue

        log.warning(f"{label}: giving up after invalid reply ({err})")
        return JSONResult(None, "failed", response.content, err)


# Value helpers for validators

def unit_float(value: Any) -> Optional[float]:
    """value as a float clamped to [0, 1]; None if not a finite number."""
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(f):
        return None
    return max(0.0, min(1.0, f))


def require_unit_floats(*keys: str, defaults: Optional[Dict[str, float]] = None) -> Validator:
    """Validator: each key must be a finite number (clamped to [0, 1]); keys
    in defaults may be missing or invalid and take the default instead."""
    defaults = defaults or {}

    def validate(data: Dict[str, Any]) -> Tuple[Optional[Dict[str, Any]], str]:
        out = dict(data)
        for key in keys:
            value = unit_float(data.get(key))
            if value is None:
                if key not in defaults:
                    return None, f'"{key}" must be a number between 0 and 1'
                value = defaults[key]
            out[key] = value
        return out, ""

    return validate


def hour_of_day(value: Any) -> Optional[int]:
    """Hour 0-23 from 6, 6.0, "6", "06:00", "6am", "6pm"; 24 means end of day -> 23."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        if not math.isfinite(value):
            return None
        h = int(value)
    else:
        m = re.match(r"\s*(\d{1,2})(?::\d{2})?\s*(am|pm)?\s*$", str(value), re.I)
        if not m:
            return None
        h = int(m.group(1))
        suffix = (m.group(2) or "").lower()
        if suffix == "pm" and h < 12:
            h += 12
        elif suffix == "am" and h == 12:
            h = 0
    if h == 24:
        return 23
    return h if 0 <= h <= 23 else None
