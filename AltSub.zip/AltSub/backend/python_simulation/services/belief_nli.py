#!/usr/bin/env python3
"""
Belief NLI: polarity-aware equivalence checks between belief texts.

Embedding similarity measures topic, not stance: with all-MiniLM-L6-v2,
"The new expansion is worth buying" and "The new expansion is not worth buying"
score ~0.94. Anywhere beliefs are merged by similarity, embeddings are only used
to find candidates, and this NLI cross-encoder decides whether two candidate
texts are the same belief (see BeliefNLI.same_belief_many).
"""

import logging
import threading
from typing import Dict, List, Sequence, Tuple

import numpy as np

log = logging.getLogger(__name__)

DEFAULT_NLI_MODEL = "cross-encoder/nli-deberta-v3-small"

# Cached pair scores are cleared past this size to bound memory in long runs
_MAX_CACHE_PAIRS = 100_000


class BeliefNLI:
    """NLI cross-encoder wrapper with a thread-safe pair-score cache."""

    def __init__(
        self,
        model_name: str = DEFAULT_NLI_MODEL,
        entailment_threshold: float = 0.5,
        contradiction_threshold: float = 0.5,
        high_similarity: float = 0.85,
    ):
        """
        Args:
            model_name: sentence-transformers CrossEncoder NLI model
            entailment_threshold: Min entailment probability (either direction)
                for a candidate to count as the same belief
            contradiction_threshold: Contradiction probability (either direction)
                at or above which two texts are never the same belief
            high_similarity: Embedding similarity at or above which a
                non-contradicting candidate counts as the same belief even
                without entailment
        """
        from sentence_transformers import CrossEncoder

        self.model_name = model_name
        self.entailment_threshold = entailment_threshold
        self.contradiction_threshold = contradiction_threshold
        self.high_similarity = high_similarity
        self._model = CrossEncoder(model_name)

        # Label order differs between NLI models, so read it from the config
        labels = {
            str(name).lower(): int(idx)
            for idx, name in self._model.model.config.id2label.items()
        }
        self._entail_idx = labels["entailment"]
        self._contra_idx = labels["contradiction"]

        self._cache: Dict[Tuple[str, str], np.ndarray] = {}
        self._lock = threading.Lock()
        log.info(f"BeliefNLI: Loaded {model_name}")

    def _probs(self, pairs: Sequence[Tuple[str, str]]) -> List[np.ndarray]:
        """Softmax label probabilities for each (premise, hypothesis) pair."""
        with self._lock:
            missing = list(dict.fromkeys(p for p in pairs if p not in self._cache))
            if missing:
                if len(self._cache) + len(missing) > _MAX_CACHE_PAIRS:
                    self._cache.clear()
                scores = self._model.predict(
                    missing, apply_softmax=True, show_progress_bar=False
                )
                for pair, score in zip(missing, scores):
                    self._cache[pair] = np.asarray(score)
            return [self._cache[p] for p in pairs]

    def same_belief_many(
        self,
        pairs: Sequence[Tuple[str, str]],
        similarities: Sequence[float],
    ) -> List[bool]:
        """For each candidate (a, b) with embedding similarity s, whether they are
        the same belief:

        - never, if either direction is a contradiction ("X" vs "not X");
        - yes, if either text entails the other (a more specific wording of the
          same claim counts as the same belief);
        - yes, if s >= high_similarity (near-identical wording that NLI scores
          neutral, e.g. two compound claims differing in one detail);
        - otherwise no.

        Requiring two-way entailment instead is too strict for LLM-extracted
        beliefs: in a smoke run it split near-duplicates at similarity 0.95.
        """
        if not pairs:
            return []
        directed = [d for a, b in pairs for d in ((a, b), (b, a))]
        probs = self._probs(directed)
        out = []
        for i, sim in enumerate(similarities):
            fwd, rev = probs[2 * i], probs[2 * i + 1]
            if max(fwd[self._contra_idx], rev[self._contra_idx]) >= self.contradiction_threshold:
                out.append(False)
            elif max(fwd[self._entail_idx], rev[self._entail_idx]) >= self.entailment_threshold:
                out.append(True)
            else:
                out.append(bool(sim >= self.high_similarity))
        return out

    def contradicts_many(self, pairs: Sequence[Tuple[str, str]]) -> List[bool]:
        """For each (a, b): True if either text contradicts the other."""
        if not pairs:
            return []
        directed = [d for a, b in pairs for d in ((a, b), (b, a))]
        probs = self._probs(directed)
        t = self.contradiction_threshold
        return [
            bool(max(probs[2 * i][self._contra_idx], probs[2 * i + 1][self._contra_idx]) >= t)
            for i in range(len(pairs))
        ]


_instances: Dict[str, BeliefNLI] = {}
_instances_lock = threading.Lock()


def get_belief_nli(model_name: str = DEFAULT_NLI_MODEL) -> BeliefNLI:
    """Shared BeliefNLI per model, so the cross-encoder is loaded once per process."""
    with _instances_lock:
        if model_name not in _instances:
            _instances[model_name] = BeliefNLI(model_name)
        return _instances[model_name]
