#!/usr/bin/env python3
"""
Subreddit seed context: real recent discussion for the attacker orchestrator's
day-0 plan.

The simulation starts with an empty subreddit, so on day 0 the orchestrator has
no previous-day posts to plan against. The initializer (which already has the
Reddit SQLite DB open) samples the last day of real activity and saves it to
subreddit_seed_context.json in the setup dir; run_simulation hands it to the
orchestrator as day -1 data. Same post/comment dict shape the sim stores per day.

Standalone, for setups initialized before this existed:
    python -m python_simulation.services.subreddit_seed_context \
        --db-path DB.db --subreddit destiny2 --output-dir SETUP_DIR
"""

import argparse
import json
import logging
import sqlite3
from pathlib import Path
from typing import Any, Dict, Optional

log = logging.getLogger(__name__)

SEED_CONTEXT_FILENAME = "subreddit_seed_context.json"

# Not organic discussion: deleted accounts, bots and mod-team accounts
_EXCLUDED_AUTHOR_SQL = (
    "author IS NOT NULL AND author NOT IN ('[deleted]', 'AutoModerator') "
    "AND author NOT LIKE '%-ModTeam'"
)
_REMOVED_TEXT = ("[removed]", "[deleted]")


def _truncate(text: str, max_chars: int) -> str:
    text = (text or "").strip()
    return text if len(text) <= max_chars else text[: max_chars - 3] + "..."


def build_seed_context(
    conn: sqlite3.Connection,
    subreddit: str,
    window_hours: int = 24,
    num_posts: int = 10,
    comments_per_post: int = 5,
    max_post_chars: int = 1000,
    max_comment_chars: int = 400,
) -> Dict[str, Any]:
    """Top posts (and their top top-level comments) from the last window_hours of the DB."""
    row = conn.execute(
        "SELECT MAX(created_utc) FROM submissions WHERE subreddit = ? COLLATE NOCASE",
        (subreddit,),
    ).fetchone()
    if not row or row[0] is None:
        log.warning(f"Seed context: no submissions for r/{subreddit}")
        return {"posts": [], "comments": []}
    window_start = row[0] - window_hours * 3600

    post_rows = conn.execute(
        f"""SELECT id, title, selftext, score FROM submissions
            WHERE subreddit = ? COLLATE NOCASE AND created_utc > ?
              AND {_EXCLUDED_AUTHOR_SQL}
              AND COALESCE(stickied, 0) = 0 AND distinguished IS NULL
            ORDER BY score DESC LIMIT ?""",
        (subreddit, window_start, num_posts),
    ).fetchall()

    posts, comments = [], []
    for post_id, title, selftext, score in post_rows:
        body = "" if (selftext or "").strip() in _REMOVED_TEXT else (selftext or "")
        content = f"{(title or '').strip()}\n\n{body.strip()}".strip()
        posts.append(
            {
                "event_id": f"t3_{post_id}",
                "type": "post",
                "content": _truncate(content, max_post_chars),
                "score": score or 0,
                "author_type": "regular",
            }
        )
        for (body_text, c_score) in conn.execute(
            f"""SELECT body, score FROM comments
                WHERE link_id = ? AND parent_id = link_id
                  AND {_EXCLUDED_AUTHOR_SQL}
                  AND body NOT IN ('[removed]', '[deleted]')
                ORDER BY score DESC LIMIT ?""",
            (f"t3_{post_id}", comments_per_post),
        ):
            comments.append(
                {
                    "root_post_id": f"t3_{post_id}",
                    "type": "reply",
                    "content": _truncate(body_text, max_comment_chars),
                    "score": c_score or 0,
                    "author_type": "regular",
                }
            )

    log.info(
        f"Seed context: {len(posts)} posts, {len(comments)} comments from the last "
        f"{window_hours}h of r/{subreddit}"
    )
    return {"posts": posts, "comments": comments, "source": "reddit_db", "subreddit": subreddit}


def save_seed_context(context: Dict[str, Any], output_dir: str) -> Path:
    path = Path(output_dir) / SEED_CONTEXT_FILENAME
    with open(path, "w", encoding="utf-8") as f:
        json.dump(context, f, indent=2, ensure_ascii=False)
    return path


def load_seed_context(config_dir: Path) -> Optional[Dict[str, Any]]:
    path = Path(config_dir) / SEED_CONTEXT_FILENAME
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s - %(message)s")
    parser = argparse.ArgumentParser(description="Build subreddit_seed_context.json for a setup")
    parser.add_argument("--db-path", required=True)
    parser.add_argument("--subreddit", required=True)
    parser.add_argument("--output-dir", required=True, help="Setup dir (where simulation_config.json is)")
    args = parser.parse_args()
    conn = sqlite3.connect(f"file:{args.db_path}?mode=ro", uri=True)
    try:
        path = save_seed_context(build_seed_context(conn, args.subreddit), args.output_dir)
    finally:
        conn.close()
    print(f"Wrote {path}")


if __name__ == "__main__":
    main()
