"""Belief statements model ("axes"): definitions, acceptance semantics, LLM updates,
agents, resolution."""

import json
from pathlib import Path

import numpy as np
import pytest

from python_simulation.agents.biased_moderator_agent import BiasedModeratorAgent
from python_simulation.agents.llm_user_agent import LLMUserAgent, ParseResult
from python_simulation.core.belief_axes import (
    DEFAULT_AXIS_SETS,
    BeliefAxis,
    BeliefConfig,
    alignment,
    belief_config_for_set,
    campaign_positions,
    complete_positions,
    default_belief_config,
    format_acceptance,
    load_belief_config,
    prior_positions,
    resolve_belief_config,
    strongest_axis,
)
from python_simulation.core.simulation_data import EventType, SimulationState

from .test_services import ScriptedProvider
from ..factories import SUB, ev, make_world, stub_llm_service

AXES = [
    BeliefAxis("x", "X is good", "Domain X"),
    BeliefAxis("y", "Y is fair", "Domain Y"),
    BeliefAxis("z", "Z helps", "Domain Z", prior_mean=0.3),
]
CONFIG = BeliefConfig("axes", list(AXES), {"x": 0.9, "y": 0.8}, "test")
SETUPS_DIR = Path(__file__).resolve().parents[4] / "Simulation_Setups" / "belief_axes"


# --- definitions -----------------------------------------------------------------


def test_validation_rejects_bad_configs():
    with pytest.raises(ValueError):
        BeliefConfig("axes", []).validate()
    with pytest.raises(ValueError):
        BeliefConfig("axes", [AXES[0], AXES[0]]).validate()
    with pytest.raises(ValueError):
        BeliefConfig("axes", list(AXES), {"nope": 0.5}).validate()
    with pytest.raises(ValueError):
        BeliefConfig("axes", list(AXES), {"x": 1.5}).validate()
    with pytest.raises(ValueError):
        BeliefConfig("bogus", list(AXES)).validate()
    with pytest.raises(ValueError):
        BeliefConfig("axes", [BeliefAxis("a", "  ")]).validate()
    old = {"model": "axes", "axes": [{"id": "a", "label": "A", "pole_0": "p", "pole_1": "q"}]}
    with pytest.raises(ValueError, match="two-pole"):
        BeliefConfig.from_dict(old)


def test_round_trip_and_builtin_sets_are_valid():
    assert BeliefConfig.from_dict(CONFIG.to_dict()) == CONFIG
    for key in DEFAULT_AXIS_SETS:
        config = belief_config_for_set(key)
        assert config.axes and config.source == f"default:{key}"
    # thesis belief spaces: C1-C7 and P1-P6
    assert belief_config_for_set("destiny2").axis_ids == [f"C{i}" for i in range(1, 8)]
    assert belief_config_for_set("politics").axis_ids == [f"P{i}" for i in range(1, 7)]


def test_resolution_order(tmp_path):
    assert default_belief_config("DestinyTheGame").source == "default:destiny2"
    assert default_belief_config("politics").source == "default:politics"
    assert default_belief_config("worldnews").source == "default:politics"
    assert default_belief_config("aww").source == "default:generic"
    path = tmp_path / "axes.json"
    path.write_text(json.dumps(CONFIG.to_dict()))
    from_file = resolve_belief_config("destiny2", str(path))
    assert from_file.axis_ids == ["x", "y", "z"] and from_file.source == "file:axes.json"
    assert resolve_belief_config("destiny2", str(path), model="free_text").model == "free_text"


@pytest.mark.parametrize("name", sorted(DEFAULT_AXIS_SETS))
def test_setup_axis_files_match_builtin_sets(name):
    """Simulation_Setups/belief_axes/*.json are generated from DEFAULT_AXIS_SETS
    (python -m python_simulation.core.belief_axes <dir>); regenerate after edits."""
    from_file = load_belief_config(SETUPS_DIR / f"{name}.json")
    builtin = belief_config_for_set(name)
    assert from_file.axes == builtin.axes
    assert from_file.campaign_targets == builtin.campaign_targets


# --- value semantics ----------------------------------------------------------------


def test_format_acceptance_shows_the_value():
    axis = AXES[0]
    assert format_acceptance(axis, 0.52) == '"X is good" (acceptance: 0.52)'
    assert format_acceptance(axis, 1.4) == '"X is good" (acceptance: 1.00)'


def test_campaign_targets_are_extremes_and_users_start_neutral():
    d2 = belief_config_for_set("destiny2")
    assert d2.campaign_targets == {"C1": 0.0, "C2": 0.0, "C3": 0.0, "C4": 0.0,
                                   "C5": 1.0, "C6": 1.0, "C7": 1.0}
    pol = belief_config_for_set("politics")
    assert pol.campaign_targets == {"P1": 0.0, "P2": 0.0, "P3": 0.0, "P4": 1.0,
                                    "P5": 0.0, "P6": 0.0}
    for config in (d2, pol):
        assert set(prior_positions(config).values()) == {0.5}
        assert campaign_positions(config) == config.campaign_targets


def test_strongest_axis_alignment_and_positions():
    assert strongest_axis({"x": 0.6, "y": 0.1, "z": 0.5}) == "y"
    assert strongest_axis({}) == "default"
    assert alignment({"x": 0.9, "y": 0.8, "z": 0.0}, CONFIG.campaign_targets) == pytest.approx(1.0)
    assert alignment({"x": 0.1, "y": 0.8}, CONFIG.campaign_targets) == pytest.approx(0.6)
    assert alignment({"x": 0.5}, {}) is None
    assert campaign_positions(CONFIG) == {"x": 0.9, "y": 0.8, "z": 0.5}
    assert complete_positions(CONFIG, {"x": 1.4, "y": "bad", "z": None}) == {"x": 1.0, "y": 0.5, "z": 0.3}
    sampled = BeliefConfig("axes", [BeliefAxis("s", "S holds", "S", 0.5, 0.2)])
    values = [prior_positions(sampled, np.random.default_rng(i))["s"] for i in range(200)]
    assert 0.0 <= min(values) and max(values) <= 1.0 and np.std(values) > 0.1


# --- LLM service ----------------------------------------------------------------------


def test_axis_update_is_capped_and_ignores_unknown_keys():
    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([('{"a1": 1.0, "a2": 0.45, "a9": 0.1, "a3": "x"}', "stop")])
    out = svc.update_axis_positions("content", {"x": 0.5, "y": 0.5, "z": 0.3}, AXES)
    cap = svc.config.belief_update_max_change
    assert out == {"x": pytest.approx(0.5 + cap), "y": pytest.approx(0.45), "z": 0.3}
    prompt = svc._llm_provider.calls[0]["messages"][0]["content"]
    assert '- [a1] "X is good" (your acceptance: 0.50)' in prompt
    assert "0.0 (complete rejection) through 0.5 (neutral) to 1.0 (complete acceptance)" in prompt


def test_axis_update_failure_and_empty_content_leave_positions():
    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([])
    assert svc.update_axis_positions("content", {"x": 0.2}, AXES[:1]) == {"x": 0.2}
    assert svc.update_axis_positions("   ", {"x": 0.2}, AXES[:1]) == {"x": 0.2}


def test_stub_axis_update_stays_within_cap():
    svc = stub_llm_service()
    positions = {"x": 0.0, "y": 0.5, "z": 1.0}
    for i in range(30):
        new = svc.update_axis_positions(f"content number {i}", positions, AXES)
        assert all(abs(new[a] - positions[a]) <= svc.config.belief_update_max_change + 1e-9 for a in new)
        assert all(0.0 <= v <= 1.0 for v in new.values())
        positions = new


def test_axis_context_lists_stances_strongest_first():
    svc = stub_llm_service()
    lines = svc._format_axis_context({"x": 0.55, "y": 0.1, "z": 0.75}, AXES)
    assert lines == [
        "(acceptance of each statement: 0.0 = complete rejection, 0.5 = neutral, "
        "1.0 = complete acceptance)",
        '- "X is good" (acceptance: 0.55)',
        '- "Y is fair" (acceptance: 0.10)',
        '- "Z helps" (acceptance: 0.75)',
    ]
    svc.config.max_beliefs_in_prompt = 2  # strongest two, definition order kept
    assert svc._format_axis_context({"x": 0.55, "y": 0.1, "z": 0.75}, AXES)[1:] == [
        '- "Y is fair" (acceptance: 0.10)', '- "Z helps" (acceptance: 0.75)',
    ]


# --- agents ---------------------------------------------------------------------------


def axes_user(service=None, positions=None):
    agent = LLMUserAgent(0, positions or {"x": 0.5, "y": 0.2, "z": 0.8}, SUB, {"read": 5},
                         np.ones(4, bool), llm_service=service or stub_llm_service())
    agent.axes = list(AXES)
    agent.seed_rng(0)
    return agent


def test_axes_reading_uses_one_llm_call_and_no_extraction():
    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([('{"a1": 0.6}', "stop")])
    agent = axes_user(svc)
    state, am = make_world(2)
    item = am.commit_event(ev(1, EventType.POST, content="A long enough post about X and Y"), 0)
    agent.parse(item, state)
    assert len(svc._llm_provider.calls) == 1
    assert agent.beliefs == {"x": 0.6, "y": 0.2, "z": 0.8}
    assert state.belief_network.get_agent_beliefs(0) == agent.beliefs


def test_axes_job_path_equals_direct_and_merges_deltas():
    state, am = make_world(2)
    item = am.commit_event(ev(1, EventType.POST, content="Some content to react to"), 0)
    direct, staged = axes_user(), axes_user()
    direct.parse(item, state)
    staged.apply_parse_result(staged.parse_job(item, state)(), state)
    assert direct.beliefs == staged.beliefs
    agent = axes_user()
    result = ParseResult({"x": 0.5, "y": 0.2, "z": 0.8}, {"x": 0.6, "y": 0.2, "z": 0.7})
    agent.beliefs["z"] = 0.9  # changed meanwhile
    merged = agent._merge_llm_update(result)
    assert merged["x"] == 0.6 and merged["z"] == pytest.approx(0.8)


def test_axes_prompts_and_belief_tag():
    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([("A reply", "stop")])
    agent = axes_user(svc, {"x": 0.95, "y": 0.5, "z": 0.5})
    state, am = make_world(2)
    item = am.commit_event(ev(1, EventType.POST), 0)
    reply = agent.reply(item, state)
    assert reply.belief_id == "x"
    prompt = svc._llm_provider.calls[0]["messages"][0]["content"]
    assert '- "X is good" (acceptance: 0.95)' in prompt and "complete rejection" in prompt


def test_biased_moderator_prompt_lists_campaign_targets():
    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([('{"contradicts_beliefs": false, "contradiction_score": 0.1}', "stop")])
    mod = BiasedModeratorAgent(9, {"x": 0.9}, SUB, {"read": 1}, np.ones(2, bool), llm_service=svc)
    mod.axes, mod.campaign_targets = list(AXES), {"x": 0.9}
    mod.analyze_content("some content")
    prompt = svc._llm_provider.calls[0]["messages"][0]["content"]
    assert '- "X is good" (acceptance: 0.90)' in prompt and "Y is" not in prompt
    assert "complete rejection" in prompt


# --- runtime model resolution -------------------------------------------------------


def test_run_belief_model_resolution(monkeypatch):
    from python_simulation.run_simulation import resolve_run_belief_config

    monkeypatch.delenv("SIM_BELIEF_MODEL", raising=False)
    sim = {"simulation_config": {"target_subreddit": "politics"}}
    assert resolve_run_belief_config(sim, {}) is None  # older config: free text
    with_block = {**sim, "belief_config": CONFIG.to_dict()}
    assert resolve_run_belief_config(with_block, {}).axis_ids == ["x", "y", "z"]
    assert resolve_run_belief_config(with_block, {"belief_model": "free_text"}) is None
    forced = resolve_run_belief_config(sim, {"belief_model": "axes"})
    assert forced.source == "default:politics"  # no axes in config: built-in set
    monkeypatch.setenv("SIM_BELIEF_MODEL", "free_text")
    assert resolve_run_belief_config(with_block, {"belief_model": "axes"}) is None


def test_likert_labels_use_the_nearest_anchor():
    from python_simulation.core.belief_axes import acceptance_label, format_value

    assert [acceptance_label(v) for v in (0.0, 0.1, 0.2, 0.5, 0.62, 0.63, 0.9, 1.0)] == [
        "completely rejects", "completely rejects", "rejects", "neutral", "neutral", "accepts",
        "completely accepts", "completely accepts",
    ]
    assert acceptance_label(0.125) == "rejects"  # tie goes to the more neutral anchor
    assert format_value(0.25, verbal=True) == "0.25, rejects" and format_value(0.25) == "0.25"


def test_verbal_labels_switch_changes_context_and_update_prompts():
    svc = stub_llm_service(verbal_acceptance_labels=True)
    lines = svc._format_axis_context({"x": 0.2, "y": 0.5, "z": 0.8}, AXES)
    assert "0.25 = rejects" in lines[0] and lines[1] == '- "X is good" (acceptance: 0.20, rejects)'
    svc._llm_provider = ScriptedProvider([('{"a1": 0.2}', "stop")])
    svc.update_axis_positions("content", {"x": 0.2, "y": 0.5, "z": 0.8}, AXES)
    prompt = svc._llm_provider.calls[0]["messages"][0]["content"]
    assert '(your acceptance: 0.20, rejects)' in prompt and "1.00 = completely accepts" in prompt


def test_llm_attacker_writes_with_its_campaign_brief():
    from python_simulation.agents.llm_attacker_agent import LLMAttackerAgent

    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([("A reply", "stop"), ('{"title": "t", "text": "x"}', "stop")])
    attacker = LLMAttackerAgent(0, {"x": 1.0}, SUB, {"read": 1}, np.ones(4, bool), llm_service=svc,
                                campaign_brief="X is great, spread the word.")
    attacker.axes = list(AXES)
    attacker.seed_rng(0)
    state, am = make_world(2)
    item = am.commit_event(ev(1, EventType.POST), 0)
    attacker.reply(item, state)
    attacker.natural_post_job(state)()
    for call in svc._llm_provider.calls:
        prompt = call["messages"][0]["content"]
        assert "You are posting to promote this narrative" in prompt and "X is great" in prompt
    # organic users never get a brief
    user = axes_user(svc)
    svc._llm_provider = ScriptedProvider([("A reply", "stop")])
    user.reply(item, state)
    assert "promote this narrative" not in svc._llm_provider.calls[0]["messages"][0]["content"]


def test_attacker_confrontation_guard_switch_affects_only_attackers():
    line = "Avoids being confrontational unless your beliefs strongly oppose"
    for guard in (True, False):
        svc = stub_llm_service(attacker_avoid_confrontation=guard)
        svc._llm_provider = ScriptedProvider([("r", "stop"), ("r", "stop")])
        svc.generate_reply_content("A post", {"x": 1.0}, SUB, axes=AXES, campaign_brief="Push X.")
        svc.generate_reply_content("A post", {"x": 0.5}, SUB, axes=AXES)  # organic: no brief
        attacker, organic = (c["messages"][0]["content"] for c in svc._llm_provider.calls)
        assert (line in attacker) is guard
        assert line in organic
