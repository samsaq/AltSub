"""Feed ordering strategies and the FeedManager."""

import numpy as np
import pytest

from python_simulation.core.feed_system import (
    ChronologicalFeedOrderingStrategy,
    DefaultFeedOrderingStrategy,
    EngagementWeightedFeedOrderingStrategy,
    FeedManager,
    RedditHotFeedOrderingStrategy,
    ScoreBasedFeedOrderingStrategy,
)
from python_simulation.core.simulation_data import EventType

from ..factories import ev, make_world


def _posts(am, times, author=0):
    return [am.commit_event(ev(author, EventType.POST), 0, time_s=t) for t in times]


def test_chronological_newest_first_with_limit():
    state, am = make_world()
    a, b, c = _posts(am, [100, 300, 200])
    strat = ChronologicalFeedOrderingStrategy()
    assert strat.order_feed([a, b, c], 1, state) == [b, c, a]
    assert strat.order_feed([a, b, c], 1, state, max_items=1) == [b]


def test_default_replies_to_own_content_come_first():
    state, am = make_world()
    mine = am.commit_event(ev(1, EventType.POST), 0, time_s=0)
    other = am.commit_event(ev(2, EventType.POST), 0, time_s=900)
    reply_to_me = am.commit_event(ev(0, EventType.REPLY, mine.event_id), 0, time_s=10)
    strat = DefaultFeedOrderingStrategy(shuffle_percentage=0)
    assert strat.order_feed([other, reply_to_me], 1, state)[0] is reply_to_me


def test_default_score_is_children_times_time_and_votes_do_not_count():
    state, am = make_world(6)
    old, new = _posts(am, [300, 600])
    for voter in (1, 2, 3, 4):
        am.commit_event(ev(voter, EventType.UPVOTE, old.event_id), 0)
    strat = DefaultFeedOrderingStrategy(shuffle_percentage=0)
    assert strat.order_feed([old, new], 5, state) == [new, old]
    # Two replies triple the child factor: 3 * 300 > 1 * 600
    for replier in (1, 2):
        am.commit_event(ev(replier, EventType.REPLY, old.event_id), 0, time_s=700)
    assert strat.order_feed([old, new], 5, state)[0] is old


def test_default_shuffle_is_seeded_and_keeps_items():
    state, am = make_world()
    posts = _posts(am, range(0, 3000, 100))

    def order(seed):
        strat = DefaultFeedOrderingStrategy(shuffle_percentage=0.3)
        strat.rng = np.random.default_rng(seed)
        return strat.order_feed(list(posts), 1, state)

    assert order(1) == order(1)
    assert order(1) != order(2)
    assert sorted(e.event_id for e in order(1)) == sorted(e.event_id for e in posts)


def test_score_based_ties_negatives_and_decay():
    state, am = make_world()
    old, new = _posts(am, [0, 3000])
    state.now_s = 6000
    strat = ScoreBasedFeedOrderingStrategy(recency_decay=0.95)
    assert strat.order_feed([old, new], 1, state) == [new, old]  # zero scores: newest first
    old.score = new.score = -1
    assert strat.order_feed([old, new], 1, state) == [new, old]  # older sinks
    old.score, new.score = 5, 1
    assert strat.order_feed([old, new], 1, state) == [old, new]  # 5 * 0.95^20 > 1 * 0.95^10


def test_decay_is_per_reference_step_not_per_second():
    state, am = make_world()
    (post,) = _posts(am, [0])
    post.score = 1
    state.now_s = 300.0  # one reference step
    assert ScoreBasedFeedOrderingStrategy(0.5).calculate_score(post, 1.0) == pytest.approx(0.5)
    strat = ScoreBasedFeedOrderingStrategy(0.5)
    ranked = strat.order_feed([post], 1, state)
    assert ranked == [post]


def test_engagement_weighted_boosts_replies_to_viewer():
    state, am = make_world()
    mine = am.commit_event(ev(1, EventType.POST), 0, time_s=0)
    reply = am.commit_event(ev(2, EventType.REPLY, mine.event_id), 0, time_s=0)
    other = am.commit_event(ev(2, EventType.POST), 0, time_s=0)
    for voter in (0, 3):
        am.commit_event(ev(voter, EventType.UPVOTE, reply.event_id), 0)
        am.commit_event(ev(voter, EventType.UPVOTE, other.event_id), 0)
    am.commit_event(ev(1, EventType.UPVOTE, other.event_id), 0)
    state.now_s = 0
    strat = EngagementWeightedFeedOrderingStrategy(reply_priority_boost=2.0)
    # reply: 2 votes x2 boost = 4 beats other: 3 votes
    assert strat.order_feed([other, reply], 1, state)[0] is reply


def test_reddit_hot_trades_votes_against_age():
    state, am = make_world(13)
    old, new = _posts(am, [0, 45000])  # 45000 s = one log10 vote unit
    strat = RedditHotFeedOrderingStrategy()
    assert strat.order_feed([old, new], 12, state)[0] is new
    for voter in range(1, 12):  # 11 net upvotes: log10(11) > 1
        am.commit_event(ev(voter, EventType.UPVOTE, old.event_id), 0)
    assert strat.order_feed([old, new], 12, state)[0] is old


def test_feed_manager_lifecycle():
    state, am = make_world(3)
    fm = am.feed_manager
    a, b = _posts(am, [0, 10], author=0)
    assert list(fm.users_feed[1]) == [a.event_id, b.event_id]
    assert fm.users_feed[0] == {}  # own posts
    fm.mark_read(1, a.event_id)
    assert fm.get_unread_count(1) == 1
    fm.update_feeds([a], state)  # already read: never re-added
    assert a.event_id not in fm.users_feed[1]
    state.remove_event(b.event_id)
    assert fm.get_feed(1, state=state) == []  # removed from state: filtered
    fm.purge_orphaned_feed_events(state)
    assert fm.users_feed[2] == {a.event_id: a}


def test_set_rng_survives_strategy_swap():
    fm = FeedManager()
    rng = np.random.default_rng(3)
    fm.set_rng(rng)
    fm.set_ordering_strategy(ChronologicalFeedOrderingStrategy())
    assert fm.ordering_strategy.rng is rng
