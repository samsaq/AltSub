"""AgentManager: the commit path and the discrete engine's phases."""

from typing import List, Optional

import numpy as np
import pytest

from python_simulation.agents.attacker_activity import CoordinationTarget
from python_simulation.core.attacker_coordination import CoordinationHub
from python_simulation.core.simulation_data import EventType, MediaEvent

from ..factories import SUB, StubAgent, ban, ev, make_world


class ScriptedAgent(StubAgent):
    """Discrete-engine agent with scripted behaviour."""

    def __init__(self, agent_id, active=True, post=False, reply=False, vote=None,
                 read_count=10, on_parse=None):
        super().__init__(agent_id)
        self.active, self.post, self.do_reply, self.vote = active, post, reply, vote
        self.read_count = read_count
        self.on_parse = on_parse
        self.parsed: List[int] = []
        self.clock = None

    def set_clock(self, timestep, time_s=None):
        self.clock = (timestep, time_s)

    def is_active(self, t):
        return self.active

    def generate_post_events(self, t, state):
        return [ev(self.agent_id, EventType.POST, t=t)] if self.post else []

    def parse(self, event, state):
        self.parsed.append(event.event_id)
        if self.on_parse:
            self.on_parse(event, state)

    def should_reply(self, event, state):
        return self.do_reply and not self.is_banned(state)

    def reply(self, event, state):
        return ev(self.agent_id, EventType.REPLY, event.event_id)

    def choose_vote(self, event, state):
        return None if self.is_banned(state) else self.vote

    def upvote(self, event, state):
        return ev(self.agent_id, EventType.UPVOTE, event.event_id)

    def downvote(self, event, state):
        return ev(self.agent_id, EventType.DOWNVOTE, event.event_id)


# --- commit_event -----------------------------------------------------------


def test_commit_guards_and_counts():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    assert am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 0) is not None
    assert am.commit_event(ev(1, EventType.DOWNVOTE, post.event_id), 0) is None
    ban(state, 2)
    assert am.commit_event(ev(2, EventType.REPLY, post.event_id), 0) is None
    assert am.commit_event(ev(2, EventType.POST), 0) is None
    state.remove_event(post.event_id)
    assert am.commit_event(ev(3, EventType.REPLY, post.event_id), 0) is None
    assert dict(am.commit_rejections) == {
        "duplicate_vote": 1, "author_banned": 2, "target_removed": 1
    }


def test_refused_event_gets_no_id():
    state, am = make_world()
    ban(state, 0)
    e = ev(0, EventType.POST)
    assert am.commit_event(e, 0) is None
    assert state.next_event_id == 0 and e.event_id == 0 and state.events == []


def test_commit_stamps_time_and_feeds_posts_and_replies_only():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST, t=99), 3, time_s=950.5)
    assert (post.timestamp, post.time_s) == (3, 950.5)
    assert post.event_id in am.feed_manager.users_feed[1]
    assert post.event_id not in am.feed_manager.users_feed[0]  # own post
    vote = am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 4)
    assert vote.time_s == 4 * state.timestep_duration_seconds
    assert all(vote.event_id not in f for f in am.feed_manager.users_feed.values())


def test_author_unknown_to_manager_is_not_ban_checked():
    state, am = make_world(1)
    assert am.commit_event(ev(99, EventType.POST), 0) is not None


# --- discrete phases --------------------------------------------------------


def test_think_phase_commits_posts_of_active_unbanned_agents():
    agents = [ScriptedAgent(0, post=True), ScriptedAgent(1, post=True, active=False),
              ScriptedAgent(2, post=True)]
    state, am = make_world(agents=agents)
    ban(state, 2)
    am.think_phase(5)
    assert [(e.user_id, e.timestamp, e.time_s) for e in state.events] == [(0, 5, 1500.0)]
    assert agents[0].clock == (5, 1500.0)


@pytest.mark.parametrize("parallel", [False, True])
def test_communicate_reads_votes_replies_and_marks_read(parallel):
    poster = ScriptedAgent(0, post=True)
    reader = ScriptedAgent(1, reply=True, vote="upvote", read_count=5)
    state, am = make_world(agents=[poster, reader])
    am.enable_timestep_parallelism = parallel
    am.max_llm_concurrency = 4
    am.think_phase(0)
    am.communicate_phase(0)
    post = state.events[0]
    assert reader.parsed == [post.event_id]
    assert post.upvotes == [1] and len(post.replies) == 1
    assert am.feed_manager.get_unread_count(1) == 0
    assert am.items_read >= 1


def test_parallel_communicate_refuses_reply_to_item_removed_mid_step():
    """A moderator earlier in the step removes the post; a later agent that
    queued a reply from its feed snapshot has it refused at commit."""
    poster = ScriptedAgent(0, post=True)

    def remove(event, state):
        state.remove_event(event.event_id)

    remover = ScriptedAgent(1, on_parse=remove)
    replier = ScriptedAgent(2, reply=True)
    state, am = make_world(agents=[poster, remover, replier])
    am.enable_timestep_parallelism = True
    am.think_phase(0)
    am.communicate_phase(0)
    assert state.events == []
    assert am.commit_rejections["target_removed"] == 1


def test_parallel_think_commits_in_agent_id_order():
    agents = [ScriptedAgent(i, post=True) for i in range(6)]
    state, am = make_world(agents=agents)
    am.enable_timestep_parallelism, am.max_llm_concurrency = True, 8
    am.think_phase(0)
    assert [e.user_id for e in state.events] == list(range(6))


# --- coordination ------------------------------------------------------------


class AttackerStub(ScriptedAgent):
    agent_type = "template_attacker"

    def __init__(self, agent_id):
        super().__init__(agent_id)
        self.targets: List[CoordinationTarget] = []

    def add_coordination_target(self, target):
        self.targets.append(target)

    def pop_due_coordination_targets(self, t):
        due = [x for x in self.targets if x.due_timestep <= t]
        self.targets = [x for x in self.targets if x.due_timestep > t]
        return due


def _hub_world(n=3, strength=1.0, comment_prob=1.0):
    agents = [AttackerStub(i) for i in range(n)]
    state, am = make_world(agents=agents)
    hub = CoordinationHub(range(n), strength, comment_prob, delay_min=1, delay_max=6)
    hub.rng = np.random.default_rng(0)
    am.coordination_hub = hub
    return state, am, hub, agents


def test_hub_schedules_amplification_by_every_other_attacker():
    state, am, hub, agents = _hub_world()
    post = am.commit_event(ev(0, EventType.POST), 10)
    scheduled = hub.on_new_events([post], 10, am.agents, state)
    assert sorted({a for a, _ in scheduled}) == [1, 2]
    assert agents[0].targets == []
    for t in agents[1].targets + agents[2].targets:
        assert 11 <= t.due_timestep <= 16 and t.due_time_s is None
    assert hub.stats["upvotes_scheduled"] == 2 and hub.stats["comments_scheduled"] == 2


def test_hub_event_mode_returns_due_times_in_window_without_storing():
    state, am, hub, agents = _hub_world()
    post = am.commit_event(ev(0, EventType.POST), 0, time_s=1000.0)
    scheduled = hub.on_new_events([post], 3, am.agents, state, step_s=300.0)
    assert agents[1].targets == [] and scheduled
    for _, target in scheduled:
        assert 1300.0 <= target.due_time_s <= 2800.0
        assert target.due_timestep == int(target.due_time_s // 300)


def test_hub_ignores_replies_non_attackers_and_banned():
    state, am, hub, agents = _hub_world()
    ban(state, 2)
    post = am.commit_event(ev(0, EventType.POST), 0)
    reply = am.commit_event(ev(1, EventType.REPLY, post.event_id), 0)
    hub.on_new_events([reply], 0, am.agents, state)
    assert hub.stats["posts_seen"] == 0
    scheduled = hub.on_new_events([post], 0, am.agents, state)
    assert {a for a, _ in scheduled} == {1}
    assert agents[1].targets and agents[2].targets == []


def test_coordination_actions_execute_skip_and_mark_read():
    state, am, hub, agents = _hub_world(comment_prob=1.0)
    post = am.commit_event(ev(0, EventType.POST), 0)
    hub.on_new_events([post], 0, am.agents, state)
    ban(state, 2)
    am._run_coordination_actions(10)
    assert post.upvotes == [1] and len(post.replies) == 1
    assert hub.stats["upvotes_executed"] == 1 and hub.stats["comments_executed"] == 1
    assert hub.stats["skipped_banned"] == 2
    assert post.event_id not in am.feed_manager.users_feed[1]
