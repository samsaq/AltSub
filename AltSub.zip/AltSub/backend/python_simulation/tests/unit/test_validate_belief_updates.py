"""Controlled post tests of the update mechanism (tools/validate_belief_updates.py) with a fake model."""

import csv
import json
import re

import pytest

from python_simulation.services.llm_provider import LLMResponse
from python_simulation.tools import validate_belief_semantics as vbs
from python_simulation.tools import validate_belief_updates as vbu


class FakeUpdater:
    """Moves each expected statement the right way. spill=True moves every
    other statement (spillover); reverse=True moves targets backwards."""

    model = "fake-updater"

    def __init__(self, items, spill=False, reverse=False):
        self.spill, self.reverse = spill, reverse
        self.by_text = {it["text"]: it.get("expected", {})
                        for sc in items["scenarios"].values() for it in sc["items"]}

    def is_available(self):
        return True

    def chat_completion_meta(self, messages, temperature=0.3, max_tokens=500, **kwargs):
        prompt = messages[-1]["content"]
        text = re.search(r'^Content: "(.*)"$', prompt, re.M).group(1)
        lines = re.findall(r'^- \[(a\d+)\] "(.*)" \(your acceptance: ([0-9.]+)\)$', prompt, re.M)
        prefix = "C" if lines and "Destiny" in lines[0][1] else "P"
        expected = self.by_text[text]
        out = {}
        for n, (alias, _, value) in enumerate(lines, start=1):
            sid, v = f"{prefix}{n}", float(value)
            step = {"high": 0.1, "low": -0.1}.get(expected.get(sid), 0.0)
            if self.reverse:
                step = -step
            if self.spill and sid not in expected:
                step = 0.1
            out[alias] = round(min(1.0, max(0.0, v + step)), 3)
        return LLMResponse(json.dumps(out), "stop")


@pytest.fixture
def items():
    return json.loads(vbs.DEFAULT_ITEMS.read_text(encoding="utf-8"))


def run(tmp_path, monkeypatch, fake, *extra):
    monkeypatch.setattr(vbu, "make_provider", lambda name: fake)
    assert vbu.main(["--reps", "2", "--out-root", str(tmp_path), "--max-workers", "2", *extra]) == 0
    (run_dir,) = [p for p in tmp_path.iterdir() if p.is_dir()]
    return run_dir


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def test_dry_run(capsys):
    assert vbu.main(["--dry-run", "--reps", "1", "--starts", "0.5"]) == 0
    out = capsys.readouterr().out
    assert "43 update call(s)" in out  # 43 posts x 1 start x 1 rep


def test_correct_updates_pass_and_artifacts_are_complete(tmp_path, monkeypatch, items):
    run_dir = run(tmp_path, monkeypatch, FakeUpdater(items))
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["starts"] == [0.5, 0.25, 0.75] and manifest["cap"] == 0.15
    calls = [json.loads(l) for l in (run_dir / "calls.jsonl").read_text(encoding="utf-8").splitlines()]
    # the real simulation update prompt
    assert all("Update how much you accept each of these belief statements" in c["messages"][0]["content"]
               for c in calls)
    for name in ("targets", "spillover"):
        rows = read_csv(run_dir / "summary" / f"{name}.csv")
        assert rows and all(r["pass"] == "True" for r in rows), name


def test_spillover_and_reversed_updates_fail(tmp_path, monkeypatch, items):
    run_dir = run(tmp_path, monkeypatch, FakeUpdater(items, spill=True, reverse=True))
    targets = read_csv(run_dir / "summary" / "targets.csv")
    assert all(r["pass"] == "False" for r in targets if r["expected"] != "neutral")
    spill = read_csv(run_dir / "summary" / "spillover.csv")
    assert spill and all(r["pass"] == "False" for r in spill if float(r["mean_delta"]) > 0)


def test_proposals_beyond_cap_are_counted(tmp_path, monkeypatch, items):
    class Overshoot(FakeUpdater):
        def chat_completion_meta(self, messages, temperature=0.3, max_tokens=500, **kwargs):
            prompt = messages[-1]["content"]
            lines = re.findall(r'^- \[(a\d+)\] ', prompt, re.M)
            return LLMResponse(json.dumps({a: 1.0 for a in lines}), "stop")

    run_dir = run(tmp_path, monkeypatch, Overshoot(items), "--starts", "0.5")
    cap = read_csv(run_dir / "summary" / "cap.csv")
    assert all(float(r["rate"]) == 1.0 for r in cap)  # every proposal of 1.0 from 0.5 exceeds 0.15
    calls = [json.loads(l) for l in (run_dir / "calls.jsonl").read_text(encoding="utf-8").splitlines()]
    assert all(abs(d) <= 0.15 + 1e-9 for c in calls for d in c["delta"].values())  # clamped


def test_neutral_criterion_allows_movement_toward_neutral_only():
    assert vbu._neutral_ok(0.04, 0.5) and not vbu._neutral_ok(0.06, 0.5)
    assert vbu._neutral_ok(-0.13, 0.75) and vbu._neutral_ok(0.10, 0.25)  # toward 0.5
    assert not vbu._neutral_ok(0.05, 0.75) and not vbu._neutral_ok(-0.05, 0.25)  # away
    assert vbu._neutral_ok(0.01, 0.75)  # below the movement threshold
