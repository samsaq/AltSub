"""Agent behaviour, using the stub LLM service and offline canonicalizer/NLI."""

import json
from concurrent.futures import ThreadPoolExecutor

import numpy as np
import pytest

from python_simulation.agents.base_agent import pick_vote
from python_simulation.agents.biased_moderator_agent import BiasedModeratorAgent, ContentAnalysis
from python_simulation.agents.llm_attacker_agent import LLMAttackerAgent
from python_simulation.agents.llm_user_agent import LLMUserAgent, ParseResult
from python_simulation.agents.rule_moderator_agent import RuleAnalysis, RuleModeratorAgent
from python_simulation.agents.template_attacker_agent import TemplateAttackerAgent
from python_simulation.core.simulation_data import EventType, SimulationState
from python_simulation.services.attacker_campaign_orchestrator import CampaignInstruction
from python_simulation.systems.mitigation_system import MitigationSystem

from ..conftest import TEMPLATES
from ..factories import SUB, FakeCanonicalizer, ban, ev, make_world, stub_llm_service

WEIGHTS = {"read": 10, "post": 0.1, "reply": 0.1, "upvote": 0.15, "downvote": 0.05}
SERVICE = stub_llm_service()


def user(agent_id=0, beliefs=None, canonicalizer=None, **kwargs):
    agent = LLMUserAgent(
        agent_id, beliefs or {"a": 0.5, "b": 0.6}, SUB, WEIGHTS, np.ones(10, bool),
        llm_service=SERVICE, canonicalizer=canonicalizer, **kwargs,
    )
    agent.seed_rng(1)
    return agent


def committed_post(content="The latest patch made the game more balanced, honestly"):
    state, am = make_world(3)
    return state, am, am.commit_event(ev(1, EventType.POST, content=content), 0)


# base


def test_pick_vote_scales_probabilities_above_one():
    rng = np.random.default_rng(0)
    votes = [pick_vote(0.9, 0.9, rng) for _ in range(4000)]
    assert None not in votes
    assert votes.count("upvote") / len(votes) == pytest.approx(0.5, abs=0.03)
    assert pick_vote(0.0, 0.0, rng) is None


def test_seed_rng_is_reproducible_and_per_agent():
    a1, a2, b = user(0), user(0), user(1)
    for agent in (a1, a2, b):
        agent.seed_rng(42)
    assert a1.rng.random() == a2.rng.random()
    a1.seed_rng(42)
    assert a1.rng.random() != b.rng.random()


# LLM user: reading


def test_parse_equals_job_path():
    state, am, item = committed_post()
    direct, staged = user(canonicalizer=FakeCanonicalizer()), user(canonicalizer=FakeCanonicalizer())
    direct.parse(item, state)
    job = staged.parse_job(item, state)
    staged.apply_parse(job(), state)
    assert direct.beliefs == staged.beliefs
    assert direct.belief_texts == staged.belief_texts


def test_compute_parse_is_pure():
    state, am, item = committed_post()
    agent = user()
    inp = agent.prepare_parse(item, state)
    before = (dict(agent.beliefs), dict(state.belief_text_registry))
    agent.compute_parse(inp)
    assert (dict(agent.beliefs), dict(state.belief_text_registry)) == before


def test_apply_parse_adopts_new_claims_and_registers_texts():
    canon = FakeCanonicalizer()
    agent = user(canonicalizer=canon)
    state = SimulationState()
    result = ParseResult({"a": 0.5, "b": 0.6}, {"a": 0.5, "b": 0.6},
                         {"Raids are too hard": 0.7, "Loot is fair": 0.4})
    agent.set_clock(12)
    agent.apply_parse(result, state)
    adopted = {canon.canonicalize_belief_text(t)[0]: s for t, s in result.claims.items()}
    for belief_id, strength in adopted.items():
        assert agent.beliefs[belief_id] == strength
        assert belief_id in state.belief_text_registry
        assert state.belief_network.get_belief(0, belief_id) == strength
    assert len(canon.metadata_writes) == 2
    assert agent.belief_history[-1]["timestep"] == 12


def test_event_engine_apply_defers_metadata_writes():
    canon = FakeCanonicalizer()
    agent = user(canonicalizer=canon)
    agent.apply_parse_result(ParseResult(dict(agent.beliefs), dict(agent.beliefs), {"New claim here": 0.6}),
                             SimulationState())
    assert canon.metadata_writes == []


def test_already_held_claim_is_not_readopted():
    canon = FakeCanonicalizer()
    held_id, _ = canon.canonicalize_belief_text("Raids are too hard")
    agent = user(beliefs={held_id: 0.9}, canonicalizer=canon)
    agent.apply_parse(ParseResult({held_id: 0.9}, {held_id: 0.9}, {"raids are too hard": 0.4}),
                      SimulationState())
    assert agent.beliefs == {held_id: 0.9}


def test_contradicting_claim_weakens_strong_belief_instead_of_adopting():
    canon = FakeCanonicalizer()
    held_id, _ = canon.canonicalize_belief_text("The patch is good")
    agent = user(beliefs={held_id: 0.8}, canonicalizer=canon,
                 belief_texts={held_id: "The patch is good"})
    agent.apply_parse(ParseResult({held_id: 0.8}, {held_id: 0.8}, {"The patch is not good": 0.9}),
                      SimulationState())
    assert set(agent.beliefs) == {held_id}
    assert agent.beliefs[held_id] == pytest.approx(0.8 - SERVICE.config.belief_update_max_change)


def test_contradicting_claim_replaces_weak_belief():
    canon = FakeCanonicalizer()
    held_id, _ = canon.canonicalize_belief_text("The patch is good")
    agent = user(beliefs={held_id: 0.2, "other": 0.5}, canonicalizer=canon,
                 belief_texts={held_id: "The patch is good"})
    agent.apply_parse(
        ParseResult(dict(agent.beliefs), dict(agent.beliefs), {"The patch is not good": 0.9}),
        SimulationState(),
    )
    assert held_id not in agent.beliefs and "other" in agent.beliefs
    assert 0.9 in agent.beliefs.values()


def test_belief_cap_culls_weakest():
    canon = FakeCanonicalizer()
    agent = user(beliefs={"a": 0.5, "b": 0.6}, canonicalizer=canon,
                 belief_cap_enabled=True, belief_cap=3)
    claims = {"Claim one about raids": 0.9, "Claim two about loot": 0.35}
    agent.apply_parse(ParseResult(dict(agent.beliefs), dict(agent.beliefs), claims), SimulationState())
    assert len(agent.beliefs) == 3
    assert "a" not in agent.beliefs or min(agent.beliefs.values()) >= 0.5


def test_merge_keeps_consolidation_and_applies_deltas():
    agent = user(beliefs={"a": 0.5, "b": 0.6, "c": 0.4})
    result = ParseResult({"a": 0.5, "b": 0.6, "c": 0.4}, {"a": 0.6, "b": 0.6, "c": 0.3})
    agent.replace_beliefs({"a": 0.55, "b": 0.6}, 0)  # consolidation meanwhile
    merged = agent._merge_llm_update(result)
    assert set(merged) == {"a", "b"} and merged["a"] == pytest.approx(0.65)
    agent.replace_beliefs({"a": 0.5, "b": 0.6, "c": 0.4}, 0)
    assert agent._merge_llm_update(result) == {"a": 0.6, "b": 0.6, "c": 0.3}


# LLM user: acting


def test_reply_job_uses_belief_snapshot():
    state, am, item = committed_post()
    agent = user(beliefs={"a": 0.9, "b": 0.1})
    job = agent.reply_job(item, state)
    agent.beliefs = {"b": 1.0}
    reply = job()
    assert reply.parent_id == item.event_id and reply.belief_id == "a"
    assert reply.content


def test_llm_vote_job_and_banned_agent_never_votes():
    state, am, item = committed_post()
    agent = user(llm_voting_enabled=True)
    p_up, p_down = agent.vote_probabilities_job(item, state)()
    assert 0 <= p_up <= 1 and 0 <= p_down <= 1
    state.subreddit_membership.add_member(0, SUB)
    ban(state, 0)
    assert all(agent.choose_vote(item, state) is None for _ in range(20))
    assert not agent.should_reply(item, state)


def test_natural_post_rolls_probability():
    state, _ = make_world(1)
    always = LLMUserAgent(0, {"a": 0.5}, SUB, {**WEIGHTS, "post": 1.0}, np.ones(3, bool), llm_service=SERVICE)
    never = LLMUserAgent(1, {"a": 0.5}, SUB, {**WEIGHTS, "post": 0.0}, np.ones(3, bool), llm_service=SERVICE)
    assert len(always.generate_post_events(0, state)) == 1
    assert never.generate_post_events(0, state) == []


# attackers


def attacker(schedule, session_duration="medium"):
    agent = LLMAttackerAgent(7, {"campaign_x": 0.9}, SUB, WEIGHTS, np.array(schedule, bool),
                             llm_service=SERVICE, session_duration=session_duration)
    agent.seed_rng(3)
    return agent


def instruction(start, end, content="Campaign post text"):
    return CampaignInstruction(content=content, start_timestep=start, end_timestep=end)


def test_instruction_executes_at_a_naturally_active_step_in_its_window():
    schedule = [0] * 20
    schedule[12] = schedule[13] = 1
    agent = attacker(schedule)
    instr = instruction(10, 15)
    agent.add_instruction(instr)
    assert instr.execute_timestep in (12, 13)
    instr2 = instruction(2, 5)  # never naturally active: any step in window
    agent.add_instruction(instr2)
    assert 2 <= instr2.execute_timestep <= 5


def test_instruction_lifecycle_posts_once_then_campaign_session():
    agent = attacker([0] * 40, session_duration="short")
    state, _ = make_world(1)
    instr = instruction(5, 5)
    agent.add_instruction(instr)
    assert not agent.is_active(4) and agent.is_active(5)
    posts = agent.generate_post_events(5, state)
    assert [p.content for p in posts] == ["Campaign post text"]
    assert instr.executed
    assert agent.is_active(5)  # campaign session ("short" = 1 step)
    assert agent.generate_post_events(6, state) == []
    assert agent.pending_instructions == []  # pruned at the next check


def test_expired_instruction_is_dropped_and_empty_content_skipped():
    agent = attacker([0] * 40)
    state, _ = make_world(1)
    stale = instruction(1, 2)
    agent.add_instruction(stale)
    assert not agent.is_active(10) and agent.pending_instructions == []
    empty = instruction(12, 12, content="")
    agent.add_instruction(empty)
    assert agent.generate_post_events(12, state) == []
    assert empty.executed and agent._campaign_session_until < 12


def test_template_attacker_fills_and_chooses_reply_context(tmp_path):
    (tmp_path / "default_campaign.json").write_text(json.dumps(TEMPLATES))
    agent = TemplateAttackerAgent(5, {"x": 0.9}, SUB, {**WEIGHTS, "post": 1.0}, np.ones(4, bool),
                                  campaign_templates_dir=str(tmp_path), attacker_agent_ids={5, 6})
    agent.seed_rng(0)
    state, am = make_world(8)
    posts = agent.generate_post_events(0, state)
    assert posts and "{" not in posts[0].content
    fellow = am.commit_event(ev(6, EventType.POST, content="anything"), 0)
    opposing = am.commit_event(ev(1, EventType.POST, content="this got worse"), 0)
    assert agent._reply_context(fellow) == "fellow_attacker_post"
    assert agent._reply_context(opposing) == "opposing_viewpoint"
    assert agent.reply(fellow, state).content.startswith("Totally agree")


def test_template_attacker_without_templates_posts_nothing(tmp_path):
    agent = TemplateAttackerAgent(5, {}, SUB, {**WEIGHTS, "post": 1.0}, np.ones(4, bool),
                                  campaign_templates_dir=str(tmp_path))
    state, _ = make_world(1)
    assert agent.generate_post_events(0, state) == []
    assert agent.natural_post_job(state) is None


# moderators


def rule_mod(agent_id, mitigation, violates=True):
    mod = RuleModeratorAgent(agent_id, {}, SUB, {"read": 15}, np.ones(4, bool),
                             mitigation_system=mitigation, llm_service=SERVICE)
    mod._analyze_rules = lambda content: RuleAnalysis(violates, 0.95, "rude")
    return mod


def test_rule_moderators_remove_and_flag_once_per_item():
    m = MitigationSystem(ban_threshold=10)
    mod_a, mod_b = rule_mod(10, m), rule_mod(11, m)
    state, am = make_world(agents=None, n_agents=3)
    target = am.commit_event(ev(1, EventType.POST), 0)
    reply = am.commit_event(ev(2, EventType.REPLY, target.event_id), 0)
    for mod in (mod_a, mod_b):  # both read the item before either acts
        mod.apply_parse_result(mod.parse_job(target, state)(), state)
    mod_a.flush_pending_moderation(state, am.feed_manager)
    mod_b.flush_pending_moderation(state, am.feed_manager)
    assert state.events == []  # thread removed with its reply
    assert mod_a.removed_event_ids == [target.event_id] and mod_b.removed_event_ids == []
    assert [f["agent_id"] for f in m.flag_log] == [1]
    assert reply.event_id not in am.feed_manager.users_feed[0]


def test_rule_moderator_skips_votes_and_empty_content():
    m = MitigationSystem()
    mod = rule_mod(10, m)
    state, am = make_world(3)
    post = am.commit_event(ev(1, EventType.POST, content="   "), 0)
    vote = am.commit_event(ev(2, EventType.UPVOTE, post.event_id), 0)
    assert mod.parse_job(post, state) is None and mod.parse_job(vote, state) is None
    assert mod.expected_action_probs() == (0.0, 0.0)


def biased(feed_manager, analyses):
    mod = BiasedModeratorAgent(20, {"n": 0.9}, SUB, {"read": 10}, np.ones(4, bool),
                               llm_service=SERVICE, scan_frequency=12, feed_manager=feed_manager)
    mod.analyze_content = lambda content: analyses(content)
    return mod


def remove_if_bad(content):
    bad = "bad" in content
    return ContentAnalysis(bad, 0.99 if bad else 0.0, "rule", "belief", succeeded=True)


def test_biased_moderator_three_strikes_ban():
    state, am = make_world(3)
    mod = biased(am.feed_manager, remove_if_bad)
    for i in range(3):
        am.commit_event(ev(1, EventType.POST, content=f"bad post {i}"), 0)
    mod.moderate(0, state)
    assert [a.action_type for a in mod.moderation_log] == ["remove_post"] * 3 + ["ban_user"]
    assert state.banned_agent_network.is_banned(1, SUB) and state.events == []
    assert all(a.time_s == 0.0 for a in mod.moderation_log)


def test_biased_moderator_lookback_covers_gap_since_previous_scan():
    state, am = make_world(3)
    seen = []
    mod = biased(am.feed_manager, lambda c: (seen.append(c), remove_if_bad(c))[1])
    am.commit_event(ev(1, EventType.POST, content="early"), 0, time_s=100)
    mod.moderate(0, state, now_s=3600)
    # Long inactivity: content posted long before this scan is still reviewed
    am.commit_event(ev(1, EventType.POST, content="during the gap"), 0, time_s=5000)
    mod.moderate(0, state, now_s=50_000)
    assert seen == ["early", "during the gap"]  # each judged once


def test_biased_moderator_retries_failed_analysis_and_executor_matches():
    state, am = make_world(3)
    calls = []

    def flaky(content):
        calls.append(content)
        return ContentAnalysis(succeeded=len(calls) > 1)

    mod = biased(am.feed_manager, flaky)
    am.commit_event(ev(1, EventType.POST, content="fine"), 0, time_s=0)
    mod.moderate(0, state, now_s=10)
    mod.moderate(0, state, now_s=4000)
    assert calls == ["fine", "fine"]

    def run(executor):
        st, a = make_world(3)
        for i in range(6):
            a.commit_event(ev(1 + i % 2, EventType.POST, content=f"{'bad' if i % 3 == 0 else 'ok'} {i}"), 0)
        m = biased(a.feed_manager, remove_if_bad)
        m.moderate(0, st, now_s=0, executor=executor)
        return [(x.event_id, x.action_type) for x in m.moderation_log]

    with ThreadPoolExecutor(4) as pool:
        assert run(pool) == run(None)


def test_biased_moderator_does_not_read_feed():
    state, am = make_world(1)
    assert not biased(am.feed_manager, remove_if_bad).reads_feed()
