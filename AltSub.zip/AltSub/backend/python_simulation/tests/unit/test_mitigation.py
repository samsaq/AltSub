"""MitigationSystem: scans, flags/bans, evidence ledgers, coordination traces."""

from python_simulation.core.simulation_data import EventType
from python_simulation.systems.mitigation_system import MitigationSystem

from ..factories import ev, make_world

STEP = 300.0


def mit(**kwargs) -> MitigationSystem:
    defaults = dict(scan_frequency=10, ban_threshold=3, step_s=STEP)
    defaults.update(kwargs)
    return MitigationSystem(**defaults)


def post(am, user, t, content="some text content"):
    return am.commit_event(ev(user, EventType.POST, content=content), int(t // STEP), time_s=t)


def test_discrete_scan_frequency_and_first_scan_at_zero():
    m = mit(rate_limiting_enabled=True)
    state, _ = make_world()
    scans = []
    m.rate_limit_check = lambda ts, st, now: scans.append((ts, now))
    for t in range(25):
        m.scan(t, state)
    assert scans == [(0, 0.0), (10, 3000.0), (20, 6000.0)]
    m.scan(21, state, now_s=6400.0)  # event engine: scheduled, no frequency check
    assert scans[-1] == (21, 6400.0)


def test_flags_ban_at_threshold_and_stop_after_ban():
    state, am = make_world()
    m = mit()
    for i in range(5):
        m.flag_agent(1, "x", state, timestep=i, source="test")
    assert m.mitigation_flags[1] == 3
    assert [f["banned"] for f in m.flag_log] == [False, False, True]
    assert state.banned_agent_network.is_banned(1, "sub")
    assert m.flag_log[0]["time_s"] == 0.0 and m.flag_log[2]["time_s"] == 2 * STEP
    m.flag_agent(2, "y", state, timestep=4, time_s=1234.5)
    assert m.flag_log[-1]["time_s"] == 1234.5


def test_duplicates_flag_once_per_evidence_and_again_for_new_evidence():
    state, am = make_world()
    m = mit(duplicate_detection_enabled=True, duplicate_similarity_threshold=0.8,
            duplicate_lookback_window=100)
    post(am, 1, 0, "the raid is the best part of this season")
    post(am, 1, 300, "the raid is the best part of this season")
    post(am, 2, 300, "completely different words entirely here")
    m.scan(10, state)
    m.scan(20, state)  # same pair still in the window: not counted again
    assert [f["agent_id"] for f in m.flag_log] == [1]
    post(am, 1, 6100, "matchmaking quality has gotten much worse lately")
    post(am, 1, 6200, "matchmaking quality has gotten much worse lately")
    m.scan(30, state)
    assert [f["agent_id"] for f in m.flag_log] == [1, 1]


def test_duplicate_window_excludes_old_and_future_events():
    state, am = make_world()
    m = mit(duplicate_detection_enabled=True, duplicate_lookback_window=10)
    post(am, 1, 0, "identical text identical text")
    post(am, 1, 3500, "identical text identical text")  # outside 10-step window at scan 12
    m.scan(12, state)
    assert m.flag_log == []
    post(am, 1, 3700, "identical text identical text")
    m.scan(12, state, now_s=3600.0)  # the 3700 s post is in the future
    assert m.flag_log == []


def test_rate_limit_counts_new_actions_only():
    state, am = make_world()
    m = mit(rate_limiting_enabled=True, rate_limit_window=24, rate_limit_threshold=3)
    for i in range(4):
        post(am, 1, 100 + i, f"post number {i}")
    m.scan(10, state)
    m.scan(20, state)  # same burst still in the window
    assert [f["source"] for f in m.flag_log] == ["rate_limit"]
    for i in range(4):
        post(am, 1, 6100 + i, f"later post {i}")
    m.scan(30, state)
    assert len(m.flag_log) == 2


def test_rate_limit_ignores_votes():
    state, am = make_world(6)
    p = post(am, 0, 0)
    for voter in range(1, 6):
        am.commit_event(ev(voter, EventType.UPVOTE, p.event_id), 0, time_s=10)
    m = mit(rate_limiting_enabled=True, rate_limit_threshold=0)
    m.scan(10, state)
    assert [f["agent_id"] for f in m.flag_log] == [0]


def _edges(m, state, now_s=10_000.0, window_start=-1.0):
    edges = {}

    def add_edge(u, v, trace, score, evidence):
        edges[(u, v)] = (trace, evidence)

    recent = m._window(state, window_start, now_s)
    by_target, targets = m._coordination_engagements(recent, state)
    m._co_engagement_edges(by_target, targets, window_start, add_edge, state)
    m._co_content_edges(recent, add_edge, state)
    m._fast_amplification_edges(by_target, targets, window_start, add_edge, state)
    return edges


def test_co_content_needs_sync_and_enough_matches():
    state, am = make_world()
    m = mit(coordination_sync_window=6, coordination_min_content_matches=2,
            coordination_content_similarity_threshold=0.8)
    text_a, text_b = "buy the new season pass now", "the economy update is great"
    post(am, 1, 0, text_a)
    post(am, 2, 1800, text_a)  # exactly at the sync limit
    post(am, 1, 4000, text_b)
    post(am, 2, 5801, text_b)  # 1801 s apart: out of sync
    assert _edges(m, state) == {}
    post(am, 2, 4100, text_b)
    assert _edges(m, state)[(1, 2)][0] == "co_content"


def _co_engagement_world(lag_s: float):
    """Accounts 1 and 2 upvote the same three items lag_s apart; accounts 3-5
    each engage other items (so the shared items are rare, i.e. IDF > 0)."""
    state, am = make_world(8)
    items = [post(am, 0, i * 20_000, f"item {i}") for i in range(6)]
    for it in items[:3]:
        am.commit_event(ev(1, EventType.UPVOTE, it.event_id), 0, time_s=it.time_s + 10)
        am.commit_event(ev(2, EventType.UPVOTE, it.event_id), 0, time_s=it.time_s + 10 + lag_s)
    for voter, it in zip((3, 4, 5), items[3:]):
        am.commit_event(ev(voter, EventType.UPVOTE, it.event_id), 0, time_s=it.time_s + 10)
    return state


def test_co_engagement_requires_synchronised_shared_targets():
    m = mit(coordination_sync_window=6, coordination_min_shared_targets=3,
            coordination_similarity_threshold=0.1, coordination_significance=1.0)
    assert _edges(m, _co_engagement_world(60), now_s=200_000.0)[(1, 2)][0] == "co_engagement"
    # Same targets but 2 h apart: not co-engagement
    assert (1, 2) not in _edges(m, _co_engagement_world(7200), now_s=200_000.0)


def test_fast_amplification_boundary_is_exact_in_seconds():
    state, am = make_world(6)
    m = mit(coordination_sync_window=6, coordination_min_amplifications=1,
            coordination_significance=1.0)
    for i in range(3):
        p = post(am, 0, 1000.0 * i)
        am.commit_event(ev(1, EventType.UPVOTE, p.event_id), 0, time_s=p.time_s + 1800.0)
    late = post(am, 2, 10.0)
    am.commit_event(ev(3, EventType.UPVOTE, late.event_id), 0, time_s=10.0 + 1801.0)
    edges = _edges(m, state)
    assert (1, 0) in edges
    assert not any(3 in k for k in edges)


def test_detect_coordination_flags_group_and_records_edges():
    state, am = make_world()
    m = mit(coordinated_detection_enabled=True, coordination_min_content_matches=2,
            ban_threshold=10)
    for t in (0, 3000):
        post(am, 1, t, "the new season is great buy it")
        post(am, 2, t + 60, "the new season is great buy it")
    m.scan(20, state)
    assert sorted(f["agent_id"] for f in m.flag_log) == [1, 2]
    assert m.coordination_edges[0]["agents"] == [1, 2]
    assert m.coordination_edges[0]["time_s"] == 6000.0
    m.scan(30, state)  # no new evidence: no new flags
    assert len(m.flag_log) == 2
