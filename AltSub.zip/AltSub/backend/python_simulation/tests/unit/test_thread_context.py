"""Thread context for comments read from the flat feed (core/thread_context.py)."""

from python_simulation.core.simulation_data import EventType
from python_simulation.core.thread_context import format_thread, thread_context

from ..factories import SUB, ev, make_world, stub_llm_service
from .test_services import ScriptedProvider


def _thread(state, am, depth):
    """Commit a post and a chain of `depth` nested comments; return all events."""
    post = am.commit_event(ev(0, EventType.POST, content="The original post"), 0)
    chain = [post]
    for i in range(depth):
        chain.append(am.commit_event(
            ev(1 + i % 3, EventType.REPLY, parent=chain[-1].event_id, content=f"comment {i}"), 0
        ))
    return chain


def test_post_has_no_thread():
    state, am = make_world()
    post = _thread(state, am, 0)[0]
    assert thread_context(post, state) == []


def test_comment_thread_is_root_first():
    state, am = make_world()
    post, c0, c1 = _thread(state, am, 2)
    assert thread_context(c1, state) == [
        ("post", "0", "The original post"),
        ("comment", "1", "comment 0"),
    ]
    assert thread_context(c0, state) == [("post", "0", "The original post")]


def test_long_thread_keeps_post_and_nearest_comments():
    state, am = make_world()
    events = _thread(state, am, 8)
    out = thread_context(events[-1], state, max_ancestors=3)
    # post, omission marker, then the two comments directly above the item
    assert out[0] == ("post", "0", "The original post")
    assert out[1][2] == "[... 5 earlier comment(s) omitted ...]"
    assert [e[2] for e in out[2:]] == ["comment 5", "comment 6"]


def test_removed_ancestor_ends_chain():
    state, am = make_world()
    post, c0, c1, c2 = _thread(state, am, 3)
    del state.events_by_id[c0.event_id]  # c0 removed: c1's parent is missing
    out = thread_context(c2, state)
    assert out == [("comment", "unknown", "[removed]"), ("comment", "2", "comment 1")]


def test_long_text_is_clipped():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST, content="x" * 2000), 0)
    reply = am.commit_event(ev(1, EventType.REPLY, parent=post.event_id), 0)
    (_, _, text), = thread_context(reply, state, post_chars=100)
    assert len(text) == 100 and text.endswith("...")


def test_prompts_include_thread_only_for_comments():
    state, am = make_world()
    post, c0, c1 = _thread(state, am, 2)
    thread = thread_context(c1, state)
    rendered = format_thread(thread)
    assert "[Original post by user 0]" in rendered and "[Comment by user 1]" in rendered

    svc = stub_llm_service()
    provider = ScriptedProvider([("a reply", "stop"), ("a reply", "stop")])
    svc._llm_provider = provider
    svc.generate_reply_content("comment 1", {}, SUB, thread=thread)
    svc.generate_reply_content("The original post", {}, SUB)
    with_thread, without = (c["messages"][-1]["content"] for c in provider.calls)
    assert "The original post" in with_thread and "comment you are replying to" in with_thread
    assert "Thread so far" not in without and "replying to this post" in without

    provider = ScriptedProvider([('{"b1": 0.5}', "stop")])
    svc._llm_provider = provider
    svc.update_beliefs_from_content("comment 1", {"a": 0.5}, thread=thread)
    prompt = provider.calls[0]["messages"][-1]["content"]
    assert "context only" in prompt and "The original post" in prompt
