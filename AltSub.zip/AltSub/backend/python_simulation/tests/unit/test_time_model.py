import math

import numpy as np
import pytest

from python_simulation.core.event_scheduler import EventKind, EventScheduler
from python_simulation.core.time_model import (
    ActivityIntervals,
    DurationSpec,
    TimeModel,
    sample_time_in,
    session_length_timesteps,
)


def _mean(spec: DurationSpec, n: int = 20000) -> float:
    rng = np.random.default_rng(0)
    return float(np.mean([spec.sample(rng) for _ in range(n)]))


def test_duration_spec_means():
    assert _mean(DurationSpec("fixed", 3.0)) == 3.0
    assert _mean(DurationSpec("exponential", 20.0)) == pytest.approx(20.0, rel=0.03)
    assert _mean(DurationSpec("lognormal", 60.0, 40.0)) == pytest.approx(60.0, rel=0.03)
    assert _mean(DurationSpec("uniform", min_s=600, max_s=3000)) == pytest.approx(1800, rel=0.02)


def test_duration_spec_clipping_and_roundtrip():
    spec = DurationSpec("lognormal", 60.0, 40.0, 10.0, 300.0)
    rng = np.random.default_rng(1)
    samples = [spec.sample(rng) for _ in range(5000)]
    assert min(samples) >= 10.0 and max(samples) <= 300.0
    assert DurationSpec.from_dict(spec.to_dict()) == spec


def test_read_item_spec_matches_discrete_item_rate():
    tm = TimeModel()
    reply_p, vote_p = 0.1, 0.2
    spec = tm.read_item_spec(10, reply_p, vote_p)
    cycle = spec.expected() + reply_p * tm.reply_compose.expected() + vote_p * tm.vote.expected()
    # One reference step of activity yields read_density items on average
    assert cycle == pytest.approx(tm.reference_step_s / 10)


def test_read_item_spec_floor():
    tm = TimeModel()
    spec = tm.read_item_spec(1000, 1.0, 1.0)
    assert spec.expected() == tm.min_read_mean_s


def test_post_rate_keeps_expected_count():
    tm = TimeModel()
    # p per 300 s step -> p posts per step on average
    assert tm.post_rate_per_s(0.1) * tm.reference_step_s == pytest.approx(0.1)


def test_session_lengths_match_discrete_ranges():
    tm = TimeModel()
    rng = np.random.default_rng(2)
    medium = [tm.session_length_s("medium", rng) for _ in range(20000)]
    discrete = [session_length_timesteps("medium", rng) * 300 for _ in range(20000)]
    assert np.mean(medium) == pytest.approx(np.mean(discrete), rel=0.02)
    assert tm.session_length_s("short", rng) == 300.0


def test_default_action_durations():
    tm = TimeModel()
    rng = np.random.default_rng(0)
    for spec, seconds in ((tm.vote, 1.0), (tm.reply_compose, 48.0), (tm.post_compose, 133.0)):
        assert spec.dist == "fixed" and spec.sample(rng) == seconds


def test_overrides_and_validation():
    rng = np.random.default_rng(1)
    tm = TimeModel.from_config({"reply_compose": {"mean_s": 90}, "min_read_mean_s": 2})
    # overriding a fixed duration's value moves its bounds too (not clipped to 49 s)
    assert tm.reply_compose.dist == "fixed" and tm.reply_compose.sample(rng) == 90.0
    assert tm.min_read_mean_s == 2.0
    # switching a fixed duration to a distribution drops the old fixed bounds
    tm = TimeModel.from_config({"post_compose": {"dist": "lognormal", "mean_s": 120, "sd_s": 60}})
    samples = [tm.post_compose.sample(rng) for _ in range(2000)]
    assert np.std(samples) > 10 and np.mean(samples) == pytest.approx(120, rel=0.1)
    # explicit bounds are kept
    tm = TimeModel.from_config({"vote": {"dist": "uniform", "min_s": 2, "max_s": 4}})
    assert 2.0 <= tm.vote.sample(rng) <= 4.0
    with pytest.raises(ValueError):
        TimeModel.from_config({"calibration_mode": "absolute"})
    assert "vote" in TimeModel().to_dict()


def test_activity_intervals_from_schedule():
    sched = [0, 1, 1, 0, 0, 1, 0, 1]
    iv = ActivityIntervals.from_schedule(sched, 300.0)
    assert iv.intervals == [(300.0, 900.0), (1500.0, 1800.0), (2100.0, 2400.0)]
    assert iv.contains(300.0) and iv.contains(899.0)
    assert not iv.contains(900.0) and not iv.contains(0.0)
    assert iv.clip(600, 2200) == [(600, 900.0), (1500.0, 1800.0), (2100.0, 2200)]
    assert iv.total() == 1200.0


def test_sample_time_in_windows():
    rng = np.random.default_rng(3)
    windows = [(0.0, 10.0), (100.0, 110.0)]
    for _ in range(200):
        t = sample_time_in(windows, rng)
        assert 0 <= t < 10 or 100 <= t < 110
    assert sample_time_in([], rng) is None


def test_scheduler_orders_by_time_kind_agent_then_insertion():
    s = EventScheduler()
    s.schedule(10.0, EventKind.READ_START, 1, "a")
    s.schedule(10.0, EventKind.COMMIT, 5, "b")
    s.schedule(10.0, EventKind.COMMIT, 2, "c")
    s.schedule(5.0, EventKind.READ_START, 9, "d")
    s.schedule(10.0, EventKind.COMMIT, 2, "e")
    s.schedule(10.0004, EventKind.COMMIT, 0, "f")  # rounds to the same ms
    order = [s.pop().payload for _ in range(len(s))]
    assert order == ["d", "f", "c", "e", "b", "a"]
