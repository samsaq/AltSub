"""parameter_tuning wiring (halving/hyperband/random) with the simulation subprocess faked.

The fake writes a final_output.json whose mitigation_summary depends on the
candidate's mitigation_scan_frequency (best near 30; for the rule moderation
stage, its detection threshold, best near 0.6) and the seed: better settings
catch more of the 2 attacker accounts (of 10 users), so the account-level MCC
gives the search something to find without running simulations.
"""

import csv
import hashlib
import json
import sys
import threading
from pathlib import Path

import pytest

from python_simulation.tools import parameter_tuning as pt


class FakeRunner:
    def __init__(self):
        self.calls = []
        self.lock = threading.Lock()

    def __call__(self, repo_root, config_dir, output_dir, timeout_sec, *, stream_output=False, seed=None):
        cfg = json.loads((config_dir / "simulation_config.json").read_text())
        mit = cfg["mitigation_config"]
        with self.lock:
            self.calls.append({"config": cfg, "seed": seed, "dir": str(config_dir)})
        h = hashlib.sha256(f"{seed}:{json.dumps(mit, sort_keys=True)}".encode()).digest()
        noise = h[0] % 3
        if mit.get("enable_rule_moderators"):
            quality = 20 - abs(mit.get("rule_moderator_detection_threshold", 0.7) - 0.6) * 30
        else:
            quality = 20 - abs(mit["mitigation_scan_frequency"] - 30) / 3
        caught = 2 if quality + noise >= 18 else 1 if quality + noise >= 12 else 0
        sources = [src for src, key in (
            ("duplicate", "enable_duplicate_detection"), ("rate_limit", "enable_rate_limiting"),
            ("coordination", "enable_coordinated_detection"), ("rule_moderator", "enable_rule_moderators"),
        ) if mit.get(key)]
        flagged = ["1", "2"][:caught] + (["3"] if noise == 2 else [])
        types = {"1": "llm_attacker", "2": "template_attacker",
                 **{str(i): "llm_user" for i in range(3, 11)}, "11": "rule_moderator"}
        output_dir.mkdir(parents=True, exist_ok=True)
        (output_dir / "final_output.json").write_text(json.dumps({
            "mitigation_summary": {
                "flag_counts_by_agent": {a: 3 * len(sources) for a in flagged},
                "flag_counts_by_source": {a: {s: 3 for s in sources} for a in flagged},
                "first_flag_time_s_by_source": {a: {s: 3600.0 for s in sources} for a in flagged},
                "mitigation_ban_time_s": {a: 7200.0 for a in flagged},
                "agent_type_by_id": types,
                "banned_agent_ids": flagged,
            }
        }))
        return True, ""


def write_base(root, days=3, name="base"):
    base = root / name
    base.mkdir()
    steps = 288 * days
    (base / "simulation_config.json").write_text(json.dumps({
        "simulation_config": {"duration_days": days, "interval_minutes": 5},
        "runtime_config": {"seed": 7},
        "mitigation_config": {"mitigation_scan_frequency": 12},
        "agent_activity_schedules": {"0": [1] * steps, "1": [0] * steps},
    }))
    (base / "agent_profiles.json").write_text(json.dumps(
        [{"user_type": "llm_user"}, {"user_type": "attacker"}]
    ))
    return base


@pytest.fixture
def fake(monkeypatch):
    runner = FakeRunner()
    monkeypatch.setattr(pt, "_run_simulation", runner)
    return runner


def run_main(monkeypatch, *argv):
    monkeypatch.setattr(sys, "argv", ["parameter_tuning", *map(str, argv)])
    pt.main()


SMALL = ("--configs", 6, "--eta", 3, "--rungs", "1:1,full:2", "--race-max-seeds", 4,
         "--race-min-seeds", 3, "--confirm-seeds", 3, "--max-workers", 4, "--quiet")


def test_halving_end_to_end(tmp_path, monkeypatch, fake):
    base = write_base(tmp_path)
    root = tmp_path / "tuning"
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", root, "--seed", 3, *SMALL)

    results = json.loads((root / "results" / "tuning_results.json").read_text())
    assert results["method"] == "halving"
    assert set(results["stages"]) == set(pt.DEFAULT_STAGES)
    for stage in pt.DEFAULT_STAGES:
        scenario = pt.STAGE_SCENARIOS[stage]
        best = results["stages"][stage][0]
        assert best["error"] is None and best["reached"] == "race_survivor"
        # auto_runner contract (MITIGATION_MAP): runs/<stage>/<scenario>/trial_<id>/config
        cfg_path = root / "runs" / stage / scenario / f"trial_{best['trial_id']:04d}" / "config" / "simulation_config.json"
        cfg = json.loads(cfg_path.read_text())
        assert cfg["simulation_config"]["duration_days"] == 3  # full length, not a short rung
        for k, v in best["params"].items():
            assert cfg["mitigation_config"][k] == v
        assert cfg["mitigation_config"]["mitigation_ban_threshold"] == pt.MITIGATION_BAN_THRESHOLD
        racing_info = results["racing"][stage]
        assert racing_info["confirmation"], "winner and baseline rerun on held-out seeds"
        assert set(racing_info["heldout_seeds"]).isdisjoint(racing_info["tuning_seeds"])

    # Every run: seed passed and written to the config; short rungs really shortened
    for call in fake.calls:
        assert call["config"]["runtime_config"]["seed"] == call["seed"]
        days = call["config"]["simulation_config"]["duration_days"]
        assert days in (1, 3)
        assert len(call["config"]["agent_activity_schedules"]["0"]) == 288 * days

    rows = list(csv.DictReader(open(root / "results" / "tuning_evaluations.csv", encoding="utf-8")))
    assert len(rows) == len(fake.calls)
    assert "Noise ratio" in (root / "results" / "tuning_results.txt").read_text()

    # Resume: same seed and inputs -> nothing reruns, same winners
    n = len(fake.calls)
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", root, "--seed", 3, "--resume", *SMALL)
    assert len(fake.calls) == n
    again = json.loads((root / "results" / "tuning_results.json").read_text())
    assert {s: e[0]["trial_id"] for s, e in again["stages"].items()} == \
        {s: e[0]["trial_id"] for s, e in results["stages"].items()}

    # Without --resume everything reruns
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", root, "--seed", 3, *SMALL)
    assert len(fake.calls) == 2 * n


def test_stage1_parallel_matches_sequential(tmp_path, monkeypatch, fake):
    base = write_base(tmp_path)
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", tmp_path / "a", *SMALL)
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", tmp_path / "b", "--sequential-stage1", *SMALL)
    a = json.loads((tmp_path / "a" / "results" / "tuning_results.json").read_text())
    b = json.loads((tmp_path / "b" / "results" / "tuning_results.json").read_text())
    assert a["racing"] == b["racing"]


def test_hyperband_and_dry_run(tmp_path, monkeypatch, fake, capsys):
    base = write_base(tmp_path)
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", tmp_path / "t", "--dry-run",
             "--method", "hyperband", *SMALL)
    assert "bracket 1" in capsys.readouterr().out
    assert fake.calls == [] and not (tmp_path / "t").exists()
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", tmp_path / "t", "--method", "hyperband", *SMALL)
    results = json.loads((tmp_path / "t" / "results" / "tuning_results.json").read_text())
    brackets = {r["bracket"] for r in results["racing"]["stage_1_duplicate_only"]["rungs"]}
    assert brackets == {0, 1}


def test_random_method_still_works(tmp_path, monkeypatch, fake):
    base = write_base(tmp_path)
    root = tmp_path / "tuning"
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", root, "--method", "random",
             "--trials", 8, "--quiet")
    results = json.loads((root / "results" / "tuning_results.json").read_text())
    assert set(results["stages"]) == set(pt.DEFAULT_STAGES)
    assert len(fake.calls) == 8


def test_run_simulation_seed_overrides_env(monkeypatch, tmp_path):
    seen = {}

    class Proc:
        returncode = 0
        pid = 1

        def communicate(self, timeout=None):
            return "", ""

    def popen(cmd, **kw):
        seen["cmd"], seen["kw"] = cmd, kw
        return Proc()

    monkeypatch.setenv("SIM_SEED", "999")
    monkeypatch.setattr(pt.subprocess, "Popen", popen)
    ok, _ = pt._run_simulation(tmp_path, tmp_path, tmp_path, 10, seed=42)
    assert ok
    assert seen["cmd"][-2:] == ["--seed", "42"]
    assert "SIM_SEED" not in seen["kw"]["env"]
    pt._run_simulation(tmp_path, tmp_path, tmp_path, 10)
    assert "--seed" not in seen["cmd"] and "env" not in seen["kw"]


def test_two_setups_each_evaluation_runs_both(tmp_path, monkeypatch, fake):
    llm = write_base(tmp_path, name="llm_attackers")
    tpl = write_base(tmp_path, name="template_attackers")
    root = tmp_path / "tuning"
    run_main(monkeypatch, "--base-config-dir", llm, tpl, "--tuning-root", root, "--seed", 3, *SMALL)
    results = json.loads((root / "results" / "tuning_results.json").read_text())
    assert results["calibration_setups"] == ["llm_attackers", "template_attackers"]
    # Every evaluation (evals/<days>_seed<seed>/<setup>/config) ran both setups, same seed
    by_eval = {}
    for call in fake.calls:
        config_dir = Path(call["dir"])
        by_eval.setdefault(config_dir.parents[1], []).append((config_dir.parent.name, call["seed"]))
    for runs in by_eval.values():
        assert sorted(label for label, _ in runs) == ["llm_attackers", "template_attackers"]
        assert len({seed for _, seed in runs}) == 1
    best = results["stages"]["stage_1_duplicate_only"][0]
    assert set(best["mcc_by_setup"]) == {"llm_attackers", "template_attackers"}
    rule = results["stages"]["stage_1_rule_moderation_only"][0]
    assert set(rule["params"]) == {"rule_moderator_detection_threshold"}


def test_setup_without_attackers_is_rejected(tmp_path, monkeypatch, fake):
    base = write_base(tmp_path)
    (base / "agent_profiles.json").write_text(json.dumps([{"user_type": "llm_user"}]))
    with pytest.raises(SystemExit, match="no attacker profiles"):
        run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", tmp_path / "t", *SMALL)


def test_stages_default_to_batch_set_and_coordination_is_opt_in(tmp_path, monkeypatch, fake):
    assert "stage_1_coordination_only" not in pt.DEFAULT_STAGES
    assert "stage_2_all_mitigations_except_coordination" in pt.DEFAULT_STAGES
    base = write_base(tmp_path)
    root = tmp_path / "tuning"
    run_main(monkeypatch, "--base-config-dir", base, "--tuning-root", root,
             "--stages", "stage_1_coordination_only", "stage_2_all_mitigations_except_coordination", *SMALL)
    results = json.loads((root / "results" / "tuning_results.json").read_text())
    assert set(results["stages"]) == {"stage_1_coordination_only", "stage_2_all_mitigations_except_coordination"}
    # stage 2 runs include the rule moderators, coordination off
    stage2 = [c["config"] for c in fake.calls
              if c["config"]["mitigation_config"].get("enable_rule_moderators")]
    assert stage2 and all(not c["mitigation_config"]["enable_coordinated_detection"] for c in stage2)
    assert all("rule_moderator_detection_threshold" in c["mitigation_config"] for c in stage2)
