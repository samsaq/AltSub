"""campaign_templates_dir may be written relative to the config folder (core/config_paths.py)."""

from pathlib import Path

from python_simulation.core.config_paths import resolve_config_paths


def test_relative_dir_resolves_against_config_folder(tmp_path):
    cfg = {"campaign_config": {"campaign_templates_dir": "../campaign_templates"}}
    resolve_config_paths(cfg, tmp_path / "llm_attackers")
    assert Path(cfg["campaign_config"]["campaign_templates_dir"]) == (tmp_path / "campaign_templates").resolve()


def test_absolute_and_missing_are_unchanged(tmp_path):
    absolute = str((tmp_path / "templates").resolve())
    cfg = {"campaign_config": {"campaign_templates_dir": absolute}}
    assert resolve_config_paths(cfg, tmp_path / "x")["campaign_config"]["campaign_templates_dir"] == absolute
    assert resolve_config_paths({}, tmp_path) == {}
    assert resolve_config_paths({"campaign_config": {}}, tmp_path) == {"campaign_config": {}}
