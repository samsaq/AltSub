"""SimulationState invariants: event bookkeeping, votes, scores, removal."""

from python_simulation.core.simulation_data import (
    BannedAgentNetwork,
    BeliefNetwork,
    EventType,
    MediaEvent,
    SimulationState,
)

from ..factories import ev, make_world


def test_event_time_prefers_time_s_and_falls_back_to_timestep():
    state = SimulationState(timestep_duration_seconds=60.0)
    e = MediaEvent(0, 1, None, EventType.POST, "b", "s", 7)
    assert state.event_time(e) == 420.0
    e.time_s = 431.5
    assert state.event_time(e) == 431.5


def test_post_with_parent_and_vote_without_parent_are_invalid():
    import pytest

    with pytest.raises(ValueError):
        MediaEvent(0, 1, 5, EventType.POST, "b", "s", 0)
    with pytest.raises(ValueError):
        MediaEvent(0, 1, None, EventType.UPVOTE, "b", "s", 0)


def test_votes_update_voter_lists_and_score_not_replies():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 0)
    am.commit_event(ev(2, EventType.DOWNVOTE, post.event_id), 0)
    am.commit_event(ev(3, EventType.UPVOTE, post.event_id), 0)
    reply = am.commit_event(ev(1, EventType.REPLY, post.event_id), 0)
    assert post.replies == [reply.event_id]
    assert post.upvotes == [1, 3] and post.downvotes == [2]
    assert post.score == 1
    assert [v.event_id for v in state.votes_by_target[post.event_id]] == [1, 2, 3]


def test_events_indexed_by_id_and_user():
    state, am = make_world()
    a = am.commit_event(ev(0, EventType.POST), 0)
    b = am.commit_event(ev(0, EventType.POST), 1)
    c = am.commit_event(ev(1, EventType.REPLY, a.event_id), 1)
    assert [a.event_id, b.event_id, c.event_id] == [0, 1, 2]
    assert state.get_event(1) is b
    assert state.get_user_events(0) == [a, b]
    state.get_user_events(0).clear()  # returns a copy
    assert len(state.get_user_events(0)) == 2


def test_remove_event_cascades_through_thread_and_votes():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    r1 = am.commit_event(ev(1, EventType.REPLY, post.event_id), 0)
    r2 = am.commit_event(ev(2, EventType.REPLY, r1.event_id), 0)
    v1 = am.commit_event(ev(3, EventType.UPVOTE, r2.event_id), 0)
    v_post = am.commit_event(ev(2, EventType.UPVOTE, post.event_id), 0)
    other = am.commit_event(ev(3, EventType.POST), 0)

    removed = state.remove_event(r1.event_id)
    assert set(removed) == {r1.event_id, r2.event_id, v1.event_id}
    assert state.removed_by_cascade == 2
    assert post.replies == [] and post.score == 1  # its own vote is untouched
    assert [e.event_id for e in state.events] == [post.event_id, v_post.event_id, other.event_id]
    assert all(e.event_id not in removed for evs in state.events_by_user.values() for e in evs)
    assert r2.event_id not in state.votes_by_target


def test_removing_a_post_removes_votes_on_it():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    vote = am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 0)
    assert set(state.remove_event(post.event_id)) == {post.event_id, vote.event_id}
    assert state.events == []


def test_removing_a_vote_restores_score():
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    v = am.commit_event(ev(1, EventType.DOWNVOTE, post.event_id), 0)
    assert post.score == -1
    assert state.remove_event(v.event_id) == [v.event_id]
    assert post.score == 0 and post.downvotes == [] and state.votes_by_target[post.event_id] == []


def test_remove_missing_event_is_a_no_op():
    state, _ = make_world()
    assert state.remove_event(123) == []


def test_belief_network_clamps():
    bn = BeliefNetwork()
    bn.set_belief(1, "x", 1.4)
    bn.update_belief(1, "y", -0.3)
    assert bn.get_agent_beliefs(1) == {"x": 1.0, "y": 0.0}
    bn.replace_agent_beliefs(1, {"z": "0.5"})
    assert bn.get_agent_beliefs(1) == {"z": 0.5}
    assert bn.get_belief(9, "q") == 0.0


def test_ban_threshold():
    bans = BannedAgentNetwork()
    bans.increment_ban(1, "s")
    assert bans.is_banned(1, "s") and not bans.is_banned(1, "s", threshold=2)
    assert not bans.is_banned(1, "other")
