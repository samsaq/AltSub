"""Account-level MCC used as the mitigation tuning objective (tools/account_mcc.py)."""

import math

import pytest

from python_simulation.tools.account_mcc import account_confusion, mcc


def summary(**kw):
    base = {
        # 2 attackers, 4 organic users, 1 rule moderator (not a user)
        "agent_type_by_id": {"0": "llm_attacker", "1": "template_attacker", "2": "llm_user",
                             "3": "llm_user", "4": "llm_user", "5": "llm_user",
                             "6": "rule_moderator"},
        "flag_counts_by_agent": {},
        "flag_counts_by_source": {},
        "first_flag_time_s_by_source": {},
        "mitigation_ban_time_s": {},
        "banned_agent_ids": [],
    }
    base.update(kw)
    return {"mitigation_summary": base}


def test_mcc_formula_and_undefined_cases():
    assert mcc(2, 0, 0, 23) == pytest.approx(1.0)
    assert mcc(0, 2, 2, 0) == pytest.approx(-1.0)
    assert mcc(1, 1, 1, 22) == pytest.approx(21 / 46)
    # no predicted positives / no attackers: denominator 0 -> 0
    assert mcc(0, 0, 2, 23) == 0.0
    assert mcc(0, 1, 0, 24) == 0.0


def test_flagged_counts_only_the_given_sources():
    out = summary(
        flag_counts_by_source={"0": {"duplicate": 2}, "1": {"rate_limit": 1}, "2": {"duplicate": 1}},
        first_flag_time_s_by_source={"0": {"duplicate": 7200.0}, "1": {"rate_limit": 3600.0}},
    )
    c = account_confusion(out, "flagged", ["duplicate"])
    assert (c["tp"], c["fp"], c["fn"], c["tn"]) == (1, 1, 1, 3)
    assert c["n_users"] == 6 and c["n_attackers"] == 2  # the rule moderator is not scored
    assert c["mcc"] == pytest.approx(mcc(1, 1, 1, 3))
    assert c["attacker_detect_hours"] == pytest.approx(2.0)
    any_source = account_confusion(out, "flagged", None)
    assert (any_source["tp"], any_source["fp"]) == (0, 0)  # falls back to flag_counts_by_agent (empty)


def test_banned_decision_and_detection_time():
    out = summary(banned_agent_ids=["0", "1", "6"], mitigation_ban_time_s={"0": 3600.0, "1": 10800.0})
    c = account_confusion(out, "banned")
    assert (c["tp"], c["fp"], c["fn"], c["tn"]) == (2, 0, 0, 4)
    assert c["mcc"] == pytest.approx(1.0)
    assert c["attacker_detect_hours"] == pytest.approx(2.0)


def test_users_who_never_acted_count_as_negatives():
    out = summary(banned_agent_ids=["0"])
    c = account_confusion(out, "banned")
    assert c["tn"] == 4 and c["fn"] == 1
    assert math.isclose(c["mcc"], mcc(1, 0, 1, 4))


def test_old_outputs_fall_back_to_total_flags():
    out = summary(flag_counts_by_agent={"0": 1, "3": 2})
    out["mitigation_summary"].pop("flag_counts_by_source")
    c = account_confusion(out, "flagged", ["duplicate"])
    assert (c["tp"], c["fp"]) == (1, 1)
