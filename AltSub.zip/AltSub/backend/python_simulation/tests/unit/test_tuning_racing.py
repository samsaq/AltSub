"""Successive halving / Hyperband / racing scheduler (tools/tuning_racing.py) on synthetic objectives."""

import hashlib
import math

import pytest

from python_simulation.tools import tuning_racing as racing
from python_simulation.tools.tuning_racing import (
    BASELINE_CONFIG_ID, Rung, ScoreBook, SearchSettings,
)


def _noise(config_id, days, seed, scale):
    h = hashlib.sha256(f"{config_id}:{days}:{seed}".encode()).digest()
    return (int.from_bytes(h[:4], "big") / 2**32 - 0.5) * 2 * scale


class Synthetic:
    """Objective = params["q"] + seeded noise; records every request."""

    def __init__(self, noise=0.0, fail=()):
        self.noise = noise
        self.fail = set(fail)  # config ids whose runs all fail
        self.requests = []
        self.batches = []

    def __call__(self, requests):
        self.batches.append(list(requests))
        out = []
        for r in requests:
            self.requests.append(r)
            if r.config_id in self.fail:
                out.append(racing.EvalResult(r, None, {"error": "boom"}))
            else:
                v = r.params.get("q", 0.0) + _noise(r.config_id, r.days, r.seed, self.noise)
                out.append(racing.EvalResult(r, v, {}))
        return out


def sampler(values):
    it = iter(values)
    return lambda: {"q": next(it)}


SEEDS = racing.derive_seeds(1, "tuning", 12)
HELDOUT = racing.derive_seeds(1, "heldout", 6)


# rungs/seeds
def test_parse_rungs_full_and_clamp():
    assert racing.parse_rungs("1:1, full:2,3:4", full_days=3) == [Rung(1, 1), Rung(None, 2), Rung(None, 4)]
    assert racing.parse_rungs("1:1,2:1") == [Rung(1, 1), Rung(2, 1)]


@pytest.mark.parametrize("spec", ["", "1:0", "0:1", "2:1,1:1", "1:2,1:1", "1:1,1:1", "x", "1-1"])
def test_parse_rungs_rejects(spec):
    with pytest.raises(ValueError):
        racing.parse_rungs(spec)


def test_derive_seeds_deterministic_and_streams_disjoint():
    assert racing.derive_seeds(5, "tuning", 8) == racing.derive_seeds(5, "tuning", 8)
    assert racing.derive_seeds(5, "tuning", 4) == racing.derive_seeds(5, "tuning", 8)[:4]
    assert not set(racing.derive_seeds(5, "tuning", 50)) & set(racing.derive_seeds(5, "heldout", 50))
    assert racing.derive_seeds(5, "tuning", 8) != racing.derive_seeds(6, "tuning", 8)


# halving
def test_halving_counts_common_seeds_and_reuse():
    configs = {i: {"q": float(i)} for i in range(1, 28)}
    ev = Synthetic()
    book = ScoreBook()
    rungs = [Rung(1, 1), Rung(None, 2), Rung(None, 4)]
    survivors, records = racing.successive_halving(configs, list(configs), rungs, 3, SEEDS, book, ev)
    assert [len(r.scores) for r in records] == [27, 9, 3]
    assert [r.new_runs for r in records] == [27, 18, 6]  # full x4 reuses full x2
    assert survivors == [27, 26, 25]
    # Common random numbers: every config in a rung ran on the same seeds
    for rec in records:
        assert {s.seeds for s in rec.scores} == {tuple(SEEDS[: rec.rung.seeds])}
    # No (config, days, seed) evaluated twice
    keys = [(r.config_id, r.days, r.seed) for r in ev.requests]
    assert len(keys) == len(set(keys))


def test_halving_ranks_failed_configs_last_and_never_promotes_them():
    configs = {i: {"q": float(i)} for i in range(1, 7)}
    ev = Synthetic(fail={6, 5})
    book = ScoreBook()
    survivors, records = racing.successive_halving(
        configs, list(configs), [Rung(1, 1), Rung(None, 1)], 2, SEEDS, book, ev
    )
    assert records[0].promoted == [4, 3, 2]
    assert [s.config_id for s in records[0].scores][-2:] == [5, 6]


def test_halving_finds_best_under_noise():
    # True quality 0..26; noise sd ~ 1.7, rungs average more seeds later
    configs = {i: {"q": float(i - 1)} for i in range(1, 28)}
    ev = Synthetic(noise=3.0)
    survivors, _ = racing.successive_halving(
        configs, list(configs), [Rung(1, 1), Rung(None, 3), Rung(None, 6)], 3, SEEDS, ScoreBook(), ev
    )
    assert survivors[0] in (27, 26, 25)


def test_hyperband_brackets():
    assert racing.hyperband_brackets(27, 3, 3) == [(0, 27), (1, 9), (2, 3)]
    assert racing.hyperband_brackets(5, 3, 3) == [(0, 5), (1, 2), (2, 1)]


# racing
def test_race_eliminates_clear_losers_and_keeps_leader():
    configs = {1: {"q": 10.0}, 2: {"q": 0.0}, 3: {"q": 9.9}, 4: {"q": -5.0}}
    ev = Synthetic(noise=0.5)
    book = ScoreBook()
    rec = racing.race(configs, [1, 2, 3, 4], None, SEEDS, 2, 10, 0.05, 3, book, ev)
    assert 1 in rec.survivors
    assert 2 in rec.eliminated_order and 4 in rec.eliminated_order
    assert rec.eliminated_order.index(4) <= rec.eliminated_order.index(2)  # worst out first
    assert rec.survivors[0] == 1


def test_race_stops_at_max_seeds_when_indistinguishable():
    configs = {1: {"q": 1.0}, 2: {"q": 1.0}, 3: {"q": 1.0}}
    ev = Synthetic(noise=1.0)
    rec = racing.race(configs, [1, 2, 3], None, SEEDS, 2, 6, 0.05, 3, ScoreBook(), ev)
    assert rec.seeds_used == 6
    assert len(rec.survivors) >= 2


def test_race_zero_variance_objective():
    # Count-based objectives often tie exactly; constant gaps are significant, exact ties are not
    configs = {1: {"q": 5.0}, 2: {"q": 5.0}, 3: {"q": 2.0}}
    rec = racing.race(configs, [1, 2, 3], None, SEEDS, 1, 5, 0.05, 3, ScoreBook(), Synthetic())
    assert rec.eliminated_order == [3]
    assert sorted(rec.survivors) == [1, 2]


def test_race_drops_config_that_always_fails():
    configs = {1: {"q": 1.0}, 2: {"q": 2.0}}
    rec = racing.race(configs, [1, 2], None, SEEDS, 1, 4, 0.05, 2, ScoreBook(), Synthetic(fail={2}))
    assert rec.survivors == [1]


def test_paired_tests_edge_cases():
    assert racing.paired_greater_p([1, 2], [0, 1]) == 0.0  # constant positive gap
    assert racing.paired_greater_p([1, 1], [1, 1]) == 1.0
    assert racing.paired_greater_p([1], [0]) == 1.0  # one pair: no test
    assert racing.friedman_p([[1, 1, 1], [2, 2, 2]]) == 1.0
    assert racing.friedman_p([[3, 2, 1], [3, 2, 1], [3, 2, 1], [3, 2, 1]]) < 0.05


# whole search
def small_settings(**kw):
    base = dict(
        n_configs=9, eta=3, rungs=[Rung(1, 1), Rung(None, 3)], race_max_seeds=6,
        race_min_seeds=3, confirm_top=1, confirm_seeds=4,
    )
    base.update(kw)
    return SearchSettings(**base)


def test_run_search_end_to_end_with_heldout_and_baseline():
    ev = Synthetic(noise=0.2)
    settings = small_settings()
    res = racing.run_search(sampler([float(i) for i in range(9)]), settings, SEEDS, HELDOUT, ev,
                            baseline_params={"q": 3.0})
    assert res.best_config_id == 9
    # Confirmation ran at full fidelity on held-out seeds only
    confirm = [r for r in ev.requests if r.label == "confirm"]
    assert {r.seed for r in confirm} == set(HELDOUT[:4])
    assert {r.days for r in confirm} == {None}
    assert {r.config_id for r in confirm} == {9, BASELINE_CONFIG_ID}
    assert not {r.seed for r in ev.requests if r.label != "confirm"} & set(HELDOUT)
    (diff,) = res.baseline_diffs
    assert diff["config_id"] == 9 and diff["mean_diff"] == pytest.approx(5.0, abs=0.5)
    assert diff["ci95"][0] > 0
    # Ranking: winner first, every sampled config listed once, baseline excluded
    ranking = res.ranking()
    assert ranking[0]["config_id"] == 9 and ranking[0]["heldout"] is not None
    assert sorted(r["config_id"] for r in ranking) == list(range(1, 10))


def test_run_search_is_deterministic():
    def go():
        ev = Synthetic(noise=1.0)
        res = racing.run_search(sampler([float(i % 4) for i in range(9)]), small_settings(), SEEDS, HELDOUT, ev)
        return [(r.config_id, r.days, r.seed) for r in ev.requests], res.race.survivors
    assert go() == go()


def test_run_search_hyperband_races_all_bracket_finalists():
    ev = Synthetic()
    settings = small_settings(method="hyperband", confirm_top=0)
    res = racing.run_search(sampler([float(i) for i in range(20)]), settings, SEEDS, HELDOUT, ev)
    # brackets: 9 configs from rung 0 (-> 3), 3 configs straight at rung 1
    assert len(res.configs) == 12
    assert len(res.race.entrants) == 6
    assert res.best_config_id == 12
    assert res.confirmation == []


def test_run_search_rejects_overlapping_seeds():
    with pytest.raises(ValueError):
        racing.run_search(sampler([0.0] * 9), small_settings(), SEEDS, SEEDS[:4], Synthetic())


def test_plan_budget_bounds_actual_runs():
    for method in ("halving", "hyperband"):
        settings = small_settings(method=method)
        ev = Synthetic(noise=5.0)
        racing.run_search(sampler([0.0] * 30), settings, SEEDS, HELDOUT, ev)
        plan = racing.plan_budget(settings)
        assert len(ev.requests) <= plan["total_runs_max"]
    # Exact for the deterministic part of the default schedule
    plan = racing.plan_budget(SearchSettings())
    assert [r["new_runs"] for r in plan["brackets"][0]["rungs"]] == [27, 18, 6]
    assert plan["race_runs_max"] == 3 * (8 - 4)
    assert plan["confirm_runs"] == 2 * 5


def test_noise_summary():
    book = ScoreBook()
    for cid, q in ((1, 0.0), (2, 10.0)):
        for seed, eps in zip(SEEDS[:4], (-1, 1, -1, 1)):
            book.add(racing.EvalResult(racing.EvalRequest(cid, {}, None, seed, "x"), q + eps))
    ns = racing.noise_summary(book, [1, 2], None, SEEDS[:4])
    assert ns["within_sd"] == pytest.approx(math.sqrt(4 / 3))
    assert ns["between_sd"] == pytest.approx(math.sqrt(50))
    assert ns["ratio"] < 0.2
