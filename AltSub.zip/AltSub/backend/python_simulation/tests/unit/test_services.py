"""LLM JSON handling, the LLM service, the stub provider, orchestrator, consolidation."""

import json
from typing import List

import numpy as np
import pytest

from python_simulation.services.belief_consolidation import consolidate_beliefs, cull_to_cap
from python_simulation.services.llm_json import (
    complete_json,
    extract_json_text,
    hour_of_day,
    parse_json_text,
    require_unit_floats,
    unit_float,
)
from python_simulation.services.llm_provider import LLMResponse
from python_simulation.services.stub_llm_provider import StubLLMProvider

from ..factories import SUB, FakeCanonicalizer, ban, make_world, stub_llm_service


class ScriptedProvider:
    """Provider returning scripted (content, finish_reason) replies in order."""

    supports_json_mode = True
    max_output_tokens = 4000

    def __init__(self, replies):
        self.replies = list(replies)
        self.calls: List[dict] = []

    def is_available(self):
        return True

    def chat_completion_meta(self, messages, temperature, max_tokens, **kwargs):
        self.calls.append({"messages": messages, "max_tokens": max_tokens, **kwargs})
        if not self.replies:
            return None
        content, finish = self.replies.pop(0)
        return LLMResponse(content, finish)

    def chat_completion(self, messages, temperature=0.3, max_tokens=500, **kwargs):
        r = self.chat_completion_meta(messages, temperature, max_tokens, **kwargs)
        return r.content if r else None


# llm_json


def test_extract_json_from_fences_and_prose():
    assert extract_json_text('Sure!\n```json\n{"a": 1}\n```') == '{"a": 1}'
    assert extract_json_text('text {"a": [1, 2]} trailing') == '{"a": [1, 2]}'
    assert extract_json_text("```\n[1, 2]") == "[1, 2]"


def test_parse_repairs_and_validates():
    data, status, _ = parse_json_text('{"a": 1,}')
    assert data == {"a": 1} and status == "repaired"
    data, status, err = parse_json_text("[1, 2]")
    assert data is None and "object" in err
    assert parse_json_text('{"items": [1]}', expect=list, wrap_key="items")[0] == [1]
    validate = require_unit_floats("p", "q", defaults={"q": 0.5})
    assert parse_json_text('{"p": 2, "q": "x"}', validate=validate)[0] == {"p": 1.0, "q": 0.5}
    assert parse_json_text('{"q": 1}', validate=validate)[0] is None


def test_complete_json_grows_tokens_on_truncation_then_succeeds():
    provider = ScriptedProvider([('{"a": ', "length"), ('{"a": 1}', "stop")])
    result = complete_json(provider, [{"role": "user", "content": "x"}], temperature=0, max_tokens=100)
    assert result.ok and result.data == {"a": 1}
    assert [c["max_tokens"] for c in provider.calls] == [100, 200]
    assert provider.calls[0]["response_format"] == {"type": "json_object"}


def test_complete_json_feedback_retry_then_failure():
    provider = ScriptedProvider([("not json at all", "stop"), ('{"a": 1}', "stop")])
    result = complete_json(provider, [{"role": "user", "content": "x"}], temperature=0,
                           max_tokens=50, validate=require_unit_floats("p"))
    assert not result.ok and result.status == "failed"
    assert "That reply was not valid" in provider.calls[1]["messages"][-1]["content"]
    ok = complete_json(ScriptedProvider([("nope", "stop"), ('{"p": 0.3}', "stop")]),
                       [{"role": "user", "content": "x"}], temperature=0, max_tokens=50,
                       validate=require_unit_floats("p"))
    assert ok.ok and ok.status == "retried"


def test_value_helpers():
    assert unit_float("0.4") == 0.4 and unit_float(7) == 1.0
    assert unit_float("nan") is None and unit_float(None) is None
    assert [hour_of_day(v) for v in (6, "06:00", "6pm", "12am", 24, "25", True)] == [
        6, 6, 18, 0, 23, None, None
    ]


# stub provider


def test_stub_provider_is_deterministic():
    stub = StubLLMProvider()
    msgs = [{"role": "user", "content": "You are replying to this post in r/x: hello"}]
    assert stub.chat_completion(msgs) == stub.chat_completion(msgs)
    assert stub.chat_completion([{"role": "user", "content": "unknown prompt"}]) == "{}"


def test_service_with_stub_returns_valid_shapes():
    svc = stub_llm_service()
    beliefs = {"a": 0.5, "b": 0.6}
    updated = svc.update_beliefs_from_content("Some content about the game", beliefs, belief_id_to_text={"a": "A", "b": "B"})
    assert set(updated) == {"a", "b"}
    assert all(abs(updated[k] - beliefs[k]) <= svc.config.belief_update_max_change + 1e-9 for k in beliefs)
    probs = svc.analyze_voting_decision("content", beliefs, SUB)
    assert set(probs) == {"upvote", "downvote", "no_vote"}
    assert svc.generate_post_content(beliefs, {}, SUB)
    assert svc.generate_reply_content("parent", beliefs, SUB)
    for text, strength in svc.extract_new_belief_claims("Long enough content to extract from", beliefs, SUB).items():
        assert 0.3 <= strength <= 1.0 and len(text) >= 5


def test_belief_update_is_bounded_and_ignores_unknown_keys():
    svc = stub_llm_service()
    svc._llm_provider = ScriptedProvider([('{"b1": 1.0, "b2": "x", "zz": 0.9}', "stop")])
    out = svc.update_beliefs_from_content("content", {"a": 0.2, "b": 0.5})
    assert out == {"a": pytest.approx(0.2 + svc.config.belief_update_max_change), "b": 0.5}
    svc._llm_provider = ScriptedProvider([])
    assert svc.update_beliefs_from_content("content", {"a": 0.2}) == {"a": 0.2}  # failure: unchanged
    assert svc.update_beliefs_from_content("   ", {"a": 0.2}) == {"a": 0.2}


def test_claim_extraction_filters_and_low_mode():
    svc = stub_llm_service()
    reply = json.dumps({"Raids are too hard": 0.8, "Weak": 0.9, "Loot is fair": 0.2, "Bad number": "x"})
    svc._llm_provider = ScriptedProvider([(reply, "stop")])
    assert svc.extract_new_belief_claims("c", {}, SUB) == {"Raids are too hard": 0.8}
    low = stub_llm_service(new_belief_strength_mode="low", new_belief_low_strength=0.35)
    low._llm_provider = ScriptedProvider([(reply, "stop")])
    assert low.extract_new_belief_claims("c", {}, SUB) == {"Raids are too hard": 0.35}


def test_canonicalize_claims_with_and_without_canonicalizer():
    svc = stub_llm_service()
    claims = {"Raids are too hard": 0.8}
    assert svc.canonicalize_claims(claims, {}) == {"raids_are_too_hard": ("Raids are too hard", 0.8)}
    canon = FakeCanonicalizer()
    out = svc.canonicalize_claims(claims, {}, canon, write_metadata=False)
    (belief_id,) = out
    assert canon.metadata_writes == []
    assert svc.canonicalize_claims(claims, {belief_id: 0.5}, canon) == {}


# orchestrator


def _orchestrator(n_attackers=2, provider=None):
    from python_simulation.agents.llm_attacker_agent import LLMAttackerAgent
    from python_simulation.services.attacker_campaign_orchestrator import (
        AttackerCampaignOrchestrator, CampaignConfig, CampaignObjective,
    )

    svc = stub_llm_service()
    agents = [
        LLMAttackerAgent(i, {"c": 0.9}, SUB, {"read": 5}, np.ones(288 * 2, bool), llm_service=svc)
        for i in range(n_attackers)
    ]
    state, am = make_world(agents=agents)
    orch = AttackerCampaignOrchestrator(CampaignConfig(CampaignObjective.AMPLIFY_NARRATIVE, "narr", daily_post_target=3))
    orch.llm_provider = provider or StubLLMProvider()
    orch.register_attacker_agents([a.agent_id for a in agents])
    return orch, state, am, agents


def test_campaign_plan_validation():
    from python_simulation.services.attacker_campaign_orchestrator import _validate_campaign_plan

    data, err = _validate_campaign_plan({"target_posts": [
        {"content": "x", "start_hour": "9pm", "end_hour": 6},
        {"content": "", "start_hour": 1, "end_hour": 2},
    ]})
    assert data["target_posts"] == [{"content": "x", "start_hour": 6, "end_hour": 21}]
    assert data["risk_assessment"] == 0.5
    assert _validate_campaign_plan({"target_posts": []})[0] is None


def test_plan_with_stub_and_fallback_when_llm_fails():
    orch, *_ = _orchestrator()
    plan = orch.plan_daily_campaign(0)
    assert len(plan.target_posts) == 3 and plan.source == "ok"
    orch.llm_provider = ScriptedProvider([("garbage", "stop"), ("still garbage", "stop")])
    fallback = orch.plan_daily_campaign(1)
    assert fallback.source == "fallback" and len(fallback.target_posts) == 1


def test_distribute_windows_round_robin_and_banned_skipped():
    orch, state, am, agents = _orchestrator(n_attackers=3)
    ban(state, 1)
    from python_simulation.services.attacker_campaign_orchestrator import DailyCampaignPlan

    plan = DailyCampaignPlan("day_1", [
        {"content": "a", "start_hour": 6, "end_hour": 9},
        {"content": "b", "start_hour": 23, "end_hour": 23},
        {"content": "c", "start_hour": 0, "end_hour": 0},
    ], {}, 0.3)
    delivered = []
    orch.distribute_instructions_to_agents(plan, am, 288, 1,
                                           deliver=lambda agent, instr: delivered.append((agent.agent_id, instr)))
    assert [a for a, _ in delivered] == [0, 2, 0]
    first, second, _ = (i for _, i in delivered)
    assert (first.start_timestep, first.end_timestep) == (288 + 72, 288 + 119)  # 06:00 to 09:55
    assert (second.start_timestep, second.end_timestep) == (288 + 276, 288 + 287)  # whole 23:00 hour
    assert (first.start_s, first.end_s) == (86400 + 6 * 3600, 86400 + 10 * 3600)


def test_default_delivery_uses_add_instruction():
    orch, state, am, agents = _orchestrator(n_attackers=1)
    from python_simulation.services.attacker_campaign_orchestrator import DailyCampaignPlan

    plan = DailyCampaignPlan("day_0", [{"content": "a", "start_hour": 2, "end_hour": 3}], {}, 0.3)
    orch.distribute_instructions_to_agents(plan, am, 288, 0)
    (instr,) = agents[0].pending_instructions
    assert 24 <= instr.execute_timestep <= 47


# consolidation


def test_cull_to_cap_keeps_protected_and_strongest():
    beliefs = {"p": 0.1, "a": 0.9, "b": 0.5, "c": 0.7}
    assert cull_to_cap(beliefs, 3, {"p"}) == {"p": 0.1, "a": 0.9, "c": 0.7}
    assert cull_to_cap({"a": 1.5}, 3, set()) == {"a": 1.0}


def test_consolidation_merges_same_beliefs_keeps_contradictions_and_drops_weak():
    canon = FakeCanonicalizer()
    texts = {
        "x1": "Raids are too hard", "x2": "raids are too hard",
        "y": "Raids are not too hard", "w": "Loot drops are fair", "campaign_1": "Buy the pass",
    }
    beliefs = {"x1": 0.8, "x2": 0.6, "y": 0.5, "w": 0.1, "campaign_1": 0.05}
    out = consolidate_beliefs(
        beliefs, belief_text_source=texts, canonicalizer=canon, belief_cap=10,
        protect_attacker_beliefs=True, weak_belief_threshold=0.2,
        campaign_belief_texts={"c": "Buy the pass"}, attacker_similarity_threshold=0.9,
    )
    assert out == {"x1": 0.8, "y": 0.5, "campaign_1": 0.05}
