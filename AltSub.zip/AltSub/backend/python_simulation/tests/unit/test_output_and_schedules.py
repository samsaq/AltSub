"""Output files (snapshots, media events, final output) and schedule generation."""

import json

import numpy as np

from python_simulation.core.rule_moderator_schedule import generate_rule_moderator_schedules
from python_simulation.core.simulation_data import EventType
from python_simulation.systems.mitigation_system import MitigationSystem
from python_simulation.systems.output_system import OutputManager

from ..factories import ev, make_world


def test_snapshot_slices_day_by_seconds_for_any_timestep_length(tmp_path):
    state, am = make_world()
    state.timestep_duration_seconds = 900.0  # 15-minute steps: 96 per day
    m = MitigationSystem(step_s=900.0)
    late_day0 = am.commit_event(ev(0, EventType.POST), 95)  # 85500 s
    day1 = am.commit_event(ev(0, EventType.POST), 96)  # 86400 s
    m.flag_agent(1, "x", state, timestep=95)
    m.flag_agent(2, "y", state, timestep=96)
    out = OutputManager(str(tmp_path))
    out.save_snapshot(95, 0, state, am, mitigation_system=m)
    snap = json.loads((tmp_path / "daily_snapshots" / "day_0_data.json").read_text())
    assert [e["event_id"] for e in snap["simulation_data"]["events"]] == [late_day0.event_id]
    assert snap["simulation_data"]["events"][0]["time_s"] == 85500.0
    assert [f["agent_id"] for f in snap["mitigation_data"]["flags_today"]] == [1]
    assert snap["time_unit_seconds"] == 900.0


def test_media_events_and_final_output_fields(tmp_path):
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 1, time_s=310.5)
    am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 1)
    am.commit_rejections["target_removed"] += 2
    out = OutputManager(str(tmp_path))
    out.save_media_events(state)
    out.save_final_output(state, am, MitigationSystem(), run_info={"time_model": "event", "seed": 3})
    media = json.loads((tmp_path / "media_events.json").read_text())
    assert media[0]["time_s"] == 310.5 and media[0]["timestamp"] == 1 and media[0]["replies"] == []
    final = json.loads((tmp_path / "final_output.json").read_text())
    assert final["commit_rejections"] == {"target_removed": 2}
    assert final["time_model"] == "event" and final["seed"] == 3
    assert final["event_counts_by_type"]["upvote"] == 1
    assert {"removed_by_cascade", "items_read", "time_unit_seconds"} <= set(final)


def test_rule_moderator_schedules_are_daily_staggered_blocks():
    tpd = 288
    schedules = generate_rule_moderator_schedules(tpd * 2, tpd, 3, 0.25, seed=1)
    assert len(schedules) == 3
    for s in schedules:
        for day in range(2):
            block = s[day * tpd:(day + 1) * tpd]
            assert block.sum() == 72
            on = np.flatnonzero(block)
            assert on[-1] - on[0] == 71  # one contiguous block
    # non-overlapping when 3 x 72 <= 288
    assert not np.any(schedules[0] & schedules[1])
    again = generate_rule_moderator_schedules(tpd * 2, tpd, 3, 0.25, seed=1)
    assert all(np.array_equal(a, b) for a, b in zip(schedules, again))
