"""Belief statement semantic check (tools/validate_belief_semantics.py) with a fake model."""

import csv
import json
import re

import pytest

from python_simulation.services.llm_provider import LLMResponse
from python_simulation.tools import validate_belief_semantics as vbs

LEVEL_WORDS = {"0.1": "hate", "0.5": "meh", "0.9": "love"}
WORD_VALUES = {"hate": 0.1, "meh": 0.5, "love": 0.9}


class FakeModel:
    """Answers each probe like a model that understands the statements.

    flip=True reverses the scale (0 read as acceptance) to check that failures show.
    """

    model = "fake-model"

    def __init__(self, items, flip=False):
        self.flip = flip
        self.expected = {it["text"]: it.get("expected", {}) for sc in items.values() for it in sc["items"]}
        self.calls = []

    def is_available(self):
        return True

    def _value(self, v):
        return round(1 - v, 2) if self.flip else v

    def chat_completion_meta(self, messages, temperature=0.3, max_tokens=500, **kwargs):
        prompt = messages[-1]["content"]
        self.calls.append((prompt, temperature))
        if "choose the description" in prompt:
            ans = {"0.0": "A", "0.5": "B", "1.0": "C"} if not self.flip else {"0.0": "C", "0.5": "B", "1.0": "A"}
            return LLMResponse(json.dumps(ans), "stop")
        if "Generate a natural, engaging post" in prompt or "You are replying to" in prompt:
            # Simulation post / reply prompt: write each held (non-neutral) view as a token
            held = re.findall(r'^- "(.*)" \(acceptance: ([0-9.]+)\)$', prompt, re.M)
            tokens = " ".join(f"a{n}={self._value(float(v))}" for n, (_, v) in enumerate(held, start=1)
                              if abs(float(v) - 0.5) >= 0.3)
            if "Generate a natural, engaging post" in prompt:
                return LLMResponse(json.dumps({"title": "My take", "text": tokens}), "stop")
            return LLMResponse(tokens or "Interesting.", "stop")
        if "author of the REPLY accepts" in prompt or (
                "estimate how much the post's author accepts" in prompt and re.search(r"\ba\d+=", prompt)):
            aliases = re.findall(r"^- \[(a\d+)\] \"(.*)\"$", prompt, re.M)
            out = {alias: None for alias, _ in aliases}
            out.update({f"a{n}": float(v) for n, v in re.findall(r"\ba(\d+)=([0-9.]+)", prompt)})
            return LLMResponse(json.dumps(out), "stop")
        if "Write a short Reddit comment" in prompt:
            level = re.search(r"acceptance of this belief statement is ([0-9.]+)", prompt).group(1)
            return LLMResponse(f"I {LEVEL_WORDS[level]} it.", "stop")
        if "estimate how much the post's author accepts" in prompt:
            text = re.search(r'Read this post:\n\n"(.*)"\n\nBelief statements', prompt, re.S).group(1)
            aliases = re.findall(r"^- \[(a\d+)\] \"(.*)\"$", prompt, re.M)
            out = {alias: None for alias, _ in aliases}
            word = next((w for w in WORD_VALUES if f"I {w} it." == text), None)
            if word is not None:  # round-trip comment: rate every statement at the level
                out = {alias: self._value(WORD_VALUES[word]) for alias, _ in aliases}
            else:  # scenario item: rate the expected statements, null elsewhere
                expected = self.expected.get(text, {})
                for n, (alias, _) in enumerate(aliases, start=1):
                    sid = self._sid_for(prompt, n)
                    if sid in expected:
                        out[alias] = self._value({"low": 0.1, "neutral": 0.5, "high": 0.9}[expected[sid]])
            return LLMResponse(json.dumps(out), "stop")
        if "Return JSON: {\"0.0\"" in prompt:
            return LLMResponse(json.dumps({k: f"desc {k}" for k in ("0.0", "0.25", "0.5", "0.75", "1.0")}), "stop")
        if "ambiguities" in prompt:
            return LLMResponse(json.dumps({"ambiguities": []}), "stop")
        return LLMResponse("A plain restatement.", "stop")

    def _sid_for(self, prompt, n):
        prefix = "C" if "r/destiny2" in prompt else "P"
        return f"{prefix}{n}"


@pytest.fixture
def items():
    return json.loads(vbs.DEFAULT_ITEMS.read_text(encoding="utf-8"))["scenarios"]


def run(tmp_path, monkeypatch, fake, *extra):
    monkeypatch.setattr(vbs, "make_provider", lambda name: fake)
    assert vbs.main(["run", "--reps", "2", "--out-root", str(tmp_path), "--max-workers", "2", *extra]) == 0
    (run_dir,) = [p for p in tmp_path.iterdir() if p.is_dir()]
    return run_dir


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def test_scenario_items_cover_every_statement(items):
    scenarios = vbs.load_scenarios(list(vbs.SCENARIOS), vbs.DEFAULT_ITEMS)
    for sc in scenarios:
        for axis in sc.config.axes:
            labels = {it["expected"][axis.id] for it in sc.items if axis.id in it["expected"]}
            assert labels == {"low", "neutral", "high"}, axis.id
        assert any(not it["expected"] for it in sc.items)  # off-topic controls


def test_dry_run_counts_calls(capsys):
    assert vbs.main(["run", "--dry-run", "--reps", "2", "--scenario", "politics"]) == 0
    out = capsys.readouterr().out
    # per rep: 6 statements x (4 single probes + 3 round-trip levels x 2 calls) + 20 items
    # + expression: (1 post + 6 neutral-post replies + 6 statements x 2 levels) x 2 calls
    assert f"{(6 * (4 + 6) + 20 + (1 + 6 + 12) * 2) * 2} LLM call(s)" in out


def test_run_writes_artifacts_and_passes_for_a_model_that_understands(tmp_path, monkeypatch, items):
    fake = FakeModel(items)
    run_dir = run(tmp_path, monkeypatch, fake)
    manifest = json.loads((run_dir / "manifest.json").read_text(encoding="utf-8"))
    assert manifest["model"] == "fake-model" and manifest["reps"] == 2
    assert set(manifest["belief_sets"]) == {"destiny2", "politics"}
    assert "complete rejection" in manifest["scale"] and set(manifest["template_hashes"]) >= set(vbs.PROBES) - {"round_trip", "expression"}

    calls = [json.loads(line) for line in (run_dir / "calls.jsonl").read_text(encoding="utf-8").splitlines()]
    assert len(calls) == len(fake.calls)
    assert all(c["messages"][0]["content"] for c in calls)
    gen = [c for c in calls if c.get("step") == "generate"]
    assert gen and all(c["temperature"] == vbs.GENERATION_TEMPERATURE for c in gen)
    assert all(c["temperature"] == vbs.PROBE_TEMPERATURE for c in calls if c.get("step") != "generate")

    for name in ("anchor_choice", "ratings", "round_trip", "off_target"):
        rows = read_csv(run_dir / "summary" / f"{name}.csv")
        assert rows and all(r["pass"] == "True" for r in rows), name
    sheet = read_csv(run_dir / "coding_sheet.csv")
    assert {r["probe"] for r in sheet} == {"paraphrase", "anchors", "ambiguity"}
    assert len(sheet) == 13 * 3 * 2 and all(r["code (pass/flag/fail)"] == "" for r in sheet)
    assert "ratings: 39/39 pass" in (run_dir / "report.md").read_text(encoding="utf-8").replace("## ", "")


def test_reversed_scale_fails_the_automatic_checks(tmp_path, monkeypatch, items):
    run_dir = run(tmp_path, monkeypatch, FakeModel(items, flip=True), "--probes", "anchor_choice", "rating", "round_trip")
    anchors = read_csv(run_dir / "summary" / "anchor_choice.csv")
    assert all(r["pass"] == "False" for r in anchors)
    ratings = read_csv(run_dir / "summary" / "ratings.csv")
    assert all(r["pass"] == "False" for r in ratings if r["expected"] != "neutral")
    assert all(int(r["direction_errors"]) == 2 for r in ratings if r["expected"] != "neutral")
    rt = read_csv(run_dir / "summary" / "round_trip.csv")
    assert all(r["pass"] == "False" and float(r["spearman"]) < 0 for r in rt)


def test_spearman_and_ranges():
    assert vbs.spearman([0.1, 0.5, 0.9], [0.2, 0.4, 0.8]) == pytest.approx(1.0)
    assert vbs.spearman([0.1, 0.5, 0.9], [0.8, 0.4, 0.2]) == pytest.approx(-1.0)
    assert vbs.spearman([0.1, 0.9], [0.1, 0.9]) is None
    assert vbs._in_range(0.39, "low") and not vbs._in_range(0.4, "low")
    assert vbs._in_range(0.6, "neutral") and vbs._in_range(0.61, "high")
    assert vbs._direction_error(0.3, "high") and not vbs._direction_error(0.5, "high")


def test_expression_uses_the_simulation_prompts(tmp_path, monkeypatch, items):
    run_dir = run(tmp_path, monkeypatch, FakeModel(items), "--probes", "expression")
    calls = [json.loads(line) for line in (run_dir / "calls.jsonl").read_text(encoding="utf-8").splitlines()]
    gen = [c for c in calls if c.get("step") == "generate"]
    posts = [c for c in gen if c["kind"] == "post"]
    replies = [c for c in gen if c["kind"] == "reply"]
    # the logged messages are the simulation's own prompts, with the numeric views
    assert posts and all("Generate a natural, engaging post" in c["messages"][0]["content"] for c in posts)
    assert replies and all("You are replying to" in c["messages"][0]["content"] for c in replies)
    assert all("(acceptance: 1.00)" in c["messages"][0]["content"] for c in posts)
    camp = read_csv(run_dir / "summary" / "expression_campaign.csv")
    assert camp and all(r["pass"] == "True" for r in camp)
    stmt = read_csv(run_dir / "summary" / "expression_statement.csv")
    assert len(stmt) == 13 and all(r["pass"] == "True" for r in stmt)


def test_expression_flags_a_model_that_writes_the_opposite(tmp_path, monkeypatch, items):
    run_dir = run(tmp_path, monkeypatch, FakeModel(items, flip=True), "--probes", "expression")
    assert all(r["pass"] == "False" for r in read_csv(run_dir / "summary" / "expression_campaign.csv"))
    assert all(r["pass"] == "False" for r in read_csv(run_dir / "summary" / "expression_statement.csv"))
