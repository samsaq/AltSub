"""
Test suite for python_simulation (run from backend/):

    python -m pytest python_simulation/tests              # everything offline
    python -m pytest python_simulation/tests -m "not e2e" # fast unit loop (~1 s)
    python -m pytest python_simulation/tests --update-golden   # accept new golden runs
    python -m pytest python_simulation/tests --run-llm    # also real-LLM smoke (costs API calls)

Layout:
    unit/         one module at a time, in memory (factories.py)
    integration/  whole runs of both engines with the stub LLM (marked e2e)
    regression/   golden runs (snapshots of seeded stub runs; marked e2e) and
                  test_fixed_bugs.py, one test per fixed bug (see its docstring)

Markers (set automatically): e2e (integration/regression dirs), models (needs
the embedder/NLI models in the local HF cache; skipped otherwise), llm (needs a
real LLM provider; skipped unless --run-llm).

Shared fixtures: synthetic simulation setups that run without the Reddit
database, model downloads or network (stub LLM provider).
"""

import json
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pytest

BACKEND_DIR = Path(__file__).resolve().parents[2]
if str(BACKEND_DIR) not in sys.path:
    sys.path.insert(0, str(BACKEND_DIR))

TESTS_DIR = Path(__file__).resolve().parent
GOLDEN_DIR = TESTS_DIR / "regression" / "golden"


def pytest_addoption(parser):
    parser.addoption(
        "--update-golden", action="store_true", default=False,
        help="Rewrite golden run snapshots instead of comparing (review the git diff)",
    )
    parser.addoption(
        "--run-llm", action="store_true", default=False,
        help="Run tests that call a real LLM provider (API cost)",
    )


def pytest_configure(config):
    config.addinivalue_line("markers", "e2e: runs a whole simulation (integration/regression)")
    config.addinivalue_line("markers", "models: needs embedder/NLI models in the local HF cache")
    config.addinivalue_line("markers", "llm: calls a real LLM provider (only with --run-llm)")


def models_cached() -> bool:
    hub = Path.home() / ".cache" / "huggingface" / "hub"
    return (hub / "models--sentence-transformers--all-MiniLM-L6-v2").exists() and (
        hub / "models--cross-encoder--nli-deberta-v3-small"
    ).exists()


def pytest_collection_modifyitems(config, items):
    skip_llm = pytest.mark.skip(reason="real-LLM test: pass --run-llm to run it")
    skip_models = pytest.mark.skip(reason="embedder/NLI models not in the local HF cache")
    have_models = models_cached()
    for item in items:
        parts = Path(str(item.fspath)).parts
        if "integration" in parts or "regression" in parts:
            item.add_marker(pytest.mark.e2e)
        if "llm" in item.keywords and not config.getoption("--run-llm"):
            item.add_marker(skip_llm)
        if "models" in item.keywords and not have_models:
            item.add_marker(skip_models)


@pytest.fixture
def golden(request):
    """golden(name, data): compare data with tests/regression/golden/<name>.json,
    or write it with --update-golden. Data must be JSON-serialisable."""
    update = request.config.getoption("--update-golden")

    def check(name: str, data: Any) -> None:
        path = GOLDEN_DIR / f"{name}.json"
        text = json.dumps(data, indent=1, sort_keys=True) + "\n"
        if update or not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text)
            if not update:
                pytest.skip(f"golden file {path.name} created; rerun to compare")
            return
        expected = json.loads(path.read_text())
        actual = json.loads(text)
        if actual != expected:
            diffs = _json_diff(expected, actual)
            pytest.fail(
                f"Run differs from golden {path.name} ({len(diffs)} differences):\n  "
                + "\n  ".join(diffs[:25])
                + "\nIf the change is intended, rerun with --update-golden and review the diff."
            )

    return check


def _json_diff(expected: Any, actual: Any, path: str = "") -> List[str]:
    if isinstance(expected, dict) and isinstance(actual, dict):
        out = []
        for key in sorted(set(expected) | set(actual)):
            if key not in actual:
                out.append(f"{path}/{key}: missing (expected {expected[key]!r})")
            elif key not in expected:
                out.append(f"{path}/{key}: unexpected {actual[key]!r}")
            else:
                out.extend(_json_diff(expected[key], actual[key], f"{path}/{key}"))
        return out
    if isinstance(expected, list) and isinstance(actual, list) and len(expected) == len(actual):
        out = []
        for i, (a, b) in enumerate(zip(expected, actual)):
            out.extend(_json_diff(a, b, f"{path}[{i}]"))
        return out
    return [] if expected == actual else [f"{path}: expected {expected!r}, got {actual!r}"]

SUBREDDIT = "testsub"

TEMPLATES = {
    "campaign_name": "default_campaign",
    "narrative": "The new season is great",
    "templates": {
        "posts": [
            {"id": "p1", "template": "Honestly {thing} is the best part of this season",
             "variables": {"thing": ["the raid", "the story", "the loot"]}},
            {"id": "p2", "template": "Anyone else think {thing} got way better?",
             "variables": {"thing": ["matchmaking", "the economy"]}},
        ],
        "replies": [
            {"context": "fellow_attacker_post", "template": "Totally agree, {x}",
             "variables": {"x": ["great post", "well said"]}},
            {"context": "neutral", "template": "Good point about {x}",
             "variables": {"x": ["this", "the season"]}},
        ],
        "voting_rules": {"downvote_keywords": ["worse", "bad"]},
    },
}


def _schedule(rng: np.random.Generator, num_timesteps: int, steps_per_day: int,
              sessions_per_day: int, session_steps: int) -> List[int]:
    schedule = [0] * num_timesteps
    days = num_timesteps // steps_per_day
    for day in range(days):
        for _ in range(sessions_per_day):
            start = day * steps_per_day + int(rng.integers(0, steps_per_day - session_steps))
            for t in range(start, start + session_steps):
                schedule[t] = 1
    return schedule


def _profile(user_type: str, idx: int, read_density: float, post_probability: float,
             session_duration: str = "medium") -> Dict[str, Any]:
    beliefs = {f"b{idx}_{k}": round(0.3 + 0.1 * k, 2) for k in range(3)}
    return {
        "user_type": user_type,
        "subreddit": SUBREDDIT,
        "beliefs": beliefs,
        "belief_texts": {b: f"Belief {b} about the game" for b in beliefs},
        "behavioral_params": {
            "read_density": read_density,
            "post_probability": post_probability,
            "pr_comment": 0.1,
            "pr_upvote": 0.15,
            "pr_downvote": 0.05,
        },
        "activity_patterns": {"session_duration": session_duration},
    }


def make_setup(
    root: Path,
    *,
    days: int = 1,
    n_users: int = 6,
    n_template_attackers: int = 0,
    n_llm_attackers: int = 0,
    n_rule_moderators: int = 0,
    biased_moderator: bool = False,
    mitigation: Optional[Dict[str, Any]] = None,
    time_model: str = "discrete",
    seed: int = 7,
    interval_minutes: int = 5,
    read_density: float = 10,
    post_probability: float = 0.2,
    sessions_per_day: int = 3,
    session_steps: int = 12,
    always_active: bool = False,
    llm_voting: bool = False,
    canonicalizer: bool = False,
    belief_model: Optional[str] = None,
    extra: Optional[Dict[str, Dict[str, Any]]] = None,
) -> Path:
    """Write simulation_config.json and agent_profiles.json under root/config.

    belief_model: None = no belief_config block (free-text, as older setups);
    "axes" = belief_config with the generic placeholder axes plus two campaign
    targets, and axis_positions for every profile; "free_text" = explicit block.
    """
    config_dir = root / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    templates_dir = root / "campaign_templates"
    templates_dir.mkdir(exist_ok=True)
    (templates_dir / "default_campaign.json").write_text(json.dumps(TEMPLATES))

    steps_per_day = 24 * 60 // interval_minutes
    num_timesteps = steps_per_day * days
    rng = np.random.default_rng(1234)

    profiles: List[Dict[str, Any]] = []
    for i in range(n_users):
        profiles.append(_profile("llm_user", i, read_density, post_probability))
    for i in range(n_template_attackers):
        profiles.append(_profile("template_attacker", len(profiles), read_density, post_probability))
    for i in range(n_llm_attackers):
        profiles.append(_profile("attacker", len(profiles), read_density, post_probability))
    for i in range(n_rule_moderators):
        p = _profile("rule_moderator", len(profiles), 15, 0.0)
        p["behavioral_params"].update(pr_comment=0.0, pr_upvote=0.0, pr_downvote=0.0)
        profiles.append(p)
    if biased_moderator:
        profiles.append(_profile("biased_moderator", len(profiles), 10, 0.0))

    schedules = {}
    for idx, p in enumerate(profiles):
        if p["user_type"] == "rule_moderator":
            continue  # generated by run_simulation.ensure_rule_moderator_schedules
        if always_active or p["user_type"] == "biased_moderator":
            schedules[str(idx)] = [1] * num_timesteps
        else:
            schedules[str(idx)] = _schedule(
                rng, num_timesteps, steps_per_day, sessions_per_day, session_steps
            )

    mitigation_config = {
        "enable_duplicate_detection": False,
        "enable_rate_limiting": False,
        "enable_coordinated_detection": False,
        "mitigation_scan_frequency": 10,
    }
    if n_rule_moderators:
        mitigation_config.update(
            enable_rule_moderators=True,
            rule_moderator_count=n_rule_moderators,
            rule_moderator_active_fraction=0.5,
            subreddit_rules="Be civil.",
        )
    mitigation_config.update(mitigation or {})

    config = {
        "simulation_config": {
            "duration_days": days,
            "interval_minutes": interval_minutes,
            "target_subreddit": SUBREDDIT,
            "total_agents": len(profiles),
            "num_attacker": n_llm_attackers,
            "num_template_attacker": n_template_attackers,
            "attacker_target_narrative": TEMPLATES["narrative"],
        },
        "llm_config": {"provider": "stub", "llm_voting_enabled": llm_voting},
        "runtime_config": {
            "seed": seed,
            "time_model": time_model,
            "llm_max_concurrency": 4,
            "enable_belief_canonicalizer": canonicalizer,
        },
        "mitigation_config": mitigation_config,
        "biased_moderator_config": {
            "enable_biased_moderator": biased_moderator,
            "biased_mod_scan_frequency": 12,
            "subreddit_rules": "Be civil.",
        },
        "campaign_config": {
            "campaign_templates_dir": str(templates_dir),
            "target_narrative": TEMPLATES["narrative"],
            "coordination_strength": 1.0,
            "daily_post_target": 4,
        },
        "feed_config": {"feed_strategy": "default"},
        "agent_activity_schedules": schedules,
    }
    if belief_model is not None:
        from python_simulation.core.belief_axes import (
            campaign_positions, default_belief_config,
        )

        belief_config = default_belief_config(SUBREDDIT, model=belief_model)
        belief_config.campaign_targets = {
            "gen_community_sentiment": 0.1, "gen_recent_changes": 0.9,
        }
        config["belief_config"] = belief_config.to_dict()
        if belief_model == "axes":
            placement = np.random.default_rng(99)
            for p in profiles:
                if p["user_type"] in ("template_attacker", "attacker", "biased_moderator"):
                    p["axis_positions"] = campaign_positions(belief_config)
                elif p["user_type"] == "llm_user":
                    p["axis_positions"] = {
                        a.id: round(float(placement.uniform(0.1, 0.9)), 3)
                        for a in belief_config.axes
                    }
    for section, values in (extra or {}).items():
        config.setdefault(section, {}).update(values)

    (config_dir / "simulation_config.json").write_text(json.dumps(config))
    (config_dir / "agent_profiles.json").write_text(json.dumps(profiles))
    return config_dir


def run_setup(config_dir: Path, out_name: str = "out",
              overrides: Optional[Dict[str, Dict[str, Any]]] = None):
    from python_simulation.run_simulation import run_simulation_from_config

    out = config_dir.parent / out_name
    run = run_simulation_from_config(config_dir, out, overrides)
    return run, out


def canonical_log(run) -> List[tuple]:
    """Order-sensitive summary of every committed event (for determinism checks)."""
    state = run.state
    return [
        (e.event_id, e.type.value, e.user_id, e.parent_id,
         round(state.event_time(e), 3), e.content or "")
        for e in state.events
    ]


@pytest.fixture
def setup_factory(tmp_path):
    def factory(name: str = "run", **kwargs) -> Path:
        return make_setup(tmp_path / name, **kwargs)
    return factory
