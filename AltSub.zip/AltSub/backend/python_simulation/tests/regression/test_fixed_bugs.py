"""
One regression test per fixed bug.

Convention for new entries (add one with every bug fix):
  - name: test_<what_was_wrong>
  - docstring: "Bug: <symptom>." plus how it was fixed and anything
    non-obvious about the cause
  - write the test so it FAILS on the old code and passes on the fix;
    prefer the smallest in-memory reproduction (tests/factories.py) over a run
  - if the fix changes simulation outcomes, also refresh the golden runs
    (--update-golden) and mention it in the commit
"""

import json

import numpy as np
import pytest

from python_simulation.core.feed_system import ScoreBasedFeedOrderingStrategy
from python_simulation.core.simulation_data import EventType, SimulationState
from python_simulation.systems.mitigation_system import MitigationSystem
from python_simulation.systems.output_system import OutputManager

from ..conftest import make_setup, run_setup
from ..factories import SUB, StubAgent, ev, make_world, stub_llm_service


def test_votes_were_counted_as_replies():
    """Bug: vote event IDs were appended to parent.replies, inflating feed
    ranking (child_size) and the replies field of media_events.json."""
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 0)
    assert post.replies == []


def test_score_drifted_on_repeat_votes():
    """Bug: score += 1 ran on every upvote event while the voter list was
    deduplicated, so score could exceed len(upvotes) - len(downvotes).
    Fix: repeat votes are refused and score is derived."""
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 0)
    am.commit_event(ev(1, EventType.UPVOTE, post.event_id), 0)
    assert post.score == 1 == len(post.upvotes)


def test_replies_to_removed_items_became_orphans():
    """Bug: a reply/vote queued before its parent was removed (parallel
    communicate, or any delayed action) was still committed with a dangling
    parent_id. Fix: commit-time check."""
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    state.remove_event(post.event_id)
    assert am.commit_event(ev(1, EventType.REPLY, post.event_id), 0) is None
    assert all(e.parent_id is None or state.get_event(e.parent_id) for e in state.events)


def test_removal_left_thread_behind():
    """Bug: removing a post left its replies (and votes) in state with a
    dangling parent. Fix: removal cascades."""
    state, am = make_world()
    post = am.commit_event(ev(0, EventType.POST), 0)
    reply = am.commit_event(ev(1, EventType.REPLY, post.event_id), 0)
    state.remove_event(post.event_id)
    assert state.get_event(reply.event_id) is None


def test_rule_moderators_double_flagged_one_item():
    """Bug: two rule moderators reading the same item each flagged its author
    (flags were applied before checking the item still existed), so one post
    counted twice toward the ban threshold."""
    from python_simulation.agents.rule_moderator_agent import RuleAnalysis, RuleModeratorAgent

    m = MitigationSystem(ban_threshold=10)
    state, am = make_world(3)
    item = am.commit_event(ev(1, EventType.POST), 0)
    mods = []
    for mod_id in (10, 11):
        mod = RuleModeratorAgent(mod_id, {}, SUB, {"read": 5}, np.ones(2, bool), m,
                                 llm_service=stub_llm_service())
        mod._analyze_rules = lambda c: RuleAnalysis(True, 1.0, "x")
        mod.apply_parse_result(mod.parse_job(item, state)(), state)
        mods.append(mod)
    for mod in mods:
        mod.flush_pending_moderation(state, am.feed_manager)
    assert len(m.flag_log) == 1


def test_snapshots_assumed_288_steps_per_day(tmp_path):
    """Bug: output_system (and analyze_simulation) sliced days as 24*12
    timesteps, wrong for any interval_minutes other than 5. Fix: days are
    sliced by simulated seconds."""
    state, am = make_world()
    state.timestep_duration_seconds = 900.0
    am.commit_event(ev(0, EventType.POST), 100)  # day 1 at 15-min steps
    OutputManager(str(tmp_path)).save_snapshot(95, 0, state, am)
    snap = json.loads((tmp_path / "daily_snapshots" / "day_0_data.json").read_text())
    assert snap["simulation_data"]["events"] == []


def test_missing_schedule_deactivated_agent_after_1000_steps(tmp_path):
    """Bug: an agent without a schedule got np.ones(1000) and silently went
    inactive after ~3.5 days. Fix: active for the whole run."""
    from python_simulation.run_simulation import build_simulation

    cfg = make_setup(tmp_path, days=5, n_users=2)
    config = json.loads((cfg / "simulation_config.json").read_text())
    del config["agent_activity_schedules"]["1"]
    (cfg / "simulation_config.json").write_text(json.dumps(config))
    run = build_simulation(cfg, tmp_path / "out")
    assert run.agent_manager.agents[1].activity_schedule.shape == (5 * 288,)
    assert run.agent_manager.agents[1].is_active(5 * 288 - 1)


def test_belief_update_rolled_back_consolidation():
    """Bug: parse() wrote the whole belief set computed at read start, so a
    read overlapping day-end consolidation restored beliefs consolidation had
    dropped. Fix: changes merge as deltas onto current beliefs."""
    from python_simulation.agents.llm_user_agent import LLMUserAgent, ParseResult

    agent = LLMUserAgent(0, {"a": 0.5, "dropped": 0.4}, SUB, {"read": 5}, np.ones(1, bool),
                         llm_service=stub_llm_service())
    result = ParseResult({"a": 0.5, "dropped": 0.4}, {"a": 0.5, "dropped": 0.45})
    agent.replace_beliefs({"a": 0.5}, 0)  # consolidation dropped a belief mid-read
    agent.apply_parse(result, SimulationState())
    assert "dropped" not in agent.beliefs


def test_belief_history_used_item_creation_time():
    """Bug: belief_history (and canonical first_seen) were stamped with the
    read item's creation timestep, not when it was read."""
    from python_simulation.agents.llm_user_agent import LLMUserAgent, ParseResult

    agent = LLMUserAgent(0, {"a": 0.5}, SUB, {"read": 5}, np.ones(1, bool),
                         llm_service=stub_llm_service())
    agent.set_clock(40)
    agent.apply_parse(ParseResult({"a": 0.5}, {"a": 0.6}), SimulationState())
    assert agent.belief_history[-1]["timestep"] == 40


def test_instruction_window_excluded_its_end_hour():
    """Bug: end_timestep was the first step of end_hour, so a 23:00 end never
    reached the last 55 minutes of the day."""
    from python_simulation.services.attacker_campaign_orchestrator import (
        AttackerCampaignOrchestrator, CampaignConfig, CampaignObjective, DailyCampaignPlan,
    )
    from python_simulation.agents.llm_attacker_agent import LLMAttackerAgent

    agent = LLMAttackerAgent(0, {}, SUB, {"read": 5}, np.ones(288, bool), llm_service=stub_llm_service())
    state, am = make_world(agents=[agent])
    orch = AttackerCampaignOrchestrator(CampaignConfig(CampaignObjective.AMPLIFY_NARRATIVE, "n"))
    orch.register_attacker_agents([0])
    got = []
    orch.distribute_instructions_to_agents(
        DailyCampaignPlan("d", [{"content": "x", "start_hour": 23, "end_hour": 23}], {}, 0.1),
        am, 288, 0, deliver=lambda a, i: got.append(i))
    assert got[0].end_timestep == 287


def test_empty_instruction_posted_none_content():
    """Bug: an instruction without content produced a post with content=None
    (the value of a log.warning call). Fix: skipped."""
    from python_simulation.agents.llm_attacker_agent import LLMAttackerAgent
    from python_simulation.services.attacker_campaign_orchestrator import CampaignInstruction

    agent = LLMAttackerAgent(0, {}, SUB, {"read": 5}, np.zeros(10, bool), llm_service=stub_llm_service())
    agent.add_instruction(CampaignInstruction("", 3, 3))
    state, _ = make_world(agents=[agent])
    assert agent.generate_post_events(3, state) == []


def test_biased_moderator_missed_content_after_inactivity():
    """Bug: the biased moderator looked back a fixed 2 x scan_frequency, so
    content posted during a longer inactive stretch was never reviewed.
    Fix: the lookback reaches the previous scan."""
    from python_simulation.agents.biased_moderator_agent import BiasedModeratorAgent, ContentAnalysis

    state, am = make_world(2)
    seen = []
    mod = BiasedModeratorAgent(5, {"n": 1.0}, SUB, {"read": 1}, np.ones(2, bool),
                               llm_service=stub_llm_service(), scan_frequency=12)
    mod.analyze_content = lambda c: (seen.append(c), ContentAnalysis(succeeded=True))[1]
    mod.moderate(0, state, now_s=0)
    am.commit_event(ev(1, EventType.POST, content="posted during the gap"), 0, time_s=1000)
    mod.moderate(0, state, now_s=40_000)  # 2 x 12 steps = 7200 s would miss it
    assert seen == ["posted during the gap"]


def test_score_feed_put_oldest_zero_score_items_first():
    """Bug: score-based ranking multiplied score by recency, so every
    zero-score item tied and the stable sort returned the oldest first; negative
    scores ranked older items above newer ones."""
    state, am = make_world()
    old = am.commit_event(ev(0, EventType.POST), 0)
    new = am.commit_event(ev(0, EventType.POST), 5)
    state.now_s = 3000
    assert ScoreBasedFeedOrderingStrategy().order_feed([old, new], 1, state)[0] is new


def test_runs_were_not_reproducible(setup_factory):
    """Bug: nothing seeded the RNGs (global np.random/random), so no run could
    be repeated. Fix: runtime_config.seed + per-agent streams."""
    from ..conftest import canonical_log

    a, _ = run_setup(setup_factory("a", n_users=4))
    b, _ = run_setup(setup_factory("b", n_users=4))
    assert canonical_log(a) == canonical_log(b)
