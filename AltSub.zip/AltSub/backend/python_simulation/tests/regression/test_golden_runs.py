"""
Golden runs: seeded stub-LLM simulations whose outcome is pinned in
tests/regression/golden/*.json.

Any change to simulation behaviour (agents, feeds, mitigations, engines,
time model, stub provider) changes these summaries. When a change is intended
(e.g. a bug fix), rerun with --update-golden and review the golden diff in git:
it shows exactly which outcomes moved (event counts, flags, beliefs, ...).
An unexpected diff is a regression.

The summary has readable aggregates for diagnosis plus a hash of the full
ordered event log, so even changes the aggregates miss are caught.
"""

import hashlib
import json
from collections import Counter

import pytest

from ..conftest import canonical_log, run_setup

ALL_MITIGATIONS = {
    "enable_duplicate_detection": True,
    "enable_rate_limiting": True,
    "enable_coordinated_detection": True,
}

SCENARIOS = {
    # Users, both attacker types, a rule moderator, a biased moderator, all
    # mitigations: exercises every subsystem in one day
    "full": dict(days=1, n_users=6, n_template_attackers=2, n_llm_attackers=2,
                 n_rule_moderators=1, biased_moderator=True, mitigation=ALL_MITIGATIONS),
    # Users only over two days (day boundary, belief drift, LLM voting)
    "users_two_days": dict(days=2, n_users=8, llm_voting=True),
    # The "full" scenario with the belief axes model
    "axes_full": dict(days=1, n_users=6, n_template_attackers=2, n_llm_attackers=2,
                      n_rule_moderators=1, biased_moderator=True, mitigation=ALL_MITIGATIONS,
                      belief_model="axes"),
}


def summarize(run) -> dict:
    state, am = run.state, run.agent_manager
    log = canonical_log(run)
    by_type = Counter(e.type.value for e in state.events)
    by_agent = Counter((e.user_id, e.type.value) for e in state.events)
    hours = Counter(int(state.event_time(e) // 3600) for e in state.events)
    hub = am.coordination_hub
    return {
        "event_log_sha256": hashlib.sha256(json.dumps(log).encode()).hexdigest(),
        "events_by_type": dict(sorted(by_type.items())),
        "events_by_agent": {f"{a}:{t}": n for (a, t), n in sorted(by_agent.items())},
        "events_by_hour": {str(h): n for h, n in sorted(hours.items())},
        "items_read": am.items_read,
        "commit_rejections": dict(sorted(am.commit_rejections.items())),
        "removed_by_cascade": state.removed_by_cascade,
        "flags": [[f["source"], f["agent_id"], f["timestep"]] for f in run.mitigation_system.flag_log],
        "banned": sorted(a for a, s in state.banned_agent_network.ban_counts.items() if sum(s.values())),
        "coordination": {k: v for k, v in sorted(hub.stats.items())} if hub else None,
        "final_beliefs": {
            str(a): {b: round(s, 6) for b, s in sorted(state.belief_network.get_agent_beliefs(a).items())}
            for a in sorted(am.agents)
        },
    }


@pytest.mark.parametrize("time_model", ["discrete", "event"])
@pytest.mark.parametrize("scenario", sorted(SCENARIOS))
def test_golden_run(setup_factory, golden, scenario, time_model):
    run, _ = run_setup(setup_factory(f"{scenario}_{time_model}", time_model=time_model,
                                     **SCENARIOS[scenario]))
    golden(f"{scenario}_{time_model}", summarize(run))
