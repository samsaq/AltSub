"""Seed content: real "last 24 hours" posts and comments in the feed at time 0 (core/seed_content.py)."""

import json

import pytest

from python_simulation.run_simulation import run_simulation_from_config
from python_simulation.services.subreddit_seed_context import SEED_CONTEXT_FILENAME


def seed_file(config_dir, n_posts=3, comments=2):
    posts = [{"event_id": f"t3_p{i}", "type": "post", "content": f"Seed headline number {i} about world news",
              "score": 5000 - i, "author_type": "regular"} for i in range(n_posts)]
    replies = [{"root_post_id": f"t3_p{i}", "type": "reply", "content": f"Seed comment {j} on post {i}",
                "score": 100 - j, "author_type": "regular"} for i in range(n_posts) for j in range(comments)]
    (config_dir / SEED_CONTEXT_FILENAME).write_text(json.dumps({"posts": posts, "comments": replies}))


def load(out):
    final = json.loads((out / "final_output.json").read_text())
    events = json.loads((out / "media_events.json").read_text())
    return final, events


@pytest.mark.parametrize("time_model", ["event", "discrete"])
def test_seed_posts_and_comments_are_in_the_feed_and_exempt(setup_factory, tmp_path, time_model):
    config_dir = setup_factory(
        days=1, n_users=4, n_template_attackers=1, n_rule_moderators=1, time_model=time_model,
        mitigation={"enable_duplicate_detection": True, "enable_rate_limiting": True,
                    "rate_limit_window": 12, "rate_limit_threshold": 0, "duplicate_similarity_threshold": 0.0},
    )
    seed_file(config_dir)
    out = tmp_path / "out"
    run_simulation_from_config(config_dir, out)
    final, events = load(out)

    seeds = [e for e in events if e["seed"]]
    posts = [e for e in seeds if e["type"] == "post"]
    replies = [e for e in seeds if e["type"] == "reply"]
    assert len(posts) == 3 and len(replies) == 6
    post_ids = {p["event_id"] for p in posts}
    assert all(r["parent_id"] in post_ids for r in replies)  # top comments under their own post
    assert all(e["user_id"] < 0 and e["time_s"] == 0.0 for e in seeds)
    assert len({e["user_id"] for e in seeds}) == len(seeds)  # one placeholder account per item
    assert all(p["score"] == sum(1 for _ in p["upvotes"]) - len(p["downvotes"]) for p in posts)  # real score not used

    # counted separately, never flagged or banned, not in agent metrics
    assert final["seed_events"] == {"posts": 3, "replies": 6}
    assert final["total_events"] == sum(1 for e in events if not e["seed"])
    summary = final["mitigation_summary"]
    seed_ids = {str(e["user_id"]) for e in seeds}
    assert not seed_ids & set(summary["flag_counts_by_agent"])
    assert not seed_ids & {str(a) for a in summary["banned_agent_ids"]}
    assert not seed_ids & set(summary["agent_type_by_id"])
    # agents engaged with the seed content
    engaged = [e for e in events if not e["seed"] and e["parent_id"] in post_ids | {r["event_id"] for r in replies}]
    assert engaged or sum(len(p["upvotes"]) + len(p["downvotes"]) for p in posts), "no agent touched the seed content"


def test_seed_content_can_be_switched_off(setup_factory, tmp_path):
    config_dir = setup_factory(days=1, n_users=3, time_model="event")
    seed_file(config_dir)
    cfg = json.loads((config_dir / "simulation_config.json").read_text())
    cfg["runtime_config"]["seed_initial_posts"] = False
    (config_dir / "simulation_config.json").write_text(json.dumps(cfg))
    run_simulation_from_config(config_dir, tmp_path / "out")
    final, events = load(tmp_path / "out")
    assert not any(e["seed"] for e in events) and final["seed_events"] == {"posts": 0, "replies": 0}
