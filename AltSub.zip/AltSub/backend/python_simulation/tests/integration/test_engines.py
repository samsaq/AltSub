"""End-to-end runs of both engines with the stub LLM."""

import json
import logging

import numpy as np
import pytest

from python_simulation.core.simulation_data import EventType, MediaEvent
from python_simulation.run_simulation import build_simulation, run_event

from ..conftest import canonical_log, run_setup

logging.getLogger("python_simulation").setLevel(logging.WARNING)

ALL_MITIGATIONS = {
    "enable_duplicate_detection": True,
    "enable_rate_limiting": True,
    "enable_coordinated_detection": True,
}


@pytest.mark.parametrize("time_model", ["discrete", "event"])
def test_full_featured_run_writes_consistent_outputs(setup_factory, time_model):
    cfg = setup_factory(
        days=2, n_users=6, n_template_attackers=2, n_llm_attackers=2,
        n_rule_moderators=1, biased_moderator=True, mitigation=ALL_MITIGATIONS,
        time_model=time_model,
    )
    run, out = run_setup(cfg)
    state = run.state

    # No dangling references: every reply/vote targets an existing event
    for e in state.events:
        if e.parent_id is not None:
            assert state.get_event(e.parent_id) is not None
    # Scores match voter lists; replies lists hold replies only
    for e in state.events:
        assert e.score == len(e.upvotes) - len(e.downvotes)
        assert all(state.get_event(r).type == EventType.REPLY for r in e.replies)
    # One vote per agent per item
    for e in state.events:
        assert len(set(e.upvotes) | set(e.downvotes)) == len(e.upvotes) + len(e.downvotes)

    final = json.loads((out / "final_output.json").read_text())
    assert final["time_model"] == time_model and final["seed"] == 7
    assert final["time_unit_seconds"] == 300.0
    media = json.loads((out / "media_events.json").read_text())
    assert all("time_s" in m for m in media)
    for day in range(2):
        snap = json.loads((out / "daily_snapshots" / f"day_{day}_data.json").read_text())
        for e in snap["simulation_data"]["events"]:
            assert day * 86400 <= e["time_s"] < (day + 1) * 86400
        assert snap["time_unit_seconds"] == 300.0
    if time_model == "event":
        times = [state.event_time(e) for e in state.events]
        # Committed in time order; not all on 300 s step boundaries
        assert times == sorted(times)
        assert any(t % 300 for t in times)
        assert final["event_engine"]["reads"] > 0
        assert final["time_model_settings"]["calibration_mode"] == "match_discrete"


@pytest.mark.parametrize("time_model", ["discrete", "event"])
def test_same_seed_same_run(setup_factory, time_model):
    kwargs = dict(n_users=5, n_template_attackers=2, n_llm_attackers=2,
                  n_rule_moderators=1, mitigation=ALL_MITIGATIONS, time_model=time_model)
    run_a, _ = run_setup(setup_factory("a", **kwargs))
    run_b, _ = run_setup(setup_factory("b", **kwargs))
    assert canonical_log(run_a) == canonical_log(run_b)
    assert len(run_a.state.events) > 50


def test_event_engine_result_independent_of_thread_count(setup_factory):
    kwargs = dict(n_users=6, n_template_attackers=2, n_llm_attackers=2, n_rule_moderators=1,
                  biased_moderator=True, mitigation=ALL_MITIGATIONS, time_model="event",
                  llm_voting=True)
    serial, _ = run_setup(setup_factory("serial", **kwargs),
                          overrides={"runtime_config": {"llm_max_concurrency": 1}})
    parallel, _ = run_setup(setup_factory("parallel", **kwargs),
                            overrides={"runtime_config": {"llm_max_concurrency": 8}})
    assert canonical_log(serial) == canonical_log(parallel)
    beliefs = lambda r: {a: r.state.belief_network.get_agent_beliefs(a) for a in r.agent_manager.agents}
    assert beliefs(serial) == beliefs(parallel)


@pytest.mark.models
def test_event_engine_canonical_beliefs_independent_of_thread_count(setup_factory):
    """With the real canonicalizer (first-come canonical IDs), belief capping and
    day-end consolidation, the run is identical for 1 and 8 worker threads."""
    kwargs = dict(n_users=6, n_template_attackers=2, time_model="event", days=2,
                  canonicalizer=True,
                  extra={"belief_capping_config": {"enabled": True, "belief_cap": 6}})
    serial, _ = run_setup(setup_factory("serial", **kwargs),
                          overrides={"runtime_config": {"llm_max_concurrency": 1}})
    parallel, _ = run_setup(setup_factory("parallel", **kwargs),
                            overrides={"runtime_config": {"llm_max_concurrency": 8}})
    assert canonical_log(serial) == canonical_log(parallel)
    beliefs = lambda r: {a: r.state.belief_network.get_agent_beliefs(a) for a in r.agent_manager.agents}
    assert beliefs(serial) == beliefs(parallel)
    registry = serial.state.belief_text_registry
    assert registry == parallel.state.belief_text_registry
    assert any(not b.startswith("b") for a in beliefs(serial).values() for b in a), \
        "expected beliefs adopted from content during the run"


def test_different_seeds_differ(setup_factory):
    a, _ = run_setup(setup_factory("a", time_model="event"))
    b, _ = run_setup(setup_factory("b", time_model="event"),
                     overrides={"runtime_config": {"seed": 99}})
    assert canonical_log(a) != canonical_log(b)


def _fill_feeds(run, n_posts: int = 3000) -> None:
    """Give every agent far more unread items than it can read."""
    for i in range(n_posts):
        post = MediaEvent(0, 10_000, None, EventType.POST, "b", "testsub", 0,
                          content=f"seed post {i} with enough text to read")
        run.agent_manager.commit_event(post, 0, time_s=0.0)


def test_event_engine_reads_match_discrete_volume(tmp_path):
    """match_discrete: with a full feed, items read per session equal
    read_density per reference timestep of activity (within sampling error)."""
    from ..conftest import make_setup

    cfg = make_setup(tmp_path / "cal", days=1, n_users=20, read_density=10,
                     post_probability=0.0, sessions_per_day=4, session_steps=6,
                     time_model="event")
    run = build_simulation(cfg, tmp_path / "cal_out")
    _fill_feeds(run)
    summary = run_event(run)
    active_steps = sum(
        int(np.sum(a.activity_schedule)) for a in run.agent_manager.agents.values()
    )
    expected = active_steps * 10
    assert summary["reads"] == pytest.approx(expected, rel=0.05)
    assert summary.get("empty_feed_waits", 0) == 0


def test_event_engine_post_volume_matches_discrete(tmp_path):
    from ..conftest import make_setup

    cfg = make_setup(tmp_path / "posts", days=2, n_users=30, read_density=1,
                     post_probability=0.2, sessions_per_day=4, session_steps=8,
                     time_model="event")
    run = build_simulation(cfg, tmp_path / "posts_out")
    summary = run_event(run)
    active_steps = sum(
        int(np.sum(a.activity_schedule)) for a in run.agent_manager.agents.values()
    )
    # Natural posts start within sessions; a few commit after the run ends
    assert summary["committed_post"] == pytest.approx(active_steps * 0.2, rel=0.12)


def test_coordinated_amplifications_commit_in_sync_window(setup_factory):
    cfg = setup_factory(n_users=4, n_template_attackers=3, time_model="event",
                        post_probability=0.5, always_active=True)
    run, out = run_setup(cfg)
    state = run.state
    attackers = {a.agent_id for a in run.agent_manager.get_agents_by_type("template_attacker")}
    hub = run.agent_manager.coordination_hub
    assert hub.stats["upvotes_executed"] > 0
    # Amplification delays: commit 300-1800 s after the post (delay_min..max steps)
    delays = []
    for e in state.events:
        parent = state.get_event(e.parent_id) if e.parent_id is not None else None
        if (parent is not None and e.user_id in attackers and parent.user_id in attackers
                and parent.type == EventType.POST):
            delays.append(state.event_time(e) - state.event_time(parent))
    coordinated = [d for d in delays if d <= 1800]
    assert len(coordinated) >= hub.stats["upvotes_executed"]


@pytest.mark.parametrize("time_model", ["discrete", "event"])
@pytest.mark.parametrize("parallel", [False, True])
def test_rule_moderator_flags_once_per_removed_item(setup_factory, time_model, parallel):
    cfg = setup_factory(
        n_users=8, n_rule_moderators=3, time_model=time_model, post_probability=0.4,
        always_active=True,
        extra={"runtime_config": {"enable_timestep_parallelism": parallel},
               "mitigation_config": {"mitigation_ban_threshold": 1000}},
    )
    run, _ = run_setup(cfg)
    mods = run.agent_manager.get_agents_by_type("rule_moderator")
    removed = [eid for m in mods for eid in m.removed_event_ids]
    flags = [f for f in run.mitigation_system.flag_log if f["source"] == "rule_moderator"]
    assert removed, "stub moderator should find some violations"
    assert len(removed) == len(set(removed))  # no item removed twice
    assert len(flags) == len(removed)  # one flag per removed item
