"""Targeted behaviour of the event-driven engine on small stub-LLM setups."""

import logging

import numpy as np
import pytest

from python_simulation.core.event_engine import EventEngine
from python_simulation.core.simulation_data import EventType, MediaEvent
from python_simulation.core.time_model import SECONDS_PER_DAY
from python_simulation.run_simulation import build_simulation, run_event
from python_simulation.services.attacker_campaign_orchestrator import CampaignInstruction

from ..conftest import make_setup

logging.getLogger("python_simulation").setLevel(logging.WARNING)


def _fill_feeds(run, n=500):
    for i in range(n):
        run.agent_manager.commit_event(
            MediaEvent(0, 10_000, None, EventType.POST, "b", "testsub", 0, content=f"seed {i}"),
            0, time_s=0.0,
        )


def _engine(run, **kwargs):
    return EventEngine(run.agent_manager, run.time_model, run.sim_config["duration_days"],
                       run.mitigation_system, max_workers=2, **kwargs)


def _record(engine, name):
    """Wrap an engine handler to record (time, agent_id) of each call."""
    calls = []
    original = getattr(engine, name)

    def wrapper(ev):
        calls.append((ev.t, ev.agent_id))
        original(ev)

    setattr(engine, name, wrapper)
    return calls


def test_reads_only_start_inside_sessions(tmp_path):
    cfg = make_setup(tmp_path, n_users=3, post_probability=0.0, sessions_per_day=2,
                     session_steps=3, time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    _fill_feeds(run)
    engine = _engine(run)
    reads = _record(engine, "_on_read_done")
    starts = []
    original = engine._on_read_start

    def on_start(ev):
        proc = engine.procs[ev.agent_id]
        before = run.agent_manager.items_read
        original(ev)
        if run.agent_manager.items_read > before:
            starts.append((ev.t, proc.active(ev.t)))

    engine._on_read_start = on_start
    engine.run()
    assert starts and all(active for _, active in starts)
    assert len(reads) == len(starts)  # every started item is finished


def test_banned_agent_reads_but_never_acts(tmp_path):
    cfg = make_setup(tmp_path, n_users=3, post_probability=0.5, always_active=True,
                     time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    _fill_feeds(run, 50)
    run.state.banned_agent_network.increment_ban(0, "testsub")
    summary = run_event(run)
    assert summary["reads"] > 0
    assert not any(e.user_id == 0 for e in run.state.events)


def test_empty_feed_waits_then_resumes(tmp_path):
    cfg = make_setup(tmp_path, n_users=1, post_probability=0.0, always_active=True,
                     time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    engine = _engine(run)
    engine.run()
    waits = engine.stats["empty_feed_waits"]
    # Nothing to read all day: one recheck per refresh interval
    assert waits == pytest.approx(SECONDS_PER_DAY / 300.0, abs=2)
    assert engine.stats["reads"] == 0


def test_failed_llm_job_is_counted_and_run_continues(tmp_path):
    cfg = make_setup(tmp_path, n_users=2, always_active=True, time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    _fill_feeds(run, 30)
    agent = run.agent_manager.agents[0]

    def broken_job(event, state):
        def fail():
            raise RuntimeError("LLM down")
        return fail

    agent.parse_job = broken_job
    summary = run_event(run)
    assert summary["llm_failures"]["parse"] > 0
    assert summary["reads"] > summary["llm_failures"]["parse"]  # agent 1 unaffected


def test_nothing_commits_after_the_run_ends(tmp_path):
    cfg = make_setup(tmp_path, days=1, n_users=4, always_active=True, time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    run_event(run)
    assert max(run.state.event_time(e) for e in run.state.events) <= SECONDS_PER_DAY


def test_instruction_posting_time_inside_window_and_natural_activity(tmp_path):
    cfg = make_setup(tmp_path, n_users=1, n_llm_attackers=1, time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    engine = _engine(run)
    engine._init_agents()
    attacker = run.agent_manager.get_agents_by_type("llm_attacker")[0]
    natural = engine.procs[attacker.agent_id].natural
    start, end = natural.intervals[0][0] - 600, natural.intervals[0][1] + 600
    for _ in range(20):
        instr = CampaignInstruction("post", 0, 0, start_s=start, end_s=end)
        engine.deliver_instruction(attacker, instr)
        assert start <= instr.execute_time_s < end
        assert natural.contains(instr.execute_time_s)
    # A window with no natural activity: any time in the window
    lo = natural.intervals[0][1] + 1
    quiet = [(s, e) for s, e in natural.intervals if s > lo]
    hi = quiet[0][0] if quiet else lo + 100
    instr = CampaignInstruction("post", 0, 0, start_s=lo, end_s=hi)
    engine.deliver_instruction(attacker, instr)
    assert lo <= instr.execute_time_s < hi


def test_instruction_post_commits_and_starts_campaign_session(tmp_path):
    cfg = make_setup(tmp_path, n_users=2, n_llm_attackers=1, time_model="event",
                     extra={"campaign_config": {"daily_post_target": 3}})
    run = build_simulation(cfg, tmp_path / "out")
    summary = run_event(run)
    attacker = run.agent_manager.get_agents_by_type("llm_attacker")[0]
    campaign_posts = [e for e in run.state.events
                      if e.user_id == attacker.agent_id and e.content.startswith("Campaign post")]
    assert summary["instructions_delivered"] == 3
    assert len(campaign_posts) + summary.get("instructions_skipped_banned", 0) == 3


def test_day_boundary_callbacks_and_snapshot_times(tmp_path):
    cfg = make_setup(tmp_path, days=2, n_users=3, always_active=True, time_model="event")
    run = build_simulation(cfg, tmp_path / "out")
    calls = []
    engine = _engine(run, on_day_start=lambda d, e: calls.append(("start", d)),
                     on_day_end=lambda d, ts, now: calls.append(("end", d, ts, now)))
    engine.run()
    assert calls == [("start", 0), ("end", 0, 287, 86400.0), ("start", 1), ("end", 1, 575, 172800.0)]
