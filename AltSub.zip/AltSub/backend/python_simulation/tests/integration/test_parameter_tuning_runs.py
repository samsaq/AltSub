"""Tuning evaluator on real (stub-LLM) simulations, run in-process instead of a subprocess.

Checks what the fake runner in unit/test_parameter_tuning.py cannot: a shortened
rung really simulates fewer days, the requested seed reaches the simulation, and
the objective is scored from a real final_output.json.
"""

import json
from concurrent.futures import ThreadPoolExecutor

import pytest

from python_simulation.tools import parameter_tuning as pt
from python_simulation.tools import tuning_racing as racing


def in_process_runner(repo_root, config_dir, output_dir, timeout_sec, *, stream_output=False, seed=None):
    from python_simulation.run_simulation import run_simulation_from_config

    overrides = {"runtime_config": {"seed": seed}} if seed is not None else None
    run_simulation_from_config(config_dir, output_dir, overrides)
    return True, ""


@pytest.mark.parametrize("time_model", ["discrete", "event"])
def test_evaluator_on_real_runs(setup_factory, tmp_path, monkeypatch, time_model):
    monkeypatch.setattr(pt, "_run_simulation", in_process_runner)
    monkeypatch.delenv("SIM_SEED", raising=False)
    mitigation = {"enable_rate_limiting": True, "rate_limit_window": 12, "rate_limit_threshold": 1}
    bases = {
        "template_attackers": setup_factory(days=2, n_users=4, n_template_attackers=2,
                                            time_model=time_model, mitigation=mitigation),
        "llm_attackers": setup_factory(days=2, n_users=4, n_llm_attackers=2,
                                       time_model=time_model, mitigation=mitigation),
    }
    setups = {
        label: pt._prepare_scenario_setup(base, tmp_path / "scenario" / label, {})
        for label, base in bases.items()
    }
    with ThreadPoolExecutor(max_workers=1) as pool:
        evaluator = pt.SimulationEvaluator(
            repo_root=tmp_path, tuning_root=tmp_path / "tuning", stage_name="stage_1_rate_limit_only",
            scenario="rate_limit_only", setups=setups,
            timeout_sec=600, max_retries=0, pool=pool,
        )
        params = {"rate_limit_window": 12, "rate_limit_threshold": 1, "mitigation_scan_frequency": 6}
        requests = [
            racing.EvalRequest(1, params, 1, 101, "test"),
            racing.EvalRequest(1, params, None, 101, "test"),
            racing.EvalRequest(1, params, None, 202, "test"),
        ]
        short, full, other_seed = evaluator(requests)

    for res, req in zip((short, full, other_seed), requests):
        assert res.ok, res.details
        outputs = {}
        for label, path in res.details["final_output_paths"].items():
            out = json.loads(open(path, encoding="utf-8").read())
            assert out["seed"] == req.seed
            outputs[label] = out
        assert set(outputs) == set(setups)
        objective, counts = pt._score_outputs(outputs, "rate_limit_only", "flagged")
        assert res.objective == pytest.approx(objective)
        assert res.details["decision"] == "flagged"
        # every user account is classified once per setup (6 users per setup)
        assert counts["tp"] + counts["fp"] + counts["fn"] + counts["tn"] == 12
    for label in setups:
        cfg_short = json.loads(
            (evaluator.eval_dir(requests[0]) / label / "config" / "simulation_config.json").read_text()
        )
        assert cfg_short["simulation_config"]["duration_days"] == 1
        assert cfg_short["mitigation_config"]["enable_rate_limiting"] is True
    canonical = evaluator.trial_dir(1) / "config" / "simulation_config.json"
    assert json.loads(canonical.read_text())["simulation_config"]["duration_days"] == 2


def test_rule_moderation_stage_runs(setup_factory, tmp_path, monkeypatch):
    """The rule moderation stage adds rule moderators and scores their flags only."""
    monkeypatch.setattr(pt, "_run_simulation", in_process_runner)
    monkeypatch.delenv("SIM_SEED", raising=False)
    base = setup_factory(days=1, n_users=4, n_template_attackers=2, time_model="event")
    defaults = {**pt.RULE_MODERATOR_MITIGATION_DEFAULTS, "enable_rule_moderators": True}
    setup = pt._prepare_scenario_setup(
        base, tmp_path / "scenario", defaults, add_rule_moderators=True
    )
    profiles = json.loads((setup / "agent_profiles.json").read_text())
    assert sum(p["user_type"] == "rule_moderator" for p in profiles) == 1
    with ThreadPoolExecutor(max_workers=1) as pool:
        evaluator = pt.SimulationEvaluator(
            repo_root=tmp_path, tuning_root=tmp_path / "tuning",
            stage_name="stage_1_rule_moderation_only", scenario="rule_moderation_only",
            setups={"template_attackers": setup}, timeout_sec=600, max_retries=0, pool=pool,
        )
        (res,) = evaluator([racing.EvalRequest(1, {"rule_moderator_detection_threshold": 0.5}, None, 7, "t")])
    assert res.ok, res.details
    out = json.loads(open(res.details["final_output_path"], encoding="utf-8").read())
    cfg = json.loads((evaluator.eval_dir(res.request) / "template_attackers" / "config"
                      / "simulation_config.json").read_text())
    assert cfg["mitigation_config"]["enable_rule_moderators"] is True
    assert cfg["mitigation_config"]["rule_moderator_detection_threshold"] == 0.5
    # the rule moderator is not a user account: 6 users classified
    c = res.details
    assert c["tp"] + c["fp"] + c["fn"] + c["tn"] == 6
    srcs = {s for by in out["mitigation_summary"]["flag_counts_by_source"].values() for s in by}
    assert srcs <= {"rule_moderator"}
