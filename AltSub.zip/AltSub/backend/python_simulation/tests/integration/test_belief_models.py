"""Whole runs with the belief axes model, and the free-text model kept intact."""

import csv
import json
import logging

import pytest

from ..conftest import canonical_log, run_setup

logging.getLogger("python_simulation").setLevel(logging.WARNING)

FULL = dict(n_users=6, n_template_attackers=2, n_llm_attackers=2, n_rule_moderators=1,
            biased_moderator=True, llm_voting=True)


@pytest.mark.parametrize("time_model", ["discrete", "event"])
def test_axes_run_keeps_positions_valid_and_updates_capped(setup_factory, time_model):
    run, out = run_setup(setup_factory(time_model=time_model, belief_model="axes", days=2, **FULL))
    assert run.belief_model == "axes"
    axis_ids = set(run.belief_config.axis_ids)
    cap = 0.15
    users = run.agent_manager.get_agents_by_type("llm_user")
    for agent in run.agent_manager.agents.values():
        if agent.agent_type == "rule_moderator":
            continue
        positions = run.state.belief_network.get_agent_beliefs(agent.agent_id)
        assert set(positions) == axis_ids
        assert all(0.0 <= v <= 1.0 for v in positions.values())
    moved = 0
    for agent in users:
        history = [h["beliefs"] for h in agent.belief_history]
        moved += len(history)
        for before, after in zip(history, history[1:]):
            assert all(abs(after[a] - before[a]) <= cap + 1e-9 for a in axis_ids)
    assert moved > 0, "users' positions should move during the run"
    # Campaign agents hold the targets and never move
    targets = run.belief_config.campaign_targets
    for agent in run.agent_manager.get_agents_by_type("llm_attacker"):
        positions = run.state.belief_network.get_agent_beliefs(agent.agent_id)
        assert all(positions[a] == t for a, t in targets.items())
    # Outputs record the model and axes
    snap = json.loads((out / "daily_snapshots" / "day_0_data.json").read_text())
    final = json.loads((out / "final_output.json").read_text())
    assert snap["belief_model"] == final["belief_model"] == "axes"
    assert final["belief_config"]["campaign_targets"] == targets


def test_axes_event_run_independent_of_thread_count(setup_factory):
    kwargs = dict(time_model="event", belief_model="axes", **FULL)
    serial, _ = run_setup(setup_factory("s", **kwargs), overrides={"runtime_config": {"llm_max_concurrency": 1}})
    parallel, _ = run_setup(setup_factory("p", **kwargs), overrides={"runtime_config": {"llm_max_concurrency": 8}})
    assert canonical_log(serial) == canonical_log(parallel)
    beliefs = lambda r: {a: r.state.belief_network.get_agent_beliefs(a) for a in r.agent_manager.agents}
    assert beliefs(serial) == beliefs(parallel)


def test_config_without_belief_block_runs_free_text(setup_factory):
    run, out = run_setup(setup_factory(n_users=4))
    assert run.belief_model == "free_text" and run.belief_config is None
    assert json.loads((out / "final_output.json").read_text())["belief_model"] == "free_text"
    assert any(b.startswith("b") for b in run.state.belief_network.get_agent_beliefs(0))


def test_belief_model_override_switches_axes_setup_to_free_text(setup_factory):
    run, _ = run_setup(setup_factory(belief_model="axes", n_users=3),
                       overrides={"runtime_config": {"belief_model": "free_text"}})
    assert run.belief_model == "free_text"


def test_analyzer_reports_axis_alignment(setup_factory):
    from python_simulation.tools.analyze_simulation import SimulationAnalyzer
    from python_simulation.tools.thesis_tables import _alignment

    cfg = setup_factory(time_model="event", belief_model="axes", days=2, **FULL)
    run, out = run_setup(cfg)
    for name in ("simulation_config.json", "agent_profiles.json"):
        (out / name).write_text((cfg / name).read_text())
    analyzer = SimulationAnalyzer(str(out))
    analyzer.load_all_data()
    assert analyzer.belief_axes_config is not None
    analyzer.analyze_campaign_influence()
    analyzer.analyze_belief_alignment_change()
    analysis = out / "analysis"
    with open(analysis / "belief_alignment_change_summary.csv", newline="") as f:
        metrics = {row["metric"]: row for row in csv.DictReader(f)}
    assert set(metrics) == {"axis_alignment", "mean_abs_position_change"}
    with open(analysis / "axis_positions.csv", newline="") as f:
        rows = list(csv.DictReader(f))
    assert {r["day"] for r in rows} == {"-1", "0", "1"}
    values = _alignment(analysis)
    assert values["delta_alignment"] is not None and values["delta_cosine"] is None
