"""
Real-LLM smoke test (opt-in: --run-llm). Uses the provider configured by the
environment (MISTRAL_API_KEY / OPENAI_API_KEY / local endpoint) and costs a
small number of API calls (a few dozen per engine).

Checks that prompts and response parsing still work end to end with a real
model, which the stub provider cannot show.
"""

import pytest

from ..conftest import run_setup


@pytest.mark.llm
@pytest.mark.parametrize("belief_model", [None, "axes"])
@pytest.mark.parametrize("time_model", ["discrete", "event"])
def test_tiny_run_with_real_llm(setup_factory, time_model, belief_model):
    cfg = setup_factory(
        days=1, n_users=2, n_llm_attackers=1, time_model=time_model, belief_model=belief_model,
        sessions_per_day=1, session_steps=2, read_density=2, post_probability=0.5,
        extra={"llm_config": {"provider": "auto"}, "campaign_config": {"daily_post_target": 1}},
    )
    run, out = run_setup(cfg)
    state = run.state
    assert state.events, "expected some activity"
    posts = [e for e in state.events if e.content]
    assert all(e.content and "Interesting discussion happening" not in e.content for e in posts), \
        "post generation fell back (LLM call or JSON parse failed)"
    plans = run.orchestrator.daily_plans if run.orchestrator else []
    assert all(p.source != "fallback" for p in plans), "campaign planning fell back"
    if belief_model == "axes":
        users = run.agent_manager.get_agents_by_type("llm_user")
        assert any(agent.belief_history for agent in users), \
            "no axis update was applied (LLM replies not parsed as positions?)"
