"""
Small in-memory building blocks for unit tests: state + manager, events,
minimal agents, and offline stand-ins for the canonicalizer and NLI model.
"""

import hashlib
import re
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np

from python_simulation.core.agent_manager import AgentManager
from python_simulation.core.feed_system import FeedManager
from python_simulation.core.simulation_data import EventType, MediaEvent, SimulationState

SUB = "sub"


def ev(user: int, etype: EventType, parent: Optional[int] = None, t: int = 0,
       content: str = "some text content") -> MediaEvent:
    """An uncommitted event (commit with AgentManager.commit_event)."""
    if etype in (EventType.UPVOTE, EventType.DOWNVOTE):
        content = ""
    return MediaEvent(0, user, parent, etype, "b", SUB, t, content=content)


class StubAgent:
    """Minimal agent: ban checks only (for manager/state tests)."""

    agent_type = "llm_user"

    def __init__(self, agent_id: int):
        self.agent_id = agent_id

    def is_banned(self, state, threshold=1):
        return state.banned_agent_network.is_banned(self.agent_id, SUB, threshold)


def make_world(n_agents: int = 4, agents: Optional[Sequence] = None,
               strategy=None) -> Tuple[SimulationState, AgentManager]:
    """State + AgentManager with n StubAgents (or the given agents) in SUB."""
    state = SimulationState()
    am = AgentManager(state, FeedManager(strategy))
    for agent in agents if agents is not None else [StubAgent(i) for i in range(n_agents)]:
        state.subreddit_membership.add_member(agent.agent_id, SUB)
        am.add_agent(agent)
    return state, am


def ban(state: SimulationState, agent_id: int) -> None:
    state.banned_agent_network.increment_ban(agent_id, SUB)


def stub_llm_service(**config):
    from python_simulation.services.llm_reddit_service import LLMRedditService, LLMServiceConfig

    return LLMRedditService(LLMServiceConfig(provider="stub", **config))


# Offline canonicalizer / NLI

_NEG = re.compile(r"\b(not|never|no)\b", re.I)


def _words(text: str) -> List[str]:
    return [w for w in re.findall(r"[a-z]+", text.lower()) if w not in ("not", "never", "no")]


class FakeNLI:
    """Two texts contradict if they have the same words but exactly one is
    negated; they are the same belief if they have the same words and the
    same polarity."""

    def _same_words(self, a: str, b: str) -> bool:
        return sorted(_words(a)) == sorted(_words(b))

    def contradicts_many(self, pairs) -> List[bool]:
        return [
            self._same_words(a, b) and bool(_NEG.search(a)) != bool(_NEG.search(b))
            for a, b in pairs
        ]

    def same_belief_many(self, pairs, sims=None) -> List[bool]:
        return [
            self._same_words(a, b) and bool(_NEG.search(a)) == bool(_NEG.search(b))
            for a, b in pairs
        ]


class FakeCanonicalizer:
    """BeliefCanonicalizer stand-in: hashed bag-of-words embeddings, first-come
    canonical IDs decided by FakeNLI, metadata writes recorded in memory."""

    DIM = 64

    def __init__(self):
        self.nli = FakeNLI()
        self.canonical: List[Tuple[str, str]] = []  # (belief_id, text)
        self.metadata_writes: List[str] = []
        self.calls: List[str] = []

    def _embed(self, texts: List[str]) -> np.ndarray:
        if not texts:
            return np.array([])
        out = np.zeros((len(texts), self.DIM))
        for i, text in enumerate(texts):
            for w in _words(text):
                out[i, int(hashlib.md5(w.encode()).hexdigest(), 16) % self.DIM] += 1.0
            norm = np.linalg.norm(out[i])
            if norm:
                out[i] /= norm
        return out

    def canonicalize_belief_text(self, text: str, timestep=None) -> Tuple[str, str]:
        self.calls.append(text)
        for belief_id, canonical in self.canonical:
            if self.nli.same_belief_many([(text, canonical)])[0]:
                return belief_id, canonical
        belief_id = hashlib.sha1(text.encode()).hexdigest()[:16]
        self.canonical.append((belief_id, text))
        return belief_id, text

    def add_to_metadata(self, belief_id, text, timestep=None) -> None:
        self.metadata_writes.append(belief_id)
