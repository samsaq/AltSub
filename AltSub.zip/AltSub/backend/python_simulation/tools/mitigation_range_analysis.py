#!/usr/bin/env python3
"""
Evidence for defensible mitigation parameter ranges, from the June 2025
Pushshift extracts (Simulation_Setups/reddit_databases) and the template
attackers' campaign templates.

The two algorithmic mitigations judge each account on its own behaviour
(systems/mitigation_system.py):
  - duplicate detection flags an account when two of ITS OWN posts/replies
    within the lookback window have Jaccard word similarity >= the threshold
    (same tokenizer as the simulation: lowercase, punctuation stripped, word set);
  - rate limiting flags an account whose posts + replies within the window
    number MORE than the threshold.

So this script measures, for real users over one week (matching 7-day runs):
  1. self-similarity: for each user, the highest Jaccard similarity between two
     of their own texts that fall within a lookback window; reported as the share
     of users (with >= 2 texts in some window) who would be flagged at each
     threshold, overall and when texts shorter than N words are ignored;
  2. activity: for each user, the most posts + comments they made in any window
     of W hours; reported as percentiles over active users and the share of
     users exceeding each threshold;
  3. template attackers: Jaccard similarity between two renderings of the
     campaign templates (same template / different templates), i.e. how
     detectable template reuse is.

Usage (from backend/):
  python -m python_simulation.tools.mitigation_range_analysis [--start 2025-06-09 --days 7]
      [--json out.json]
"""

import argparse
import bisect
import json
import random
import re
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Set, Tuple

from .reddit_text_length_stats import DEFAULT_DB_DIR, PLACEHOLDER_TEXTS, is_mod_or_bot

REPO = Path(__file__).resolve().parents[3]
UNIVERSES = REPO / "Simulation_Setups" / "simulations" / "universes"
SCENARIOS = {
    "destiny2": ("2025-06-destiny2.db", "destiny2_base_sim_small"),
    "politics": ("2025-06-politics.db", "politics_base_sim_small"),
}
STEP_MIN = 5  # simulation reference timestep (minutes)
LOOKBACK_HOURS = (2.5, 8.0, 25.0)            # current duplicate lookback range (30-300 steps) + middle
RATE_WINDOW_HOURS = (0.5, 1, 2, 6, 12, 24)   # current rate-limit window range (6-288 steps)
THRESHOLDS = (0.5, 0.6, 0.7, 0.8, 0.9, 0.95, 1.0)
MIN_WORDS = (0, 5, 10)
RATE_K = (1, 2, 3, 4, 5, 6, 8, 10, 15, 20, 30)
PERCENTILES = (50, 90, 95, 99, 99.9)


def tokenize(text: str) -> Set[str]:
    """Same tokenizer as MitigationSystem._jaccard_similarity."""
    words = set()
    for word in text.lower().split():
        word = "".join(c for c in word if c.isalnum())
        if word:
            words.add(word)
    return words


def jaccard(a: Set[str], b: Set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


def load_items(db: Path, start: datetime, days: int):
    """(author, utc, kind, text) for posts (title + body, as simulation posts are)
    and comments in the window; bots / moderators / deleted authors excluded.
    Removed or deleted bodies still count for activity but carry no text."""
    lo, hi = int(start.timestamp()), int((start + timedelta(days=days)).timestamp())
    conn = sqlite3.connect(f"file:{db.as_posix()}?mode=ro", uri=True)
    items = []
    try:
        for author, utc, title, body, dist in conn.execute(
            "SELECT author, created_utc, title, selftext, distinguished FROM submissions "
            "WHERE created_utc >= ? AND created_utc < ?", (lo, hi)):
            if not author or author == "[deleted]" or is_mod_or_bot(author, dist):
                continue
            body = "" if (body or "").strip().lower() in PLACEHOLDER_TEXTS else (body or "")
            items.append((author, int(utc), "post", f"{title or ''}\n\n{body}".strip()))
        for author, utc, body, dist in conn.execute(
            "SELECT author, created_utc, body, distinguished FROM comments "
            "WHERE created_utc >= ? AND created_utc < ?", (lo, hi)):
            if not author or author == "[deleted]" or is_mod_or_bot(author, dist):
                continue
            text = "" if (body or "").strip().lower() in PLACEHOLDER_TEXTS else (body or "")
            items.append((author, int(utc), "comment", text))
    finally:
        conn.close()
    return items


def percentile(sorted_vals: Sequence[float], p: float) -> Optional[float]:
    if not sorted_vals:
        return None
    k = (len(sorted_vals) - 1) * p / 100.0
    f = int(k)
    if f >= len(sorted_vals) - 1:
        return float(sorted_vals[-1])
    return sorted_vals[f] + (k - f) * (sorted_vals[f + 1] - sorted_vals[f])


def activity_stats(by_user: Dict[str, List[int]]) -> Dict[str, dict]:
    """Per window: percentiles of each user's max actions in any window, and the
    share of users who exceed k actions (would be flagged at threshold k)."""
    out = {}
    for hours in RATE_WINDOW_HOURS:
        w = int(hours * 3600)
        maxima = []
        for times in by_user.values():
            best, j = 0, 0
            for i in range(len(times)):
                while times[i] - times[j] >= w:
                    j += 1
                best = max(best, i - j + 1)
            maxima.append(best)
        maxima.sort()
        n = len(maxima)
        out[f"{hours}h"] = {
            "window_steps": int(hours * 60 / STEP_MIN),
            "users": n,
            "percentiles_of_max_actions": {str(p): percentile(maxima, p) for p in PERCENTILES},
            "share_exceeding": {str(k): round(sum(m > k for m in maxima) / n, 5) for k in RATE_K},
        }
    return out


def self_similarity(texts_by_user: Dict[str, List[Tuple[int, Set[str], int]]]) -> Dict[str, dict]:
    """Per lookback and minimum length: share of eligible users (>= 2 texts within
    some window) whose best within-window pair reaches each threshold."""
    out = {}
    for hours in LOOKBACK_HOURS:
        w = int(hours * 3600)
        for min_words in MIN_WORDS:
            best_by_user = []
            for items in texts_by_user.values():
                pool = [(t, s) for t, s, n in items if n >= max(1, min_words)]
                if len(pool) < 2:
                    continue
                best, eligible, j = 0.0, False, 0
                for i in range(len(pool)):
                    while pool[i][0] - pool[j][0] >= w:
                        j += 1
                    for k in range(j, i):
                        eligible = True
                        sim = jaccard(pool[i][1], pool[k][1])
                        if sim > best:
                            best = sim
                            if best >= 1.0:
                                break
                    if best >= 1.0:
                        break
                if eligible:
                    best_by_user.append(best)
            n = len(best_by_user)
            out[f"{hours}h|min{min_words}"] = {
                "lookback_steps": int(hours * 60 / STEP_MIN),
                "min_words": min_words,
                "eligible_users": n,
                "share_flagged_at": {str(t): round(sum(b >= t for b in best_by_user) / n, 5) if n else None
                                     for t in THRESHOLDS},
            }
    return out


def template_similarity(path: Path, samples: int = 4000, seed: int = 0) -> dict:
    """Jaccard between two renderings: of the same template, and of two different
    templates (posts and replies pooled)."""
    data = json.loads(path.read_text(encoding="utf-8"))
    templates = [t for t in data["templates"].get("posts", []) + data["templates"].get("replies", [])
                 if isinstance(t.get("template"), str)]
    rng = random.Random(seed)

    def render(t):
        text = t["template"]
        for var, options in (t.get("variables") or {}).items():
            if options:
                text = text.replace("{" + var + "}", str(rng.choice(options)))
        return tokenize(text)

    def summary(vals):
        vals.sort()
        return {"median": round(percentile(vals, 50), 3), "p10": round(percentile(vals, 10), 3),
                "p90": round(percentile(vals, 90), 3),
                "share_at_or_above": {str(t): round(sum(v >= t for v in vals) / len(vals), 3) for t in THRESHOLDS}}

    same = [jaccard(render(t), render(t)) for t in (rng.choice(templates) for _ in range(samples))]
    diff = []
    for _ in range(samples):
        a, b = rng.sample(templates, 2)
        diff.append(jaccard(render(a), render(b)))
    return {"templates": len(templates), "same_template": summary(same), "different_templates": summary(diff)}


def analyze(name: str, start: datetime, days: int, db_dir: Path) -> dict:
    db_name, universe = SCENARIOS[name]
    items = load_items(db_dir / db_name, start, days)
    times_by_user: Dict[str, List[int]] = defaultdict(list)
    texts_by_user: Dict[str, List[Tuple[int, Set[str], int]]] = defaultdict(list)
    for author, utc, _kind, text in items:
        times_by_user[author].append(utc)
        if text:
            toks = tokenize(text)
            if toks:
                texts_by_user[author].append((utc, toks, len(text.split())))
    for v in times_by_user.values():
        v.sort()
    for v in texts_by_user.values():
        v.sort(key=lambda x: x[0])
    result = {
        "database": db_name,
        "span": f"{start.date()} + {days} days",
        "items": len(items),
        "active_users": len(times_by_user),
        "activity": activity_stats(times_by_user),
        "self_similarity": self_similarity(texts_by_user),
    }
    tpl = UNIVERSES / universe / "campaign_templates" / "default_campaign.json"
    if tpl.exists():
        result["template_attacker"] = template_similarity(tpl)
    return result


def report(results: Dict[str, dict]) -> str:
    lines = ["Mitigation range evidence (Pushshift June 2025; bots, moderators and deleted authors excluded)", ""]
    for name, r in results.items():
        lines.append(f"== {name} ({r.get('database', '')}): {r['span']}, {r['items']} posts+comments, {r['active_users']} active users")
        lines.append("  Rate limit: users' max posts+comments in any window (percentiles) | share exceeding k")
        for win, a in r["activity"].items():
            pct = ", ".join(f"p{p}={v:g}" for p, v in a["percentiles_of_max_actions"].items())
            exc = ", ".join(f">{k}:{v:.3%}" for k, v in a["share_exceeding"].items() if k in ("2", "4", "6", "10", "20"))
            lines.append(f"    {win:>5} ({a['window_steps']:>3} steps): {pct} | {exc}")
        lines.append("  Duplicate: share of users with 2+ texts in a window whose own best pair reaches the threshold")
        for key, s in r["self_similarity"].items():
            shares = ", ".join(f">={t}:{v:.1%}" for t, v in s["share_flagged_at"].items() if v is not None)
            lines.append(f"    lookback {key:<11} (n={s['eligible_users']}): {shares}")
        if "template_attacker" in r:
            ta = r["template_attacker"]
            for kind in ("same_template", "different_templates"):
                s = ta[kind]
                shares = ", ".join(f">={t}:{v:.0%}" for t, v in s["share_at_or_above"].items())
                lines.append(f"  Template attacker, {kind} ({ta['templates']} templates): median {s['median']}, "
                             f"p10 {s['p10']}, p90 {s['p90']} | {shares}")
        lines.append("")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--start", default="2025-06-09", help="Start date (UTC) of the one-week span")
    parser.add_argument("--days", type=int, default=7)
    parser.add_argument("--db-dir", type=Path, default=DEFAULT_DB_DIR)
    parser.add_argument("--scenario", choices=[*SCENARIOS, "all"], default="all")
    parser.add_argument("--json", type=Path)
    parser.add_argument("--db", action="append", default=[], metavar="SCENARIO=FILE",
                        help="Use this database file for a scenario, e.g. politics=2025-06-worldnews.db "
                             "(relative to --db-dir); repeatable")
    args = parser.parse_args(argv)
    for spec in args.db:
        scenario, _, db_file = spec.partition("=")
        if scenario not in SCENARIOS or not db_file:
            parser.error(f"--db expects SCENARIO=FILE with SCENARIO in {list(SCENARIOS)}")
        SCENARIOS[scenario] = (db_file, SCENARIOS[scenario][1])
    start = datetime.strptime(args.start, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    names = list(SCENARIOS) if args.scenario == "all" else [args.scenario]
    results = {}
    for name in names:
        print(f"Analyzing r/{name} ...", file=sys.stderr)
        results[name] = analyze(name, start, args.days, args.db_dir)
    print(report(results))
    if args.json:
        args.json.write_text(json.dumps(results, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    sys.exit(main())
