#!/usr/bin/env python3
"""
Compare the discrete and event-driven engines on the same population.

Runs one simulation setup (a directory with simulation_config.json and
agent_profiles.json) under both time models for several seeds, then reports
per-engine means and the event/discrete ratio for activity volumes, reply
latency, moderation and mitigation outcomes, and belief change. Use it to
check that switching the clock (with match_discrete calibration) leaves the
volumes intact and to see what it does change.

Usage:
  python -m python_simulation.tools.compare_time_models \
      --config-dir Simulation_Setups/simulations/universes/destiny2_base_sim_small \
      --out-dir comparison_runs --seeds 1 2 3 4 5 [--stub] [--days 1]

--stub uses the deterministic stub LLM (fast, no API cost) to check the
mechanics; without it the configured LLM is used.
"""

import argparse
import csv
import json
import logging
import statistics
import time
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Dict, List

from ..core.belief_axes import alignment, complete_positions
from ..core.simulation_data import EventType
from ..run_simulation import run_simulation_from_config

log = logging.getLogger(__name__)

TIME_MODELS = ("discrete", "event")


def _percentile(values: List[float], q: float) -> float:
    if not values:
        return float("nan")
    values = sorted(values)
    k = (len(values) - 1) * q
    lo, hi = int(k), min(int(k) + 1, len(values) - 1)
    return values[lo] + (values[hi] - values[lo]) * (k - lo)


def run_metrics(
    run,
    initial_beliefs: Dict[int, Dict[str, float]],
    wall_s: float,
    initial_axis_positions: Dict[int, Dict[str, float]] = None,
) -> Dict[str, float]:
    """Summary numbers for one finished run."""
    state = run.state
    am = run.agent_manager
    days = int(run.sim_config["duration_days"])
    out: Dict[str, float] = {"wall_time_s": round(wall_s, 1)}
    out["items_read_per_day"] = am.items_read / days

    counts = Counter(e.type.value for e in state.events)
    for etype in EventType:
        out[f"{etype.value}s_per_day"] = counts.get(etype.value, 0) / days

    by_type_actions: Dict[str, List[int]] = defaultdict(list)
    per_agent = Counter(e.user_id for e in state.events)
    for agent_id, agent in am.agents.items():
        by_type_actions[agent.agent_type].append(per_agent.get(agent_id, 0))
    for agent_type, values in by_type_actions.items():
        out[f"actions_per_{agent_type}_per_day"] = statistics.mean(values) / days

    latencies = []
    for e in state.events:
        if e.type == EventType.REPLY and e.parent_id is not None:
            parent = state.get_event(e.parent_id)
            if parent is not None:
                latencies.append(state.event_time(e) - state.event_time(parent))
    out["reply_latency_median_s"] = _percentile(latencies, 0.5)
    out["reply_latency_p90_s"] = _percentile(latencies, 0.9)

    flags = Counter(f["source"] for f in run.mitigation_system.flag_log)
    for source in ("duplicate", "rate_limit", "coordination", "rule_moderator"):
        out[f"flags_{source}"] = flags.get(source, 0)
    out["banned_agents"] = sum(
        1 for by_sub in state.banned_agent_network.ban_counts.values() if sum(by_sub.values()) > 0
    )
    out["coordination_edges"] = len(run.mitigation_system.coordination_edges)
    out["biased_removals"] = sum(
        sum(1 for a in m.moderation_log if a.action_type != "ban_user")
        for m in am.get_agents_by_type("biased_moderator")
    )
    out["removed_by_cascade"] = state.removed_by_cascade
    for reason, n in am.commit_rejections.items():
        out[f"refused_{reason}"] = n
    hub = am.coordination_hub
    if hub is not None:
        out["amplifications_executed"] = hub.stats["upvotes_executed"] + hub.stats["comments_executed"]

    # Belief change of LLM users: mean absolute change of initially held beliefs
    # (axis positions in the belief axes model), and belief count at the end
    axes = run.belief_config
    initial_axis_positions = initial_axis_positions or {}
    changes, counts_end, align_changes = [], [], []
    for agent in am.get_agents_by_type("llm_user"):
        final = state.belief_network.get_agent_beliefs(agent.agent_id)
        initial = initial_beliefs.get(agent.agent_id, {})
        if axes is not None:
            initial = complete_positions(axes, initial_axis_positions.get(agent.agent_id))
            start = alignment(initial, axes.campaign_targets)
            end = alignment(final, axes.campaign_targets)
            if start is not None and end is not None:
                align_changes.append(end - start)
        changes.extend(abs(final.get(b, 0.0) - s) for b, s in initial.items())
        counts_end.append(len(final))
    if changes:
        out["llm_user_mean_abs_belief_change"] = statistics.mean(changes)
        out["llm_user_beliefs_at_end"] = statistics.mean(counts_end)
    if align_changes:
        out["llm_user_axis_alignment_change"] = statistics.mean(align_changes)
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    parser.add_argument("--config-dir", type=Path, required=True)
    parser.add_argument("--out-dir", type=Path, required=True)
    parser.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3, 4, 5])
    parser.add_argument("--stub", action="store_true", help="Use the deterministic stub LLM")
    parser.add_argument("--days", type=int, default=None, help="Override duration_days")
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s")

    profiles = json.loads((args.config_dir / "agent_profiles.json").read_text())
    initial_beliefs = {i: dict(p.get("beliefs", {})) for i, p in enumerate(profiles)}
    initial_axis_positions = {i: dict(p.get("axis_positions") or {}) for i, p in enumerate(profiles)}

    rows: List[Dict[str, Any]] = []
    for seed in args.seeds:
        for model in TIME_MODELS:
            overrides: Dict[str, Dict[str, Any]] = {
                "runtime_config": {"time_model": model, "seed": seed}
            }
            if args.stub:
                overrides["llm_config"] = {"provider": "stub"}
            if args.days:
                overrides["simulation_config"] = {"duration_days": args.days}
            out = args.out_dir / f"{model}_seed{seed}"
            t0 = time.perf_counter()
            run = run_simulation_from_config(args.config_dir, out, overrides)
            metrics = run_metrics(run, initial_beliefs, time.perf_counter() - t0, initial_axis_positions)
            rows.append({"time_model": model, "seed": seed, **metrics})
            log.info("Finished %s seed %s: %s", model, seed, metrics)

    args.out_dir.mkdir(parents=True, exist_ok=True)
    keys = sorted({k for r in rows for k in r} - {"time_model", "seed"})
    with open(args.out_dir / "comparison_runs.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["time_model", "seed", *keys])
        writer.writeheader()
        writer.writerows(rows)

    summary = []
    for key in keys:
        means = {}
        for model in TIME_MODELS:
            values = [r[key] for r in rows if r["time_model"] == model and key in r]
            values = [v for v in values if v == v]  # drop NaN
            means[model] = statistics.mean(values) if values else float("nan")
        ratio = means["event"] / means["discrete"] if means["discrete"] else float("nan")
        summary.append({"metric": key, **means, "event/discrete": ratio})
    with open(args.out_dir / "comparison_summary.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["metric", *TIME_MODELS, "event/discrete"])
        writer.writeheader()
        writer.writerows(summary)

    width = max(len(s["metric"]) for s in summary)
    print(f"\n{'metric':<{width}}  {'discrete':>12}  {'event':>12}  {'event/disc':>10}")
    for s in summary:
        print(
            f"{s['metric']:<{width}}  {s['discrete']:>12.3f}  {s['event']:>12.3f}  "
            f"{s['event/discrete']:>10.3f}"
        )
    print(f"\nWritten to {args.out_dir}")


if __name__ == "__main__":
    main()
