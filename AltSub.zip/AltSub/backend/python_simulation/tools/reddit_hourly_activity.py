#!/usr/bin/env python3
"""
Hour-of-day posting volume per subreddit from the monthly Pushshift SQLite
extracts in Simulation_Setups/reddit_databases, turned into 24 activity
multipliers per subreddit that average exactly 1 over the day.

For each subreddit and hour of the day h (in the chosen timezone):
    avg_per_hour[h] = items created during hour h / number of hour-h slots in the data span
    multiplier[h]   = avg_per_hour[h] / mean(avg_per_hour)
so sum(multiplier) == 24 and mean(multiplier) == 1. Multiplying a continuous
action rate by multiplier[hour_of_day(t)] reshapes activity over the day while
keeping the expected number of actions per day unchanged.

Three multiplier sets are produced per subreddit: posts (submissions),
comments, and all (posts + comments together, so dominated by comments).
Removed / deleted items are counted, since they were still posted. Automated
moderator / bot items (AutoModerator, *-ModTeam, moderator-distinguished) are
excluded by default because they fire in response to other activity rather
than following human schedules; pass --include-mod-content to keep them.

Timezone: Pushshift timestamps are UTC. The simulation clock starts at hour 0,
so pick the timezone the simulation's "midnight" is meant to be in with --tz
(IANA name; default America/New_York, matching the agent initializer's
default --activity-timezone). DST is handled per timestamp.

Usage:
    python -m python_simulation.tools.reddit_hourly_activity
    python -m python_simulation.tools.reddit_hourly_activity --tz UTC
    python -m python_simulation.tools.reddit_hourly_activity --json hourly_multipliers.json
    python -m python_simulation.tools.reddit_hourly_activity --db path/to/2025-06-politics.db
"""

import argparse
import json
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, List, Optional
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from .reddit_text_length_stats import (
    DEFAULT_DB_DIR,
    _resolve_dbs,
    is_mod_or_bot,
)

KINDS = ("posts", "comments", "all")
DEFAULT_TZ = "America/New_York"


def _hour_slot_exposure(min_utc: int, max_utc: int, tz) -> List[int]:
    """How many times each local hour of day occurs in [min_utc, max_utc].

    Counts whole UTC hours from the hour containing min_utc to the hour
    containing max_utc, then bins each by its local hour (so DST shifts and
    timezone offsets are reflected exactly).
    """
    exposure = [0] * 24
    start = datetime.fromtimestamp(min_utc, tz=timezone.utc).replace(minute=0, second=0, microsecond=0)
    end = datetime.fromtimestamp(max_utc, tz=timezone.utc)
    t = start
    while t <= end:
        exposure[t.astimezone(tz).hour] += 1
        t += timedelta(hours=1)
    return exposure


def _multipliers(avg: List[float]) -> List[float]:
    mean = sum(avg) / len(avg)
    if mean <= 0:
        return [1.0] * len(avg)
    return [a / mean for a in avg]


def analyze_db(db_path: Path, tz, include_mod: bool, subreddit: Optional[str] = None) -> Dict[str, dict]:
    """Hourly counts, averages and multipliers per subreddit in one database
    (only `subreddit` if given, case-insensitive)."""
    where = "created_utc IS NOT NULL"
    params: tuple = ()
    if subreddit:
        where += " AND lower(subreddit) = ?"
        params = (subreddit.lower(),)
    conn = sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True)
    counts: Dict[str, Dict[str, List[int]]] = defaultdict(lambda: {"posts": [0] * 24, "comments": [0] * 24})
    excluded: Dict[str, Dict[str, int]] = defaultdict(lambda: {"posts": 0, "comments": 0})
    span: Dict[str, List[int]] = {}
    try:
        for kind, table in (("posts", "submissions"), ("comments", "comments")):
            for sub, author, distinguished, utc in conn.execute(
                f"SELECT subreddit, author, distinguished, created_utc FROM {table} WHERE {where}", params
            ):
                sub = (sub or "<unknown>").lower()
                if not include_mod and is_mod_or_bot(author, distinguished):
                    excluded[sub][kind] += 1
                    continue
                utc = int(utc)
                counts[sub][kind][datetime.fromtimestamp(utc, tz=tz).hour] += 1
                lo_hi = span.setdefault(sub, [utc, utc])
                lo_hi[0] = min(lo_hi[0], utc)
                lo_hi[1] = max(lo_hi[1], utc)
    finally:
        conn.close()

    result: Dict[str, dict] = {}
    for sub in sorted(counts):
        lo, hi = span[sub]
        exposure = _hour_slot_exposure(lo, hi, tz)
        c = counts[sub]
        c["all"] = [p + m for p, m in zip(c["posts"], c["comments"])]
        entry = {
            "database": db_path.name,
            "first_item_utc": datetime.fromtimestamp(lo, tz=timezone.utc).isoformat(),
            "last_item_utc": datetime.fromtimestamp(hi, tz=timezone.utc).isoformat(),
            "hour_slots_per_hour_of_day": exposure,
            "excluded_mod_or_bot": dict(excluded[sub]),
        }
        for kind in KINDS:
            avg = [c[kind][h] / exposure[h] if exposure[h] else 0.0 for h in range(24)]
            entry[kind] = {
                "total": sum(c[kind]),
                "count_by_hour": c[kind],
                "avg_per_hour": [round(a, 3) for a in avg],
                "avg_per_day": round(sum(avg), 2),
                "multipliers": [round(m, 4) for m in _multipliers(avg)],
            }
        result[sub] = entry
    return result


def hourly_multipliers(
    db_path,
    subreddit: Optional[str] = None,
    tz_name: str = DEFAULT_TZ,
    kind: str = "all",
    include_mod: bool = False,
) -> List[float]:
    """24 hour-of-day activity multipliers (mean 1) for one subreddit.

    Used by the agent initializer to weight session start hours. With no
    subreddit, the database must hold exactly one subreddit.
    """
    if kind not in KINDS:
        raise ValueError(f"kind must be one of {KINDS}, got {kind!r}")
    results = analyze_db(Path(db_path), ZoneInfo(tz_name), include_mod, subreddit)
    if not results:
        raise ValueError(f"No activity for subreddit {subreddit!r} in {db_path}")
    if len(results) > 1:
        raise ValueError(f"{db_path} holds several subreddits {sorted(results)}; pass subreddit")
    return list(next(iter(results.values()))[kind]["multipliers"])


def format_report(results: Dict[str, dict], tz_name: str, include_mod: bool) -> str:
    lines = [
        "Reddit hour-of-day activity per subreddit",
        f"Timezone: {tz_name}   Mod/bot content: {'included' if include_mod else 'excluded'}",
        "Multipliers average 1.0 over the 24 hours (multiplier = avg_per_hour / daily mean).",
        "",
    ]
    for sub, r in results.items():
        lines.append(f"r/{sub}  ({r['database']}, {r['first_item_utc']} -> {r['last_item_utc']})")
        lines.append(
            f"  avg per day: posts {r['posts']['avg_per_day']:.1f}, comments {r['comments']['avg_per_day']:.1f}"
        )
        lines.append(f"  {'hour':>4} {'posts/h':>8} {'mult':>6} {'comm/h':>9} {'mult':>6} {'all mult':>8}")
        max_all = max(r["all"]["multipliers"]) or 1.0
        for h in range(24):
            bar = "#" * int(round(30 * r["all"]["multipliers"][h] / max_all))
            lines.append(
                f"  {h:>4} {r['posts']['avg_per_hour'][h]:>8.2f} {r['posts']['multipliers'][h]:>6.2f} "
                f"{r['comments']['avg_per_hour'][h]:>9.1f} {r['comments']['multipliers'][h]:>6.2f} "
                f"{r['all']['multipliers'][h]:>8.2f}  {bar}"
            )
        for kind in KINDS:
            m = r[kind]["multipliers"]
            lines.append(f"  {kind} multipliers: [{', '.join(f'{x:.3f}' for x in m)}]")
        lines.append("")
    return "\n".join(lines)


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(
        description="Hour-of-day posting volume and normalized activity multipliers per subreddit."
    )
    parser.add_argument("--db", nargs="+", help="Specific .db file(s). Default: every *.db in --db-dir.")
    parser.add_argument("--db-dir", type=Path, default=DEFAULT_DB_DIR, help=f"Directory of .db files (default: {DEFAULT_DB_DIR}).")
    parser.add_argument("--tz", default=DEFAULT_TZ, help=f"IANA timezone that simulation hour 0 refers to (default: {DEFAULT_TZ}).")
    parser.add_argument("--include-mod-content", action="store_true", help="Keep AutoModerator / *-ModTeam / moderator-distinguished items.")
    parser.add_argument("--json", type=Path, help="Also write the full stats and multipliers to this JSON file.")
    parser.add_argument("--output", type=Path, help="Write the text report here instead of stdout.")
    args = parser.parse_args(argv)

    try:
        tz = ZoneInfo(args.tz)
    except (ZoneInfoNotFoundError, ValueError):
        print(f"Error: unknown timezone {args.tz!r} (on Windows, `pip install tzdata` may be needed)", file=sys.stderr)
        return 1
    try:
        dbs = _resolve_dbs(args.db, args.db_dir)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    results: Dict[str, dict] = {}
    for db in dbs:
        print(f"Reading {db.name} ...", file=sys.stderr)
        for sub, r in analyze_db(db, tz, args.include_mod_content).items():
            key = sub if sub not in results else f"{sub} ({db.name})"
            results[key] = r

    report = format_report(results, args.tz, args.include_mod_content)
    if args.output:
        args.output.write_text(report, encoding="utf-8")
        print(f"Wrote {args.output}", file=sys.stderr)
    else:
        print(report)
    if args.json:
        payload = {
            "timezone": args.tz,
            "include_mod_content": args.include_mod_content,
            "normalization": "mean of the 24 multipliers is 1 (sum = 24)",
            "subreddits": results,
        }
        args.json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        print(f"Wrote {args.json}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
