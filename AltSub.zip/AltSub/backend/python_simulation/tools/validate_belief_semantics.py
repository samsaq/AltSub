#!/usr/bin/env python3
"""
Semantic check of the belief statements: does the simulation's own model read
each statement, and the acceptance scale, the way the author intends?

Probes (each repeated --reps times, at the simulation's belief-update
temperature unless noted), sent through the simulation's LLM client:

  paraphrase     "Restate in your own words what accepting this means."     -> coded by the author
  anchors        "Describe a user at 0.0 / 0.25 / 0.5 / 0.75 / 1.0."        -> coded by the author
  anchor_choice  0.0 / 0.5 / 1.0 -> A convinced false / B undecided /
                 C convinced true (expected A, B, C)                          -> scored automatically
  ambiguity      "Which words are vague or open to more than one reading?"  -> coded by the author
  rating         the author's scenario posts (validation/belief_space/
                 scenario_items.json): rate the post author's acceptance of
                 every statement, null if the post says nothing             -> scored automatically
                 (in expected range, direction errors, off-target readings
                 = overlap between statements)
  round_trip     generate a comment at acceptance 0.1 / 0.5 / 0.9 (at the
                 simulation's generation temperature), then rate it blind
                 with the rating prompt                                      -> scored automatically
                 (rank correlation, direction errors)
  expression     the simulation's own post and reply generation
                 (LLMRedditService.generate_post_content /
                 generate_reply_content, unchanged prompts and temperature),
                 then a blind rating of the generated text                  -> scored automatically
                   campaign:  an agent holding the campaign targets (the LLM
                              attackers' beliefs) writes posts and replies to
                              the scenario's neutral posts; share of positions
                              taken that fall on the campaign side
                   statement: neutral on every statement except one held at
                              0.1 or 0.9, replying to that statement's neutral
                              post; share of replies rated on the right side

Every probe frames the statements as the simulation does (a Reddit user in
the subreddit, the same scale wording, the same statement text).

Artifacts: <out-root>/<run_id>/
  manifest.json      git commit (and dirty flag), model, temperatures, reps,
                     hashes of the statements, scenario items and prompt templates
  calls.jsonl        one line per LLM call: probe, statement / item, rep, the
                     messages sent, the raw reply, the parsed result
  summary/*.csv      anchor_choice.csv, ratings.csv, off_target.csv, round_trip.csv
  coding_sheet.csv   paraphrase / anchors / ambiguity replies with empty
                     code (pass / flag / fail) and note columns for the author
  report.md          pass/fail against the criteria fixed below (automatic probes)

Follow-up conversations: the "chat" command opens an interactive session with
the same model and framing and logs every turn to <out-root>/conversations/.

Usage (from backend/):
  python -m python_simulation.tools.validate_belief_semantics run --dry-run
  python -m python_simulation.tools.validate_belief_semantics run --kind development
  python -m python_simulation.tools.validate_belief_semantics run --kind record --reps 5
  python -m python_simulation.tools.validate_belief_semantics chat --scenario politics --statement P4
"""

import argparse
import csv
import hashlib
import json
import logging
import math
import subprocess
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..core.belief_axes import (
    ACCEPTANCE_SCALE,
    NEUTRAL,
    BeliefAxis,
    BeliefConfig,
    belief_config_for_set,
    campaign_positions,
)
from ..services.llm_json import complete_json, unit_float

log = logging.getLogger(__name__)

VALIDATION_DIR = Path(__file__).resolve().parents[1] / "validation" / "belief_space"
DEFAULT_ITEMS = VALIDATION_DIR / "scenario_items.json"
DEFAULT_OUT_ROOT = VALIDATION_DIR / "semantic"
SCENARIOS = ("destiny2", "politics")
PROBES = ("paraphrase", "anchors", "anchor_choice", "ambiguity", "rating", "round_trip", "expression")

# Same temperatures as the simulation: belief updates use 0.1 (LLMRedditService.
# update_axis_positions); replies and posts use creativity_temperature 0.7.
PROBE_TEMPERATURE = 0.1
GENERATION_TEMPERATURE = 0.7
ROUND_TRIP_LEVELS = (0.1, 0.5, 0.9)
EXPRESSION_LEVELS = (0.1, 0.9)
EXPECTED_ANCHOR_CHOICE = {"0.0": "A", "0.5": "B", "1.0": "C"}
# Expected ranges for scenario items (low < 0.4 <= neutral <= 0.6 < high)
RANGES = {"low": (0.0, 0.4), "neutral": (0.4, 0.6), "high": (0.6, 1.0)}
# A non-null rating at least this far from neutral counts as taking a position
OFF_TARGET_LEAN = 0.1

# Pass criteria, fixed before running (automatic probes)
CRITERIA = {
    "anchor_choice_min_rate": 0.8,   # share of reps answering A / B / C for 0 / 0.5 / 1
    "rating_min_in_range": 0.8,      # share of reps inside the expected range, per item
    "rating_max_direction_errors": 0,  # reps rated on the wrong side (high <-> low)
    "off_target_max_rate": 0.2,      # share of reps taking a position on an unrelated statement
    "round_trip_min_spearman": 0.8,  # rank correlation of generated level vs blind rating
    "round_trip_max_direction_errors": 0,
    "expression_campaign_min_side_rate": 0.8,  # positions taken that are on the campaign side
    "expression_statement_min_correct": 0.8,   # replies rated on the held side (null = miss)
}

# Prompt templates (hashed into the manifest; edit = new version)

TEMPLATES = {
    "paraphrase": """You are a Reddit user in r/{subreddit}. Consider this belief statement:

"{statement}"

In one or two sentences, restate in your own words what it means to accept this statement. Reply with the restatement only.""",
    "anchors": """You are a Reddit user in r/{subreddit}. Consider this belief statement:

"{statement}"

A user's acceptance of the statement is a value from 0.0 to 1.0 ({scale}). In one sentence each, describe what a user at each of these values believes.

Return JSON: {{"0.0": "...", "0.25": "...", "0.5": "...", "0.75": "...", "1.0": "..."}}
Return ONLY JSON.""",
    "anchor_choice": """You are a Reddit user in r/{subreddit}. Consider this belief statement:

"{statement}"

A user's acceptance of the statement is a value from 0.0 to 1.0 ({scale}). For each value below, choose the description that best fits a user at that value:
A = convinced the statement is false
B = undecided, or has no opinion either way
C = convinced the statement is true

Values: 0.0, 0.5, 1.0
Return JSON: {{"0.0": "A, B or C", "0.5": "A, B or C", "1.0": "A, B or C"}}
Return ONLY JSON.""",
    "ambiguity": """You are a Reddit user in r/{subreddit}. Consider this belief statement:

"{statement}"

Which words or phrases in it are vague, or could be read in more than one way by users of r/{subreddit}? For each, list the different readings. If nothing is ambiguous, return an empty list.

Return JSON: {{"ambiguities": [{{"phrase": "...", "readings": ["...", "..."]}}]}}
Return ONLY JSON.""",
    "rating": """You are a Reddit user in r/{subreddit}. Read this post:

"{text}"

Belief statements (acceptance: {scale}):
{statement_lines}

For each statement, estimate how much the post's author accepts it, from 0.0 to 1.0. Use 0.5 if the author is undecided or mixed about it. Use null only for statements the post does not address at all.

Return JSON keyed by the bracketed key: {{"a1": acceptance or null, ...}}
Return ONLY JSON.""",
    "rating_reply": """You are a Reddit user in r/{subreddit}. Read this reply to a post:

Post: "{parent}"
Reply: "{text}"

Belief statements (acceptance: {scale}):
{statement_lines}

For each statement, estimate how much the author of the REPLY accepts it, from 0.0 to 1.0. Use 0.5 if the reply's author is undecided or mixed about it. Use null only for statements the reply does not address at all.

Return JSON keyed by the bracketed key: {{"a1": acceptance or null, ...}}
Return ONLY JSON.""",
    "generate": """You are a Reddit user in r/{subreddit}. Your acceptance of this belief statement is {level:.1f} (acceptance: {scale}):

"{statement}"

Write a short Reddit comment (one to three sentences) that expresses your view on it naturally, as you would on r/{subreddit}. Do not mention numbers and do not quote the statement. Reply with the comment only.""",
    "chat_system": """You are a Reddit user in r/{subreddit}. The simulation describes users' beliefs as acceptance of statements (acceptance: {scale}). Belief statements:
{statement_lines}""",
}


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def statement_lines(axes: List[BeliefAxis]) -> str:
    return "\n".join(f'- [a{n}] "{a.statement}"' for n, a in enumerate(axes, start=1))


# Calls


@dataclass
class Scenario:
    name: str
    subreddit: str
    config: BeliefConfig
    items: List[Dict[str, Any]] = field(default_factory=list)
    campaign_narrative: str = ""


class CallLog:
    """Thread-safe JSONL writer for every LLM call."""

    def __init__(self, path: Path, run_id: str, model: str) -> None:
        self.path, self.run_id, self.model = path, run_id, model
        self._lock = threading.Lock()
        self.records: List[Dict[str, Any]] = []

    def write(self, record: Dict[str, Any]) -> Dict[str, Any]:
        record = {"run_id": self.run_id, "model": self.model,
                  "time": datetime.now(timezone.utc).isoformat(), **record}
        with self._lock:
            self.records.append(record)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        return record


class RecordingProvider:
    """Wraps the provider so calls made inside LLMRedditService are logged:
    each thread's exchanges (messages, temperature, reply) since reset()."""

    def __init__(self, provider) -> None:
        self._provider = provider
        self._local = threading.local()

    def __getattr__(self, name):
        return getattr(self._provider, name)

    def reset(self) -> None:
        self._local.exchanges = []

    def exchanges(self) -> List[Dict[str, Any]]:
        return list(getattr(self._local, "exchanges", []))

    def chat_completion_meta(self, messages, temperature=0.3, max_tokens=500, **kwargs):
        resp = self._provider.chat_completion_meta(messages, temperature=temperature,
                                                   max_tokens=max_tokens, **kwargs)
        if not hasattr(self._local, "exchanges"):
            self._local.exchanges = []
        self._local.exchanges.append({"messages": list(messages), "temperature": temperature,
                                      "reply": resp.content if resp else None})
        return resp

    def chat_completion(self, messages, temperature=0.3, max_tokens=500, **kwargs):
        resp = self.chat_completion_meta(messages, temperature, max_tokens, **kwargs)
        return resp.content if resp else None


def make_service(provider, verbal_labels: bool = False):
    """The simulation's LLMRedditService, calling the (recording) provider."""
    from ..services.llm_reddit_service import LLMRedditService, LLMServiceConfig

    service = LLMRedditService(LLMServiceConfig(provider="stub", verbal_acceptance_labels=verbal_labels))
    service._llm_provider = RecordingProvider(provider)
    return service


def _text_call(provider, prompt: str, temperature: float, max_tokens: int = 300) -> Tuple[str, str]:
    messages = [{"role": "user", "content": prompt}]
    resp = provider.chat_completion_meta(messages, temperature=temperature, max_tokens=max_tokens)
    if resp is None:
        return "", "no response"
    return (resp.content or "").strip(), ""


def _json_call(provider, prompt: str, label: str, max_tokens: int = 600):
    return complete_json(
        provider, [{"role": "user", "content": prompt}],
        temperature=PROBE_TEMPERATURE, max_tokens=max_tokens, label=label,
    )


def _parse_rating(data: Any, axes: List[BeliefAxis]) -> Dict[str, Optional[float]]:
    alias = {f"a{n}": a.id for n, a in enumerate(axes, start=1)}
    out: Dict[str, Optional[float]] = {a.id: None for a in axes}
    for key, value in (data or {}).items():
        sid = alias.get(str(key).strip("[] "))
        if sid is not None and value is not None:
            out[sid] = unit_float(value)
    return out


def _rate(provider, sc: Scenario, text: str, label: str,
          parent: Optional[str] = None) -> Tuple[str, Dict[str, Any], Dict[str, Optional[float]]]:
    """Blind rating of a text (a reply is rated with the post it answers)."""
    prompt = TEMPLATES["rating" if parent is None else "rating_reply"].format(
        subreddit=sc.subreddit, text=text, parent=parent, scale=ACCEPTANCE_SCALE,
        statement_lines=statement_lines(sc.config.axes),
    )
    result = _json_call(provider, prompt, label)
    parsed = _parse_rating(result.data, sc.config.axes) if result.ok else {}
    return prompt, {"raw": result.raw, "status": result.status, "error": result.error}, parsed


def _opposing_seeds(sc: Scenario) -> List[Dict[str, Any]]:
    """Posts that argue against the campaign on a targeted statement."""
    targets = sc.config.campaign_targets
    out = []
    for it in sc.items:
        for sid, label in it.get("expected", {}).items():
            t = targets.get(sid)
            if t is not None and ((label == "high" and t < 0.5) or (label == "low" and t > 0.5)):
                out.append(it)
                break
    return out


def build_tasks(scenarios: List[Scenario], probes: List[str], reps: int,
                campaign_brief: bool = False, opposing_seeds: bool = False,
                campaign_only: bool = False) -> List[Dict[str, Any]]:
    tasks = []
    for sc in scenarios:
        for rep in range(1, reps + 1):
            for axis in sc.config.axes:
                for probe in ("paraphrase", "anchors", "anchor_choice", "ambiguity"):
                    if probe in probes:
                        tasks.append({"probe": probe, "scenario": sc, "axis": axis, "rep": rep})
                if "round_trip" in probes:
                    for level in ROUND_TRIP_LEVELS:
                        tasks.append({"probe": "round_trip", "scenario": sc, "axis": axis,
                                      "rep": rep, "level": level})
            if "rating" in probes:
                for item in sc.items:
                    tasks.append({"probe": "rating", "scenario": sc, "item": item, "rep": rep})
            if "expression" in probes:
                seeds = [it for it in sc.items if "neutral" in it.get("expected", {}).values()]
                tasks.append({"probe": "expression", "scenario": sc, "rep": rep,
                              "condition": "campaign", "kind": "post", "brief": campaign_brief})
                for seed in seeds:
                    tasks.append({"probe": "expression", "scenario": sc, "rep": rep,
                                  "condition": "campaign", "kind": "reply", "item": seed,
                                  "brief": campaign_brief, "seed_type": "neutral"})
                if opposing_seeds:
                    for seed in _opposing_seeds(sc):
                        tasks.append({"probe": "expression", "scenario": sc, "rep": rep,
                                      "condition": "campaign", "kind": "reply", "item": seed,
                                      "brief": campaign_brief, "seed_type": "opposing"})
                if campaign_only:
                    continue
                for axis in sc.config.axes:
                    seed = next((it for it in seeds if axis.id in it["expected"]), None)
                    if seed is None:
                        continue
                    for level in EXPRESSION_LEVELS:
                        tasks.append({"probe": "expression", "scenario": sc, "rep": rep,
                                      "condition": "statement", "kind": "reply", "item": seed,
                                      "axis": axis, "level": level})
    return tasks


def calls_per_task(task: Dict[str, Any]) -> int:
    return 2 if task["probe"] in ("round_trip", "expression") else 1


def run_expression(provider, service, task: Dict[str, Any], calls: CallLog) -> None:
    """Generate with the simulation's own post / reply prompt, then rate blind."""
    sc: Scenario = task["scenario"]
    axes = sc.config.axes
    if task["condition"] == "campaign":
        positions = campaign_positions(sc.config)
    else:
        positions = {a.id: NEUTRAL for a in axes}
        positions[task["axis"].id] = task["level"]
    seed = task.get("item")
    brief = sc.campaign_narrative if task["condition"] == "campaign" and task.get("brief") else None
    base = {"scenario": sc.name, "probe": "expression", "rep": task["rep"],
            "campaign_brief": bool(brief), "verbal_labels": service.config.verbal_acceptance_labels,
            "condition": task["condition"], "kind": task["kind"],
            "statement_id": task["axis"].id if "axis" in task else None,
            "level": task.get("level"), "item_id": seed["id"] if seed else None,
            "seed_type": task.get("seed_type"),
            "positions": positions}
    t0 = time.perf_counter()
    service._llm_provider.reset()
    error = ""
    try:
        if task["kind"] == "post":
            text = service.generate_post_content(positions, {}, sc.subreddit, axes=axes,
                                                 campaign_brief=brief)
        else:
            text = service.generate_reply_content(seed["text"], positions, sc.subreddit, axes=axes,
                                                  campaign_brief=brief)
    except Exception as e:  # the service logs and falls back; record anything else
        text, error = "", str(e)
    exchanges = service._llm_provider.exchanges()
    calls.write({**base, "step": "generate",
                 "temperature": exchanges[-1]["temperature"] if exchanges else None,
                 "messages": exchanges[-1]["messages"] if exchanges else [],
                 "raw": exchanges[-1]["reply"] if exchanges else None, "exchanges": len(exchanges),
                 "error": error, "parsed": text, "elapsed_s": round(time.perf_counter() - t0, 2)})
    if not text:
        return
    t1 = time.perf_counter()
    prompt, meta, parsed = _rate(provider, sc, text, f"expression {task['condition']}",
                                 parent=seed["text"] if task["kind"] == "reply" else None)
    calls.write({**base, "step": "rate", "temperature": PROBE_TEMPERATURE,
                 "messages": [{"role": "user", "content": prompt}], **meta, "parsed": parsed,
                 "elapsed_s": round(time.perf_counter() - t1, 2)})


def run_task(provider, task: Dict[str, Any], calls: CallLog, service=None) -> None:
    sc: Scenario = task["scenario"]
    probe, rep = task["probe"], task["rep"]
    if probe == "expression":
        run_expression(provider, service, task, calls)
        return
    base = {"scenario": sc.name, "probe": probe, "rep": rep}
    t0 = time.perf_counter()
    if probe == "rating":
        item = task["item"]
        prompt, meta, parsed = _rate(provider, sc, item["text"], f"rating {item['id']}")
        calls.write({**base, "item_id": item["id"], "expected": item.get("expected", {}),
                     "temperature": PROBE_TEMPERATURE, "messages": [{"role": "user", "content": prompt}],
                     **meta, "parsed": parsed, "elapsed_s": round(time.perf_counter() - t0, 2)})
        return
    axis: BeliefAxis = task["axis"]
    fmt = {"subreddit": sc.subreddit, "statement": axis.statement, "scale": ACCEPTANCE_SCALE}
    base["statement_id"] = axis.id
    if probe == "round_trip":
        level = task["level"]
        gen_prompt = TEMPLATES["generate"].format(level=level, **fmt)
        comment, err = _text_call(provider, gen_prompt, GENERATION_TEMPERATURE)
        calls.write({**base, "step": "generate", "level": level, "temperature": GENERATION_TEMPERATURE,
                     "messages": [{"role": "user", "content": gen_prompt}], "raw": comment,
                     "error": err, "parsed": comment, "elapsed_s": round(time.perf_counter() - t0, 2)})
        if not comment:
            return
        t1 = time.perf_counter()
        prompt, meta, parsed = _rate(provider, sc, comment, f"round_trip {axis.id}")
        calls.write({**base, "step": "rate", "level": level, "temperature": PROBE_TEMPERATURE,
                     "messages": [{"role": "user", "content": prompt}], **meta, "parsed": parsed,
                     "elapsed_s": round(time.perf_counter() - t1, 2)})
        return
    prompt = TEMPLATES[probe].format(**fmt)
    if probe == "paraphrase":
        text, err = _text_call(provider, prompt, PROBE_TEMPERATURE)
        meta: Dict[str, Any] = {"raw": text, "error": err, "parsed": text}
    else:
        result = _json_call(provider, prompt, f"{probe} {axis.id}")
        parsed: Any = result.data
        if probe == "anchor_choice" and isinstance(parsed, dict):
            parsed = {k: str(v).strip().upper()[:1] for k, v in parsed.items()}
        meta = {"raw": result.raw, "status": result.status, "error": result.error, "parsed": parsed}
    calls.write({**base, "temperature": PROBE_TEMPERATURE,
                 "messages": [{"role": "user", "content": prompt}], **meta,
                 "elapsed_s": round(time.perf_counter() - t0, 2)})


# Analysis


def _mean_sd(values: List[float]) -> Tuple[Optional[float], Optional[float]]:
    if not values:
        return None, None
    m = sum(values) / len(values)
    sd = math.sqrt(sum((v - m) ** 2 for v in values) / (len(values) - 1)) if len(values) > 1 else 0.0
    return m, sd


def _ranks(values: List[float]) -> List[float]:
    order = sorted(range(len(values)), key=lambda i: values[i])
    ranks = [0.0] * len(values)
    i = 0
    while i < len(order):
        j = i
        while j + 1 < len(order) and values[order[j + 1]] == values[order[i]]:
            j += 1
        for k in range(i, j + 1):
            ranks[order[k]] = (i + j) / 2 + 1
        i = j + 1
    return ranks


def spearman(x: List[float], y: List[float]) -> Optional[float]:
    if len(x) < 3:
        return None
    rx, ry = _ranks(x), _ranks(y)
    mx, my = sum(rx) / len(rx), sum(ry) / len(ry)
    cov = sum((a - mx) * (b - my) for a, b in zip(rx, ry))
    vx = math.sqrt(sum((a - mx) ** 2 for a in rx))
    vy = math.sqrt(sum((b - my) ** 2 for b in ry))
    return cov / (vx * vy) if vx and vy else None


def _in_range(value: Optional[float], label: str) -> bool:
    if value is None:
        return False
    lo, hi = RANGES[label]
    if label == "low":
        return value < hi
    if label == "high":
        return value > lo
    return lo <= value <= hi


def _direction_error(value: Optional[float], label: str) -> bool:
    if value is None:
        return False
    return (label == "high" and value < 0.4) or (label == "low" and value > 0.6)


def analyze(records: List[Dict[str, Any]], reps: int) -> Dict[str, List[Dict[str, Any]]]:
    tables: Dict[str, List[Dict[str, Any]]] = {}

    # anchor_choice: per statement, share of reps answering exactly A/B/C
    by_stmt: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for r in records:
        if r["probe"] == "anchor_choice":
            by_stmt.setdefault((r["scenario"], r["statement_id"]), []).append(r)
    rows = []
    for (sc, sid), recs in sorted(by_stmt.items()):
        ok = [isinstance(r.get("parsed"), dict) and all(
            r["parsed"].get(k) == v for k, v in EXPECTED_ANCHOR_CHOICE.items()) for r in recs]
        answers = {k: "".join(sorted(str((r.get("parsed") or {}).get(k, "?")) for r in recs))
                   for k in EXPECTED_ANCHOR_CHOICE}
        rate = sum(ok) / len(recs)
        rows.append({"scenario": sc, "statement_id": sid, "reps": len(recs), "correct_rate": round(rate, 3),
                     "answers_0.0": answers["0.0"], "answers_0.5": answers["0.5"], "answers_1.0": answers["1.0"],
                     "pass": rate >= CRITERIA["anchor_choice_min_rate"]})
    tables["anchor_choice"] = rows

    # rating: per item x expected statement; off-target positions per item
    by_item: Dict[Tuple[str, str], List[Dict[str, Any]]] = {}
    for r in records:
        if r["probe"] == "rating":
            by_item.setdefault((r["scenario"], r["item_id"]), []).append(r)
    rating_rows, off_counts = [], {}
    for (sc, item_id), recs in sorted(by_item.items()):
        expected = recs[0].get("expected") or {}
        for sid, label in expected.items():
            values = [(r.get("parsed") or {}).get(sid) for r in recs]
            got = [v for v in values if v is not None]
            m, sd = _mean_sd(got)
            in_range = sum(_in_range(v, label) for v in values) / len(values)
            dir_err = sum(_direction_error(v, label) for v in values)
            rating_rows.append({
                "scenario": sc, "item_id": item_id, "statement_id": sid, "expected": label,
                "reps": len(values), "nulls": len(values) - len(got),
                "mean": None if m is None else round(m, 3), "sd": None if sd is None else round(sd, 3),
                "in_range_rate": round(in_range, 3), "direction_errors": dir_err,
                "pass": in_range >= CRITERIA["rating_min_in_range"]
                and dir_err <= CRITERIA["rating_max_direction_errors"],
            })
        target = "|".join(sorted(expected)) or "off-topic"
        for r in recs:
            for sid, v in (r.get("parsed") or {}).items():
                if sid in expected:
                    continue
                key = (sc, target, sid)
                hits, n = off_counts.get(key, (0, 0))
                took = v is not None and abs(v - 0.5) >= OFF_TARGET_LEAN
                off_counts[key] = (hits + int(took), n + 1)
    tables["ratings"] = rating_rows
    tables["off_target"] = [
        {"scenario": sc, "item_target": target, "other_statement": sid, "readings": n,
         "positions_taken": hits, "rate": round(hits / n, 3),
         "pass": hits / n <= CRITERIA["off_target_max_rate"]}
        for (sc, target, sid), (hits, n) in sorted(off_counts.items()) if n
    ]

    # round_trip: per statement, generated level vs blind rating of that statement
    pairs: Dict[Tuple[str, str], List[Tuple[float, Optional[float]]]] = {}
    for r in records:
        if r["probe"] == "round_trip" and r.get("step") == "rate":
            v = (r.get("parsed") or {}).get(r["statement_id"])
            pairs.setdefault((r["scenario"], r["statement_id"]), []).append((r["level"], v))
    rt_rows = []
    for (sc, sid), ps in sorted(pairs.items()):
        rated = [(lv, v) for lv, v in ps if v is not None]
        rho = spearman([lv for lv, _ in rated], [v for _, v in rated])
        dir_err = sum(1 for lv, v in rated if (lv < 0.5 and v > 0.6) or (lv > 0.5 and v < 0.4))
        row = {"scenario": sc, "statement_id": sid, "pairs": len(ps), "nulls": len(ps) - len(rated),
               "spearman": None if rho is None else round(rho, 3), "direction_errors": dir_err}
        for level in ROUND_TRIP_LEVELS:
            m, _ = _mean_sd([v for lv, v in rated if lv == level])
            row[f"mean_at_{level}"] = None if m is None else round(m, 3)
        row["pass"] = (rho is not None and rho >= CRITERIA["round_trip_min_spearman"]
                       and dir_err <= CRITERIA["round_trip_max_direction_errors"])
        rt_rows.append(row)
    tables["round_trip"] = rt_rows
    tables.update(analyze_expression(records))
    return tables


def _positioned(v: Optional[float]) -> bool:
    return v is not None and abs(v - 0.5) >= OFF_TARGET_LEAN


def analyze_expression(records: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    rated = [r for r in records if r["probe"] == "expression" and r.get("step") == "rate"]
    if not rated:
        return {}
    # campaign profile: per scenario x kind x statement
    groups: Dict[Tuple[str, str, str], List[Tuple[float, Optional[float]]]] = {}
    for r in rated:
        if r["condition"] != "campaign":
            continue
        kind = r["kind"] if r["kind"] == "post" else f"reply-{r.get('seed_type') or 'neutral'}"
        for sid, target in r["positions"].items():
            groups.setdefault((r["scenario"], kind, sid), []).append(
                (target, (r.get("parsed") or {}).get(sid)))
    camp = []
    for (sc, kind, sid), vals in sorted(groups.items()):
        pos = [(t, v) for t, v in vals if _positioned(v)]
        side = sum(1 for t, v in pos if (v - 0.5) * (t - 0.5) > 0)
        rate = side / len(pos) if pos else None
        camp.append({"scenario": sc, "kind": kind, "statement_id": sid, "target": vals[0][0],
                     "texts": len(vals), "positions_taken": len(pos), "campaign_side": side,
                     "against_campaign": len(pos) - side,
                     "campaign_side_rate": None if rate is None else round(rate, 3),
                     "mean_rating": (lambda m: None if m is None else round(m, 3))(
                         _mean_sd([v for _, v in vals if v is not None])[0]),
                     "pass": rate is not None and rate >= CRITERIA["expression_campaign_min_side_rate"]})
    # single statement held at 0.1 / 0.9
    by_stmt: Dict[Tuple[str, str], List[Tuple[float, Optional[float]]]] = {}
    for r in rated:
        if r["condition"] == "statement":
            by_stmt.setdefault((r["scenario"], r["statement_id"]), []).append(
                (r["level"], (r.get("parsed") or {}).get(r["statement_id"])))
    stmt = []
    for (sc, sid), vals in sorted(by_stmt.items()):
        correct = sum(1 for lv, v in vals if v is not None and ((lv < 0.5 and v < 0.4) or (lv > 0.5 and v > 0.6)))
        row = {"scenario": sc, "statement_id": sid, "replies": len(vals),
               "nulls": sum(1 for _, v in vals if v is None), "correct": correct,
               "correct_rate": round(correct / len(vals), 3)}
        for level in EXPRESSION_LEVELS:
            m, _ = _mean_sd([v for lv, v in vals if lv == level and v is not None])
            row[f"mean_at_{level}"] = None if m is None else round(m, 3)
        row["pass"] = correct / len(vals) >= CRITERIA["expression_statement_min_correct"]
        stmt.append(row)
    return {"expression_campaign": camp, "expression_statement": stmt}


def _write_csv(path: Path, rows: List[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_coding_sheet(path: Path, records: List[Dict[str, Any]]) -> None:
    rows = []
    for r in records:
        if r["probe"] not in ("paraphrase", "anchors", "ambiguity"):
            continue
        response = r.get("parsed")
        if not isinstance(response, str):
            response = json.dumps(response, ensure_ascii=False) if response is not None else r.get("raw", "")
        rows.append({"scenario": r["scenario"], "statement_id": r["statement_id"], "probe": r["probe"],
                     "rep": r["rep"], "response": response, "code (pass/flag/fail)": "", "note": ""})
    rows.sort(key=lambda x: (x["scenario"], x["statement_id"], x["probe"], x["rep"]))
    _write_csv(path, rows)


def write_report(path: Path, manifest: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> None:
    lines = [
        f"# Belief statement semantic check: {manifest['run_id']}",
        "",
        f"- Kind: {manifest['kind']}  |  model: {manifest['model']}  |  reps: {manifest['reps']}",
        f"- Git: {manifest['git_commit']}{' (dirty)' if manifest['git_dirty'] else ''}",
        f"- Scale: {manifest['scale']}",
        f"- Criteria: `{json.dumps(CRITERIA)}`",
        "",
        "Paraphrase, anchor descriptions and ambiguity replies are coded by the author in coding_sheet.csv.",
        "",
    ]
    for name, rows in tables.items():
        failed = [r for r in rows if not r.get("pass")]
        lines.append(f"## {name}: {len(rows) - len(failed)}/{len(rows)} pass")
        for r in failed:
            lines.append("- FAIL " + ", ".join(f"{k}={v}" for k, v in r.items() if k != "pass"))
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


# Setup


def load_scenarios(names: List[str], items_path: Path) -> List[Scenario]:
    items = json.loads(Path(items_path).read_text(encoding="utf-8")).get("scenarios", {})
    out = []
    for name in names:
        config = belief_config_for_set(name)
        entry = items.get(name, {})
        ids = set(config.axis_ids)
        for item in entry.get("items", []):
            unknown = set(item.get("expected", {})) - ids
            if unknown:
                raise ValueError(f"scenario item {item.get('id')} expects unknown statements {sorted(unknown)}")
            bad = {v for v in item.get("expected", {}).values()} - set(RANGES)
            if bad:
                raise ValueError(f"scenario item {item.get('id')}: expected labels must be {sorted(RANGES)}")
        out.append(Scenario(name, entry.get("subreddit", name), config, list(entry.get("items", [])),
                            entry.get("campaign_narrative", "")))
    return out


def make_provider(name: str):
    if name == "stub":
        from ..services.stub_llm_provider import StubLLMProvider

        return StubLLMProvider()
    from ..services.llm_provider import get_llm_provider

    return get_llm_provider(None if name == "auto" else name)


def _git_state() -> Tuple[str, bool]:
    root = Path(__file__).resolve().parents[3]
    try:
        commit = subprocess.run(["git", "rev-parse", "HEAD"], cwd=root, capture_output=True,
                                text=True, check=True).stdout.strip()
        dirty = bool(subprocess.run(["git", "status", "--porcelain"], cwd=root, capture_output=True,
                                    text=True, check=True).stdout.strip())
        return commit, dirty
    except (OSError, subprocess.CalledProcessError):
        return "unknown", True


def build_manifest(run_id: str, kind: str, provider, scenarios: List[Scenario], probes: List[str],
                   reps: int, items_path: Path) -> Dict[str, Any]:
    commit, dirty = _git_state()
    return {
        "run_id": run_id,
        "kind": kind,
        "created": datetime.now(timezone.utc).isoformat(),
        "git_commit": commit,
        "git_dirty": dirty,
        "model": getattr(provider, "model", None) or type(provider).__name__,
        "provider": getattr(provider, "provider_type", None) or type(provider).__name__,
        "temperatures": {"probes": PROBE_TEMPERATURE, "generation": GENERATION_TEMPERATURE},
        "reps": reps,
        "probes": probes,
        "scale": ACCEPTANCE_SCALE,
        "criteria": CRITERIA,
        "round_trip_levels": list(ROUND_TRIP_LEVELS),
        "expression_levels": list(EXPRESSION_LEVELS),
        "simulation_prompts": "expression probe uses LLMRedditService.generate_post_content / "
                              "generate_reply_content unchanged (see the logged messages)",
        "template_hashes": {k: _sha(v) for k, v in TEMPLATES.items()},
        "scenario_items": {"path": str(items_path), "sha": _sha(Path(items_path).read_text(encoding="utf-8"))},
        "belief_sets": {
            sc.name: {
                "source": sc.config.source,
                "sha": _sha(json.dumps([vars(a) for a in sc.config.axes], sort_keys=True)),
                "statements": [{"id": a.id, "domain": a.domain, "statement": a.statement}
                               for a in sc.config.axes],
                "items": len(sc.items),
            }
            for sc in scenarios
        },
    }


# Commands


def cmd_run(args: argparse.Namespace) -> int:
    names = list(SCENARIOS) if args.scenario == "all" else [args.scenario]
    probes = args.probes or list(PROBES)
    scenarios = load_scenarios(names, args.items)
    tasks = build_tasks(scenarios, probes, args.reps, campaign_brief=args.campaign_brief,
                        opposing_seeds=args.opposing_seeds, campaign_only=args.campaign_only)
    n_calls = sum(calls_per_task(t) for t in tasks)
    if args.dry_run:
        print(f"{len(tasks)} probe task(s), {n_calls} LLM call(s) "
              f"({', '.join(names)}; probes {', '.join(probes)}; {args.reps} rep(s))")
        return 0

    provider = make_provider(args.provider)
    if provider is None or not provider.is_available():
        print("No LLM provider available (set MISTRAL_API_KEY, or --provider stub for a dry test)",
              file=sys.stderr)
        return 1
    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    run_dir = Path(args.out_root) / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    manifest = build_manifest(run_id, args.kind, provider, scenarios, probes, args.reps, args.items)
    manifest["expression_options"] = {
        "campaign_brief": args.campaign_brief,
        "verbal_acceptance_labels": args.verbal_labels,
        "attacker_avoid_confrontation": not args.no_confrontation_guard,
        "opposing_seeds": args.opposing_seeds,
        "campaign_only": args.campaign_only,
        "note": "generation side only; the blind rater always uses the numeric scale",
    }
    if args.label:
        manifest["label"] = args.label
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    calls = CallLog(run_dir / "calls.jsonl", run_id, manifest["model"])
    service = make_service(provider, args.verbal_labels) if "expression" in probes else None
    if service is not None and args.no_confrontation_guard:
        service.config.attacker_avoid_confrontation = False
    log.info("Run %s: %d task(s), %d call(s) -> %s", run_id, len(tasks), n_calls, run_dir)
    with ThreadPoolExecutor(max_workers=max(1, args.max_workers)) as pool:
        for future in [pool.submit(run_task, provider, t, calls, service) for t in tasks]:
            future.result()

    tables = analyze(calls.records, args.reps)
    for name, rows in tables.items():
        _write_csv(run_dir / "summary" / f"{name}.csv", rows)
    write_coding_sheet(run_dir / "coding_sheet.csv", calls.records)
    write_report(run_dir / "report.md", manifest, tables)
    print(f"Wrote {run_dir}")
    for name, rows in tables.items():
        print(f"  {name}: {sum(1 for r in rows if r.get('pass'))}/{len(rows)} pass")
    return 0


def cmd_chat(args: argparse.Namespace) -> int:
    """Interactive follow-up conversation, logged turn by turn."""
    sc = load_scenarios([args.scenario], args.items)[0]
    axes = [a for a in sc.config.axes if not args.statement or a.id == args.statement]
    if not axes:
        print(f"Unknown statement {args.statement}", file=sys.stderr)
        return 1
    provider = make_provider(args.provider)
    if provider is None or not provider.is_available():
        print("No LLM provider available", file=sys.stderr)
        return 1
    system = TEMPLATES["chat_system"].format(
        subreddit=sc.subreddit, scale=ACCEPTANCE_SCALE, statement_lines=statement_lines(axes))
    messages = [{"role": "system", "content": system}]
    out_dir = Path(args.out_root) / "conversations"
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{datetime.now().strftime('%Y%m%d_%H%M%S')}_{sc.name}_{args.statement or 'all'}.jsonl"
    commit, dirty = _git_state()
    header = {"type": "header", "scenario": sc.name, "statements": [a.id for a in axes],
              "model": getattr(provider, "model", None), "temperature": args.temperature,
              "git_commit": commit, "git_dirty": dirty, "system": system,
              "template_sha": _sha(TEMPLATES["chat_system"])}
    with open(path, "a", encoding="utf-8") as f:
        f.write(json.dumps(header, ensure_ascii=False) + "\n")
    print(f"Logging to {path}\nSystem prompt:\n{system}\n(empty line or Ctrl+C to end)\n")
    turn = 0
    try:
        while True:
            user = input("you> ").strip()
            if not user:
                break
            turn += 1
            messages.append({"role": "user", "content": user})
            resp = provider.chat_completion_meta(messages, temperature=args.temperature, max_tokens=600)
            reply = (resp.content if resp else "") or "(no response)"
            messages.append({"role": "assistant", "content": reply})
            print(f"model> {reply}\n")
            with open(path, "a", encoding="utf-8") as f:
                f.write(json.dumps({"type": "turn", "turn": turn, "user": user, "assistant": reply,
                                    "time": datetime.now(timezone.utc).isoformat()}, ensure_ascii=False) + "\n")
    except (KeyboardInterrupt, EOFError):
        pass
    print(f"Saved {turn} turn(s) to {path}")
    return 0


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Semantic check of the belief statements")
    sub = parser.add_subparsers(dest="command", required=True)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--items", type=Path, default=DEFAULT_ITEMS, help="Scenario items JSON")
    common.add_argument("--out-root", type=Path, default=DEFAULT_OUT_ROOT)
    common.add_argument("--provider", default="auto",
                        help="auto | mistral | openai | local | stub (offline test)")

    run = sub.add_parser("run", parents=[common], help="Run the probes and write artifacts")
    run.add_argument("--scenario", choices=[*SCENARIOS, "all"], default="all")
    run.add_argument("--probes", nargs="+", choices=PROBES, help="Subset of probes (default: all)")
    run.add_argument("--reps", type=int, default=5)
    run.add_argument("--kind", choices=["development", "record"], default="development",
                     help="record = a run of record cited in the thesis; development = discardable")
    run.add_argument("--max-workers", type=int, default=4)
    run.add_argument("--dry-run", action="store_true", help="Print the number of calls and exit")
    run.add_argument("--campaign-brief", action="store_true",
                     help="expression: give the attacker profile its campaign narrative (as LLM attackers get)")
    run.add_argument("--verbal-labels", action="store_true",
                     help="expression: show Likert-style labels next to values in the generation prompts")
    run.add_argument("--label", default="", help="Free-text label stored in the manifest")
    run.add_argument("--opposing-seeds", action="store_true",
                     help="expression: attackers also reply to posts that argue against the campaign")
    run.add_argument("--campaign-only", action="store_true",
                     help="expression: only the campaign (attacker) condition")
    run.add_argument("--no-confrontation-guard", action="store_true",
                     help="expression: drop 'Avoids being confrontational...' from the attackers' reply prompt")

    chat = sub.add_parser("chat", parents=[common], help="Interactive follow-up conversation (logged)")
    chat.add_argument("--scenario", choices=SCENARIOS, required=True)
    chat.add_argument("--statement", help="Statement id to discuss (default: all statements)")
    chat.add_argument("--temperature", type=float, default=PROBE_TEMPERATURE)

    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    return cmd_run(args) if args.command == "run" else cmd_chat(args)


if __name__ == "__main__":
    sys.exit(main())
