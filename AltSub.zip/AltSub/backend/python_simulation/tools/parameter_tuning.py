#!/usr/bin/env python3
"""
Parameter tuning for mitigation settings.

This tool:
1) Clones a base simulation config into scenario-specific tuning folders.
2) Samples mitigation parameters.
3) Runs simulations repeatedly.
4) Scores each run by the account-level Matthews correlation coefficient
   (tools/account_mcc.py): attacker accounts are positives, all other user
   accounts negatives.
5) Reports best settings per mitigation and for all-mitigations jointly.

Stages (matching auto_runner's mitigation scenarios): stage 1 tunes each
mitigation alone (duplicate, rate limit, rule moderation; coordination only
with --stages); an account counts as predicted positive if that mechanism
flagged it. Stage 2 tunes duplicate + rate limit + rule moderation together
(auto_runner's all_mitigations_except_coordination), sampling near the
stage-1 winners; an account counts as predicted positive if it was banned
(three strikes across mechanisms).

Calibration setups: --base-config-dir takes one or more setup folders (one per
attacker type, e.g. .../llm_attackers .../template_attackers). Every
evaluation runs each setup with the same seed and scores the mean MCC.

Search methods (--method):
- halving (default): successive halving over fidelity rungs (short runs on one
  seed first, survivors get full-length runs on more seeds), then a statistical
  race among the finalists, then confirmation of the winner against the untuned
  baseline on held-out seeds. See tools/tuning_racing.py.
- hyperband: as halving, with several brackets that trust short runs less.
- random: the previous staged random search (one run per config).

Outputs (under <tuning-root>/results): tuning_results.json (auto_runner reads
stages.<stage>[0] and that trial's config/simulation_config.json),
tuning_results.txt, and for halving/hyperband tuning_evaluations.csv (every run).
"""

from __future__ import annotations

import argparse
import csv
import hashlib
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import math
import logging
import os
import random
import signal
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from pathlib import Path
import threading
from typing import Any, Callable, Dict, List, Optional, Tuple

try:
    from . import tuning_racing as racing
except ImportError:  # run as a script
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import tuning_racing as racing  # type: ignore[no-redef]

log = logging.getLogger(__name__)


try:
    from .account_mcc import ATTACKER_AGENT_TYPES, account_confusion
    from ..core.config_paths import resolve_config_paths
    from ..core.rule_moderator_schedule import (
        RULE_MODERATOR_MITIGATION_DEFAULTS,
        inject_rule_moderator_agents,
    )
except ImportError:  # run as a script
    from account_mcc import ATTACKER_AGENT_TYPES, account_confusion  # type: ignore[no-redef]
    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "core"))
    from config_paths import resolve_config_paths  # type: ignore[no-redef]
    from rule_moderator_schedule import (  # type: ignore[no-redef]
        RULE_MODERATOR_MITIGATION_DEFAULTS,
        inject_rule_moderator_agents,
    )

# Fixed mitigation policy (not searched)
MITIGATION_BAN_THRESHOLD = 3  # three-strikes system

# Rate-limit search ranges. Agents peak at ~1-5 posts/replies per window and
# rate_limit_check flags only when count > threshold, so thresholds stay small.
RATE_LIMIT_WINDOW_RANGE = (6, 288)  # timesteps (30 min to 24 h at 5-min steps)
RATE_LIMIT_THRESHOLD_RANGE = (1, 8)

# Coordination (co-action network) search ranges; ints are inclusive.
# Attacker-side coordination settings (coordination_strength etc.) are never
# tuned here: tuning optimises the defender against the base config's attackers.
COORDINATION_INT_RANGES = {
    "coordination_lookback_window": (24, 288),  # 2-24 h at 5-min steps
    "coordination_sync_window": (1, 12),  # 5-60 min
    "coordination_min_shared_targets": (1, 5),
    "coordination_min_content_matches": (1, 4),
    "coordination_min_amplifications": (1, 6),
}
COORDINATION_FLOAT_RANGES = {
    "coordination_similarity_threshold": (0.05, 0.8),
    "coordination_content_similarity_threshold": (0.5, 0.95),
}
# Significance level, sampled log-uniformly (spans orders of magnitude)
COORDINATION_SIGNIFICANCE_RANGE = (0.0005, 0.1)

# Rule moderators' LLM confidence needed to remove an item and flag its author
RULE_MODERATOR_THRESHOLD_RANGE = (0.30, 0.95)

# Flag sources that count as "flagged" in each single-mechanism scenario
SCENARIO_SOURCES = {
    "duplicate_only": ("duplicate",),
    "rate_limit_only": ("rate_limit",),
    "coordination_only": ("coordination",),
    "rule_moderation_only": ("rule_moderator",),
}
# Attacker profile user_type values (agent_profiles.json)
ATTACKER_PROFILE_TYPES = {"attacker", "llm_attacker", "template_attacker"}

# Optional per-setup inputs run_simulation reads from its --config-dir, besides
# simulation_config.json / agent_profiles.json: initial belief clusters, and the
# real subreddit discussion the orchestrator uses for its day-0 plan (same name as
# services.subreddit_seed_context.SEED_CONTEXT_FILENAME).
SETUP_INPUT_FILES = ("belief_clustering_metadata.json", "subreddit_seed_context.json")


def copy_setup_inputs(
    src_dir: Path, dst_dir: Path, fallback_dir: Optional[Path] = None
) -> Dict[str, bool]:
    """
    Copy SETUP_INPUT_FILES from src_dir (else fallback_dir) into dst_dir.
    A stale copy in dst_dir is removed when neither source has the file.
    Returns {filename: copied}.
    """
    copied: Dict[str, bool] = {}
    for name in SETUP_INPUT_FILES:
        src = Path(src_dir) / name
        if not src.is_file() and fallback_dir is not None:
            src = Path(fallback_dir) / name
        dst = Path(dst_dir) / name
        if src.is_file():
            if src.resolve() != dst.resolve():
                shutil.copy2(src, dst)
            copied[name] = True
        else:
            if dst.is_file():
                dst.unlink()
            copied[name] = False
    return copied


@dataclass
class TrialResult:
    stage: str
    scenario: str
    trial_id: int
    params: Dict[str, Any]
    objective_value: float  # mean account-level MCC over the setups
    tp: int  # confusion counts summed over the setups
    fp: int
    fn: int
    tn: int
    mcc_by_setup: Dict[str, float]
    attacker_detect_hours: Optional[float]
    run_seconds: float
    final_output_path: str
    error: Optional[str] = None


class TuningProgress:
    """Thread-safe global progress and running best objective for terminal updates."""

    def __init__(self, total_trials: int) -> None:
        self._lock = threading.Lock()
        self._total = max(1, total_trials)
        self._completed = 0
        self._best_objective = float("-inf")
        self._best_label = ""

    def record(
        self,
        stage_name: str,
        scenario: str,
        trial_id: int,
        result: TrialResult,
    ) -> None:
        with self._lock:
            self._completed += 1
            done = self._completed
            total = self._total
            improved = False
            if result.error is None and result.objective_value > self._best_objective:
                self._best_objective = result.objective_value
                self._best_label = f"{stage_name}/{scenario}/trial_{trial_id:04d}"
                improved = True
            best_obj = self._best_objective
            best_label = self._best_label

        if result.error:
            log.warning(
                "[%d/%d] FAIL %s %s trial_%04d — %.1fs — %s",
                done,
                total,
                stage_name,
                scenario,
                trial_id,
                result.run_seconds,
                result.error[:200] + ("…" if len(result.error) > 200 else ""),
            )
        else:
            log.info(
                "[%d/%d] done %s %s trial_%04d — %.1fs — MCC=%.4f — tp=%d fp=%d fn=%d tn=%d",
                done,
                total,
                stage_name,
                scenario,
                trial_id,
                result.run_seconds,
                result.objective_value,
                result.tp,
                result.fp,
                result.fn,
                result.tn,
            )
        if improved:
            log.info(
                "*** New best objective %.4f @ %s ***\n    params=%s",
                best_obj,
                best_label,
                json.dumps(result.params, sort_keys=True),
            )


def _load_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def _ensure_base_files(base_config_dir: Path) -> Tuple[Path, Path]:
    sim_config = base_config_dir / "simulation_config.json"
    profiles = base_config_dir / "agent_profiles.json"
    if not sim_config.exists() or not profiles.exists():
        raise FileNotFoundError(
            f"Base config directory missing required files: {sim_config}, {profiles}"
        )
    return sim_config, profiles


def _prepare_scenario_setup(
    base_config_dir: Path,
    scenario_dir: Path,
    mitigation_defaults: Dict[str, Any],
    trial_duration_days: Optional[int] = None,
    add_rule_moderators: bool = False,
) -> Path:
    """Copy a base setup into scenario_dir with the scenario's mitigation
    defaults. add_rule_moderators: append rule moderator agents (as auto_runner
    does for its rule moderator scenarios) unless the base already has some."""
    sim_config_path, profiles_path = _ensure_base_files(base_config_dir)
    scenario_dir.mkdir(parents=True, exist_ok=True)

    scenario_sim_config = scenario_dir / "simulation_config.json"
    scenario_profiles = scenario_dir / "agent_profiles.json"

    sim_data = resolve_config_paths(_load_json(sim_config_path), Path(sim_config_path).parent)
    sim_data.setdefault("mitigation_config", {})
    sim_data["mitigation_config"].update(mitigation_defaults)
    if trial_duration_days is not None:
        _shorten_simulation(sim_data, trial_duration_days)
    # Always refresh profiles from the base: a stale copy from an earlier
    # population would otherwise be reused silently after a re-init
    profiles = _load_json(profiles_path)
    if add_rule_moderators and not any(
        p.get("user_type") == "rule_moderator" for p in profiles
    ):
        sim_data, profiles = inject_rule_moderator_agents(sim_data, profiles)
    _save_json(scenario_sim_config, sim_data)
    _save_json(scenario_profiles, profiles)
    copied = copy_setup_inputs(base_config_dir, scenario_dir)
    missing = [name for name, ok in copied.items() if not ok]
    if missing:
        log.warning("Base config dir %s has no %s", base_config_dir, ", ".join(missing))
    return scenario_dir


def _shorten_simulation(sim_data: Dict[str, Any], days: int, *, verbose: bool = True) -> None:
    """
    Run trials for the first `days` days only (faster tuning). Activity schedules
    are cut to match. Only mitigation_config is taken from tuning trials by
    auto_runner, so batch runs keep the universe's full duration.
    """
    sim = sim_data.setdefault("simulation_config", {})
    full_days = int(sim.get("duration_days", days))
    if days >= full_days:
        return
    interval = int(sim.get("interval_minutes", 5))
    steps = (24 * 60 // interval) * days
    sim["duration_days"] = days
    sim_data["agent_activity_schedules"] = {
        k: list(v)[:steps] for k, v in (sim_data.get("agent_activity_schedules") or {}).items()
    }
    (log.info if verbose else log.debug)(
        "Tuning trials shortened to %d of %d simulated days", days, full_days
    )


def _candidate_output_dir(root: Path, stage: str, scenario: str, trial_id: int) -> Path:
    return root / "runs" / stage / scenario / f"trial_{trial_id:04d}"


def _build_candidate_config(
    scenario_config_path: Path, candidate_params: Dict[str, Any], scenario_flags: Dict[str, bool]
) -> Dict[str, Any]:
    cfg = _load_json(scenario_config_path)
    mitigation = cfg.setdefault("mitigation_config", {})
    mitigation["enable_duplicate_detection"] = scenario_flags.get("duplicate", False)
    mitigation["enable_rate_limiting"] = scenario_flags.get("rate", False)
    mitigation["enable_coordinated_detection"] = scenario_flags.get("coordination", False)
    mitigation["enable_rule_moderators"] = scenario_flags.get("rule", False)
    mitigation.update(candidate_params)
    mitigation["mitigation_ban_threshold"] = MITIGATION_BAN_THRESHOLD
    return cfg


def _terminate_simulation_process_tree(proc: subprocess.Popen) -> None:
    """
    Hard-stop run_simulation and any child processes.

    subprocess.run(timeout=...) only kills the immediate child; the simulation may
    spawn worker processes (multiprocessing, etc.) that keep running and never
    release the slot. On POSIX we start the child in its own session and SIGKILL
    the whole process group.
    """
    if proc.poll() is not None:
        return
    pid = proc.pid
    if os.name == "nt":
        proc.kill()
    else:
        try:
            pgid = os.getpgid(pid)
            os.killpg(pgid, signal.SIGKILL)
        except (ProcessLookupError, PermissionError, OSError) as e:
            log.debug("killpg failed (%s); using proc.kill()", e)
            try:
                proc.kill()
            except ProcessLookupError:
                pass
    try:
        proc.wait(timeout=120)
    except subprocess.TimeoutExpired:
        log.warning("Child pid=%s still alive 120s after kill; may be stuck in uninterruptible wait", pid)


def _run_simulation(
    repo_root: Path,
    config_dir: Path,
    output_dir: Path,
    timeout_sec: int,
    *,
    stream_output: bool = False,
    seed: Optional[int] = None,
) -> Tuple[bool, str]:
    """Run one simulation in a subprocess. seed: run seed (overrides SIM_SEED and
    the config's runtime_config.seed)."""
    cmd = [
        sys.executable,
        "-m",
        "backend.python_simulation.run_simulation",
        "--config-dir",
        str(config_dir),
        "--output-dir",
        str(output_dir),
    ]
    # New session => new process group on POSIX so we can kill workers too.
    popen_kw: Dict[str, Any] = {}
    if os.name != "nt":
        popen_kw["start_new_session"] = True
    if seed is not None:
        cmd += ["--seed", str(seed)]
        # SIM_SEED would otherwise win over --seed and give every run one seed
        popen_kw["env"] = {k: v for k, v in os.environ.items() if k != "SIM_SEED"}

    if stream_output:
        proc = subprocess.Popen(
            cmd,
            cwd=str(repo_root),
            stdout=None,
            stderr=None,
            **popen_kw,
        )
        try:
            proc.wait(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            log.warning(
                "Simulation timed out after %ds; terminating process tree (pid=%s)",
                timeout_sec,
                proc.pid,
            )
            _terminate_simulation_process_tree(proc)
            return False, f"timeout after {timeout_sec}s (process tree terminated)"
    else:
        proc = subprocess.Popen(
            cmd,
            cwd=str(repo_root),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            **popen_kw,
        )
        try:
            out, err = proc.communicate(timeout=timeout_sec)
        except subprocess.TimeoutExpired:
            log.warning(
                "Simulation timed out after %ds; terminating process tree (pid=%s)",
                timeout_sec,
                proc.pid,
            )
            _terminate_simulation_process_tree(proc)
            # Drain / close pipes so communicate does not deadlock on join
            try:
                proc.communicate(timeout=30)
            except (subprocess.TimeoutExpired, ValueError):
                pass
            return False, f"timeout after {timeout_sec}s (process tree terminated)"

        if proc.returncode != 0:
            combined = ((err or "") + (out or "")).strip()
            return False, f"run_simulation failed ({proc.returncode}): {combined[-1000:]}"

    # stream_output path: no captured stderr; only failure left to handle here
    if proc.returncode != 0:
        return False, f"run_simulation failed (exit {proc.returncode})"
    return True, ""


def _stage_decision(stage_name: str) -> str:
    """Stage 1 (one mechanism): flagged by it; stage 2 (all together): banned."""
    return "banned" if stage_name.startswith("stage_2") else "flagged"


def _score_outputs(
    outputs: Dict[str, Dict[str, Any]], scenario: str, decision: str
) -> Tuple[float, Dict[str, Any]]:
    """Mean account-level MCC over the setups' final_output.json, plus details
    (confusion counts summed over setups, MCC per setup, mean hours to detect
    a caught attacker)."""
    sources = SCENARIO_SOURCES.get(scenario) if decision == "flagged" else None
    per = {label: account_confusion(out, decision, sources) for label, out in outputs.items()}
    objective = sum(c["mcc"] for c in per.values()) / len(per)
    hours = [c["attacker_detect_hours"] for c in per.values() if c["attacker_detect_hours"] is not None]
    details: Dict[str, Any] = {k: sum(c[k] for c in per.values()) for k in ("tp", "fp", "fn", "tn")}
    details["mcc_by_setup"] = {label: round(c["mcc"], 6) for label, c in per.items()}
    details["attacker_detect_hours"] = sum(hours) / len(hours) if hours else None
    details["decision"] = decision
    return objective, details


def _sample_bool(rng: random.Random) -> bool:
    return bool(rng.randint(0, 1))


def _sample_int(rng: random.Random, low: int, high: int) -> int:
    return int(rng.randint(low, high))


def _sample_float(rng: random.Random, low: float, high: float, precision: int = 3) -> float:
    return round(rng.uniform(low, high), precision)


def _sample_params_for_scenario(rng: random.Random, scenario: str) -> Dict[str, Any]:
    if scenario == "rule_moderation_only":
        # Rule moderators read the feed; scan frequency does not apply to them
        return {
            "rule_moderator_detection_threshold": _sample_float(rng, *RULE_MODERATOR_THRESHOLD_RANGE),
        }
    common = {
        "mitigation_scan_frequency": _sample_int(rng, 5, 60),
    }
    if scenario == "duplicate_only":
        return {
            **common,
            "duplicate_similarity_threshold": _sample_float(rng, 0.50, 0.98),
            "duplicate_lookback_window": _sample_int(rng, 30, 300),
            "use_embedding_similarity_for_duplicates": _sample_bool(rng),
        }
    if scenario == "rate_limit_only":
        return {
            **common,
            "rate_limit_window": _sample_int(rng, *RATE_LIMIT_WINDOW_RANGE),
            "rate_limit_threshold": _sample_int(rng, *RATE_LIMIT_THRESHOLD_RANGE),
        }
    if scenario == "coordination_only":
        return {**common, **_sample_coordination_params(rng)}
    if scenario == "all_mitigations_except_coordination":
        return {
            **common,
            "duplicate_similarity_threshold": _sample_float(rng, 0.50, 0.98),
            "duplicate_lookback_window": _sample_int(rng, 30, 300),
            "use_embedding_similarity_for_duplicates": _sample_bool(rng),
            "rate_limit_window": _sample_int(rng, *RATE_LIMIT_WINDOW_RANGE),
            "rate_limit_threshold": _sample_int(rng, *RATE_LIMIT_THRESHOLD_RANGE),
            "rule_moderator_detection_threshold": _sample_float(rng, *RULE_MODERATOR_THRESHOLD_RANGE),
        }
    raise ValueError(f"Unknown scenario: {scenario}")


def _sample_coordination_params(rng: random.Random) -> Dict[str, Any]:
    params: Dict[str, Any] = {
        k: _sample_int(rng, lo, hi) for k, (lo, hi) in COORDINATION_INT_RANGES.items()
    }
    params.update(
        {k: _sample_float(rng, lo, hi) for k, (lo, hi) in COORDINATION_FLOAT_RANGES.items()}
    )
    params["coordination_significance"] = _sample_log_float(
        rng, *COORDINATION_SIGNIFICANCE_RANGE
    )
    params["use_embedding_similarity_for_coordination"] = _sample_bool(rng)
    return params


def _sample_log_float(rng: random.Random, low: float, high: float) -> float:
    return float(f"{math.exp(rng.uniform(math.log(low), math.log(high))):.3g}")


def _clamp_int(value: int, low: int, high: int) -> int:
    return max(low, min(high, int(value)))


def _clamp_float(value: float, low: float, high: float) -> float:
    return max(low, min(high, float(value)))


def _sample_joint_from_stage1(
    rng: random.Random,
    best_duplicate: Optional[Dict[str, Any]],
    best_rate: Optional[Dict[str, Any]],
    best_rule: Optional[Dict[str, Any]] = None,
    scenario: str = "all_mitigations_except_coordination",
) -> Dict[str, Any]:
    """
    Stage-2 sampler (duplicate + rate limit + rule moderators) seeded by the
    stage-1 best regions (each the best params of that stage, or None). Falls
    back to global random ranges where a stage-1 best is unavailable.
    """
    base = _sample_params_for_scenario(rng, scenario)

    if best_duplicate:
        d = best_duplicate
        base["duplicate_similarity_threshold"] = _clamp_float(
            _sample_float(
                rng,
                _clamp_float(float(d.get("duplicate_similarity_threshold", 0.85)) - 0.08, 0.50, 0.98),
                _clamp_float(float(d.get("duplicate_similarity_threshold", 0.85)) + 0.08, 0.50, 0.98),
            ),
            0.50,
            0.98,
        )
        base["duplicate_lookback_window"] = _sample_int(
            rng,
            _clamp_int(int(d.get("duplicate_lookback_window", 100)) - 40, 30, 300),
            _clamp_int(int(d.get("duplicate_lookback_window", 100)) + 40, 30, 300),
        )
        base["use_embedding_similarity_for_duplicates"] = bool(
            d.get("use_embedding_similarity_for_duplicates", False)
        )

    if best_rate:
        r = best_rate
        base["rate_limit_window"] = _sample_int(
            rng,
            _clamp_int(int(r.get("rate_limit_window", 24)) - 30, *RATE_LIMIT_WINDOW_RANGE),
            _clamp_int(int(r.get("rate_limit_window", 24)) + 30, *RATE_LIMIT_WINDOW_RANGE),
        )
        base["rate_limit_threshold"] = _sample_int(
            rng,
            _clamp_int(int(r.get("rate_limit_threshold", 3)) - 2, *RATE_LIMIT_THRESHOLD_RANGE),
            _clamp_int(int(r.get("rate_limit_threshold", 3)) + 2, *RATE_LIMIT_THRESHOLD_RANGE),
        )

    if best_rule and "rule_moderator_detection_threshold" in base:
        c = float(best_rule.get("rule_moderator_detection_threshold", 0.7))
        base["rule_moderator_detection_threshold"] = _sample_float(
            rng,
            _clamp_float(c - 0.1, *RULE_MODERATOR_THRESHOLD_RANGE),
            _clamp_float(c + 0.1, *RULE_MODERATOR_THRESHOLD_RANGE),
        )

    return base


def _scenario_flags(scenario: str) -> Dict[str, bool]:
    if scenario == "duplicate_only":
        return {"duplicate": True, "rate": False, "coordination": False, "rule": False}
    if scenario == "rate_limit_only":
        return {"duplicate": False, "rate": True, "coordination": False, "rule": False}
    if scenario == "coordination_only":
        return {"duplicate": False, "rate": False, "coordination": True, "rule": False}
    if scenario == "rule_moderation_only":
        return {"duplicate": False, "rate": False, "coordination": False, "rule": True}
    if scenario == "all_mitigations_except_coordination":
        return {"duplicate": True, "rate": True, "coordination": False, "rule": True}
    raise ValueError(f"Unknown scenario: {scenario}")


def _run_trial_with_retries(
    repo_root: Path,
    setups: Dict[str, Path],
    tuning_output_root: Path,
    stage: str,
    scenario: str,
    trial_id: int,
    params: Dict[str, Any],
    timeout_sec: int,
    max_retries: int,
    *,
    stream_simulation_output: bool = False,
) -> TrialResult:
    """Run one logical trial, retrying the simulation subprocess on failure."""
    trial: Optional[TrialResult] = None
    for _attempt in range(max_retries + 1):
        trial = _run_trial(
            repo_root=repo_root,
            setups=setups,
            tuning_output_root=tuning_output_root,
            stage=stage,
            scenario=scenario,
            trial_id=trial_id,
            params=params,
            timeout_sec=timeout_sec,
            stream_simulation_output=stream_simulation_output,
        )
        if trial.error is None:
            break
    assert trial is not None
    return trial


def _run_trial(
    repo_root: Path,
    setups: Dict[str, Path],
    tuning_output_root: Path,
    stage: str,
    scenario: str,
    trial_id: int,
    params: Dict[str, Any],
    timeout_sec: int,
    *,
    stream_simulation_output: bool = False,
) -> TrialResult:
    """Run the trial once per setup (attacker type) and score the mean MCC."""
    stage_trial_dir = _candidate_output_dir(tuning_output_root, stage, scenario, trial_id)
    first_label = next(iter(setups))
    # Canonical full config (what auto_runner reads), from the first setup
    _save_json(
        stage_trial_dir / "config" / "simulation_config.json",
        _build_candidate_config(
            setups[first_label] / "simulation_config.json",
            candidate_params=params,
            scenario_flags=_scenario_flags(scenario),
        ),
    )
    log.debug(
        "Starting simulation: %s %s trial_%04d params=%s",
        stage,
        scenario,
        trial_id,
        json.dumps(params, sort_keys=True),
    )
    outputs: Dict[str, Dict[str, Any]] = {}
    elapsed = 0.0
    error: Optional[str] = None
    final_output_path = ""
    for label, setup_dir in setups.items():
        run_dir = stage_trial_dir / "setups" / label
        trial_config_dir = run_dir / "config"
        trial_output_dir = run_dir / "simulation_output"
        trial_config_dir.mkdir(parents=True, exist_ok=True)
        _save_json(
            trial_config_dir / "simulation_config.json",
            _build_candidate_config(
                setup_dir / "simulation_config.json",
                candidate_params=params,
                scenario_flags=_scenario_flags(scenario),
            ),
        )
        shutil.copy2(setup_dir / "agent_profiles.json", trial_config_dir / "agent_profiles.json")
        copy_setup_inputs(setup_dir, trial_config_dir)
        t0 = time.perf_counter()
        ok, err = _run_simulation(
            repo_root=repo_root,
            config_dir=trial_config_dir,
            output_dir=trial_output_dir,
            timeout_sec=timeout_sec,
            stream_output=stream_simulation_output,
        )
        elapsed += time.perf_counter() - t0
        path = trial_output_dir / "final_output.json"
        final_output_path = final_output_path or str(path)
        if not ok or not path.exists():
            error = f"{label}: {err or 'missing final_output.json'}"
            break
        outputs[label] = _load_json(path)

    if error is not None:
        return TrialResult(
            stage=stage,
            scenario=scenario,
            trial_id=trial_id,
            params=params,
            objective_value=float("-inf"),
            tp=0,
            fp=0,
            fn=0,
            tn=0,
            mcc_by_setup={},
            attacker_detect_hours=None,
            run_seconds=elapsed,
            final_output_path=final_output_path,
            error=error,
        )

    objective_value, d = _score_outputs(outputs, scenario, _stage_decision(stage))
    return TrialResult(
        stage=stage,
        scenario=scenario,
        trial_id=trial_id,
        params=params,
        objective_value=objective_value,
        tp=d["tp"],
        fp=d["fp"],
        fn=d["fn"],
        tn=d["tn"],
        mcc_by_setup=d["mcc_by_setup"],
        attacker_detect_hours=d["attacker_detect_hours"],
        run_seconds=elapsed,
        final_output_path=final_output_path,
    )


def _run_trial_jobs(
    *,
    repo_root: Path,
    tuning_root: Path,
    jobs: List[Tuple[str, str, Dict[str, Path], int, Dict[str, Any]]],
    timeout_sec: int,
    max_retries: int,
    max_workers: int,
    progress: Optional[TuningProgress] = None,
    stream_simulation_output: bool = False,
) -> Dict[str, List[TrialResult]]:
    """
    Run trial jobs (stage_name, scenario, setups, trial_id, params), up to
    max_workers at once across all of them (each trial is its own subprocess with
    its own output paths). Returns stage_name -> results sorted by trial_id.
    """

    def run(job: Tuple[str, str, Dict[str, Path], int, Dict[str, Any]]) -> TrialResult:
        stage_name, scenario, setups, trial_id, params = job
        return _run_trial_with_retries(
            repo_root,
            setups,
            tuning_root,
            stage_name,
            scenario,
            trial_id,
            params,
            timeout_sec,
            max_retries,
            stream_simulation_output=stream_simulation_output,
        )

    results: Dict[str, List[TrialResult]] = {job[0]: [] for job in jobs}
    if max_workers <= 1:
        for job in jobs:
            res = run(job)
            if progress is not None:
                progress.record(job[0], job[1], job[3], res)
            results[job[0]].append(res)
    else:
        with ThreadPoolExecutor(max_workers=max_workers) as pool:
            future_to_job = {pool.submit(run, job): job for job in jobs}
            for fut in as_completed(future_to_job):
                job = future_to_job[fut]
                res = fut.result()
                if progress is not None:
                    progress.record(job[0], job[1], job[3], res)
                results[job[0]].append(res)
    for stage_results in results.values():
        stage_results.sort(key=lambda r: r.trial_id)
    return results


def _run_stage_trials(
    *,
    repo_root: Path,
    setups: Dict[str, Path],
    tuning_root: Path,
    stage_name: str,
    scenario: str,
    param_specs: List[Tuple[int, Dict[str, Any]]],
    timeout_sec: int,
    max_retries: int,
    max_workers: int,
    progress: Optional[TuningProgress] = None,
    stream_simulation_output: bool = False,
) -> List[TrialResult]:
    """Run all trials for one stage/scenario (see _run_trial_jobs)."""
    log.info(
        "--- %s (%s): %d trial(s), max_workers=%d ---",
        stage_name,
        scenario,
        len(param_specs),
        max_workers,
    )
    jobs = [(stage_name, scenario, setups, tid, params) for tid, params in param_specs]
    return _run_trial_jobs(
        repo_root=repo_root,
        tuning_root=tuning_root,
        jobs=jobs,
        timeout_sec=timeout_sec,
        max_retries=max_retries,
        max_workers=max_workers,
        progress=progress,
        stream_simulation_output=stream_simulation_output,
    ).get(stage_name, [])


def _top_k(results: List[TrialResult], k: int = 5) -> List[TrialResult]:
    valid = [r for r in results if r.error is None]
    return sorted(valid, key=lambda x: x.objective_value, reverse=True)[:k]


def _write_report(
    output_root: Path,
    setup_labels: List[str],
    seed: int,
    budget_total: int,
    max_workers: int,
    stage_results: Dict[str, List[TrialResult]],
    trial_duration_days: Optional[int] = None,
    parallel_stage1: bool = False,
) -> None:
    output_root.mkdir(parents=True, exist_ok=True)
    summary_json = {
        "seed": seed,
        "budget_total": budget_total,
        "max_workers": max_workers,
        "trial_duration_days": trial_duration_days,
        "parallel_stage1": parallel_stage1,
        "objective": OBJECTIVE_DESCRIPTION,
        "calibration_setups": setup_labels,
        "stages": {},
    }

    text_lines: List[str] = []
    text_lines.append("Mitigation Parameter Tuning Report")
    text_lines.append("=" * 40)
    text_lines.append(f"seed: {seed}")
    text_lines.append(f"budget_total: {budget_total}")
    text_lines.append(f"max_workers: {max_workers}")
    text_lines.append(
        f"trial_duration_days: {trial_duration_days if trial_duration_days else 'base config'}"
    )
    text_lines.append(f"parallel_stage1: {parallel_stage1}")
    text_lines.append(f"objective: {OBJECTIVE_DESCRIPTION}")
    text_lines.append(f"calibration setups: {', '.join(setup_labels)}")
    text_lines.append("")

    for stage_name, results in stage_results.items():
        top = _top_k(results, 5)
        summary_json["stages"][stage_name] = [asdict(r) for r in top]
        text_lines.append(f"[{stage_name}]")
        if not top:
            text_lines.append("  no successful trials")
            text_lines.append("")
            continue
        best = top[0]
        text_lines.append(f"  best MCC: {best.objective_value:.4f} (per setup: {best.mcc_by_setup})")
        text_lines.append(f"  best params: {json.dumps(best.params)}")
        text_lines.append(f"  tp={best.tp}, fp={best.fp}, fn={best.fn}, tn={best.tn}")
        text_lines.append("")

    _save_json(output_root / "tuning_results.json", summary_json)
    with open(output_root / "tuning_results.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(text_lines) + "\n")


def _validate_positive(name: str, value: int) -> None:
    if value <= 0:
        raise ValueError(f"{name} must be > 0, got {value}")


def _allocate_stage_budget(total_trials: int, scenarios: List[str]) -> Dict[str, int]:
    # Even split over the selected stages; a remainder goes one trial each to
    # stage 2 first (largest search space), then the stage-1 scenarios.
    order = sorted(scenarios, key=lambda sc: sc != "all_mitigations_except_coordination")
    base, remainder = divmod(total_trials, len(order))
    return {s: max(1, base + (1 if i < remainder else 0)) for i, s in enumerate(order)}


def _run_random_search(
    args: argparse.Namespace,
    *,
    repo_root: Path,
    base_config_dir: Path,
    tuning_root: Path,
    report_root: Path,
    scenario_dirs: Dict[str, Dict[str, Path]],
    stages: Dict[str, str],
) -> None:
    """The previous staged random search: one run (per setup) per sampled config."""
    budget = _allocate_stage_budget(args.trials, list(stages.values()))
    total_runs = sum(budget.values())
    progress = TuningProgress(total_runs)
    rng = random.Random(args.seed)
    stage_results: Dict[str, List[TrialResult]] = {s: [] for s in stages}

    log.info(
        "Starting search: %d simulation runs (trials arg=%d), budget=%s, max_workers=%d, seed=%s",
        total_runs,
        args.trials,
        budget,
        args.max_workers,
        args.seed,
    )
    log.info("Base config: %s | tuning root: %s", base_config_dir, tuning_root)

    # Stage 1
    stage_1_map = {s: sc for s, sc in stages.items() if s.startswith("stage_1_")}
    stage_1_jobs = {
        stage_name: [
            (stage_name, scenario, scenario_dirs[scenario], i, _sample_params_for_scenario(rng, scenario))
            for i in range(1, budget[scenario] + 1)
        ]
        for stage_name, scenario in stage_1_map.items()
    }
    run_kwargs = dict(
        repo_root=repo_root,
        tuning_root=tuning_root,
        timeout_sec=args.timeout_sec,
        max_retries=args.max_retries,
        max_workers=args.max_workers,
        progress=progress,
        stream_simulation_output=args.stream_simulation_output,
    )
    if args.sequential_stage1:
        for stage_name, jobs in stage_1_jobs.items():
            log.info("--- %s: %d trial(s), max_workers=%d ---", stage_name, len(jobs), args.max_workers)
            stage_results[stage_name].extend(
                _run_trial_jobs(jobs=jobs, **run_kwargs).get(stage_name, [])
            )
    else:
        all_jobs = [job for jobs in stage_1_jobs.values() for job in jobs]
        log.info(
            "--- stage 1 (all single-mitigation stages together): %d trial(s), max_workers=%d ---",
            len(all_jobs),
            args.max_workers,
        )
        for stage_name, results in _run_trial_jobs(jobs=all_jobs, **run_kwargs).items():
            stage_results[stage_name].extend(results)

    for stage_name in stage_1_map:
        top_stage = _top_k(stage_results[stage_name], 1)
        if top_stage:
            b = top_stage[0]
            log.info(
                "Stage summary %s: best MCC=%.4f (trial_%04d) tp=%d fp=%d fn=%d",
                stage_name,
                b.objective_value,
                b.trial_id,
                b.tp,
                b.fp,
                b.fn,
            )
        else:
            log.warning("Stage summary %s: no successful trials", stage_name)

    best_duplicate = _top_k(stage_results.get("stage_1_duplicate_only", []), 1)
    best_rate = _top_k(stage_results.get("stage_1_rate_limit_only", []), 1)
    best_rule = _top_k(stage_results.get("stage_1_rule_moderation_only", []), 1)

    # Stage 2 (joint): sampled near the stage-1 winners
    for stage2_name, stage2_scenario in stages.items():
        if not stage2_name.startswith("stage_2_"):
            continue
        stage2_specs = [
            (
                i,
                _sample_joint_from_stage1(
                    rng=rng,
                    best_duplicate=best_duplicate[0].params if best_duplicate else None,
                    best_rate=best_rate[0].params if best_rate else None,
                    best_rule=best_rule[0].params if best_rule else None,
                    scenario=stage2_scenario,
                ),
            )
            for i in range(1, budget[stage2_scenario] + 1)
        ]
        stage_results[stage2_name].extend(
            _run_stage_trials(
                repo_root=repo_root,
                setups=scenario_dirs[stage2_scenario],
                tuning_root=tuning_root,
                stage_name=stage2_name,
                scenario=stage2_scenario,
                param_specs=stage2_specs,
                timeout_sec=args.timeout_sec,
                max_retries=args.max_retries,
                max_workers=args.max_workers,
                progress=progress,
                stream_simulation_output=args.stream_simulation_output,
            )
        )
        top2 = _top_k(stage_results[stage2_name], 1)
        if top2:
            b2 = top2[0]
            log.info(
                "Stage summary %s: best MCC=%.4f (trial_%04d) tp=%d fp=%d fn=%d",
                stage2_name,
                b2.objective_value,
                b2.trial_id,
                b2.tp,
                b2.fp,
                b2.fn,
            )
        else:
            log.warning("Stage summary %s: no successful trials", stage2_name)

    _write_report(
        output_root=report_root,
        setup_labels=list(next(iter(scenario_dirs.values()))),
        seed=args.seed,
        budget_total=args.trials,
        max_workers=args.max_workers,
        stage_results=stage_results,
        trial_duration_days=args.trial_duration_days,
        parallel_stage1=not args.sequential_stage1,
    )
    log.info("Tuning complete. Results saved under: %s", report_root)


# Successive halving / Hyperband / racing (tools/tuning_racing.py schedules)
STAGE_SCENARIOS = {
    "stage_1_duplicate_only": "duplicate_only",
    "stage_1_rate_limit_only": "rate_limit_only",
    "stage_1_coordination_only": "coordination_only",
    "stage_1_rule_moderation_only": "rule_moderation_only",
    "stage_2_all_mitigations_except_coordination": "all_mitigations_except_coordination",
}
# Stages run by default: the scenarios of auto_runner's batch set
# (duplicate_only, rate_limit_only, rule_moderator,
# all_mitigations_except_coordination). Coordination only with --stages.
DEFAULT_STAGES = [s for s in STAGE_SCENARIOS if s != "stage_1_coordination_only"]
# Scenarios whose runs include rule moderator agents
RULE_MODERATOR_SCENARIOS = {"rule_moderation_only", "all_mitigations_except_coordination"}

OBJECTIVE_DESCRIPTION = (
    "account-level MCC (attacker accounts positive, all other user accounts negative), "
    "mean over calibration setups; predicted positive = flagged by the mechanism "
    "(stage 1) or banned (stage 2)"
)


def _file_digest(paths: List[Path]) -> str:
    h = hashlib.sha256()
    for path in paths:
        h.update(path.name.encode())
        if path.is_file():
            h.update(path.read_bytes())
    return h.hexdigest()


class EvalProgress:
    """Thread-safe run counter and log line per finished evaluation."""

    def __init__(self, planned_max: int) -> None:
        self._lock = threading.Lock()
        self._done = 0
        self._planned_max = planned_max

    def record(self, stage_name: str, result: "racing.EvalResult") -> None:
        with self._lock:
            self._done += 1
            done = self._done
        req = result.request
        where = (
            f"{stage_name} cfg_{req.config_id:04d} {racing.days_label(req.days)} "
            f"seed={req.seed} [{req.label}]"
        )
        secs = result.details.get("run_seconds", 0.0)
        if result.ok:
            log.info(
                "[%d run(s), <=%d planned] done %s - %.1fs%s - MCC=%.4f %s tp=%s fp=%s fn=%s",
                done, self._planned_max, where, secs,
                " (reused)" if result.details.get("reused") else "",
                result.objective, result.details.get("mcc_by_setup"),
                result.details.get("tp"), result.details.get("fp"), result.details.get("fn"),
            )
        else:
            err = str(result.details.get("error", ""))
            log.warning(
                "[%d run(s), <=%d planned] FAIL %s - %.1fs - %s",
                done, self._planned_max, where, secs, err[:200] + ("..." if len(err) > 200 else ""),
            )


class SimulationEvaluator:
    """racing.EvaluateFn that runs one simulation subprocess per setup per request.

    Each request (config, days, seed) runs every calibration setup (attacker
    type) with the same seed; its objective is the mean account-level MCC.
    Layout per config: runs/<stage>/<scenario>/trial_<id>/config/simulation_config.json
    (the full-length candidate config auto_runner reads, from the first setup) and
    trial_<id>/evals/<days>_seed<seed>/<setup>/{config,simulation_output,eval_key.json}.
    With resume=True a setup run whose eval_key.json matches (same config, days,
    seed and input files) is scored from its existing output instead of rerun.
    """

    def __init__(
        self,
        *,
        repo_root: Path,
        tuning_root: Path,
        stage_name: str,
        scenario: str,
        setups: Dict[str, Path],
        timeout_sec: int,
        max_retries: int,
        pool: ThreadPoolExecutor,
        progress: Optional[EvalProgress] = None,
        stream_output: bool = False,
        resume: bool = False,
    ) -> None:
        self.repo_root = repo_root
        self.tuning_root = tuning_root
        self.stage_name = stage_name
        self.scenario = scenario
        self.decision = _stage_decision(stage_name)
        self.setups = dict(setups)
        self.timeout_sec = timeout_sec
        self.max_retries = max_retries
        self.pool = pool
        self.progress = progress
        self.stream_output = stream_output
        self.resume = resume
        self._inputs_digest = {
            label: _file_digest([d / "agent_profiles.json"] + [d / n for n in SETUP_INPUT_FILES])
            for label, d in self.setups.items()
        }
        self._lock = threading.Lock()
        self._canonical_written: set = set()

    def __call__(self, requests: List["racing.EvalRequest"]) -> List["racing.EvalResult"]:
        futures = [self.pool.submit(self.evaluate_one, r) for r in requests]
        return [f.result() for f in futures]

    def trial_dir(self, config_id: int) -> Path:
        return _candidate_output_dir(self.tuning_root, self.stage_name, self.scenario, config_id)

    def eval_dir(self, request: "racing.EvalRequest") -> Path:
        return (
            self.trial_dir(request.config_id)
            / "evals"
            / f"{racing.days_label(request.days)}_seed{request.seed}"
        )

    def _candidate_config(self, params: Dict[str, Any], label: Optional[str] = None) -> Dict[str, Any]:
        setup_dir = self.setups[label or next(iter(self.setups))]
        return _build_candidate_config(
            setup_dir / "simulation_config.json",
            candidate_params=params,
            scenario_flags=_scenario_flags(self.scenario),
        )

    def _write_canonical(self, config_id: int, params: Dict[str, Any]) -> None:
        with self._lock:
            if config_id in self._canonical_written:
                return
            self._canonical_written.add(config_id)
            _save_json(
                self.trial_dir(config_id) / "config" / "simulation_config.json",
                self._candidate_config(params),
            )

    def _run_setup(
        self, request: "racing.EvalRequest", label: str
    ) -> Tuple[bool, str, float, bool, Path]:
        """Run (or reuse) one setup for a request: (ok, error, seconds, reused, final path)."""
        setup_dir = self.setups[label]
        eval_dir = self.eval_dir(request) / label
        config_dir = eval_dir / "config"
        output_dir = eval_dir / "simulation_output"
        final_path = output_dir / "final_output.json"
        key_path = eval_dir / "eval_key.json"

        cfg = self._candidate_config(request.params, label)
        if request.days is not None:
            _shorten_simulation(cfg, request.days, verbose=False)
        cfg.setdefault("runtime_config", {})["seed"] = request.seed
        key = hashlib.sha256(
            (json.dumps(cfg, sort_keys=True) + self._inputs_digest[label]).encode()
        ).hexdigest()

        if self.resume and final_path.is_file() and key_path.is_file():
            stored = _load_json(key_path)
            if stored.get("key") == key:
                return True, "", float(stored.get("run_seconds", 0.0)), True, final_path
        if eval_dir.exists():
            shutil.rmtree(eval_dir)
        config_dir.mkdir(parents=True, exist_ok=True)
        _save_json(config_dir / "simulation_config.json", cfg)
        shutil.copy2(setup_dir / "agent_profiles.json", config_dir / "agent_profiles.json")
        copy_setup_inputs(setup_dir, config_dir)
        log.debug(
            "Starting simulation: %s %s cfg_%04d %s days=%s seed=%d params=%s",
            self.stage_name, self.scenario, request.config_id, label, request.days,
            request.seed, json.dumps(request.params, sort_keys=True),
        )
        ok, err = False, ""
        t0 = time.perf_counter()
        for _attempt in range(self.max_retries + 1):
            ok, err = _run_simulation(
                repo_root=self.repo_root,
                config_dir=config_dir,
                output_dir=output_dir,
                timeout_sec=self.timeout_sec,
                stream_output=self.stream_output,
                seed=request.seed,
            )
            if ok and final_path.is_file():
                break
        elapsed = time.perf_counter() - t0
        ok = ok and final_path.is_file()
        if ok:
            _save_json(key_path, {
                "key": key,
                "run_seconds": elapsed,
                "config_id": request.config_id,
                "setup": label,
                "days": request.days,
                "seed": request.seed,
                "params": request.params,
            })
        return ok, (err or ("" if ok else "missing final_output.json")), elapsed, False, final_path

    def evaluate_one(self, request: "racing.EvalRequest") -> "racing.EvalResult":
        self._write_canonical(request.config_id, request.params)
        details: Dict[str, Any] = {"run_seconds": 0.0, "reused": True, "final_output_paths": {}}
        outputs: Dict[str, Dict[str, Any]] = {}
        for label in self.setups:
            ok, err, elapsed, reused, final_path = self._run_setup(request, label)
            details["run_seconds"] += elapsed
            details["reused"] = details["reused"] and reused
            details["final_output_paths"][label] = str(final_path)
            if not ok:
                details["error"] = f"{label}: {err}"
                break
            outputs[label] = _load_json(final_path)
        details["final_output_path"] = next(iter(details["final_output_paths"].values()), None)
        if "error" in details:
            result = racing.EvalResult(request, None, details)
        else:
            objective, counts = _score_outputs(outputs, self.scenario, self.decision)
            details.update(counts)
            result = racing.EvalResult(request, float(objective), details)
        if self.progress is not None:
            self.progress.record(self.stage_name, result)
        return result


def _log_rung(stage_name: str, record: "racing.RungRecord") -> None:
    best = record.scores[0] if record.scores else None
    log.info(
        "%s bracket %d rung %d (%s): %d config(s), %d new run(s); best cfg_%04d mean=%.4f; promoted %s",
        stage_name, record.bracket, record.rung_index, record.rung.label, len(record.scores),
        record.new_runs, best.config_id if best else -1,
        best.mean if best and best.values else float("nan"), record.promoted,
    )


def _log_race_step(stage_name: str, step: "racing.RaceStep") -> None:
    log.info(
        "%s race @%d seeds: alive=%s friedman_p=%s eliminated=%s leader=%s",
        stage_name, step.n_seeds, step.alive_before,
        "-" if step.friedman_p is None else f"{step.friedman_p:.3g}",
        {k: round(v, 4) for k, v in step.eliminated.items()} or "none", step.leader,
    )


def _run_racing_stage(
    stage_name: str,
    sample_config: Callable[[], Dict[str, Any]],
    settings: "racing.SearchSettings",
    tuning_seeds: List[int],
    heldout_seeds: List[int],
    evaluator: SimulationEvaluator,
) -> "racing.SearchResult":
    log.info(
        "--- %s (%s): %s, %d config(s), rungs %s ---",
        stage_name, evaluator.scenario, settings.method, settings.n_configs,
        ", ".join(r.label for r in settings.rungs),
    )
    result = racing.run_search(
        sample_config, settings, tuning_seeds, heldout_seeds, evaluator,
        baseline_params={},
        on_rung=lambda rec: _log_rung(stage_name, rec),
        on_race_step=lambda step: _log_race_step(stage_name, step),
    )
    best = result.best_config_id
    if best is None:
        log.warning("Stage summary %s: no surviving config", stage_name)
    else:
        score = racing.score_of(result.book, best, result.race.days, result.tuning_seeds[: result.race.seeds_used])
        log.info(
            "Stage summary %s: winner cfg_%04d tuning mean=%.4f over %d run(s) params=%s",
            stage_name, best, score.mean, score.n, json.dumps(result.configs[best], sort_keys=True),
        )
        for s in result.confirmation:
            label = "baseline" if s.config_id == racing.BASELINE_CONFIG_ID else f"cfg_{s.config_id:04d}"
            log.info("  held-out %s: mean=%.4f n=%d ci95=%s", label, s.mean, s.n, s.ci95)
    return result


def _mean_detail(details: List[Dict[str, Any]], key: str) -> Optional[float]:
    vals = [float(d[key]) for d in details if d.get(key) is not None]
    return sum(vals) / len(vals) if vals else None


def _ranking_entry(stage_name: str, scenario: str, result: "racing.SearchResult", row: Dict[str, Any]) -> Dict[str, Any]:
    """One tuning_results.json stage entry (TrialResult keys plus racing fields)."""
    score: racing.ConfigScore = row["score"]
    evals = [result.book.get(score.config_id, score.days, s) for s in score.seeds]
    details = [e.details for e in evals if e is not None and e.ok]
    heldout: Optional[racing.ConfigScore] = row["heldout"]
    return {
        "stage": stage_name,
        "scenario": scenario,
        "trial_id": score.config_id,
        "params": row["params"],
        "objective_value": score.mean if score.values else None,
        "tp": _mean_detail(details, "tp"),
        "fp": _mean_detail(details, "fp"),
        "fn": _mean_detail(details, "fn"),
        "tn": _mean_detail(details, "tn"),
        "mcc_by_setup": {
            label: _mean_detail([d.get("mcc_by_setup") or {} for d in details], label)
            for label in (details[0].get("mcc_by_setup") or {} if details else {})
        },
        "attacker_detect_hours": _mean_detail(details, "attacker_detect_hours"),
        "run_seconds": sum(float(d.get("run_seconds", 0.0)) for d in details),
        "final_output_path": details[0].get("final_output_path") if details else None,
        "error": None if score.values else "all evaluations failed",
        "reached": row["reached"],
        "fidelity": racing.days_label(score.days),
        "n_evals": score.n,
        "n_failed": score.n_failed,
        "objective_sd": score.sd,
        "objective_ci95": list(score.ci95) if score.ci95 else None,
        "heldout": heldout.to_dict() if heldout else None,
    }


def _noise_rows(result: "racing.SearchResult") -> List[Dict[str, Any]]:
    """Seed noise vs between-config spread at each rung that ran >= 2 seeds, and the race."""
    rows = []
    for rec in result.rung_records:
        if rec.rung.seeds < 2:
            continue
        ns = racing.noise_summary(
            result.book, [s.config_id for s in rec.scores], rec.rung.days,
            result.tuning_seeds[: rec.rung.seeds],
        )
        if ns:
            rows.append({"where": f"bracket {rec.bracket} rung {rec.rung_index} ({rec.rung.label})", **ns})
    ns = racing.noise_summary(
        result.book, result.race.entrants, result.race.days,
        result.tuning_seeds[: result.race.seeds_used],
    )
    if ns:
        rows.append({"where": f"race ({racing.days_label(result.race.days)}x{result.race.seeds_used})", **ns})
    return rows


def _write_evaluations_csv(path: Path, results: Dict[str, Tuple[str, "racing.SearchResult"]]) -> None:
    fields = [
        "stage", "scenario", "config_id", "label", "days", "seed", "objective",
        "decision", "tp", "fp", "fn", "tn", "mcc_by_setup", "attacker_detect_hours",
        "run_seconds", "reused", "error", "params",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        for stage_name, (scenario, result) in results.items():
            ordered = sorted(
                result.book.results(),
                key=lambda e: (e.request.config_id, racing._days_key(e.request.days), e.request.seed),
            )
            for ev in ordered:
                r, d = ev.request, ev.details
                writer.writerow({
                    "stage": stage_name,
                    "scenario": scenario,
                    "config_id": r.config_id,
                    "label": r.label,
                    "days": racing.days_label(r.days),
                    "seed": r.seed,
                    "objective": ev.objective,
                    "decision": d.get("decision"),
                    "tp": d.get("tp"),
                    "fp": d.get("fp"),
                    "fn": d.get("fn"),
                    "tn": d.get("tn"),
                    "mcc_by_setup": json.dumps(d.get("mcc_by_setup"), sort_keys=True) if d.get("mcc_by_setup") else None,
                    "attacker_detect_hours": d.get("attacker_detect_hours"),
                    "run_seconds": round(float(d.get("run_seconds", 0.0)), 2),
                    "reused": d.get("reused", False),
                    "error": d.get("error"),
                    "params": json.dumps(r.params, sort_keys=True),
                })


def _fmt_ci(ci: Optional[Tuple[float, float]]) -> str:
    return "n/a" if not ci else f"[{ci[0]:.4f}, {ci[1]:.4f}]"


def _write_racing_report(
    output_root: Path,
    setup_labels: List[str],
    seed: int,
    settings: "racing.SearchSettings",
    plan: Dict[str, Any],
    max_workers: int,
    full_days: Optional[int],
    results: Dict[str, Tuple[str, "racing.SearchResult"]],
) -> None:
    output_root.mkdir(parents=True, exist_ok=True)
    summary: Dict[str, Any] = {
        "method": settings.method,
        "seed": seed,
        "budget_total": None,
        "max_workers": max_workers,
        "trial_duration_days": full_days,
        "search_settings": settings.to_dict(),
        "planned_runs_per_stage_max": plan,
        "objective": OBJECTIVE_DESCRIPTION,
        "calibration_setups": setup_labels,
        "stages": {},
        "racing": {},
    }
    lines: List[str] = [
        "Mitigation Parameter Tuning Report",
        "=" * 40,
        f"method: {settings.method} (eta={settings.eta}, configs={settings.n_configs}, "
        f"rungs={', '.join(r.label for r in settings.rungs)})",
        f"race: alpha={settings.race_alpha}, min seeds={settings.race_min_seeds}, max seeds={settings.race_max_seeds}",
        f"confirmation: top {settings.confirm_top} on {settings.confirm_seeds} held-out seed(s)"
        + (" + untuned baseline" if settings.confirm_baseline else ""),
        f"seed: {seed}",
        f"full run length: {full_days if full_days else 'base config'} day(s)",
        f"objective: {OBJECTIVE_DESCRIPTION}",
        f"calibration setups (one run each per evaluation): {', '.join(setup_labels)}",
        "",
    ]
    for stage_name, (scenario, result) in results.items():
        ranking = result.ranking()
        summary["stages"][stage_name] = [_ranking_entry(stage_name, scenario, result, r) for r in ranking[:5]]
        noise = _noise_rows(result)
        summary["racing"][stage_name] = {
            "scenario": scenario,
            "tuning_seeds": result.tuning_seeds,
            "heldout_seeds": result.heldout_seeds[: settings.confirm_seeds],
            "configs": {str(k): v for k, v in result.configs.items()},
            "rungs": [rec.to_dict() for rec in result.rung_records],
            "race": result.race.to_dict(),
            "confirmation": [s.to_dict() for s in result.confirmation],
            "vs_baseline": result.baseline_diffs,
            "noise": noise,
            "runs": len(result.book),
            "failed_runs": sum(1 for e in result.book.results() if not e.ok),
        }

        lines.append(f"[{stage_name}]")
        lines.append(f"  runs: {len(result.book)} ({summary['racing'][stage_name]['failed_runs']} failed)")
        for rec in result.rung_records:
            best = rec.scores[0] if rec.scores else None
            lines.append(
                f"  bracket {rec.bracket} rung {rec.rung_index} {rec.rung.label}: "
                f"{len(rec.scores)} config(s), {rec.new_runs} new run(s), "
                f"best cfg_{best.config_id:04d} mean={best.mean:.4f}" if best and best.values
                else f"  bracket {rec.bracket} rung {rec.rung_index} {rec.rung.label}: no successful runs"
            )
        lines.append(
            f"  race: {len(result.race.entrants)} entrant(s), {result.race.seeds_used} seed(s), "
            f"survivors {result.race.survivors}, eliminated {result.race.eliminated_order}"
        )
        if not ranking or result.best_config_id is None:
            lines.append("  no successful trials")
            lines.append("")
            continue
        top = ranking[0]
        score: racing.ConfigScore = top["score"]
        lines.append(f"  best config: cfg_{score.config_id:04d}")
        lines.append(f"  best params: {json.dumps(top['params'], sort_keys=True)}")
        lines.append(
            f"  tuning MCC: mean={score.mean:.4f} "
            f"sd={'n/a' if score.sd is None else f'{score.sd:.4f}'} "
            f"n={score.n} ci95={_fmt_ci(score.ci95)}  (selection-biased upward)"
        )
        for s in result.confirmation:
            label = "baseline (untuned)" if s.config_id == racing.BASELINE_CONFIG_ID else f"cfg_{s.config_id:04d}"
            lines.append(f"  held-out {label}: mean={s.mean:.4f} n={s.n} ci95={_fmt_ci(s.ci95)}")
        for d in result.baseline_diffs:
            lines.append(
                f"  held-out cfg_{d['config_id']:04d} - baseline: mean={d['mean_diff']:.4f} "
                f"ci95={_fmt_ci(tuple(d['ci95']) if d['ci95'] else None)} "
                f"p(>0)={'n/a' if d['p_greater'] is None else format(d['p_greater'], '.3g')}"
            )
        for row in noise:
            ratio = "n/a" if row["ratio"] is None else f"{row['ratio']:.2f}"
            lines.append(
                f"  noise {row['where']}: within-config sd={row['within_sd']:.4f}, "
                f"between-config sd={row['between_sd']:.4f}, ratio={ratio}"
            )
        lines.append("")

    lines.append(
        "Noise ratio = run-to-run sd / sd of config means; near or above 1 means single "
        "runs cannot rank these configs (raise rung seeds or race seeds)."
    )
    _save_json(output_root / "tuning_results.json", summary)
    with open(output_root / "tuning_results.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    _write_evaluations_csv(output_root / "tuning_evaluations.csv", results)


def _format_plan(
    settings: "racing.SearchSettings", plan: Dict[str, Any], full_days: Optional[int],
    n_setups: int = 1, n_stages: int = len(DEFAULT_STAGES),
) -> str:
    out = [
        f"Per stage ({n_stages} stages; full run = {full_days or '?'} day(s)):",
    ]
    for b in plan["brackets"]:
        rungs = "; ".join(f"{r['rung']}: {r['configs']} cfg, {r['new_runs']} run(s)" for r in b["rungs"])
        out.append(f"  bracket {b['bracket']} ({b['configs']} configs from rung {b['start_rung']}): {rungs}")
    out.append(f"  race: <= {plan['race_runs_max']} run(s); confirmation: {plan['confirm_runs']} full run(s)")
    out.append(
        f"  max per stage: {plan['total_runs_max']} run(s) = {plan['full_runs_max']} full + "
        f"{plan['short_run_days_max']} simulated day(s) of short runs"
    )
    n = n_stages
    out.append(
        f"Max total: {n * plan['total_runs_max']} run(s) "
        f"({n * plan['full_runs_max']} full + {n * plan['short_run_days_max']} short-run day(s))"
    )
    if n_setups > 1:
        out.append(
            f"Each run simulates all {n_setups} calibration setups: up to "
            f"{n_setups * n * plan['total_runs_max']} simulations in total"
        )
    return "\n".join(out)


def _run_racing_search(
    args: argparse.Namespace,
    *,
    settings: "racing.SearchSettings",
    plan: Dict[str, Any],
    full_days: Optional[int],
    repo_root: Path,
    tuning_root: Path,
    report_root: Path,
    scenario_dirs: Dict[str, Dict[str, Path]],
    stages: Dict[str, str],
) -> None:
    tuning_seeds = racing.derive_seeds(args.seed, "tuning", settings.tuning_seed_count)
    heldout_seeds = racing.derive_seeds(args.seed, "heldout", max(1, settings.confirm_seeds))
    progress = EvalProgress(len(stages) * plan["total_runs_max"])
    results: Dict[str, Tuple[str, racing.SearchResult]] = {}

    with ThreadPoolExecutor(max_workers=args.max_workers) as pool:

        def evaluator_for(stage_name: str) -> SimulationEvaluator:
            scenario = stages[stage_name]
            return SimulationEvaluator(
                repo_root=repo_root,
                tuning_root=tuning_root,
                stage_name=stage_name,
                scenario=scenario,
                setups=scenario_dirs[scenario],
                timeout_sec=args.timeout_sec,
                max_retries=args.max_retries,
                pool=pool,
                progress=progress,
                stream_output=args.stream_simulation_output,
                resume=args.resume,
            )

        def run_stage1(stage_name: str) -> racing.SearchResult:
            scenario = stages[stage_name]
            # One RNG per stage, so parallel stages sample the same configs as sequential ones
            rng = random.Random(f"{args.seed}:{stage_name}")
            return _run_racing_stage(
                stage_name, lambda: _sample_params_for_scenario(rng, scenario), settings,
                tuning_seeds, heldout_seeds, evaluator_for(stage_name),
            )

        stage1 = [s for s in stages if s.startswith("stage_1_")]
        if args.sequential_stage1:
            for stage_name in stage1:
                results[stage_name] = (stages[stage_name], run_stage1(stage_name))
        elif stage1:
            # Each stage's search waits on its own batches; runs share the worker pool
            with ThreadPoolExecutor(max_workers=len(stage1)) as drivers:
                futures = {s: drivers.submit(run_stage1, s) for s in stage1}
                for stage_name in stage1:
                    results[stage_name] = (stages[stage_name], futures[stage_name].result())

        def winner(stage_name: str) -> Optional[Dict[str, Any]]:
            if stage_name not in results:
                return None
            res = results[stage_name][1]
            cid = res.best_config_id
            return res.configs[cid] if cid is not None else None

        best_dup = winner("stage_1_duplicate_only")
        best_rate = winner("stage_1_rate_limit_only")
        best_rule = winner("stage_1_rule_moderation_only")

        def run_stage2(stage_name: str) -> racing.SearchResult:
            scenario = stages[stage_name]
            rng2 = random.Random(f"{args.seed}:{stage_name}")
            return _run_racing_stage(
                stage_name,
                lambda: _sample_joint_from_stage1(
                    rng2, best_dup, best_rate, best_rule, scenario=scenario
                ),
                settings, tuning_seeds, heldout_seeds, evaluator_for(stage_name),
            )

        for stage_name in [s for s in stages if s.startswith("stage_2_")]:
            results[stage_name] = (stages[stage_name], run_stage2(stage_name))

    _write_racing_report(
        report_root, list(next(iter(scenario_dirs.values()))), args.seed, settings, plan, args.max_workers,
        args.trial_duration_days or full_days, results,
    )
    log.info("Tuning complete. Results saved under: %s", report_root)


def _search_settings_from_args(args: argparse.Namespace, full_days: Optional[int]) -> "racing.SearchSettings":
    settings = racing.SearchSettings(
        method=args.method,
        n_configs=args.configs,
        eta=args.eta,
        rungs=racing.parse_rungs(args.rungs, full_days),
        race_max_seeds=args.race_max_seeds,
        race_alpha=args.race_alpha,
        race_min_seeds=args.race_min_seeds,
        confirm_top=args.confirm_top,
        confirm_seeds=args.confirm_seeds,
        confirm_baseline=not args.no_confirm_baseline,
    )
    settings.validate()
    return settings


def _setup_labels(dirs: List[Path]) -> List[str]:
    """Short unique label per calibration setup folder (its name, then parent/name)."""
    labels = [d.name for d in dirs]
    if len(set(labels)) < len(labels):
        labels = [f"{d.parent.name}_{d.name}" for d in dirs]
    if len(set(labels)) < len(labels):
        labels = [f"{i}_{lab}" for i, lab in enumerate(labels)]
    return labels


def _check_calibration_setups(dirs: List[Path]) -> None:
    """Every setup needs attackers (MCC has no positives otherwise); warn if the
    setups together cover only one attacker type."""
    kinds = set()
    for d in dirs:
        _, profiles_path = _ensure_base_files(d)
        types = [p.get("user_type") for p in _load_json(profiles_path)]
        attackers = [t for t in types if t in ATTACKER_PROFILE_TYPES]
        if not attackers:
            raise SystemExit(
                f"Calibration setup {d} has no attacker profiles: the account-level MCC needs "
                "attackers (positives). Use an llm_attackers / template_attackers setup."
            )
        kinds.update("template" if t == "template_attacker" else "llm" for t in attackers)
        if "rule_moderator" in types:
            log.warning(
                "Setup %s already has rule_moderator agents; they act in every stage", d
            )
    if len(kinds) < 2:
        log.warning(
            "Calibration setups cover only %s attackers; pass one setup per attacker type "
            "(LLM and template) to --base-config-dir", ", ".join(sorted(kinds)),
        )


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Tune mitigation parameters (successive halving + racing by default)"
    )
    parser.add_argument(
        "--base-config-dir",
        nargs="+",
        default=["Simulation_Setups/simulations/mitigation_tuning"],
        help=(
            "Calibration setup folder(s), each with simulation_config.json and "
            "agent_profiles.json and at least one attacker; pass one per attacker type "
            "(e.g. .../llm_attackers .../template_attackers). Every evaluation runs each "
            "setup and scores the mean MCC"
        ),
    )
    parser.add_argument(
        "--tuning-root",
        default="Simulation_Setups/simulations/mitigation_parameter_tuning",
        help="Root directory for scenario configs, run outputs, and reports",
    )
    parser.add_argument("--trials", type=int, default=50, help="--method random only: total trial budget")
    parser.add_argument("--seed", type=int, default=42, help="RNG seed for reproducible search")
    parser.add_argument("--timeout-sec", type=int, default=1200, help="Per-trial timeout in seconds")
    parser.add_argument(
        "--max-retries",
        type=int,
        default=1,
        help="Retries per failed trial before marking failure",
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=1,
        help="Run up to this many trials in parallel (each trial is a separate subprocess; use with care for CPU/RAM/LLM rate limits)",
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Less console output (warnings and errors only)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="More detail (per-trial param dump via DEBUG)",
    )
    parser.add_argument(
        "--stream-simulation-output",
        action="store_true",
        help="Print run_simulation stdout/stderr in this terminal (best with --max-workers 1)",
    )
    parser.add_argument(
        "--sequential-stage1",
        action="store_true",
        help=(
            "Run the single-mitigation stages one after another. Default: run "
            "them together (they are independent; only stage 2 uses their results), "
            "sharing --max-workers"
        ),
    )
    parser.add_argument(
        "--stages",
        nargs="+",
        choices=list(STAGE_SCENARIOS),
        default=DEFAULT_STAGES,
        help=(
            "Stages to tune (default: the batch set's scenarios: "
            + ", ".join(DEFAULT_STAGES) + "). Stage 2 samples near the stage-1 winners "
            "that ran, else over the full ranges"
        ),
    )
    parser.add_argument(
        "--trial-duration-days",
        type=int,
        default=None,
        help=(
            "Simulate only this many days per trial (default: the base config's "
            "duration). Faster tuning; batch runs keep their full duration"
        ),
    )
    parser.add_argument(
        "--method",
        choices=["halving", "hyperband", "random"],
        default="halving",
        help=(
            "halving: successive halving over --rungs, race, held-out confirmation (default); "
            "hyperband: several halving brackets, some starting at later rungs; "
            "random: the previous staged random search"
        ),
    )
    parser.add_argument(
        "--configs", type=int, default=27,
        help="halving/hyperband: configs sampled per stage (first bracket)",
    )
    parser.add_argument(
        "--eta", type=int, default=3,
        help="halving/hyperband: keep the best 1/eta of configs at each rung",
    )
    parser.add_argument(
        "--rungs", default="1:1,full:2,full:4",
        help=(
            "halving/hyperband: fidelity rungs as days:seeds, cheapest first "
            "('full' = the full run). Default 1:1,full:2,full:4"
        ),
    )
    parser.add_argument(
        "--race-max-seeds", type=int, default=8,
        help="Race: most seeds a finalist is run on (at the last rung's fidelity)",
    )
    parser.add_argument("--race-alpha", type=float, default=0.05, help="Race: significance level for eliminations")
    parser.add_argument(
        "--race-min-seeds", type=int, default=3,
        help="Race: seeds needed before the first elimination test",
    )
    parser.add_argument(
        "--confirm-top", type=int, default=1,
        help="Rerun the best N configs on held-out seeds (0 = skip confirmation)",
    )
    parser.add_argument(
        "--confirm-seeds", type=int, default=5,
        help="Held-out seeds for confirmation (never used for selection)",
    )
    parser.add_argument(
        "--no-confirm-baseline", action="store_true",
        help="Do not rerun the untuned base mitigation config on the held-out seeds",
    )
    parser.add_argument(
        "--resume", action="store_true",
        help=(
            "halving/hyperband: reuse finished runs from an earlier, interrupted tuning with "
            "the same --seed and inputs (matched per run by config, days and seed)"
        ),
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print the planned number of runs and exit",
    )
    args = parser.parse_args()

    if args.method == "random":
        _validate_positive("trials", args.trials)
    if args.trial_duration_days is not None:
        _validate_positive("trial-duration-days", args.trial_duration_days)
    _validate_positive("timeout-sec", args.timeout_sec)
    _validate_positive("max-workers", args.max_workers)

    if args.verbose:
        log_level = logging.DEBUG
    elif args.quiet:
        log_level = logging.WARNING
    else:
        log_level = logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s %(levelname)s [tuning] %(message)s",
        datefmt="%H:%M:%S",
        force=True,
    )

    if args.stream_simulation_output and args.max_workers > 1:
        log.warning(
            "--stream-simulation-output with --max-workers=%d: subprocess logs may interleave",
            args.max_workers,
        )

    stages = {s: STAGE_SCENARIOS[s] for s in STAGE_SCENARIOS if s in args.stages}
    repo_root = Path(__file__).resolve().parents[3]
    base_config_dirs = [(repo_root / d).resolve() for d in args.base_config_dir]
    setup_labels = _setup_labels(base_config_dirs)
    base_config_dir = base_config_dirs[0]
    tuning_root = (repo_root / args.tuning_root).resolve()
    setup_root = tuning_root / "scenarios"
    report_root = tuning_root / "results"

    settings: Optional[racing.SearchSettings] = None
    plan: Dict[str, Any] = {}
    full_days: Optional[int] = None
    if args.method != "random":
        sim_config_path, _ = _ensure_base_files(base_config_dir)
        base_days = (_load_json(sim_config_path).get("simulation_config") or {}).get("duration_days")
        full_days = int(base_days) if base_days is not None else None
        for other in base_config_dirs[1:]:
            other_days = (_load_json(_ensure_base_files(other)[0]).get("simulation_config") or {}).get("duration_days")
            if other_days != base_days:
                log.warning(
                    "Setup %s runs %s day(s) but %s runs %s; fidelity rungs use %s",
                    other, other_days, base_config_dir, base_days, base_days,
                )
        if args.trial_duration_days is not None:
            full_days = min(full_days or args.trial_duration_days, args.trial_duration_days)
        settings = _search_settings_from_args(args, full_days)
        plan = racing.plan_budget(settings)
        log.info("Search plan (worst case):\n%s", _format_plan(settings, plan, full_days, len(base_config_dirs), len(stages)))
        if args.dry_run:
            print(_format_plan(settings, plan, full_days, len(base_config_dirs), len(stages)))
            return
    elif args.dry_run:
        print(f"random search: {sum(_allocate_stage_budget(args.trials, list(stages.values())).values())} run(s)")
        return

    _check_calibration_setups(base_config_dirs)

    # Scenario setup folders requested by plan.
    scenario_defaults = {
        "duplicate_only": {"enable_duplicate_detection": True, "enable_rate_limiting": False, "enable_coordinated_detection": False},
        "rate_limit_only": {"enable_duplicate_detection": False, "enable_rate_limiting": True, "enable_coordinated_detection": False},
        "coordination_only": {"enable_duplicate_detection": False, "enable_rate_limiting": False, "enable_coordinated_detection": True},
        "rule_moderation_only": {
            "enable_duplicate_detection": False, "enable_rate_limiting": False,
            "enable_coordinated_detection": False, "enable_rule_moderators": True,
        },
        "all_mitigations_except_coordination": {
            "enable_duplicate_detection": True, "enable_rate_limiting": True,
            "enable_coordinated_detection": False, "enable_rule_moderators": True,
        },
    }

    scenario_dirs: Dict[str, Dict[str, Path]] = {}
    for scenario, defaults in scenario_defaults.items():
        if scenario not in stages.values():
            continue
        rule = scenario in RULE_MODERATOR_SCENARIOS
        if rule:
            defaults = {**RULE_MODERATOR_MITIGATION_DEFAULTS, **defaults}
        scenario_dirs[scenario] = {
            label: _prepare_scenario_setup(
                base_config_dir=base_dir,
                scenario_dir=setup_root / scenario / label,
                mitigation_defaults=defaults,
                trial_duration_days=args.trial_duration_days,
                add_rule_moderators=rule,
            )
            for label, base_dir in zip(setup_labels, base_config_dirs)
        }

    if settings is None:
        _run_random_search(
            args,
            repo_root=repo_root,
            base_config_dir=base_config_dir,
            tuning_root=tuning_root,
            report_root=report_root,
            scenario_dirs=scenario_dirs,
            stages=stages,
        )
    else:
        log.info("Base config: %s | tuning root: %s", base_config_dir, tuning_root)
        _run_racing_search(
            args,
            settings=settings,
            plan=plan,
            full_days=full_days,
            repo_root=repo_root,
            tuning_root=tuning_root,
            report_root=report_root,
            scenario_dirs=scenario_dirs,
            stages=stages,
        )


if __name__ == "__main__":
    main()
