#!/usr/bin/env python3
"""
Account-level Matthews correlation coefficient (MCC) for mitigation runs.

The classification unit is a user account. Ground truth is the account type:
attacker accounts (llm_attacker / template_attacker) are positives and every
other user account is a negative, whatever an individual post contains.
Moderator agents (rule / biased moderators) are not users and are left out.
Every user account is scored, including accounts that never posted.

An account is predicted positive when the mitigation acted on it:
  - decision "flagged": flagged at least once by one of the given sources
    ("duplicate", "rate_limit", "coordination", "rule_moderator"); used when
    a single mechanism is tuned on its own;
  - decision "banned": banned (three-strikes across all enabled mechanisms);
    used when the mechanisms are tuned together.

MCC = (TP*TN - FP*FN) / sqrt((TP+FP)(TP+FN)(TN+FP)(TN+FN)), and 0 when the
denominator is 0 (no predicted positives, no predicted negatives, or a run
with no attackers), the usual convention.

Reads final_output.json's mitigation_summary (systems/output_system.py).
"""

import math
from typing import Any, Dict, Iterable, Optional, Set

ATTACKER_AGENT_TYPES = frozenset({"llm_attacker", "template_attacker", "attacker"})
NON_USER_AGENT_TYPES = frozenset({"rule_moderator", "biased_moderator", "moderator"})
DECISIONS = ("flagged", "banned")


def mcc(tp: int, fp: int, fn: int, tn: int) -> float:
    denom = (tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)
    if denom == 0:
        return 0.0
    return (tp * tn - fp * fn) / math.sqrt(denom)


def account_confusion(
    final_output: Dict[str, Any],
    decision: str = "banned",
    sources: Optional[Iterable[str]] = None,
) -> Dict[str, Any]:
    """Confusion counts, MCC and mean attacker detection time (hours) for one run.

    sources: for decision "flagged", the flag sources that count (None = any).
    Outputs written before flag_counts_by_source existed fall back to the
    total flag counts (all sources).
    """
    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}, got {decision!r}")
    summary = final_output.get("mitigation_summary") or {}
    types = {str(k): v for k, v in (summary.get("agent_type_by_id") or {}).items()}
    users = {a for a, t in types.items() if t not in NON_USER_AGENT_TYPES}
    attackers = {a for a in users if types[a] in ATTACKER_AGENT_TYPES}

    src: Optional[Set[str]] = set(sources) if sources is not None else None
    detect_s: Dict[str, float] = {}
    if decision == "banned":
        predicted = {str(a) for a in summary.get("banned_agent_ids") or []}
        detect_s = {str(a): float(t) for a, t in (summary.get("mitigation_ban_time_s") or {}).items()}
    else:
        by_source = summary.get("flag_counts_by_source")
        if by_source is None or src is None:
            predicted = {str(a) for a, c in (summary.get("flag_counts_by_agent") or {}).items() if int(c) > 0}
        else:
            predicted = {
                str(a) for a, counts in by_source.items()
                if any(int(counts.get(s, 0)) > 0 for s in src)
            }
        for a, firsts in (summary.get("first_flag_time_s_by_source") or {}).items():
            times = [float(t) for s, t in firsts.items() if src is None or s in src]
            if times:
                detect_s[str(a)] = min(times)
    predicted &= users

    tp = len(attackers & predicted)
    fp = len(predicted - attackers)
    fn = len(attackers - predicted)
    tn = len(users) - tp - fp - fn
    hours = [detect_s[a] / 3600.0 for a in attackers & predicted if a in detect_s]
    return {
        "tp": tp,
        "fp": fp,
        "fn": fn,
        "tn": tn,
        "mcc": mcc(tp, fp, fn, tn),
        "n_attackers": len(attackers),
        "n_users": len(users),
        "attacker_detect_hours": sum(hours) / len(hours) if hours else None,
    }
