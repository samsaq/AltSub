#!/usr/bin/env python3
"""
Filter log file by log level

Filters a simulation.log file to only show messages at a specified log level or higher.

Usage:
    python filter_log.py <input_log> <output_log> <min_level>
    
    min_level: DEBUG, INFO, WARNING, ERROR, or CRITICAL
    
Example:
    python filter_log.py simulation.log simulation_warnings.log WARNING
    # This will keep only WARNING, ERROR, and CRITICAL messages
"""

import sys
import re
from pathlib import Path
from typing import Optional

# Log level hierarchy (lower number = lower priority)
LOG_LEVELS = {
    "DEBUG": 0,
    "INFO": 1,
    "WARNING": 2,
    "ERROR": 3,
    "CRITICAL": 4,
}

# Regex pattern to match log lines: TIMESTAMP - LEVEL - MESSAGE
LOG_PATTERN = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3}) - (\w+) - (.+)$")


def parse_log_level(level_str: str) -> int:
    """Parse log level string to numeric value"""
    level_str = level_str.upper().strip()
    if level_str not in LOG_LEVELS:
        raise ValueError(
            f"Invalid log level: {level_str}. Must be one of: {', '.join(LOG_LEVELS.keys())}"
        )
    return LOG_LEVELS[level_str]


def filter_log_file(input_path: Path, output_path: Path, min_level: int) -> int:
    """
    Filter log file to only show messages at min_level or higher
    
    Returns:
        Number of lines written
    """
    lines_written = 0
    
    with open(input_path, "r", encoding="utf-8") as infile, open(
        output_path, "w", encoding="utf-8"
    ) as outfile:
        for line in infile:
            match = LOG_PATTERN.match(line.rstrip())
            if match:
                timestamp, level_str, message = match.groups()
                level = parse_log_level(level_str)
                
                if level >= min_level:
                    outfile.write(line)
                    lines_written += 1
            else:
                pass
    
    return lines_written


def main():
    """Main entry point"""
    if len(sys.argv) != 4:
        print(__doc__, file=sys.stderr)
        sys.exit(1)
    
    input_log = Path(sys.argv[1])
    output_log = Path(sys.argv[2])
    min_level_str = sys.argv[3]
    
    if not input_log.exists():
        print(f"Error: Input log file not found: {input_log}", file=sys.stderr)
        sys.exit(1)
    
    try:
        min_level = parse_log_level(min_level_str)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    try:
        lines_written = filter_log_file(input_log, output_log, min_level)
        print(
            f"Filtered log file: {lines_written} lines written to {output_log} "
            f"(min level: {min_level_str})"
        )
    except Exception as e:
        print(f"Error filtering log file: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()

