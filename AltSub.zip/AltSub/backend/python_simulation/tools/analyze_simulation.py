#!/usr/bin/env python3
"""
Simulation Analysis Script

Analyzes outputs from the Reddit Construct simulation including:
- Daily snapshots from campaign orchestrator
- Network states from Construct outputs
- Belief evolution over time
- Campaign effectiveness metrics
- Agent behavior patterns
"""

import json
import os
import sys
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Tuple, Set, Optional
import xml.etree.ElementTree as ET
from datetime import datetime
import logging
from difflib import SequenceMatcher

try:
    from sentence_transformers import SentenceTransformer

    SENTENCE_TRANSFORMERS_AVAILABLE = True
except ImportError:
    SENTENCE_TRANSFORMERS_AVAILABLE = False

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
log = logging.getLogger(__name__)

# Profile user_type values for attackers (legacy "attacker" = LLM attacker profiles)
ATTACKER_PROFILE_TYPES = ("attacker", "llm_attacker", "template_attacker")
# Organic users for "non-attacker" averages. Moderators are excluded, and
# "regular" profiles are not simulated (run_simulation skips them).
ORGANIC_PROFILE_TYPES = ("llm_user",)

if not SENTENCE_TRANSFORMERS_AVAILABLE:
    log.warning(
        "sentence-transformers not available, falling back to SequenceMatcher for text similarity"
    )

CLUSTERING_METADATA_FILENAME = "belief_clustering_metadata.json"
# Written by the canonicalizer instead when the output dir holds the input metadata
SIMULATION_CLUSTERING_METADATA_FILENAME = "belief_clustering_metadata_simulation.json"


def _setup_clustering_metadata_files(input_dir: Path) -> List[Path]:
    """The setup's original clustering metadata, searched like agent_profiles.json
    (experiment root, then its config/ directory)."""
    parent = Path(input_dir).parent
    candidates = [
        parent / "config" / CLUSTERING_METADATA_FILENAME,
        parent / CLUSTERING_METADATA_FILENAME,
        Path(input_dir) / CLUSTERING_METADATA_FILENAME,
    ]
    return [p for p in candidates if p.exists()]


def _initial_belief_ids_from_profiles(input_dir: Path) -> Set[str]:
    """Non-campaign belief IDs agents start with (agent_profiles.json)."""
    input_dir = Path(input_dir)
    for profiles_file in (
        input_dir / "agent_profiles.json",
        input_dir.parent / "agent_profiles.json",
        input_dir.parent / "config" / "agent_profiles.json",
    ):
        if profiles_file.exists():
            try:
                with open(profiles_file) as f:
                    profiles = json.load(f)
            except Exception as e:
                log.warning(f"Could not load {profiles_file}: {e}")
                return set()
            return {
                bid
                for p in profiles
                for bid in (p.get("beliefs") or {})
                if not str(bid).startswith("campaign_")
            }
    return set()


def load_clustering_metadata(
    input_dir, initial_belief_ids: Optional[Set[str]] = None
) -> Optional[Dict]:
    """Clustering metadata for a run, merged so it covers the initial beliefs.

    Runs made before the canonicalizer seeded its output from the setup metadata
    have an output belief_clustering_metadata.json holding only beliefs created
    during the run (with a placeholder config). Clusters for initial belief IDs
    that are missing are merged in from the setup's original metadata, without
    duplicating IDs, and the original clustering config is used.
    """
    input_dir = Path(input_dir)
    meta = None
    for name in (SIMULATION_CLUSTERING_METADATA_FILENAME, CLUSTERING_METADATA_FILENAME):
        path = input_dir / name
        if path.exists():
            try:
                with open(path, "r") as f:
                    meta = json.load(f)
                break
            except Exception as e:
                log.warning(f"Could not load clustering metadata {path}: {e}")

    if initial_belief_ids is None:
        initial_belief_ids = _initial_belief_ids_from_profiles(input_dir)
    initial_belief_ids = {b for b in initial_belief_ids if not str(b).startswith("campaign_")}

    have = {c.get("belief_id") for c in (meta or {}).get("cluster_details", [])}
    missing = initial_belief_ids - have
    if meta is not None and not missing:
        return meta

    for setup_file in _setup_clustering_metadata_files(input_dir):
        if meta is not None and setup_file.resolve() == (input_dir / CLUSTERING_METADATA_FILENAME).resolve():
            continue
        try:
            with open(setup_file, "r") as f:
                setup_meta = json.load(f)
        except Exception as e:
            log.warning(f"Could not load setup clustering metadata {setup_file}: {e}")
            continue
        setup_clusters = setup_meta.get("cluster_details", [])
        if meta is None:
            log.info(f"Using setup clustering metadata {setup_file} ({len(setup_clusters)} clusters)")
            return setup_meta
        added = [c for c in setup_clusters if c.get("belief_id") not in have]
        if not added:
            continue
        merged = dict(meta)
        merged["cluster_details"] = added + list(meta.get("cluster_details", []))
        # The run file's config is a placeholder when it was not seeded from the setup
        merged["config"] = dict(setup_meta.get("config", {}) or meta.get("config", {}))
        merged["config"]["num_canonical_beliefs"] = len(merged["cluster_details"])
        merged["merged_setup_metadata"] = str(setup_file)
        still_missing = missing - {c.get("belief_id") for c in added}
        log.info(
            f"Merged {len(added)} clusters from setup metadata {setup_file} into run metadata "
            f"({len(missing) - len(still_missing)}/{len(missing)} missing initial belief IDs now covered; "
            f"{len(merged['cluster_details'])} clusters total)"
        )
        return merged

    if meta is not None and missing:
        log.warning(
            f"{len(missing)} initial belief IDs have no clustering metadata and no setup metadata was found to merge"
        )
    return meta


class SimulationAnalyzer:
    """Main class for analyzing simulation outputs"""

    def __init__(self, input_dir: str = "simulation_output", output_dir: str = None):
        """
        Initialize analyzer.

        Args:
            input_dir: Path to simulation output directory (where data is read from)
            output_dir: Path to analysis output directory (where results are written)
                       If None, defaults to input_dir / "analysis"
        """
        self.input_dir = Path(input_dir)
        self.snapshots_dir = self.input_dir / "daily_snapshots"

        if output_dir:
            self.analysis_dir = Path(output_dir)
        else:
            self.analysis_dir = self.input_dir / "analysis"
        self.analysis_dir.mkdir(parents=True, exist_ok=True)

        self.daily_snapshots = []
        self.agent_profiles = {}
        self.config_data = {}
        self.final_output = {}
        self.media_events = (
            []
        )
        self.clustering_meta: Optional[Dict] = None

        # Lazy-load embedder for semantic similarity (if available)
        self._embedder: Optional[SentenceTransformer] = None
        self._embedder_model = "all-MiniLM-L6-v2"

    def load_all_data(self):
        """Load all available data from simulation outputs"""
        log.info("Loading simulation data...")

        self.daily_snapshots = self.load_daily_snapshots()
        log.info(f"Loaded {len(self.daily_snapshots)} daily snapshots")

        self.agent_profiles = self.load_agent_profiles()
        log.info(f"Loaded {len(self.agent_profiles)} agent profiles")

        self.media_events = self.load_media_events()
        log.info(f"Loaded {len(self.media_events)} media events")

        self.config_data = self.load_config()

        self.final_output = self.load_final_output()

        # Canonical belief clustering, merged with the setup's original clusters
        # when the run's file lacks the initial beliefs
        initial_belief_ids = {
            bid for p in self.agent_profiles.values() for bid in (p.get("beliefs") or {})
        }
        self.clustering_meta = load_clustering_metadata(self.input_dir, initial_belief_ids)

        self.attacker_agent_ids = {
            i for i, p in self.agent_profiles.items() if p.get("user_type") in ATTACKER_PROFILE_TYPES
        }
        self.organic_agent_ids = {
            i for i, p in self.agent_profiles.items() if p.get("user_type") in ORGANIC_PROFILE_TYPES
        }
        self._vote_index = self._build_vote_index()

    def _build_vote_index(self) -> Dict[int, Dict[str, Set[int]]]:
        """event_id -> {"up": voter ids, "down": voter ids} over the whole run.

        Built from vote events in all daily snapshots (present in every Python-sim
        run) plus the voter lists in media_events.json and newer snapshots, so a
        post's counts are the votes it received by the end of the run.
        """
        index: Dict[int, Dict[str, Set[int]]] = {}

        def add(target, voter, kind):
            if target is None or voter is None:
                return
            index.setdefault(target, {"up": set(), "down": set()})[kind].add(voter)

        for snapshot in self.daily_snapshots:
            for e in snapshot.get("simulation_data", {}).get("events", []):
                etype = str(e.get("type", "")).lower()
                if etype == "upvote":
                    add(e.get("parent_id"), e.get("user_id"), "up")
                elif etype == "downvote":
                    add(e.get("parent_id"), e.get("user_id"), "down")
                for voter in e.get("upvotes", []) or []:
                    add(e.get("event_id"), voter, "up")
                for voter in e.get("downvotes", []) or []:
                    add(e.get("event_id"), voter, "down")
        for e in self.media_events or []:
            for voter in e.get("upvotes", []) or []:
                add(e.get("event_id"), voter, "up")
            for voter in e.get("downvotes", []) or []:
                add(e.get("event_id"), voter, "down")
        return index

    def _vote_counts(self, event_id) -> Dict[str, int]:
        """Votes an event received by the end of the run: all voters, and
        community-only (votes from attackers excluded)."""
        votes = getattr(self, "_vote_index", {}).get(event_id, {"up": set(), "down": set()})
        attackers = getattr(self, "attacker_agent_ids", set())
        return {
            "upvotes": len(votes["up"]),
            "downvotes": len(votes["down"]),
            "community_upvotes": len(votes["up"] - attackers),
            "community_downvotes": len(votes["down"] - attackers),
        }

    def _initial_belief_states(self) -> Dict[str, Dict[str, float]]:
        """Beliefs before the simulation starts (agent_profiles.json), keyed like
        snapshot belief_states. The first snapshot is taken at the END of day 0,
        so using it as the baseline would hide day-0 campaign influence."""
        return {
            str(i): dict(p.get("beliefs") or {})
            for i, p in self.agent_profiles.items()
            if p.get("beliefs")
        }

    def load_media_events(self) -> List[Dict]:
        """Load media events from media_events.json (Python simulation format)"""
        events_file = self.input_dir / "media_events.json"

        if not events_file.exists():
            log.warning(f"Media events file not found: {events_file}")
            return []

        try:
            with open(events_file) as f:
                events = json.load(f)
            return events
        except Exception as e:
            log.error(f"Error loading media events: {e}")
            return []

    def _convert_events_to_posts_comments(
        self, events: List[Dict], day: int = None
    ) -> Tuple[List[Dict], List[Dict]]:
        """
        Convert unified event format to separate posts/comments arrays.

        Args:
            events: List of events with 'type' field ('post' or 'reply')
            day: Optional day filter (if provided, filters events by day)

        Returns:
            Tuple of (posts list, comments list)
        """
        posts = []
        comments = []

        step_s = self._seconds_per_timestep()

        for event in events:
            # Filter by day if specified (simulated seconds; events from older
            # runs have only an integer timestep)
            if day is not None:
                time_s = event.get("time_s")
                if time_s is None:
                    time_s = event.get("timestamp", 0) * step_s
                if not (day * 86400.0 <= time_s < (day + 1) * 86400.0):
                    continue

            user_id = event.get("user_id")
            author_type = "regular"
            if event.get("seed"):
                author_type = "seed"  # pre-existing Reddit content, not an agent
            elif user_id is not None:
                profile = self.agent_profiles.get(user_id, {})
                author_type = profile.get("user_type", "regular")

            event_dict = {
                "event_id": event.get("event_id"),
                "user_id": user_id,
                "author_type": author_type,
                "belief_id": event.get("belief_id"),
                "subreddit_id": event.get("subreddit_id"),
                "timestamp": event.get("timestamp"),
                "score": event.get("score", 0),
                "content": event.get("content", ""),
                **self._vote_counts(event.get("event_id")),
            }

            event_type = event.get("type", "").lower()
            if event_type == "post":
                event_dict["root_post_id"] = event.get("event_id")
                posts.append(event_dict)
            elif event_type == "reply":
                event_dict["parent_id"] = event.get("parent_id")
                # Find root post ID by traversing up the reply chain
                lookup_events = self.media_events if self.media_events else events
                root_post_id = self._find_root_post(
                    event.get("parent_id"), lookup_events
                )
                event_dict["root_post_id"] = root_post_id
                comments.append(event_dict)

        return posts, comments

    def _seconds_per_timestep(self) -> float:
        """Length of one simulation timestep (final_output, else config, else 5 min)."""
        unit = (self.final_output or {}).get("time_unit_seconds")
        if unit:
            return float(unit)
        interval = (self.config_data or {}).get("simulation_config", {}).get(
            "interval_minutes"
        )
        return float(interval) * 60.0 if interval else 300.0

    def _snapshot_posts_comments(self, snapshot: Dict) -> Tuple[List[Dict], List[Dict]]:
        """Posts and comments created on a snapshot's day (legacy posts/comments
        keys if present, else converted from the snapshot's events)."""
        sim_data = snapshot["simulation_data"]
        posts = sim_data.get("posts", [])
        comments = sim_data.get("comments", [])
        if not posts and not comments:
            snapshot_events = sim_data.get("events", [])
            if snapshot_events:
                posts, comments = self._convert_events_to_posts_comments(
                    snapshot_events, snapshot["day"]
                )
            elif self.media_events:
                posts, comments = self._convert_events_to_posts_comments(
                    self.media_events, snapshot["day"]
                )
        return posts, comments

    def _find_root_post(self, parent_id: int, events: List[Dict] = None) -> int:
        """Find the root post ID for a reply by traversing up the parent chain"""
        if parent_id is None:
            return None

        events_to_search = self.media_events if self.media_events else (events or [])

        event_map = {e.get("event_id"): e for e in events_to_search}

        current_id = parent_id
        while current_id is not None:
            parent_event = event_map.get(current_id)
            if parent_event is None:
                break

            if parent_event.get("type", "").lower() == "post":
                return current_id

            current_id = parent_event.get("parent_id")

        return parent_id

    def load_daily_snapshots(self) -> List[Dict]:
        """Load all daily snapshot files"""
        snapshots = []

        if not self.snapshots_dir.exists():
            log.warning(f"Snapshots directory not found: {self.snapshots_dir}")
            return snapshots

        # Find all day_*_data.json files, in day order (a plain sort puts day_10 before day_2)
        def _day_number(path: Path) -> int:
            try:
                return int(path.stem.split("_")[1])
            except (IndexError, ValueError):
                return -1

        day_files = sorted(self.snapshots_dir.glob("day_*_data.json"), key=_day_number)

        for day_file in day_files:
            try:
                with open(day_file) as f:
                    snapshot = json.load(f)
                    snapshots.append(snapshot)
            except Exception as e:
                log.error(f"Error loading {day_file}: {e}")

        return snapshots

    def load_agent_profiles(self) -> Dict:
        """Load agent profiles from initialization"""
        profiles_file = self.input_dir / "agent_profiles.json"

        if not profiles_file.exists():
            parent_dir = self.input_dir.parent
            profiles_file = parent_dir / "agent_profiles.json"
            if profiles_file.exists():
                log.info(
                    f"Found agent_profiles.json in parent directory: {profiles_file}"
                )

        if not profiles_file.exists():
            parent_dir = self.input_dir.parent
            config_profiles = parent_dir / "config" / "agent_profiles.json"
            if config_profiles.exists():
                profiles_file = config_profiles
                log.info(
                    f"Found agent_profiles.json in config directory: {profiles_file}"
                )

        if not profiles_file.exists():
            log.warning(f"Agent profiles not found: {profiles_file}")
            return {}

        try:
            with open(profiles_file) as f:
                profiles = json.load(f)
                return {i: profile for i, profile in enumerate(profiles)}
        except Exception as e:
            log.error(f"Error loading agent profiles: {e}")
            return {}

    def load_config(self) -> Dict:
        """Load simulation configuration"""
        # Try both XML (old) and JSON (new) config formats
        config_file_xml = self.input_dir / "reddit_simulation_config.xml"
        config_file_json = self.input_dir / "simulation_config.json"

        if not config_file_json.exists() and not config_file_xml.exists():
            parent_dir = self.input_dir.parent
            config_file_xml = parent_dir / "reddit_simulation_config.xml"
            config_file_json = parent_dir / "simulation_config.json"
            if config_file_json.exists() or config_file_xml.exists():
                log.info(f"Found config file in parent directory")

        if config_file_json.exists():
            config_file = config_file_json
        else:
            config_file = config_file_xml

        if not config_file.exists():
            log.warning(f"Config file not found: {config_file}")
            return {}

        try:
            if config_file.suffix == ".json":
                with open(config_file) as f:
                    return json.load(f)

            tree = ET.parse(config_file)
            root = tree.getroot()

            config = {}
            models = root.find("models")
            if models is not None:
                config["models"] = [m.get("name") for m in models.findall("model")]

            return config
        except Exception as e:
            log.error(f"Error loading config: {e}")
            return {}

    def load_final_output(self) -> Dict:
        """Load final_output.json from simulation output (for mitigation summary, etc.)."""
        final_file = self.input_dir / "final_output.json"
        if not final_file.exists():
            return {}
        try:
            with open(final_file) as f:
                return json.load(f)
        except Exception as e:
            log.warning(f"Could not load final_output.json: {e}")
            return {}

    def _print_experiment_config_summary(self) -> None:
        """Print a short experiment config summary (mitigations, basic settings, run time)."""
        config = self.config_data
        print("\n=== Experiment Config Summary ===")
        run_sec = self.final_output.get("total_run_time_seconds")
        if run_sec is not None:
            if run_sec >= 60:
                m, s = divmod(run_sec, 60)
                print(f"  Total run time: {m:.0f}m {s:.1f}s ({run_sec:.2f} s)")
            else:
                print(f"  Total run time: {run_sec:.2f} s")
        if not config:
            return
        sim = config.get("simulation_config", {})
        mit = config.get("mitigation_config", {})
        biased = config.get("biased_moderator_config", {})
        print("\n=== Experiment Summary ===")
        print(
            f"  Duration: {sim.get('duration_days', '?')} days, interval: {sim.get('interval_minutes', '?')} min"
        )
        print(f"  Subreddit: {sim.get('target_subreddit', '?')}")
        print(
            f"  Agents: total={sim.get('total_agents', '?')} (llm_user={sim.get('num_llm_users', '?')}, "
            f"attacker={sim.get('num_attacker', '?')}, template_attacker={sim.get('num_template_attacker', '?')})"
        )
        print(
            f"  Stratify agent mix (proportional activity/frequency/session): "
            f"{sim.get('stratify_agent_mix', False)}"
        )
        print("  Mitigations:")
        print(
            f"    Duplicate detection: {mit.get('enable_duplicate_detection', False)} "
            f"(threshold={mit.get('duplicate_similarity_threshold', '?')}, "
            f"embedding_similarity={mit.get('use_embedding_similarity_for_duplicates', False)})"
        )
        print(f"    Rate limiting: {mit.get('enable_rate_limiting', False)}")
        print(
            f"    Coordinated detection: {mit.get('enable_coordinated_detection', False)}"
        )
        print(
            f"    Scan frequency: {mit.get('mitigation_scan_frequency', '?')} timesteps, ban threshold: {mit.get('mitigation_ban_threshold', '?')}"
        )
        print(
            f"    Rule moderators (feed LLM + remove + MitigationSystem flags): "
            f"{mit.get('enable_rule_moderators', False)} "
            f"(count={mit.get('rule_moderator_count', '?')}, "
            f"active_fraction={mit.get('rule_moderator_active_fraction', '?')}, "
            f"read_density={mit.get('rule_moderator_read_density', '?')}, "
            f"detection_threshold={mit.get('rule_moderator_detection_threshold', '?')})"
        )
        print(
            f"    Biased LLM moderator (belief-based scan/remove): "
            f"{biased.get('enable_biased_moderator', False)} "
            f"(scan_frequency={biased.get('biased_mod_scan_frequency', '?')} timesteps)"
        )

    def _print_mitigation_summary(self) -> None:
        """Print mitigation summary: bans, bans by type, attackers vs other agents."""
        summary = (
            self.final_output.get("mitigation_summary") if self.final_output else None
        )
        if not summary:
            print("\n=== Mitigation Summary ===")
            print(
                "  No mitigation summary in final output (mitigation system may not have been recorded)."
            )
            return
        banned_ids = summary.get("banned_agent_ids", [])
        type_by_id = summary.get("agent_type_by_id", {})
        flag_counts = summary.get("flag_counts_by_agent", {})
        banned_attackers = [
            i
            for i in banned_ids
            if type_by_id.get(str(i)) in ("llm_attacker", "template_attacker")
        ]
        banned_other = [
            i
            for i in banned_ids
            if type_by_id.get(str(i)) not in ("llm_attacker", "template_attacker")
        ]
        print("\n=== Mitigation Summary ===")
        print(f"  Total bans: {len(banned_ids)}")
        if banned_ids:
            print(
                f"    Banned attackers (llm_attacker/template_attacker): {len(banned_attackers)} {banned_attackers}"
            )
            print(f"    Banned other agents: {len(banned_other)} {banned_other}")
        print(
            f"  Agents flagged (pre-ban): {len([a for a, c in flag_counts.items() if c > 0])}"
        )
        if flag_counts:
            flagged = [(a, c) for a, c in flag_counts.items() if c > 0]
            for agent_id, count in sorted(flagged, key=lambda x: -x[1])[:10]:
                atype = type_by_id.get(agent_id, "?")
                print(f"    Agent {agent_id} ({atype}): {count} flags")
            if len(flagged) > 10:
                print(f"    ... and {len(flagged) - 10} more flagged agents")

    def analyze_belief_evolution(self) -> pd.DataFrame:
        """Track how beliefs changed over time (log the changes to csv)"""
        log.info("Analyzing belief evolution...")

        belief_timeline = []

        for snapshot in self.daily_snapshots:
            day = snapshot["day"]
            belief_states = snapshot["simulation_data"].get("belief_states", {})

            for agent_id, beliefs in belief_states.items():
                for belief_id, strength in beliefs.items():
                    belief_timeline.append(
                        {
                            "day": day,
                            "agent_id": int(agent_id),
                            "belief_id": belief_id,
                            "strength": strength,
                        }
                    )

        df = pd.DataFrame(belief_timeline)

        if not df.empty:
            output_file = self.analysis_dir / "belief_evolution.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved belief evolution to {output_file}")

            summary = (
                df.groupby(["agent_id", "belief_id"])
                .agg({"strength": ["mean", "std", "min", "max"]})
                .reset_index()
            )

            summary_file = self.analysis_dir / "belief_evolution_summary.csv"
            summary.to_csv(summary_file, index=False)
            log.info(f"Saved belief summary to {summary_file}")

        return df

    # Belief axes model

    @property
    def belief_axes_config(self):
        """The run's BeliefConfig when it used the belief axes model, else None."""
        from ..core.belief_axes import BeliefConfig

        model = (self.final_output or {}).get("belief_model")
        data = (self.final_output or {}).get("belief_config") or (self.config_data or {}).get(
            "belief_config"
        )
        if model is None and data:
            model = data.get("model")
        if model != "axes" or not data or not data.get("axes"):
            return None
        return BeliefConfig.from_dict({**data, "model": "axes"})

    def _axis_states_by_day(self) -> List[Tuple[int, Dict[str, Dict[str, float]]]]:
        """(day, {agent_id: positions}) with day -1 = initial positions."""
        days = []
        initial = self._initial_axis_states()
        if initial:
            days.append((-1, initial))
        for snapshot in self.daily_snapshots:
            days.append((snapshot["day"], snapshot["simulation_data"].get("belief_states", {})))
        return days

    def _initial_axis_states(self) -> Dict[str, Dict[str, float]]:
        return {
            str(i): dict(p.get("axis_positions") or {})
            for i, p in self.agent_profiles.items()
            if p.get("axis_positions")
        }

    def _organic_ids(self) -> Set[str]:
        return {
            str(i) for i, p in self.agent_profiles.items()
            if p.get("user_type") in ORGANIC_PROFILE_TYPES
        }

    def _analyze_axes_campaign_influence(self, config) -> pd.DataFrame:
        """Daily alignment of organic users with the campaign targets, plus every
        position (axis_positions.csv)."""
        from ..core.belief_axes import alignment

        targets = config.campaign_targets
        organic = self._organic_ids()
        rows, position_rows = [], []
        for day, states in self._axis_states_by_day():
            for agent_id, positions in states.items():
                agent_type = self.agent_profiles.get(int(agent_id), {}).get("user_type", "unknown")
                for axis in config.axes:
                    if axis.id in positions:
                        position_rows.append({
                            "day": day, "agent_id": agent_id, "agent_type": agent_type,
                            "axis_id": axis.id, "position": positions[axis.id],
                        })
                if agent_id in organic and targets:
                    rows.append({
                        "day": day, "agent_id": agent_id, "agent_type": agent_type,
                        "alignment": alignment(positions, targets),
                    })
        pd.DataFrame(position_rows).to_csv(self.analysis_dir / "axis_positions.csv", index=False)
        df = pd.DataFrame(rows)
        if df.empty:
            log.warning("Belief axes: no campaign targets or no organic users; no alignment computed")
            return df
        df.to_csv(self.analysis_dir / "campaign_influence.csv", index=False)
        summary = df.groupby("day")["alignment"].agg(["mean", "std", "count"]).reset_index()
        summary.to_csv(self.analysis_dir / "campaign_influence_summary.csv", index=False)
        print("\n=== Campaign Influence Analysis (belief axes: alignment with campaign targets) ===")
        for _, row in summary.iterrows():
            label = "Initial" if row["day"] == -1 else f"Day {int(row['day'])}"
            print(f"  {label}: {row['mean']:.4f}")
        return df

    def _analyze_axes_alignment_change(self, config) -> pd.DataFrame:
        """Initial vs final alignment with the campaign targets per organic user,
        and mean absolute position change over all axes."""
        from ..core.belief_axes import alignment

        targets = config.campaign_targets
        days = self._axis_states_by_day()
        if len(days) < 2 or not targets:
            log.warning("Belief axes: need campaign targets, initial positions and a snapshot")
            return pd.DataFrame()
        start, end = days[0][1], days[-1][1]
        rows = []
        for agent_id in sorted(self._organic_ids(), key=int):
            if agent_id not in start or agent_id not in end:
                continue
            s_pos, e_pos = start[agent_id], end[agent_id]
            shared = [a.id for a in config.axes if a.id in s_pos and a.id in e_pos]
            rows.append({
                "agent_id": agent_id,
                "agent_type": self.agent_profiles.get(int(agent_id), {}).get("user_type", "unknown"),
                "start_axis_alignment": alignment(s_pos, targets),
                "end_axis_alignment": alignment(e_pos, targets),
                "mean_abs_position_change": (
                    float(np.mean([abs(e_pos[a] - s_pos[a]) for a in shared])) if shared else 0.0
                ),
            })
        df = pd.DataFrame(rows)
        if df.empty:
            return df
        df["axis_alignment_change"] = df["end_axis_alignment"] - df["start_axis_alignment"]
        df.to_csv(self.analysis_dir / "belief_alignment_change.csv", index=False)
        summary = pd.DataFrame([
            {
                "metric": "axis_alignment",
                "start_mean": df["start_axis_alignment"].mean(),
                "start_std": df["start_axis_alignment"].std(),
                "end_mean": df["end_axis_alignment"].mean(),
                "end_std": df["end_axis_alignment"].std(),
                "change_mean": df["axis_alignment_change"].mean(),
                "change_std": df["axis_alignment_change"].std(),
            },
            {
                "metric": "mean_abs_position_change",
                "start_mean": 0.0, "start_std": 0.0,
                "end_mean": df["mean_abs_position_change"].mean(),
                "end_std": df["mean_abs_position_change"].std(),
                "change_mean": df["mean_abs_position_change"].mean(),
                "change_std": df["mean_abs_position_change"].std(),
            },
        ])
        summary.to_csv(self.analysis_dir / "belief_alignment_change_summary.csv", index=False)
        print("\n=== Belief Alignment Change (belief axes, initial vs end, organic users) ===")
        print(
            f"  Alignment with campaign targets: {df['start_axis_alignment'].mean():.4f} -> "
            f"{df['end_axis_alignment'].mean():.4f} ({df['axis_alignment_change'].mean():+.4f})"
        )
        print(f"  Mean absolute position change: {df['mean_abs_position_change'].mean():.4f}")
        return df

    def analyze_campaign_influence(self) -> pd.DataFrame:
        """Measure how agents' beliefs align with campaign narrative over time using canonical belief space."""
        axes_config = self.belief_axes_config
        if axes_config is not None:
            log.info("Analyzing campaign influence (belief axes)...")
            return self._analyze_axes_campaign_influence(axes_config)
        log.info("Analyzing campaign influence on agent beliefs...")

        # Step 0: Load canonical belief space
        clustering_meta = self.clustering_meta
        if clustering_meta:
            config = clustering_meta.get("config", {})
            log.info(
                f"Loaded {len(clustering_meta.get('cluster_details', []))} canonical beliefs"
            )
            log.info(
                f"  Clustering threshold: {config.get('cluster_threshold', 'N/A')}"
            )
            reduction_ratio = config.get("reduction_ratio")
            if reduction_ratio is not None:
                log.info(f"  Reduction ratio: {reduction_ratio:.1%}")
            else:
                log.info("  Reduction ratio: N/A")
        else:
            log.warning(
                "No clustering metadata found. Beliefs may not be canonicalized properly."
            )

        # Step 1: Get all unique belief IDs across the initial beliefs and all
        # snapshots (canonical belief space)
        initial_states = self._initial_belief_states()
        all_belief_ids = set()
        for agent_beliefs in initial_states.values():
            all_belief_ids.update(agent_beliefs.keys())
        for snapshot in self.daily_snapshots:
            belief_states = snapshot["simulation_data"].get("belief_states", {})
            for agent_beliefs in belief_states.values():
                all_belief_ids.update(agent_beliefs.keys())

        all_belief_ids = sorted(all_belief_ids)
        belief_id_to_index = {bid: idx for idx, bid in enumerate(all_belief_ids)}

        log.info(f"Canonical belief space has {len(all_belief_ids)} dimensions")

        # Step 2: Extract campaign belief vector (from attackers)
        attacker_ids = [
            i
            for i, profile in self.agent_profiles.items()
            if profile.get("user_type") in ("attacker", "template_attacker")
        ]

        if not attacker_ids:
            log.warning("No attackers found, cannot measure campaign influence")
            return pd.DataFrame()

        first_snapshot = self.daily_snapshots[0] if self.daily_snapshots else None
        if not first_snapshot:
            return pd.DataFrame()

        # Attackers' beliefs are fixed; take them from the initial beliefs when available
        belief_states = initial_states or first_snapshot["simulation_data"].get("belief_states", {})

        # Use the first attacker's beliefs as the campaign belief vector (since all are the same)
        campaign_vector = np.zeros(len(all_belief_ids))
        campaign_belief_ids = set()
        if attacker_ids:
            attacker_beliefs = belief_states.get(str(attacker_ids[0]), {})
            for belief_id, strength in attacker_beliefs.items():
                if belief_id in belief_id_to_index:
                    idx = belief_id_to_index[belief_id]
                    campaign_vector[idx] = strength
                    campaign_belief_ids.add(belief_id)

        # Expand campaign vector with semantically equivalent canonical beliefs
        # This allows non-attacker agents (who have canonical IDs) to show alignment
        # Use higher threshold (0.7) for embeddings, lower (0.5) for SequenceMatcher fallback
        similarity_threshold = 0.7 if SENTENCE_TRANSFORMERS_AVAILABLE else 0.5
        campaign_vector, campaign_belief_ids = (
            self._expand_campaign_vector_with_semantic_matches(
                campaign_vector,
                campaign_belief_ids,
                belief_id_to_index,
                first_snapshot,
                clustering_meta,
                similarity_threshold=similarity_threshold,
            )
        )

        log.info(
            f"Campaign belief vector: mean={campaign_vector.mean():.3f}, "
            f"std={campaign_vector.std():.3f}, "
            f"non-zero={np.sum(campaign_vector > 0)}/{len(campaign_vector)} "
            f"({len(campaign_belief_ids)} unique belief IDs)"
        )

        # Step 3: For the initial beliefs (day -1) and each day, calculate each
        # organic user's similarity. Moderators and attackers are excluded.
        influence_data = []
        series = []
        if initial_states:
            series.append((-1, initial_states))
        else:
            log.warning("No initial beliefs in agent profiles; baseline is the end of day 0")
        series += [
            (snapshot["day"], snapshot["simulation_data"].get("belief_states", {}))
            for snapshot in self.daily_snapshots
        ]

        for day, belief_states in series:
            for agent_id_str, agent_beliefs in belief_states.items():
                agent_id = int(agent_id_str)

                if agent_id not in self.organic_agent_ids:
                    continue

                profile = self.agent_profiles.get(agent_id, {})
                agent_type = profile.get("user_type", "regular")

                agent_vector = np.zeros(len(all_belief_ids))
                for belief_id, strength in agent_beliefs.items():
                    if belief_id in belief_id_to_index:
                        idx = belief_id_to_index[belief_id]
                        agent_vector[idx] = strength

                dot_product = np.dot(campaign_vector, agent_vector)
                campaign_norm = np.linalg.norm(campaign_vector)
                agent_norm = np.linalg.norm(agent_vector)

                if campaign_norm > 0 and agent_norm > 0:
                    cosine_sim = dot_product / (campaign_norm * agent_norm)
                else:
                    cosine_sim = 0.0

                euclidean_dist = np.linalg.norm(campaign_vector - agent_vector)
                # Strengths are in [0, 1], so the largest distance is sqrt(n)
                max_possible_dist = np.sqrt(len(all_belief_ids))
                euclidean_similarity = 1 - (euclidean_dist / max_possible_dist)

                campaign_beliefs_set = set(np.where(campaign_vector > 0)[0])
                agent_beliefs_set = set(np.where(agent_vector > 0)[0])
                overlap = len(campaign_beliefs_set & agent_beliefs_set)
                jaccard = (
                    overlap / len(campaign_beliefs_set | agent_beliefs_set)
                    if (campaign_beliefs_set | agent_beliefs_set)
                    else 0
                )

                influence_data.append(
                    {
                        "day": day,
                        "agent_id": agent_id,
                        "agent_type": agent_type,
                        "cosine_similarity": cosine_sim,
                        "euclidean_distance": euclidean_dist,
                        "euclidean_similarity": euclidean_similarity,
                        "alignment_score": dot_product,
                        "num_shared_beliefs": overlap,
                        "jaccard_similarity": jaccard,
                        "agent_belief_strength": agent_norm,
                        "num_agent_beliefs": len(agent_beliefs_set),
                    }
                )

        df = pd.DataFrame(influence_data)

        if not df.empty:
            output_file = self.analysis_dir / "campaign_influence.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved campaign influence data to {output_file}")

            summary = (
                df.groupby(["day", "agent_type"])
                .agg(
                    {
                        "cosine_similarity": ["mean", "std", "min", "max"],
                        "euclidean_similarity": ["mean", "std"],
                        "alignment_score": ["mean", "std"],
                        "num_shared_beliefs": ["mean", "std"],
                    }
                )
                .reset_index()
            )

            summary_file = self.analysis_dir / "campaign_influence_summary.csv"
            summary.to_csv(summary_file, index=False)
            log.info(f"Saved campaign influence summary to {summary_file}")

            print("\n=== Campaign Influence Analysis ===")

            # Group by day to see overall trend (day -1 = initial beliefs)
            daily_avg = df.groupby("day")["cosine_similarity"].mean()
            label = lambda d: "Initial" if d == -1 else f"Day {d}"
            print(f"\nAverage Cosine Similarity Trend (organic users):")
            print(f"  {label(daily_avg.index[0])}: {daily_avg.iloc[0]:.4f}")
            if len(daily_avg) > 1:
                print(f"  {label(daily_avg.index[-1])}: {daily_avg.iloc[-1]:.4f}")
                print(f"  Change: {daily_avg.iloc[-1] - daily_avg.iloc[0]:+.4f}")

            type_summary = df.groupby("agent_type")["cosine_similarity"].agg(
                ["mean", "std"]
            )
            print(f"\nAverage Similarity by Agent Type:")
            print(type_summary)

        return df

    def analyze_belief_alignment_change(self) -> pd.DataFrame:
        """
        Compare starting vs final belief alignment with campaign beliefs for non-attacker agents.

        This analysis measures how close agents' beliefs are to the campaign narrative
        at the start vs end of the simulation, showing the impact of the campaign.
        """
        axes_config = self.belief_axes_config
        if axes_config is not None:
            log.info("Analyzing belief alignment change (belief axes)...")
            return self._analyze_axes_alignment_change(axes_config)
        log.info("Analyzing belief alignment change (start vs end)...")

        attacker_ids = [
            i
            for i, profile in self.agent_profiles.items()
            if profile.get("user_type") in ("attacker", "template_attacker")
        ]

        if not attacker_ids:
            log.warning("No attackers found, cannot measure belief alignment change")
            return pd.DataFrame()

        # Start = initial beliefs (before the simulation); end = last snapshot.
        # The first snapshot is taken at the end of day 0, so using it as the
        # start would hide day-0 campaign influence.
        first_belief_states = self._initial_belief_states()
        if not self.daily_snapshots or (not first_belief_states and len(self.daily_snapshots) < 2):
            log.warning("Need initial beliefs plus a snapshot, or 2 snapshots, to compare start vs end")
            return pd.DataFrame()

        first_snapshot = self.daily_snapshots[0]
        last_snapshot = self.daily_snapshots[-1]

        if not first_belief_states:
            log.warning("No initial beliefs in agent profiles; using the end of day 0 as the start")
            first_belief_states = first_snapshot["simulation_data"].get("belief_states", {})
        last_belief_states = last_snapshot["simulation_data"].get("belief_states", {})

        # Build canonical belief space (all beliefs at the start and across all snapshots)
        all_belief_ids = set()
        for agent_beliefs in first_belief_states.values():
            all_belief_ids.update(agent_beliefs.keys())
        for snapshot in self.daily_snapshots:
            belief_states = snapshot["simulation_data"].get("belief_states", {})
            for agent_beliefs in belief_states.values():
                all_belief_ids.update(agent_beliefs.keys())

        all_belief_ids = sorted(all_belief_ids)
        belief_id_to_index = {bid: idx for idx, bid in enumerate(all_belief_ids)}

        # Extract campaign belief vector from attackers (from first snapshot)
        campaign_vector = np.zeros(len(all_belief_ids))
        campaign_belief_ids = set()

        # Extract campaign beliefs from any attacker
        if attacker_ids:
            attacker_beliefs = first_belief_states.get(str(attacker_ids[0]), {})
            for belief_id, strength in attacker_beliefs.items():
                if belief_id in belief_id_to_index:
                    idx = belief_id_to_index[belief_id]
                    campaign_vector[idx] = strength
                    campaign_belief_ids.add(belief_id)

        # Expand campaign vector with semantically equivalent canonical beliefs
        # This allows non-attacker agents (who have canonical IDs) to show alignment
        clustering_meta = self.clustering_meta

        # Use higher threshold (0.7) for embeddings, lower (0.5) for SequenceMatcher fallback
        similarity_threshold = 0.7 if SENTENCE_TRANSFORMERS_AVAILABLE else 0.5
        campaign_vector, campaign_belief_ids = (
            self._expand_campaign_vector_with_semantic_matches(
                campaign_vector,
                campaign_belief_ids,
                belief_id_to_index,
                first_snapshot,
                clustering_meta,
                similarity_threshold=similarity_threshold,
            )
        )

        if np.sum(campaign_vector) == 0:
            log.warning("Campaign belief vector is empty, cannot measure alignment")
            return pd.DataFrame()

        log.info(
            f"Campaign belief vector: {len(campaign_belief_ids)} beliefs, "
            f"mean strength={campaign_vector.mean():.3f}"
        )

        alignment_data = []

        # Organic users only (moderators and unsimulated "regular" profiles excluded)
        non_attacker_ids = sorted(self.organic_agent_ids)

        for agent_id in non_attacker_ids:
            agent_id_str = str(agent_id)
            profile = self.agent_profiles.get(agent_id, {})
            agent_type = profile.get("user_type", "regular")

            start_beliefs = first_belief_states.get(agent_id_str, {})
            start_vector = np.zeros(len(all_belief_ids))
            for belief_id, strength in start_beliefs.items():
                if belief_id in belief_id_to_index:
                    idx = belief_id_to_index[belief_id]
                    start_vector[idx] = strength

            end_beliefs = last_belief_states.get(agent_id_str, {})
            end_vector = np.zeros(len(all_belief_ids))
            for belief_id, strength in end_beliefs.items():
                if belief_id in belief_id_to_index:
                    idx = belief_id_to_index[belief_id]
                    end_vector[idx] = strength

            start_cosine = self._calculate_cosine_similarity(
                campaign_vector, start_vector
            )
            start_euclidean = self._calculate_euclidean_similarity(
                campaign_vector, start_vector
            )
            start_overlap = self._calculate_belief_overlap(
                campaign_belief_ids, start_beliefs.keys()
            )

            end_cosine = self._calculate_cosine_similarity(campaign_vector, end_vector)
            end_euclidean = self._calculate_euclidean_similarity(
                campaign_vector, end_vector
            )
            end_overlap = self._calculate_belief_overlap(
                campaign_belief_ids, end_beliefs.keys()
            )

            cosine_change = end_cosine - start_cosine
            euclidean_change = end_euclidean - start_euclidean
            overlap_change = end_overlap - start_overlap

            alignment_data.append(
                {
                    "agent_id": agent_id,
                    "agent_type": agent_type,
                    "start_cosine_similarity": start_cosine,
                    "end_cosine_similarity": end_cosine,
                    "cosine_change": cosine_change,
                    "start_euclidean_similarity": start_euclidean,
                    "end_euclidean_similarity": end_euclidean,
                    "euclidean_change": euclidean_change,
                    "start_shared_beliefs": start_overlap,
                    "end_shared_beliefs": end_overlap,
                    "shared_beliefs_change": overlap_change,
                    "start_num_beliefs": len(start_beliefs),
                    "end_num_beliefs": len(end_beliefs),
                    "num_beliefs_change": len(end_beliefs) - len(start_beliefs),
                }
            )

        df = pd.DataFrame(alignment_data)

        if not df.empty:
            output_file = self.analysis_dir / "belief_alignment_change.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved belief alignment change data to {output_file}")

            summary_stats = {
                "metric": [],
                "start_mean": [],
                "start_std": [],
                "end_mean": [],
                "end_std": [],
                "change_mean": [],
                "change_std": [],
            }

            for metric in [
                "cosine_similarity",
                "euclidean_similarity",
                "shared_beliefs",
            ]:
                start_col = f"start_{metric}"
                end_col = f"end_{metric}"
                change_col = f"{metric.replace('_similarity', '')}_change"

                if start_col in df.columns and end_col in df.columns:
                    summary_stats["metric"].append(metric)
                    summary_stats["start_mean"].append(df[start_col].mean())
                    summary_stats["start_std"].append(df[start_col].std())
                    summary_stats["end_mean"].append(df[end_col].mean())
                    summary_stats["end_std"].append(df[end_col].std())
                    if change_col in df.columns:
                        summary_stats["change_mean"].append(df[change_col].mean())
                        summary_stats["change_std"].append(df[change_col].std())
                    else:
                        summary_stats["change_mean"].append(None)
                        summary_stats["change_std"].append(None)

            summary_df = pd.DataFrame(summary_stats)
            summary_file = self.analysis_dir / "belief_alignment_change_summary.csv"
            summary_df.to_csv(summary_file, index=False)
            log.info(f"Saved belief alignment change summary to {summary_file}")

            print("\n=== Belief Alignment Change Analysis (Initial vs End, organic users) ===")
            print(f"\nAverage Cosine Similarity:")
            print(
                f"  Start: {df['start_cosine_similarity'].mean():.4f} ± {df['start_cosine_similarity'].std():.4f}"
            )
            print(
                f"  End:   {df['end_cosine_similarity'].mean():.4f} ± {df['end_cosine_similarity'].std():.4f}"
            )
            print(
                f"  Change: {df['cosine_change'].mean():+.4f} ± {df['cosine_change'].std():.4f}"
            )

            print(f"\nAverage Shared Campaign Beliefs:")
            print(
                f"  Start: {df['start_shared_beliefs'].mean():.2f} ± {df['start_shared_beliefs'].std():.2f}"
            )
            print(
                f"  End:   {df['end_shared_beliefs'].mean():.2f} ± {df['end_shared_beliefs'].std():.2f}"
            )
            print(
                f"  Change: {df['shared_beliefs_change'].mean():+.2f} ± {df['shared_beliefs_change'].std():.2f}"
            )

            if "agent_type" in df.columns:
                type_summary = df.groupby("agent_type")["cosine_change"].agg(
                    ["mean", "std", "count"]
                )
                print(f"\nAverage Cosine Change by Agent Type:")
                print(type_summary)

            self._visualize_belief_alignment_change(df)

        return df

    def _visualize_belief_alignment_change(self, df: pd.DataFrame) -> None:
        """Generate visualization plots for belief alignment change"""
        try:
            import matplotlib.pyplot as plt
        except ImportError:
            log.warning("matplotlib not installed, skipping visualization")
            return

        if df.empty:
            return

        fig, axes = plt.subplots(2, 2, figsize=(16, 12))

        # Plot 1: Distribution of cosine similarity change
        axes[0, 0].hist(
            df["cosine_change"],
            bins=30,
            edgecolor="black",
            alpha=0.7,
            color="steelblue",
        )
        axes[0, 0].axvline(
            df["cosine_change"].mean(),
            color="red",
            linestyle="--",
            linewidth=2,
            label=f"Mean: {df['cosine_change'].mean():.4f}",
        )
        axes[0, 0].axvline(0, color="black", linestyle="-", linewidth=1, alpha=0.3)
        axes[0, 0].set_xlabel("Cosine Similarity Change (End - Start)")
        axes[0, 0].set_ylabel("Number of Agents")
        axes[0, 0].set_title("Distribution of Belief Alignment Change")
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)

        # Plot 2: Start vs End cosine similarity scatter
        axes[0, 1].scatter(
            df["start_cosine_similarity"],
            df["end_cosine_similarity"],
            alpha=0.6,
            s=50,
            c=df["cosine_change"],
            cmap="RdYlGn",
            edgecolors="black",
            linewidth=0.5,
        )
        # Add diagonal line (no change)
        max_val = max(
            df["start_cosine_similarity"].max(), df["end_cosine_similarity"].max()
        )
        min_val = min(
            df["start_cosine_similarity"].min(), df["end_cosine_similarity"].min()
        )
        axes[0, 1].plot(
            [min_val, max_val],
            [min_val, max_val],
            "k--",
            alpha=0.5,
            label="No change",
        )
        axes[0, 1].set_xlabel("Start Cosine Similarity")
        axes[0, 1].set_ylabel("End Cosine Similarity")
        axes[0, 1].set_title("Start vs End Alignment (colored by change)")
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        cbar = plt.colorbar(axes[0, 1].collections[0], ax=axes[0, 1])
        cbar.set_label("Change (End - Start)")

        # Plot 3: Change by agent type
        if "agent_type" in df.columns and df["agent_type"].nunique() > 1:
            type_change = df.groupby("agent_type")["cosine_change"].agg(["mean", "std"])
            y_pos = np.arange(len(type_change))
            axes[1, 0].barh(
                y_pos,
                type_change["mean"],
                xerr=type_change["std"],
                edgecolor="black",
                alpha=0.7,
            )
            axes[1, 0].axvline(0, color="black", linestyle="-", linewidth=1)
            axes[1, 0].set_yticks(y_pos)
            axes[1, 0].set_yticklabels(type_change.index)
            axes[1, 0].set_xlabel("Average Cosine Similarity Change")
            axes[1, 0].set_title("Alignment Change by Agent Type")
            axes[1, 0].grid(True, alpha=0.3, axis="x")
        else:
            axes[1, 0].text(
                0.5,
                0.5,
                "Insufficient agent type diversity",
                ha="center",
                va="center",
            )
            axes[1, 0].set_title("Alignment Change by Agent Type")

        # Plot 4: Shared beliefs change
        axes[1, 1].scatter(
            df["start_shared_beliefs"],
            df["end_shared_beliefs"],
            alpha=0.6,
            s=50,
            c=df["shared_beliefs_change"],
            cmap="RdYlGn",
            edgecolors="black",
            linewidth=0.5,
        )
        max_shared = max(
            df["start_shared_beliefs"].max(), df["end_shared_beliefs"].max()
        )
        if max_shared > 0:
            axes[1, 1].plot(
                [0, max_shared],
                [0, max_shared],
                "k--",
                alpha=0.5,
                label="No change",
            )
        axes[1, 1].set_xlabel("Start Shared Campaign Beliefs")
        axes[1, 1].set_ylabel("End Shared Campaign Beliefs")
        axes[1, 1].set_title("Shared Campaign Beliefs: Start vs End")
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        if len(axes[1, 1].collections) > 0:
            cbar2 = plt.colorbar(axes[1, 1].collections[0], ax=axes[1, 1])
            cbar2.set_label("Change (End - Start)")

        plt.tight_layout()
        output_file = self.analysis_dir / "belief_alignment_change_visualization.png"
        plt.savefig(output_file, dpi=300, bbox_inches="tight")
        plt.close()
        log.info(f"Saved belief alignment change visualization to {output_file}")

    def _calculate_cosine_similarity(self, vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity between two vectors"""
        dot_product = np.dot(vec1, vec2)
        norm1 = np.linalg.norm(vec1)
        norm2 = np.linalg.norm(vec2)
        if norm1 > 0 and norm2 > 0:
            return dot_product / (norm1 * norm2)
        return 0.0

    def _calculate_euclidean_similarity(
        self, vec1: np.ndarray, vec2: np.ndarray
    ) -> float:
        """Calculate normalized Euclidean similarity (1 - normalized distance)"""
        euclidean_dist = np.linalg.norm(vec1 - vec2)
        # Strengths are in [0, 1], so the largest distance (all 0s vs all 1s) is sqrt(n)
        max_possible_dist = np.sqrt(len(vec1))
        if max_possible_dist > 0:
            return 1 - (euclidean_dist / max_possible_dist)
        return 0.0

    def _calculate_belief_overlap(self, set1: set, set2: set) -> int:
        """Calculate number of overlapping beliefs between two sets"""
        return len(set1 & set2)

    def _init_embedder(self) -> bool:
        """Lazy initialization of sentence transformer embedder"""
        if self._embedder is not None:
            return True
        if not SENTENCE_TRANSFORMERS_AVAILABLE:
            return False
        try:
            self._embedder = SentenceTransformer(self._embedder_model)
            log.info(f"Initialized embedder: {self._embedder_model}")
            return True
        except Exception as e:
            log.warning(f"Failed to initialize embedder: {e}")
            return False

    def _text_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate text similarity between two strings (0-1).
        Encodes texts to embeddings using the model, then computes cosine similarity
        between the embedding vectors. Falls back to SequenceMatcher if embeddings unavailable.
        """
        if not text1 or not text2:
            return 0.0

        # Try embedding-based similarity first
        if self._init_embedder() and self._embedder is not None:
            try:
                t1 = " ".join(text1.lower().split())
                t2 = " ".join(text2.lower().split())

                embeddings = self._embedder.encode([t1, t2], convert_to_numpy=True)

                similarity = self._calculate_cosine_similarity(
                    embeddings[0], embeddings[1]
                )
                return float(similarity)
            except Exception as e:
                log.warning(
                    f"Embedding similarity failed, falling back to SequenceMatcher: {e}"
                )

        # Fallback to SequenceMatcher
        t1 = " ".join(text1.lower().split())
        t2 = " ".join(text2.lower().split())
        return SequenceMatcher(None, t1, t2).ratio()

    def _find_semantically_equivalent_beliefs(
        self,
        campaign_belief_texts: Dict[str, str],
        canonical_beliefs: Dict[str, str],
        similarity_threshold: float = 0.6,
    ) -> Dict[str, Set[str]]:
        """
        Map campaign belief IDs to semantically equivalent canonical belief IDs.

        Args:
            campaign_belief_texts: Dict mapping campaign_belief_id -> belief_text
            canonical_beliefs: Dict mapping canonical_belief_id -> canonical_text
            similarity_threshold: Minimum text similarity to consider beliefs equivalent (0-1)

        Returns:
            Dict mapping campaign_belief_id -> set of equivalent canonical_belief_ids
        """
        mapping = {}
        judged_rows = []

        for campaign_id, campaign_text in campaign_belief_texts.items():
            # Embedding similarity measures topic, not stance ("X is good" vs "X is
            # not good" score ~0.95), so it only picks candidates; each candidate's
            # stance toward the campaign claim is then judged by the LLM.
            candidates = []
            for canonical_id, canonical_text in canonical_beliefs.items():
                similarity = self._text_similarity(campaign_text, canonical_text)
                if similarity >= similarity_threshold:
                    candidates.append((canonical_id, canonical_text, similarity))
            stances, method = self._judge_campaign_stances(campaign_text, candidates)
            mapping[campaign_id] = {cid for cid, _, _ in candidates if stances.get(cid) == "support"}
            judged_rows += [
                {
                    "campaign_belief_id": campaign_id,
                    "campaign_text": campaign_text,
                    "canonical_belief_id": cid,
                    "canonical_text": text,
                    "similarity": round(sim, 4),
                    "stance": stances.get(cid, "unknown"),
                    "method": method,
                }
                for cid, text, sim in candidates
            ]

        if judged_rows:
            df = pd.DataFrame(judged_rows)
            df.to_csv(self.analysis_dir / "campaign_stance_matches.csv", index=False)
            counts = df["stance"].value_counts().to_dict()
            log.info(f"Campaign semantic expansion: candidate stances {counts} "
                     f"(only 'support' counts as campaign-aligned)")
        self._save_stance_cache()
        return mapping

    # Stance judging for campaign semantic expansion

    _STANCES = ("support", "oppose", "unrelated")

    def _stance_cache_path(self) -> Path:
        return self.analysis_dir / "campaign_stance_cache.json"

    def _load_stance_cache(self) -> Dict[str, str]:
        if getattr(self, "_stance_cache", None) is None:
            self._stance_cache = {}
            try:
                with open(self._stance_cache_path(), encoding="utf-8") as f:
                    self._stance_cache = json.load(f).get("stances", {})
            except (OSError, ValueError):
                pass
        return self._stance_cache

    def _save_stance_cache(self) -> None:
        if getattr(self, "_stance_cache", None):
            with open(self._stance_cache_path(), "w", encoding="utf-8") as f:
                json.dump({"stances": self._stance_cache}, f, indent=1, ensure_ascii=False)

    @staticmethod
    def _stance_key(campaign_text: str, canonical_text: str) -> str:
        import hashlib

        return hashlib.sha1(f"{campaign_text}\n||\n{canonical_text}".encode("utf-8")).hexdigest()

    def _judge_campaign_stances(
        self, campaign_text: str, candidates: List[Tuple[str, str, float]]
    ) -> Tuple[Dict[str, str], str]:
        """canonical_id -> "support" / "oppose" / "unrelated" for each candidate.

        One LLM call per campaign claim (temperature 0), cached in the analysis
        dir (campaign_stance_cache.json) so re-analysis is free and repeatable.
        Falls back to the strict NLI same-belief rule if no LLM is available.
        """
        if not candidates:
            return {}, "none"
        cache = self._load_stance_cache()
        stances = {}
        todo = []
        for cid, text, sim in candidates:
            cached = cache.get(self._stance_key(campaign_text, text))
            if cached in self._STANCES:
                stances[cid] = cached
            else:
                todo.append((cid, text, sim))
        if not todo:
            return stances, "llm (cached)"

        judged = self._llm_judge_stances(campaign_text, [(cid, text) for cid, text, _ in todo])
        if judged is not None:
            for cid, text, _ in todo:
                stances[cid] = judged[cid]
                cache[self._stance_key(campaign_text, text)] = judged[cid]
            return stances, "llm"

        nli = self._get_nli()
        if nli is None:
            log.warning("No LLM or NLI available for campaign stance; candidates treated as unrelated")
            stances.update({cid: "unrelated" for cid, _, _ in todo})
            return stances, "none"
        log.warning("LLM stance judging unavailable; falling back to strict NLI same-belief rule")
        same = nli.same_belief_many([(campaign_text, t) for _, t, _ in todo], [s for _, _, s in todo])
        stances.update({cid: ("support" if ok else "unrelated") for (cid, _, _), ok in zip(todo, same)})
        return stances, "nli fallback"

    def _llm_judge_stances(
        self, campaign_text: str, items: List[Tuple[str, str]]
    ) -> Optional[Dict[str, str]]:
        """Ask the LLM for each statement's stance toward the campaign claim; None on failure."""
        if getattr(self, "_llm_provider_checked", False) is False:
            self._llm_provider_checked, self._llm = True, None
            try:
                try:
                    from ..services.llm_provider import get_llm_provider
                    from ..services.llm_json import complete_json
                except ImportError:
                    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
                    from python_simulation.services.llm_provider import get_llm_provider
                    from python_simulation.services.llm_json import complete_json
                provider = get_llm_provider()
                if provider.is_available():
                    self._llm, self._complete_json = provider, complete_json
            except Exception as e:
                log.warning(f"LLM provider unavailable for stance judging: {e}")
        if self._llm is None:
            return None

        aliases = {f"s{i}": cid for i, (cid, _) in enumerate(items, start=1)}
        statements = "\n".join(f"[s{i}] {text}" for i, (_, text) in enumerate(items, start=1))
        prompt = f"""Campaign claim: "{campaign_text}"

For each numbered statement below, decide its stance toward the campaign claim:
- "support": someone holding the statement agrees with the claim or argues in the same direction
- "oppose": someone holding the statement disagrees with the claim or argues the opposite direction
- "unrelated": neither (different topic, or neutral)

Statements:
{statements}

Return ONLY JSON with one entry per statement:
{{"judgements": [{{"id": "s1", "stance": "support"}}, ...]}}"""

        def validate(data):
            out = {}
            for j in data:
                if isinstance(j, dict) and j.get("id") in aliases:
                    stance = str(j.get("stance", "")).strip().lower()
                    if stance in self._STANCES:
                        out[aliases[j["id"]]] = stance
            missing = [a for a, cid in aliases.items() if cid not in out]
            if missing:
                return None, f"missing or invalid stance for {', '.join(missing)}"
            return out, ""

        result = self._complete_json(
            self._llm,
            [{"role": "user", "content": prompt}],
            temperature=0.0,
            max_tokens=60 + 25 * len(items),
            expect=list,
            wrap_key="judgements",
            validate=validate,
            label="Campaign stance judging",
        )
        return result.data if result.ok else None

    def _get_nli(self):
        """Shared NLI checker (services/belief_nli.py), or None if unavailable.
        Without it, expansion falls back to similarity only and may count
        opposite-stance beliefs as campaign-aligned."""
        if getattr(self, "_nli_checked", False):
            return self._nli
        self._nli_checked, self._nli = True, None
        try:
            try:
                from ..services.belief_nli import get_belief_nli
            except ImportError:
                # Run as a plain script: make the package importable
                sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
                from python_simulation.services.belief_nli import get_belief_nli
            self._nli = get_belief_nli()
        except Exception as e:
            log.warning(
                f"NLI checker unavailable ({e}); campaign semantic expansion uses "
                "similarity only and may count opposite-stance beliefs as aligned"
            )
        return self._nli

    def _expand_campaign_vector_with_semantic_matches(
        self,
        campaign_vector: np.ndarray,
        campaign_belief_ids: Set[str],
        belief_id_to_index: Dict[str, int],
        first_snapshot: Dict,
        clustering_meta: Dict = None,
        similarity_threshold: float = 0.6,
    ) -> Tuple[np.ndarray, Set[str]]:
        """
        Expand campaign vector to include semantically equivalent canonical beliefs.

        This allows non-attacker agents (who have canonical IDs, not campaign_* IDs)
        to show alignment with the campaign narrative.

        Returns:
            (expanded_campaign_vector, expanded_campaign_belief_ids)
        """
        expanded_vector = campaign_vector.copy()
        expanded_campaign_belief_ids = set(campaign_belief_ids)

        belief_text_registry = first_snapshot.get("simulation_data", {}).get(
            "belief_text_registry", {}
        )
        if not belief_text_registry:
            # Fallback: try to load from config
            config = self.load_config()
            campaign_config = config.get("campaign_config", {})
            belief_text_registry = campaign_config.get("campaign_belief_texts", {})

        if not belief_text_registry:
            log.warning(
                "No campaign belief texts found, cannot expand campaign vector semantically"
            )
            return expanded_vector, expanded_campaign_belief_ids

        campaign_belief_texts = {
            bid: text
            for bid, text in belief_text_registry.items()
            if bid.startswith("campaign_")
        }

        if not campaign_belief_texts:
            log.warning("No campaign_* belief texts found in registry")
            return expanded_vector, expanded_campaign_belief_ids

        canonical_beliefs = {}
        if clustering_meta and "cluster_details" in clustering_meta:
            for cluster in clustering_meta["cluster_details"]:
                canonical_id = cluster.get("belief_id")
                canonical_text = cluster.get("canonical_text")
                if canonical_id and canonical_text:
                    canonical_beliefs[canonical_id] = canonical_text

        if not canonical_beliefs:
            log.warning(
                "No canonical belief texts found, cannot expand campaign vector semantically"
            )
            return expanded_vector, expanded_campaign_belief_ids

        semantic_mapping = self._find_semantically_equivalent_beliefs(
            campaign_belief_texts, canonical_beliefs, similarity_threshold
        )

        # Expand campaign vector with matched canonical beliefs
        # Use the same strength as the matching campaign belief
        matches_found = 0
        for campaign_id, equivalent_canonical_ids in semantic_mapping.items():
            if campaign_id not in belief_id_to_index:
                continue
            campaign_idx = belief_id_to_index[campaign_id]
            campaign_strength = expanded_vector[campaign_idx]

            for canonical_id in equivalent_canonical_ids:
                if canonical_id in belief_id_to_index:
                    canonical_idx = belief_id_to_index[canonical_id]
                    # Use the campaign belief strength (or max if already set)
                    expanded_vector[canonical_idx] = max(
                        expanded_vector[canonical_idx], campaign_strength
                    )
                    expanded_campaign_belief_ids.add(canonical_id)
                    matches_found += 1

        if matches_found > 0:
            log.info(
                f"Expanded campaign vector with {matches_found} semantically equivalent canonical beliefs "
                f"(threshold={similarity_threshold:.2f})"
            )
        else:
            log.warning(
                f"No semantic matches found between campaign and canonical beliefs "
                f"(threshold={similarity_threshold:.2f})"
            )

        return expanded_vector, expanded_campaign_belief_ids

    def analyze_agent_activity(self) -> pd.DataFrame:
        """Analyze agent activity patterns"""
        log.info("Analyzing agent activity...")

        activity_data = []

        for snapshot in self.daily_snapshots:
            day = snapshot["day"]
            agent_activity = snapshot["simulation_data"].get("agent_activity", {})
            if not agent_activity:
                # Python sim snapshots don't carry agent_activity; derive it from the
                # day's posts/comments. Votes = votes that content received by run end.
                posts, comments = self._snapshot_posts_comments(snapshot)
                for item, key in [(x, "posts_count") for x in posts] + [
                    (x, "comments_count") for x in comments
                ]:
                    uid = item.get("user_id")
                    if uid is None or item.get("seed") or int(uid) < 0:
                        continue  # seed content accounts are not agents
                    a = agent_activity.setdefault(
                        str(uid),
                        {
                            "agent_name": self.agent_profiles.get(int(uid), {}).get("username", ""),
                            "posts_count": 0,
                            "comments_count": 0,
                            "total_upvotes_received": 0,
                            "total_downvotes_received": 0,
                        },
                    )
                    a[key] += 1
                    a["total_upvotes_received"] += item.get("upvotes", 0)
                    a["total_downvotes_received"] += item.get("downvotes", 0)
                for a in agent_activity.values():
                    a["net_score"] = a["total_upvotes_received"] - a["total_downvotes_received"]

            for agent_id, activity in agent_activity.items():
                agent_id_int = int(agent_id)

                profile = self.agent_profiles.get(agent_id_int, {})

                activity_data.append(
                    {
                        "day": day,
                        "agent_id": agent_id_int,
                        "agent_name": activity.get("agent_name", ""),
                        "agent_type": activity.get(
                            "agent_type", profile.get("user_type", "regular")
                        ),
                        "posts_count": activity.get("posts_count", 0),
                        "comments_count": activity.get("comments_count", 0),
                        "total_upvotes": activity.get("total_upvotes_received", 0),
                        "total_downvotes": activity.get("total_downvotes_received", 0),
                        "net_score": activity.get("net_score", 0),
                    }
                )

        df = pd.DataFrame(activity_data)

        if not df.empty:
            output_file = self.analysis_dir / "agent_activity.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved agent activity to {output_file}")

            agent_summary = (
                df.groupby("agent_id")
                .agg(
                    {
                        "posts_count": "sum",
                        "comments_count": "sum",
                        "total_upvotes": "sum",
                        "total_downvotes": "sum",
                        "net_score": "sum",
                    }
                )
                .reset_index()
            )

            agent_summary["agent_type"] = agent_summary["agent_id"].apply(
                lambda x: self.agent_profiles.get(x, {}).get("user_type", "regular")
            )

            summary_file = self.analysis_dir / "agent_activity_summary.csv"
            agent_summary.to_csv(summary_file, index=False)
            log.info(f"Saved agent summary to {summary_file}")

            type_summary = (
                df.groupby("agent_type")
                .agg(
                    {
                        "posts_count": ["sum", "mean"],
                        "comments_count": ["sum", "mean"],
                        "total_upvotes": ["sum", "mean"],
                        "total_downvotes": ["sum", "mean"],
                        "net_score": ["sum", "mean"],
                    }
                )
                .reset_index()
            )

            type_file = self.analysis_dir / "activity_by_type.csv"
            type_summary.to_csv(type_file, index=False)
            log.info(f"Saved type summary to {type_file}")

        return df

    def analyze_campaign_effectiveness(self) -> pd.DataFrame:
        """Analyze attacker campaign effectiveness"""
        log.info("Analyzing campaign effectiveness...")

        campaign_metrics = []

        for snapshot in self.daily_snapshots:
            day = snapshot["day"]
            posts, comments = self._snapshot_posts_comments(snapshot)

            # Filter by author type
            attacker_types = ("attacker", "llm_attacker", "template_attacker")
            attacker_posts = [
                p for p in posts if p.get("author_type") in attacker_types
            ]
            attacker_comments = [
                c for c in comments if c.get("author_type") in attacker_types
            ]

            llm_posts = [p for p in posts if p.get("author_type") == "llm_user"]
            regular_posts = [p for p in posts if p.get("author_type") == "regular"]

            total_posts = len(posts)
            total_comments = len(comments)

            # Engagement: votes the day's attacker posts received by the end of the
            # run. "community_" columns exclude votes cast by attackers.
            attacker_upvotes = sum(p.get("upvotes", 0) for p in attacker_posts)
            attacker_downvotes = sum(p.get("downvotes", 0) for p in attacker_posts)
            community_up = sum(p.get("community_upvotes", 0) for p in attacker_posts)
            community_down = sum(p.get("community_downvotes", 0) for p in attacker_posts)

            campaign_metrics.append(
                {
                    "day": day,
                    "total_posts": total_posts,
                    "total_comments": total_comments,
                    "attacker_posts": len(attacker_posts),
                    "attacker_comments": len(attacker_comments),
                    "llm_posts": len(llm_posts),
                    "regular_posts": len(regular_posts),
                    "attacker_post_ratio": len(attacker_posts) / max(1, total_posts),
                    "attacker_upvotes": attacker_upvotes,
                    "attacker_downvotes": attacker_downvotes,
                    "attacker_net_score": attacker_upvotes - attacker_downvotes,
                    "avg_attacker_score": (attacker_upvotes - attacker_downvotes)
                    / max(1, len(attacker_posts)),
                    "attacker_community_upvotes": community_up,
                    "attacker_community_downvotes": community_down,
                    "attacker_community_net_score": community_up - community_down,
                    # Attacker-on-attacker votes (a coordination signal)
                    "attacker_votes_from_attackers": (attacker_upvotes - community_up)
                    + (attacker_downvotes - community_down),
                }
            )

        df = pd.DataFrame(campaign_metrics)

        if not df.empty:
            output_file = self.analysis_dir / "campaign_effectiveness.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved campaign effectiveness to {output_file}")

        return df

    def analyze_discourse_dynamics(self) -> pd.DataFrame:
        """Analyze overall discourse dynamics"""
        log.info("Analyzing discourse dynamics...")

        dynamics = []

        for snapshot in self.daily_snapshots:
            day = snapshot["day"]
            posts, comments = self._snapshot_posts_comments(snapshot)

            total_upvotes = sum(p.get("upvotes", 0) for p in posts)
            total_downvotes = sum(p.get("downvotes", 0) for p in posts)

            sorted_posts = sorted(posts, key=lambda x: x.get("score", 0), reverse=True)
            top_post_score = sorted_posts[0].get("score", 0) if sorted_posts else 0

            posts_with_comments = len(
                set(c.get("root_post_id") for c in comments if c.get("root_post_id"))
            )
            avg_comments_per_post = len(comments) / max(1, len(posts))

            dynamics.append(
                {
                    "day": day,
                    "total_posts": len(posts),
                    "total_comments": len(comments),
                    "total_upvotes": total_upvotes,
                    "total_downvotes": total_downvotes,
                    "net_score": total_upvotes - total_downvotes,
                    "top_post_score": top_post_score,
                    "posts_with_comments": posts_with_comments,
                    "avg_comments_per_post": avg_comments_per_post,
                }
            )

        df = pd.DataFrame(dynamics)

        if not df.empty:
            output_file = self.analysis_dir / "discourse_dynamics.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved discourse dynamics to {output_file}")

        return df

    def analyze_mitigation_effectiveness(self) -> pd.DataFrame:
        """Analyze which agents were flagged/banned and accuracy of detections"""
        log.info("Analyzing mitigation effectiveness...")

        mitigation_data = []

        # Per-day mitigation data is written into snapshots by the sim; older runs
        # only have end-of-run totals in final_output.json -> one row set for the last day
        sources = [(s["day"], s.get("mitigation_data", {})) for s in self.daily_snapshots]
        if not any(info for _, info in sources):
            summary = (self.final_output or {}).get("mitigation_summary", {})
            if summary.get("flag_counts_by_agent") or summary.get("banned_agent_ids"):
                log.info(
                    "No per-day mitigation data in snapshots (older run); "
                    "using end-of-run totals from final_output.json"
                )
                last_day = self.daily_snapshots[-1]["day"] if self.daily_snapshots else 0
                sources = [(last_day, {
                    "flagged_agents": summary.get("flag_counts_by_agent", {}),
                    "banned_agents": [str(a) for a in summary.get("banned_agent_ids", [])],
                })]

        for day, mitigation_info in sources:
            flagged_agents = mitigation_info.get("flagged_agents", {})
            banned_agents = mitigation_info.get("banned_agents", [])

            for agent_id_str, flags in flagged_agents.items():
                agent_id = int(agent_id_str)
                agent_profile = self.agent_profiles.get(agent_id, {})
                actual_type = agent_profile.get("user_type", "regular")

                mitigation_data.append(
                    {
                        "day": day,
                        "agent_id": agent_id,
                        "actual_type": actual_type,
                        "flags": flags,
                        "banned": agent_id_str in banned_agents,
                        "true_positive": actual_type
                        in ("attacker", "template_attacker")
                        and agent_id_str in banned_agents,
                        "false_positive": actual_type
                        not in ("attacker", "template_attacker")
                        and agent_id_str in banned_agents,
                    }
                )

        df = pd.DataFrame(mitigation_data)

        if not df.empty:
            total_attackers = sum(
                1
                for p in self.agent_profiles.values()
                if p.get("user_type") in ("attacker", "template_attacker")
            )
            attackers_caught = df[df["true_positive"]]["agent_id"].nunique()
            false_positives = df[df["false_positive"]]["agent_id"].nunique()

            print("\n=== Mitigation Effectiveness ===")
            print(f"Total attackers: {total_attackers}")
            if total_attackers > 0:
                print(
                    f"Attackers caught: {attackers_caught} ({attackers_caught/total_attackers*100:.1f}%)"
                )
            else:
                print("Attackers caught: 0 (no attackers in simulation)")
            print(f"False positives: {false_positives}")

            output_file = self.analysis_dir / "mitigation_effectiveness.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved mitigation analysis to {output_file}")
        else:
            log.info(
                "No mitigation data found in snapshots (mitigations may not be enabled)"
            )

        return df

    def analyze_biased_moderation(self) -> pd.DataFrame:
        """Analyze biased moderator actions and their impact."""
        log.info("Analyzing biased moderation...")

        mod_data = []

        for snapshot in self.daily_snapshots:
            day = snapshot["day"]

            mod_actions = snapshot.get("biased_moderation_log", [])

            for action in mod_actions:
                mod_data.append(
                    {
                        "day": day,
                        "timestep": action.get("timestep", -1),
                        "target_agent": action.get("target_agent_id", -1),
                        "action_type": action.get("action_type", "unknown"),
                        "contradiction_score": action.get("contradiction_score", 0.0),
                        "public_justification": action.get("public_justification", ""),
                        "private_reasoning": action.get("private_reasoning", ""),
                        "content": action.get("content", "")[:100],
                    }
                )

        df = pd.DataFrame(mod_data)

        if not df.empty:
            total_actions = len(df)
            unique_targets = df["target_agent"].nunique()
            removals = len(df[df["action_type"].str.contains("remove", na=False)])
            bans = len(df[df["action_type"] == "ban_user"])
            avg_score = df["contradiction_score"].mean()

            target_types = {}
            for agent_id in df["target_agent"].unique():
                agent_profile = self.agent_profiles.get(int(agent_id), {})
                agent_type = agent_profile.get("user_type", "regular")
                target_types[agent_type] = target_types.get(agent_type, 0) + 1

            print("\n=== Biased Moderation Analysis ===")
            print(f"Total actions: {total_actions}")
            print(f"Unique agents targeted: {unique_targets}")
            print(f"  Removals: {removals}")
            print(f"  Bans: {bans}")
            print(f"Average contradiction score: {avg_score:.3f}")
            print("\nTargeted agent types:")
            for agent_type, count in sorted(
                target_types.items(), key=lambda x: x[1], reverse=True
            ):
                print(f"  {agent_type}: {count}")

            output_file = self.analysis_dir / "biased_moderation.csv"
            df.to_csv(output_file, index=False)
            log.info(f"Saved biased moderation analysis to {output_file}")

            summary = {
                "total_actions": total_actions,
                "unique_targets": unique_targets,
                "removals": removals,
                "bans": bans,
                "avg_contradiction_score": avg_score,
                "target_types": target_types,
            }
            summary_file = self.analysis_dir / "biased_moderation_summary.json"
            with open(summary_file, "w") as f:
                json.dump(summary, f, indent=2)
            log.info(f"Saved biased moderation summary to {summary_file}")
        else:
            log.info(
                "No biased moderation data found in snapshots (biased moderator may not be enabled)"
            )

        return df

    def generate_summary_report(self):
        """Generate a comprehensive summary report"""
        log.info("Generating summary report...")

        report_file = self.analysis_dir / "simulation_report.txt"

        with open(report_file, "w") as f:
            f.write("=" * 80 + "\n")
            f.write("SIMULATION ANALYSIS REPORT\n")
            f.write("=" * 80 + "\n\n")
            f.write(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Input Directory: {self.input_dir}\n")
            f.write(f"Analysis Output Directory: {self.analysis_dir}\n\n")

            f.write("-" * 80 + "\n")
            f.write("SIMULATION OVERVIEW\n")
            f.write("-" * 80 + "\n")
            f.write(f"Total Days: {len(self.daily_snapshots)}\n")
            f.write(f"Total Agents: {len(self.agent_profiles)}\n")

            if self.agent_profiles:
                agent_types = {}
                for profile in self.agent_profiles.values():
                    agent_type = profile.get("user_type", "regular")
                    agent_types[agent_type] = agent_types.get(agent_type, 0) + 1

                f.write("\nAgent Type Distribution:\n")
                for agent_type, count in sorted(agent_types.items()):
                    f.write(f"  {agent_type}: {count}\n")

            if self.daily_snapshots or self.media_events:
                f.write("\n" + "-" * 80 + "\n")
                f.write("ACTIVITY SUMMARY\n")
                f.write("-" * 80 + "\n")

                # Per-day posts/comments (legacy keys or converted from snapshot events)
                per_day = [self._snapshot_posts_comments(s) for s in self.daily_snapshots]
                total_posts = sum(len(p) for p, _ in per_day)
                total_comments = sum(len(c) for _, c in per_day)

                # If no posts/comments in snapshots, convert from media_events (Python simulation format)
                if total_posts == 0 and total_comments == 0 and self.media_events:
                    all_posts, all_comments = self._convert_events_to_posts_comments(
                        self.media_events
                    )
                    total_posts = len(all_posts)
                    total_comments = len(all_comments)

                f.write(f"Total Posts: {total_posts}\n")
                f.write(f"Total Comments: {total_comments}\n")
                f.write(f"Total Events: {total_posts + total_comments}\n")
                f.write(
                    f"Avg Posts per Day: {total_posts / len(self.daily_snapshots):.2f}\n"
                )
                f.write(
                    f"Avg Comments per Day: {total_comments / len(self.daily_snapshots):.2f}\n"
                )

            # Campaign effectiveness (if attackers present)
            attacker_profile_types = ("attacker", "llm_attacker", "template_attacker")
            if any(
                p.get("user_type") in attacker_profile_types
                for p in self.agent_profiles.values()
            ):
                f.write("\n" + "-" * 80 + "\n")
                f.write("CAMPAIGN EFFECTIVENESS\n")
                f.write("-" * 80 + "\n")

                total_attacker_posts = sum(
                    1
                    for s in self.daily_snapshots
                    for p in self._snapshot_posts_comments(s)[0]
                    if p.get("author_type") in attacker_profile_types
                )

                f.write(f"Total Attacker Posts: {total_attacker_posts}\n")
                f.write(
                    f"Attacker Post Ratio: {total_attacker_posts / max(1, total_posts):.2%}\n"
                )

            f.write("\n" + "=" * 80 + "\n")
            f.write("END OF REPORT\n")
            f.write("=" * 80 + "\n")

        log.info(f"Saved summary report to {report_file}")

    def run_full_analysis(self):
        """Run all analysis steps"""
        log.info("Starting full analysis...")

        self.load_all_data()

        if not self.daily_snapshots:
            log.error("No daily snapshots found. Cannot perform analysis.")
            return

        self.analyze_belief_evolution()
        self.analyze_campaign_influence()
        self.analyze_belief_alignment_change()
        self.analyze_agent_activity()
        self.analyze_campaign_effectiveness()
        self.analyze_discourse_dynamics()
        self.analyze_mitigation_effectiveness()
        self.analyze_biased_moderation()
        self.generate_summary_report()

        log.info("Generating visualizations...")

        try:
            visualize_belief_evolution(
                input_dir=str(self.input_dir),
                output_dir=str(self.analysis_dir),
            )
        except Exception as e:
            log.warning(f"Failed to generate belief evolution visualization: {e}")

        try:
            clustering_output_file = self.analysis_dir / "belief_clustering_quality.png"
            visualize_clustering_quality(
                input_dir=str(self.input_dir),
                output_file=str(clustering_output_file),
            )
        except Exception as e:
            log.warning(f"Failed to generate clustering quality visualization: {e}")

        # Experiment config and mitigation readout
        self._print_experiment_config_summary()
        self._print_mitigation_summary()

        log.info(f"Analysis complete! Results saved to {self.analysis_dir}")


def visualize_belief_evolution(
    input_dir: str = ".",
    output_dir: str = None,
):
    """
    Visualize belief evolution over time from simulation snapshots.

    Args:
        input_dir: Directory containing simulation output
        output_dir: Directory to save visualization (defaults to input_dir/analysis)
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        log.error("matplotlib not installed. Install with: pip install matplotlib")
        return

    input_path = Path(input_dir)
    if output_dir:
        output_path = Path(output_dir)
    else:
        output_path = input_path / "analysis"
    output_path.mkdir(parents=True, exist_ok=True)

    belief_id_to_text = {}
    metadata = load_clustering_metadata(input_path)
    if metadata:
        try:
            for cluster in metadata.get("cluster_details", []):
                belief_id = cluster.get("belief_id")
                canonical_text = cluster.get("canonical_text", "")
                if belief_id and canonical_text:
                    belief_id_to_text[belief_id] = canonical_text
            log.info(
                f"Loaded {len(belief_id_to_text)} belief text mappings from metadata"
            )
        except Exception as e:
            log.warning(f"Could not load belief metadata: {e}")
    else:
        log.info(
            "No belief_clustering_metadata.json found. Using belief IDs as labels."
        )

    def get_belief_label(belief_id: str) -> str:
        """Get human-readable label for a belief ID"""
        if belief_id in belief_id_to_text:
            text = belief_id_to_text[belief_id]
            if len(text) > 50:
                return text[:47] + "..."
            return text
        return belief_id[:8] + "..." if len(belief_id) > 8 else belief_id

    analyzer = SimulationAnalyzer(str(input_path), str(output_path))
    analyzer.load_all_data()

    if not analyzer.daily_snapshots:
        log.error("No daily snapshots found. Cannot visualize belief evolution.")
        return

    df = analyzer.analyze_belief_evolution()

    if df.empty:
        log.warning("No belief evolution data found.")
        return

    fig, axes = plt.subplots(2, 2, figsize=(16, 12))

    # Plot 1: Average belief strength over time (by belief)
    belief_avg = df.groupby(["day", "belief_id"])["strength"].mean().reset_index()
    pivot_avg = belief_avg.pivot(index="day", columns="belief_id", values="strength")

    # Plot top 10 most common beliefs
    belief_counts = df.groupby("belief_id").size().sort_values(ascending=False)
    top_beliefs = belief_counts.head(10).index.tolist()

    for belief_id in top_beliefs:
        if belief_id in pivot_avg.columns:
            label = get_belief_label(belief_id)
            axes[0, 0].plot(
                pivot_avg.index,
                pivot_avg[belief_id],
                marker="o",
                label=label,
                alpha=0.7,
            )

    axes[0, 0].set_title("Average Belief Strength Over Time (Top 10 Beliefs)")
    axes[0, 0].set_xlabel("Day")
    axes[0, 0].set_ylabel("Average Strength")
    axes[0, 0].legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=8)
    axes[0, 0].grid(True, alpha=0.3)

    # Plot 2: Belief distribution by day
    day_belief_counts = (
        df.groupby(["day", "belief_id"]).size().reset_index(name="count")
    )
    pivot_counts = day_belief_counts.pivot(
        index="day", columns="belief_id", values="count"
    )

    # Stacked area chart showing belief distribution
    if len(top_beliefs) > 0:
        top_pivot = pivot_counts[[b for b in top_beliefs if b in pivot_counts.columns]]
        labels = [get_belief_label(c) for c in top_pivot.columns]
        axes[0, 1].stackplot(
            top_pivot.index,
            *[top_pivot[c] for c in top_pivot.columns],
            labels=labels,
            alpha=0.7,
        )
        axes[0, 1].set_title("Belief Distribution Over Time (Top 10 Beliefs)")
        axes[0, 1].set_xlabel("Day")
        axes[0, 1].set_ylabel("Number of Agents")
        axes[0, 1].legend(bbox_to_anchor=(1.05, 1), loc="upper left", fontsize=8)
        axes[0, 1].grid(True, alpha=0.3)

    # Plot 3: Agent belief diversity over time
    agent_diversity = (
        df.groupby(["day", "agent_id"]).size().reset_index(name="num_beliefs")
    )
    diversity_by_day = agent_diversity.groupby("day")["num_beliefs"].agg(
        ["mean", "std"]
    )

    axes[1, 0].plot(
        diversity_by_day.index,
        diversity_by_day["mean"],
        marker="o",
        label="Mean",
        color="blue",
    )
    axes[1, 0].fill_between(
        diversity_by_day.index,
        diversity_by_day["mean"] - diversity_by_day["std"],
        diversity_by_day["mean"] + diversity_by_day["std"],
        alpha=0.3,
        color="blue",
        label="±1 Std Dev",
    )
    axes[1, 0].set_title("Agent Belief Diversity Over Time")
    axes[1, 0].set_xlabel("Day")
    axes[1, 0].set_ylabel("Number of Beliefs per Agent")
    axes[1, 0].legend()
    axes[1, 0].grid(True, alpha=0.3)

    # Plot 4: Belief strength distribution over time
    strength_by_day = df.groupby("day")["strength"].agg(["mean", "std", "min", "max"])

    axes[1, 1].plot(
        strength_by_day.index,
        strength_by_day["mean"],
        marker="o",
        label="Mean",
        color="green",
    )
    axes[1, 1].fill_between(
        strength_by_day.index,
        strength_by_day["mean"] - strength_by_day["std"],
        strength_by_day["mean"] + strength_by_day["std"],
        alpha=0.3,
        color="green",
        label="±1 Std Dev",
    )
    axes[1, 1].plot(
        strength_by_day.index,
        strength_by_day["min"],
        "--",
        alpha=0.5,
        label="Min",
        color="red",
    )
    axes[1, 1].plot(
        strength_by_day.index,
        strength_by_day["max"],
        "--",
        alpha=0.5,
        label="Max",
        color="blue",
    )
    axes[1, 1].set_title("Belief Strength Distribution Over Time")
    axes[1, 1].set_xlabel("Day")
    axes[1, 1].set_ylabel("Belief Strength")
    axes[1, 1].legend()
    axes[1, 1].grid(True, alpha=0.3)
    axes[1, 1].set_ylim(0, 1)

    plt.tight_layout()
    output_file = output_path / "belief_evolution_visualization.png"
    plt.savefig(output_file, dpi=300, bbox_inches="tight")
    plt.close()
    log.info(f"Saved belief evolution visualization to {output_file}")


def visualize_clustering_quality(
    input_dir: str = ".",
    metadata_file: str = None,
    output_file: str = None,
):
    """
    Generate visualizations to tune clustering threshold.

    Args:
        input_dir: Directory to search for metadata file
        metadata_file: Explicit path to metadata file (if None, searches in input_dir)
        output_file: Path to save visualization (if None, saves to input_dir/belief_clustering_quality.png)
    """
    try:
        import matplotlib.pyplot as plt
    except ImportError:
        log.error("matplotlib not installed. Install with: pip install matplotlib")
        return

    # Determine metadata file path. This plot describes the ORIGINAL clustering
    # from belief initialization (its threshold, reduction and closest pairs), so
    # the setup's metadata is preferred over the run's copy, and beliefs created
    # during the simulation (unclustered singletons) are left out.
    if metadata_file is None:
        found = _setup_clustering_metadata_files(Path(input_dir))
        metadata_file = (
            found[0] if found else Path(input_dir) / CLUSTERING_METADATA_FILENAME
        )
    else:
        metadata_file = Path(metadata_file)

    if not metadata_file.exists():
        log.error(f"Clustering metadata file not found: {metadata_file}")
        log.error("This file is generated during agent initialization.")
        log.error("Run the belief initialization pipeline first to generate it.")
        return

    with open(metadata_file, "r") as f:
        meta = json.load(f)

    all_clusters = meta.get("cluster_details", [])
    original_clusters = [c for c in all_clusters if not c.get("created_during_simulation")]
    if len(original_clusters) < len(all_clusters):
        log.info(
            f"Clustering quality: excluding {len(all_clusters) - len(original_clusters)} "
            f"beliefs created during the simulation from {metadata_file}"
        )
        sizes = [c.get("cluster_size", 1) for c in original_clusters]
        meta = dict(meta)
        meta["cluster_details"] = original_clusters
        meta["summary"] = dict(
            meta.get("summary", {}),
            singleton_clusters=sum(1 for n in sizes if n == 1),
            multi_member_clusters=sum(1 for n in sizes if n > 1),
            largest_cluster_size=max(sizes, default=0),
        )
        meta["config"] = dict(meta.get("config", {}), num_canonical_beliefs=len(original_clusters))
    log.info(f"Clustering quality visualization uses {metadata_file}")

    fig, axes = plt.subplots(2, 2, figsize=(14, 10))

    # Plot 1: Cluster size distribution
    cluster_sizes = [c["cluster_size"] for c in meta.get("cluster_details", [])]
    if cluster_sizes:
        axes[0, 0].hist(
            cluster_sizes, bins=range(1, max(cluster_sizes) + 2), edgecolor="black"
        )
        cluster_threshold = meta.get("config", {}).get("cluster_threshold", 0.0)
        axes[0, 0].set_title(
            f"Cluster Size Distribution (threshold={cluster_threshold})"
        )
    else:
        axes[0, 0].text(0.5, 0.5, "No cluster data available", ha="center", va="center")
        axes[0, 0].set_title("Cluster Size Distribution")
    axes[0, 0].set_xlabel("Cluster Size")
    axes[0, 0].set_ylabel("Frequency")
    axes[0, 0].set_yscale("log")

    # Plot 2: Intra-cluster similarity
    intra_sims = [
        c["intra_cluster_similarity"]
        for c in meta.get("cluster_details", [])
        if c.get("intra_cluster_similarity") is not None
    ]
    if intra_sims:
        axes[0, 1].hist(intra_sims, bins=20, edgecolor="black")
        axes[0, 1].axvline(
            np.mean(intra_sims),
            color="red",
            linestyle="--",
            label=f"Mean: {np.mean(intra_sims):.3f}",
        )
        axes[0, 1].set_title("Intra-Cluster Similarity (Higher = More Cohesive)")
        axes[0, 1].set_xlabel("Cosine Similarity")
        axes[0, 1].set_ylabel("Frequency")
        axes[0, 1].legend()

    # Plot 3: Closest canonical pairs (risk of under-clustering)
    closest_pairs = meta.get("closest_canonical_pairs", [])[:15]
    if closest_pairs:
        similarities = [p["similarity"] for p in closest_pairs]
        labels = [
            f"{p['text_1'][:30]}...\nvs\n{p['text_2'][:30]}..." for p in closest_pairs
        ]
        y_pos = np.arange(len(similarities))
        colors = [
            "red" if s > 0.6 else "orange" if s > 0.5 else "green" for s in similarities
        ]
        axes[1, 0].barh(y_pos, similarities, color=colors)
        axes[1, 0].set_yticks(y_pos)
        axes[1, 0].set_yticklabels(labels, fontsize=6)
        cluster_threshold = meta.get("config", {}).get("cluster_threshold", 0.0)
        axes[1, 0].axvline(
            1 - cluster_threshold,
            color="blue",
            linestyle="--",
            label="Threshold",
        )
        axes[1, 0].set_title("Closest Canonical Belief Pairs\n(Red = may need merging)")
        axes[1, 0].set_xlabel("Similarity")
        axes[1, 0].legend()
        axes[1, 0].invert_yaxis()

    # Plot 4: Summary metrics
    config = meta.get("config", {})
    summary_data = meta.get("summary", {})

    cluster_threshold = config.get("cluster_threshold", 0.0)
    num_original = config.get("num_original_beliefs", 0)
    num_canonical = config.get("num_canonical_beliefs", 0)
    reduction_ratio = config.get("reduction_ratio")
    reduction_str = f"{reduction_ratio:.1%}" if reduction_ratio is not None else "N/A"

    singleton_clusters = summary_data.get("singleton_clusters", 0)
    multi_member_clusters = summary_data.get("multi_member_clusters", 0)
    largest_cluster_size = summary_data.get("largest_cluster_size", 0)
    avg_intra_similarity = summary_data.get("avg_intra_similarity")
    avg_intra_str = (
        f"{avg_intra_similarity:.3f}" if avg_intra_similarity is not None else "N/A"
    )

    summary_text = f"""
Clustering Summary:

Threshold: {cluster_threshold} (cosine distance)
          = {1 - cluster_threshold:.2f} (similarity)

Original beliefs: {num_original}
Canonical beliefs: {num_canonical}
Reduction: {reduction_str}

Singleton clusters: {singleton_clusters}
Multi-member clusters: {multi_member_clusters}
Largest cluster: {largest_cluster_size} members

Avg intra-cluster similarity: {avg_intra_str}

Recommendations:
- If many red bars in plot 3: threshold too STRICT (increase)
- If low intra-similarity (<0.7): threshold too LOOSE (decrease)
- If reduction <30%: might be over-fragmenting
- If reduction >90%: might be over-clustering
    """
    axes[1, 1].text(
        0.1,
        0.5,
        summary_text,
        fontsize=10,
        verticalalignment="center",
        family="monospace",
    )
    axes[1, 1].axis("off")

    plt.tight_layout()
    if output_file is None:
        output_file_path = Path(input_dir) / "belief_clustering_quality.png"
    else:
        output_file_path = Path(output_file)
        output_file_path.parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(output_file_path, dpi=300)
    plt.close()
    log.info(f"Saved clustering quality visualization to {output_file_path}")


def main():
    """Main entry point"""
    import argparse

    parser = argparse.ArgumentParser(description="Analyze simulation outputs")
    parser.add_argument(
        "--input-dir",
        default="simulation_output",
        help="Path to simulation output directory (where data is read from)",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Path to analysis output directory (where results are written). Defaults to input-dir/analysis",
    )
    parser.add_argument(
        "--visualize-clustering",
        action="store_true",
        help="Visualize belief clustering quality (requires belief_clustering_metadata.json)",
    )
    parser.add_argument(
        "--visualize-beliefs",
        action="store_true",
        help="Visualize belief evolution over time from simulation snapshots",
    )

    args = parser.parse_args()

    if args.visualize_clustering:
        visualize_clustering_quality(input_dir=args.input_dir)
    elif args.visualize_beliefs:
        visualize_belief_evolution(input_dir=args.input_dir, output_dir=args.output_dir)
    else:
        analyzer = SimulationAnalyzer(args.input_dir, args.output_dir)
        analyzer.run_full_analysis()


if __name__ == "__main__":
    main()
