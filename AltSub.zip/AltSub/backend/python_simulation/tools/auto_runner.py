#!/usr/bin/env python3
"""
Batch-run simulations for downstream analysis.

Runs a full matrix: universes (e.g. destiny2_base_sim, politics_base_sim)
× attacker modes (template_attackers, llm_attackers, no_attackers control; optional include/exclude)
× mitigation scenarios (see MITIGATION_SCENARIO_ORDER; ends with all_mitigations_except_coordination then rule_moderator)
× N repeats.

Mitigation parameters come from mitigation_parameter_tuning results (best trial configs),
except scenario "rule_moderator" (feed-based LLM moderators + MitigationSystem flags; no tuning stage).
By default the same tuning_results.json + runs root is used for every attacker mode; optional
--tuning-results-* / --tuning-runs-root-* flags select different tuning per attacker mode.

Universe bases live under a dedicated folder (default: Simulation_Setups/simulations/universes/)
so they are separate from ad-hoc / debug experiment folders under simulations/.

Only directories you name via --bases (or --only-universe) are used; nothing is auto-discovered
from simulations/ at large.

Base layout (under <universes-root>/<universe>/):
  template_attackers/simulation_config.json, agent_profiles.json
  llm_attackers/simulation_config.json, agent_profiles.json
  no_attackers/simulation_config.json, agent_profiles.json  (control: zero attackers)

Attacker mode "biased_moderator" has no folder of its own: it is built from no_attackers plus one
biased_moderator agent whose campaign narrative/beliefs come from llm_attackers. It only runs with
mitigation scenario "none" (other scenarios are skipped for this mode).

Output: Simulation_Setups/auto_runs/<batch_id>/...
"""

from __future__ import annotations

import sys
from pathlib import Path

# Ensure repo root is on sys.path so this file works as either:
#   python -m backend.python_simulation.tools.auto_runner
#   python backend/python_simulation/tools/auto_runner.py
_REPO_ROOT = Path(__file__).resolve().parents[3]
_repo_root_str = str(_REPO_ROOT)
if _repo_root_str not in sys.path:
    sys.path.insert(0, _repo_root_str)

import argparse
import csv
import json
import logging
import subprocess
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from backend.python_simulation.core.config_paths import resolve_config_paths
from backend.python_simulation.core.rule_moderator_schedule import (
    ensure_rule_moderator_mitigation_defaults,
    inject_rule_moderator_agents,
)
from backend.python_simulation.tools.parameter_tuning import (
    _run_simulation,
    copy_setup_inputs,
)

log = logging.getLogger(__name__)

# Mitigation scenario id -> (tuning_results stage key, runs/ subfolder scenario name) or None for "none"
MITIGATION_MAP: Dict[str, Optional[Tuple[str, str]]] = {
    "none": None,
    "duplicate_only": ("stage_1_duplicate_only", "duplicate_only"),
    "rate_limit_only": ("stage_1_rate_limit_only", "rate_limit_only"),
    "coordination_only": ("stage_1_coordination_only", "coordination_only"),
    "all_mitigations": ("stage_2_all_mitigations", "all_mitigations"),
}
# Not in MITIGATION_MAP: uses mitigation_config + injected rule_moderator agents (no tuning trial).
RULE_MODERATOR_SCENARIO = "rule_moderator"
# Reuses all_mitigations tuning trial; duplicate + rate on, coordination off, rule_moderators on.
ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO = "all_mitigations_except_coordination"
VALID_MITIGATION_SCENARIOS = frozenset(MITIGATION_MAP.keys()) | {
    RULE_MODERATOR_SCENARIO,
    ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO,
}
# Explicit default batch order: algorithmic/tuning scenarios first; rule_moderator always last.
# Scenario "all_mitigations" is duplicate+rate+coordination from tuning only — it does NOT add
# LLM rule_moderator agents. "all_mitigations_except_coordination" adds rule_moderator agents.
MITIGATION_SCENARIO_ORDER: List[str] = [
    "none",
    "duplicate_only",
    "rate_limit_only",
    "coordination_only",
    "all_mitigations",
    ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO,
    RULE_MODERATOR_SCENARIO,
]
if (
    len(MITIGATION_SCENARIO_ORDER) != len(VALID_MITIGATION_SCENARIOS)
    or set(MITIGATION_SCENARIO_ORDER) != VALID_MITIGATION_SCENARIOS
    or MITIGATION_SCENARIO_ORDER[-1] != RULE_MODERATOR_SCENARIO
):
    raise RuntimeError(
        "MITIGATION_SCENARIO_ORDER must list each valid scenario once, with rule_moderator last."
    )

# no_attackers: control runs with no template/LLM attackers (configs should set attacker counts to 0).
# Base modes each have their own folder under <universe>/.
BASE_ATTACKER_MODES = ("template_attackers", "llm_attackers", "no_attackers")
# Derived mode: no_attackers population + one biased_moderator (campaign from llm_attackers).
BIASED_MODERATOR_MODE = "biased_moderator"
BIASED_MODERATOR_POPULATION_MODE = "no_attackers"
BIASED_MODERATOR_CAMPAIGN_MODE = "llm_attackers"
# The biased moderator is not affected by automated mitigations, so it only runs without them.
BIASED_MODERATOR_SCENARIOS = frozenset({"none"})
ATTACKER_MODES = BASE_ATTACKER_MODES + (BIASED_MODERATOR_MODE,)
# Attacker coordination_strength sweep: an experimental factor (not tuned), applied
# only where coordination detection is on and attackers coordinate.
COORDINATION_SWEEP_SCENARIOS = frozenset({"coordination_only", "all_mitigations"})
COORDINATION_SWEEP_MODES = frozenset({"llm_attackers", "template_attackers"})
DEFAULT_COORDINATION_STRENGTHS = "0,0.5,0.8"
DEFAULT_BASES = ("destiny2_base_sim_small", "politics_base_sim_small")


def _repo_root() -> Path:
    return _REPO_ROOT


def _sims_root(repo_root: Path) -> Path:
    return repo_root / "Simulation_Setups" / "simulations"


def _default_universes_root(repo_root: Path) -> Path:
    """Folder that contains only intentional analysis universes (not all of simulations/)."""
    return _sims_root(repo_root) / "universes"


def _universe_output_name(universe_dir_name: str) -> str:
    if universe_dir_name.endswith("_base_sim"):
        return universe_dir_name[: -len("_base_sim")]
    return universe_dir_name


def _required_base_modes(attacker_modes: List[str]) -> List[str]:
    """Base mode folders needed to build the selected attacker modes."""
    needed = set()
    for mode in attacker_modes:
        if mode == BIASED_MODERATOR_MODE:
            needed.add(BIASED_MODERATOR_POPULATION_MODE)
            needed.add(BIASED_MODERATOR_CAMPAIGN_MODE)
        else:
            needed.add(mode)
    return [m for m in BASE_ATTACKER_MODES if m in needed]


def validate_base_layout(
    universes_root: Path, universe: str, attacker_modes: List[str]
) -> Dict[str, Path]:
    """
    Return base attacker_mode -> config directory for the folders the selected attacker
    modes need, or raise FileNotFoundError with a clear message.
    """
    required = _required_base_modes(attacker_modes)
    base = universes_root / universe
    if not base.is_dir():
        raise FileNotFoundError(
            f"Universe folder missing: {base}\n"
            f"Put analysis universes under {universes_root} (not loose under simulations/).\n"
            f"Expected under {base}/: each of {required} with "
            f"simulation_config.json + agent_profiles.json"
        )
    missing = []
    dirs: Dict[str, Path] = {}
    for mode in required:
        d = base / mode
        sc = d / "simulation_config.json"
        ap = d / "agent_profiles.json"
        if not sc.is_file() or not ap.is_file():
            missing.append(f"{d} (need simulation_config.json + agent_profiles.json)")
        else:
            dirs[mode] = d
    if missing:
        raise FileNotFoundError(
            f"Universe {universe!r} incomplete:\n  " + "\n  ".join(missing)
        )
    return dirs


def _load_json(path: Path) -> Dict[str, Any]:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _save_json(path: Path, data: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def load_tuning_results(path: Path) -> Dict[str, Any]:
    if not path.is_file():
        raise FileNotFoundError(f"tuning_results.json not found: {path}")
    return _load_json(path)


@dataclass(frozen=True)
class TuningBundle:
    """Tuning artifacts for resolving best-trial mitigation configs."""

    results: Dict[str, Any]
    results_path: Path
    runs_root: Path


def _tuning_bundle_from_paths(repo_root: Path, results_rel: str, runs_rel: str) -> TuningBundle:
    rp = (repo_root / results_rel).resolve()
    rr = (repo_root / runs_rel).resolve()
    return TuningBundle(load_tuning_results(rp), rp, rr)


def _optional_mode_tuning_bundle(
    repo_root: Path,
    results_rel: Optional[str],
    runs_rel: Optional[str],
    flag_label: str,
) -> Optional[TuningBundle]:
    if results_rel is None and runs_rel is None:
        return None
    if not results_rel or not runs_rel:
        raise SystemExit(
            f"{flag_label}: provide both tuning results JSON path and tuning runs root, or neither."
        )
    return _tuning_bundle_from_paths(repo_root, results_rel, runs_rel)


def build_tuning_bundles_by_attacker_mode(
    repo_root: Path,
    default_results_rel: str,
    default_runs_rel: str,
    llm_results: Optional[str],
    llm_runs: Optional[str],
    template_results: Optional[str],
    template_runs: Optional[str],
    no_attackers_results: Optional[str],
    no_attackers_runs: Optional[str],
) -> Dict[str, TuningBundle]:
    default_bundle = _tuning_bundle_from_paths(repo_root, default_results_rel, default_runs_rel)
    llm_b = _optional_mode_tuning_bundle(
        repo_root, llm_results, llm_runs, "--tuning-results-llm / --tuning-runs-root-llm"
    )
    tpl_b = _optional_mode_tuning_bundle(
        repo_root,
        template_results,
        template_runs,
        "--tuning-results-template / --tuning-runs-root-template",
    )
    na_b = _optional_mode_tuning_bundle(
        repo_root,
        no_attackers_results,
        no_attackers_runs,
        "--tuning-results-no-attackers / --tuning-runs-root-no-attackers",
    )
    return {
        "llm_attackers": llm_b if llm_b is not None else default_bundle,
        "template_attackers": tpl_b if tpl_b is not None else default_bundle,
        "no_attackers": na_b if na_b is not None else default_bundle,
        # Only runs scenario "none", which never reads tuning; mapped so lookups don't fail.
        BIASED_MODERATOR_MODE: default_bundle,
    }


# mitigation_config keys describing the universe, not tuned parameters
UNIVERSE_MITIGATION_KEYS = ("subreddit_rules",)


# Rule moderator settings tuned by parameter_tuning (stage_1_rule_moderation_only)
RULE_MODERATOR_TUNED_STAGE = "stage_1_rule_moderation_only"
# Duplicate + rate limit + rule moderators tuned together (parameter_tuning stage 2)
ALL_EXCEPT_COORD_TUNED_STAGE = "stage_2_all_mitigations_except_coordination"


def _tuned_rule_moderator_params(tuning_results: Dict[str, Any]) -> Dict[str, Any]:
    """Best rule moderator params from tuning_results ({} if that stage is absent)."""
    entries = (tuning_results.get("stages") or {}).get(RULE_MODERATOR_TUNED_STAGE) or []
    return dict(entries[0].get("params") or {}) if entries else {}


def _ensure_rule_moderator_mitigation_defaults(
    m: Dict[str, Any], tuned: Optional[Dict[str, Any]] = None
) -> None:
    """Turn on rule moderators with the tuned params (if any), then fill defaults."""
    m.update(tuned or {})
    ensure_rule_moderator_mitigation_defaults(m)


def mitigation_config_for_scenario(
    scenario: str,
    tuning_results: Dict[str, Any],
    tuning_runs_root: Path,
    base_mitigation: Dict[str, Any],
) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """
    Returns (mitigation_config, provenance dict).
    """
    prov: Dict[str, Any] = {"scenario": scenario, "source": "base_disabled"}
    if scenario not in VALID_MITIGATION_SCENARIOS:
        raise ValueError(f"Unknown scenario: {scenario}")
    rule_tuned = _tuned_rule_moderator_params(tuning_results)

    if scenario == "none":
        m = dict(base_mitigation)
        m["enable_duplicate_detection"] = False
        m["enable_rate_limiting"] = False
        m["enable_coordinated_detection"] = False
        m["enable_rule_moderators"] = False
        return m, prov

    if scenario == RULE_MODERATOR_SCENARIO:
        m = dict(base_mitigation)
        m["enable_duplicate_detection"] = False
        m["enable_rate_limiting"] = False
        m["enable_coordinated_detection"] = False
        _ensure_rule_moderator_mitigation_defaults(m, rule_tuned)
        return m, {**prov, "source": "rule_moderator_scenario"}

    if scenario == ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO:
        # Preferred: its own stage-2 tuning (duplicate + rate limit + rule
        # moderators tuned together)
        own = (tuning_results.get("stages") or {}).get(ALL_EXCEPT_COORD_TUNED_STAGE) or []
        if own:
            best = own[0]
            trial_id = int(best.get("trial_id", 0))
            trial_dir = (
                tuning_runs_root / "runs" / ALL_EXCEPT_COORD_TUNED_STAGE
                / ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO / f"trial_{trial_id:04d}"
                / "config" / "simulation_config.json"
            )
            if trial_dir.is_file():
                m = dict(_load_json(trial_dir).get("mitigation_config") or {})
                source = "tuning_trial_config"
            else:
                log.warning("Tuning trial config missing: %s; using params fallback", trial_dir)
                m = dict(base_mitigation)
                m["enable_duplicate_detection"] = True
                m["enable_rate_limiting"] = True
                m.update(best.get("params") or {})
                m.setdefault("mitigation_ban_threshold", 3)
                source = "fallback_missing_file"
            m["enable_coordinated_detection"] = False
            _ensure_rule_moderator_mitigation_defaults(m)  # threshold tuned in this stage
            return m, {
                **prov,
                "source": source,
                "stage_key": ALL_EXCEPT_COORD_TUNED_STAGE,
                "trial_id": trial_id,
                "trial_config_path": str(trial_dir),
                "tuning_objective": best.get("objective_value"),
            }
        # Older tuning results: reuse the all_mitigations trial with coordination
        # off and the stage-1 rule moderator threshold
        stage_key, run_scenario = MITIGATION_MAP["all_mitigations"]
        stages = tuning_results.get("stages") or {}
        entries = stages.get(stage_key) or []
        if not entries:
            log.warning(
                "No tuning entries for %s; using fallback for %s",
                stage_key,
                ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO,
            )
            m = _mitigation_fallback("all_mitigations", None, base_mitigation)
            m["enable_coordinated_detection"] = False
            _ensure_rule_moderator_mitigation_defaults(m, rule_tuned)
            return m, {
                **prov,
                "source": "fallback_empty_stage",
                "stage_key": stage_key,
                "derived_from": "all_mitigations",
            }

        best = entries[0]
        trial_id = int(best.get("trial_id", 0))
        trial_dir = (
            tuning_runs_root
            / "runs"
            / stage_key
            / run_scenario
            / f"trial_{trial_id:04d}"
            / "config"
            / "simulation_config.json"
        )
        if trial_dir.is_file():
            tuned_full = _load_json(trial_dir)
            m = dict(tuned_full.get("mitigation_config") or {})
            m["enable_coordinated_detection"] = False
            _ensure_rule_moderator_mitigation_defaults(m, rule_tuned)
            return m, {
                **prov,
                "source": "all_mitigations_trial_plus_rule_moderators",
                "stage_key": stage_key,
                "trial_id": trial_id,
                "trial_config_path": str(trial_dir),
                "tuning_objective": best.get("objective_value"),
                "derived_from": "all_mitigations",
            }

        log.warning(
            "Tuning trial config missing: %s; using params fallback for %s",
            trial_dir,
            ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO,
        )
        m = _mitigation_fallback("all_mitigations", best, base_mitigation)
        m["enable_coordinated_detection"] = False
        _ensure_rule_moderator_mitigation_defaults(m, rule_tuned)
        return m, {
            **prov,
            "source": "fallback_missing_file",
            "stage_key": stage_key,
            "trial_id": trial_id,
            "expected_path": str(trial_dir),
            "derived_from": "all_mitigations",
        }

    mapping = MITIGATION_MAP.get(scenario)
    if not mapping:
        raise ValueError(f"Unknown scenario: {scenario}")

    stage_key, run_scenario = mapping
    stages = tuning_results.get("stages") or {}
    entries = stages.get(stage_key) or []
    if not entries:
        log.warning("No tuning entries for %s; using fallback from params only", stage_key)
        return _mitigation_fallback(scenario, None, base_mitigation), {
            **prov,
            "source": "fallback_empty_stage",
            "stage_key": stage_key,
        }

    best = entries[0]
    trial_id = int(best.get("trial_id", 0))
    trial_dir = (
        tuning_runs_root
        / "runs"
        / stage_key
        / run_scenario
        / f"trial_{trial_id:04d}"
        / "config"
        / "simulation_config.json"
    )
    if trial_dir.is_file():
        tuned_full = _load_json(trial_dir)
        m = dict(tuned_full.get("mitigation_config") or {})
        m["enable_rule_moderators"] = False
        prov = {
            "scenario": scenario,
            "source": "tuning_trial_config",
            "stage_key": stage_key,
            "trial_id": trial_id,
            "trial_config_path": str(trial_dir),
            "tuning_objective": best.get("objective_value"),
        }
        return m, prov

    log.warning("Tuning trial config missing: %s; using params fallback", trial_dir)
    return _mitigation_fallback(scenario, best, base_mitigation), {
        **prov,
        "source": "fallback_missing_file",
        "stage_key": stage_key,
        "trial_id": trial_id,
        "expected_path": str(trial_dir),
    }


def _mitigation_fallback(
    scenario: str,
    best_entry: Optional[Dict[str, Any]],
    base_mitigation: Dict[str, Any],
) -> Dict[str, Any]:
    """Build mitigation_config from tuning result params + scenario enables."""
    flags = {
        "duplicate_only": (True, False, False),
        "rate_limit_only": (False, True, False),
        "coordination_only": (False, False, True),
        "all_mitigations": (True, True, True),
    }
    dup, rate, coord = flags[scenario]
    m = dict(base_mitigation)
    m["enable_duplicate_detection"] = dup
    m["enable_rate_limiting"] = rate
    m["enable_coordinated_detection"] = coord
    if best_entry and best_entry.get("params"):
        m.update(best_entry["params"])
    m.setdefault("mitigation_ban_threshold", 3)
    m["enable_rule_moderators"] = False
    return m


ATTACKER_PROFILE_TYPES = ("attacker", "llm_attacker", "template_attacker")


def load_campaign_for_biased_moderator(campaign_dir: Path) -> Dict[str, Any]:
    """
    Read the campaign narrative, belief texts and campaign-aligned beliefs from an attacker
    mode folder (default: llm_attackers). Raises ValueError if the narrative is missing.
    """
    cfg = resolve_config_paths(_load_json(campaign_dir / "simulation_config.json"), campaign_dir)
    profiles = _load_json(campaign_dir / "agent_profiles.json")
    cc = cfg.get("campaign_config") or {}
    sim = cfg.get("simulation_config") or {}
    narrative = (cc.get("target_narrative") or sim.get("attacker_target_narrative") or "").strip()
    if not narrative:
        raise ValueError(f"No campaign narrative in {campaign_dir / 'simulation_config.json'}")
    belief_texts = dict(cc.get("campaign_belief_texts") or {})

    # Same beliefs the attackers hold; fall back to strong belief in each campaign text.
    beliefs: Dict[str, float] = {}
    for p in profiles:
        if p.get("user_type") in ATTACKER_PROFILE_TYPES and p.get("beliefs"):
            beliefs = dict(p["beliefs"])
            break
    if not beliefs:
        beliefs = {bid: 0.9 for bid in belief_texts}
    return {
        "narrative": narrative,
        "belief_texts": belief_texts,
        "beliefs": beliefs,
        "campaign_templates_dir": cc.get("campaign_templates_dir"),
    }


def inject_biased_moderator_agent(
    cfg: Dict[str, Any], profiles: List[Dict[str, Any]], campaign: Dict[str, Any]
) -> Tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """
    Append one biased_moderator profile with an always-on schedule (aligned with
    reddit_agent_initializer) and enable it with the given campaign.
    """
    sim = cfg.setdefault("simulation_config", {})
    cc = cfg.setdefault("campaign_config", {})
    cc["target_narrative"] = campaign["narrative"]
    cc["campaign_belief_texts"] = dict(campaign["belief_texts"])
    if campaign.get("campaign_templates_dir"):
        cc["campaign_templates_dir"] = campaign["campaign_templates_dir"]
    sim["attacker_target_narrative"] = campaign["narrative"]

    bm = cfg.setdefault("biased_moderator_config", {})
    bm["enable_biased_moderator"] = True
    bm["biased_moderator_uses_campaign_beliefs"] = True

    interval = int(sim.get("interval_minutes", 5))
    timesteps_per_day = (24 * 60) // interval
    total_days = int(sim.get("duration_days", 14))
    num_timesteps = timesteps_per_day * total_days
    sub = str(sim.get("target_subreddit", "unknown"))

    idx = len(profiles)
    profiles.append(
        {
            "username": "biased_moderator_0",
            "subreddit": sub,
            "behavioral_params": {
                "read_density": 5,
                "post_probability": 0.0,
                "pr_comment": 0.0,
                "pr_upvote": 0.0,
                "pr_downvote": 0.0,
            },
            "activity_patterns": {
                "activity_level": "commenter",
                "frequency_of_use": "daily",
                "session_duration": "long",
                "active_time_slots": ["9am-12pm"],
            },
            "content_metrics": {
                "total_posts": 0,
                "total_comments": 0,
                "avg_score": 0.0,
                "controversiality": 0.0,
            },
            "beliefs": dict(campaign["beliefs"]),
            "trust_network": {},
            "user_type": "biased_moderator",
        }
    )
    cfg.setdefault("agent_activity_schedules", {})[str(idx)] = [1] * num_timesteps
    sim["total_agents"] = len(profiles)
    return cfg, profiles


def build_run_config(
    base_config_path: Path,
    base_profiles_path: Path,
    scenario: str,
    bundle: TuningBundle,
    attacker_mode: Optional[str] = None,
    campaign_source_dir: Optional[Path] = None,
    coordination_strength: Optional[float] = None,
) -> Tuple[Dict[str, Any], List[Any], Dict[str, Any]]:
    cfg = resolve_config_paths(_load_json(base_config_path), Path(base_config_path).parent)
    base_m = cfg.get("mitigation_config") or {}
    new_m, prov = mitigation_config_for_scenario(
        scenario, bundle.results, bundle.runs_root, base_m
    )
    prov = {
        **prov,
        "tuning_results_path": str(bundle.results_path),
        "tuning_runs_root": str(bundle.runs_root),
    }
    # Tuned configs come from another universe's trial; keep this universe's
    # rules so rule moderators enforce the right subreddit
    for key in UNIVERSE_MITIGATION_KEYS:
        if key in base_m:
            new_m[key] = base_m[key]
        else:
            new_m.pop(key, None)
    cfg["mitigation_config"] = new_m
    profiles = _load_json(base_profiles_path)
    if scenario in (
        RULE_MODERATOR_SCENARIO,
        ALL_MITIGATIONS_EXCEPT_COORD_SCENARIO,
    ):
        cfg, profiles = inject_rule_moderator_agents(cfg, profiles)
    if attacker_mode == BIASED_MODERATOR_MODE:
        if campaign_source_dir is None:
            raise ValueError("biased_moderator mode requires campaign_source_dir")
        campaign = load_campaign_for_biased_moderator(campaign_source_dir)
        cfg, profiles = inject_biased_moderator_agent(cfg, profiles, campaign)
        prov = {**prov, "biased_moderator_campaign_source": str(campaign_source_dir)}
    if coordination_strength is not None:
        cfg.setdefault("campaign_config", {})["coordination_strength"] = coordination_strength
        prov = {**prov, "coordination_strength_override": coordination_strength}
    return cfg, profiles, prov


def _run_analyze(
    repo_root: Path,
    simulation_output: Path,
    analysis_output: Path,
    timeout_sec: int,
) -> Tuple[bool, str]:
    cmd = [
        sys.executable,
        "-m",
        "backend.python_simulation.tools.analyze_simulation",
        "--input-dir",
        str(simulation_output),
        "--output-dir",
        str(analysis_output),
    ]
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(repo_root),
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return False, f"analyze_simulation timeout after {timeout_sec}s"
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "").strip()
        return False, f"analyze_simulation failed ({proc.returncode}): {err[-800:]}"
    return True, ""


@dataclass
class RunSpec:
    universe: str
    attacker_mode: str
    scenario: str
    repeat_index: int
    base_config: Path
    base_profiles: Path
    # biased_moderator mode only: folder the campaign narrative/beliefs are read from.
    campaign_source_dir: Optional[Path] = None
    # Set when the coordination_strength sweep applies; None keeps the base config value
    coordination_strength: Optional[float] = None

    def label(self) -> str:
        cs = "" if self.coordination_strength is None else f" cs={self.coordination_strength:g}"
        return (
            f"{self.universe} {self.attacker_mode} {self.scenario}{cs} "
            f"run_{self.repeat_index:04d}"
        )


@dataclass
class RunManifest:
    universe: str
    attacker_mode: str
    mitigation_scenario: str
    repeat_index: int
    run_dir: str
    started_utc: str
    finished_utc: str
    simulation_ok: bool
    simulation_error: Optional[str]
    analysis_ok: bool
    analysis_error: Optional[str]
    wall_seconds: float
    tuning_provenance: Dict[str, Any]
    final_output_excerpt: Dict[str, Any] = field(default_factory=dict)
    belief_metadata_seeded: bool = False
    seed_context_copied: bool = False
    coordination_strength: Optional[float] = None


def _final_output_excerpt(final_path: Path) -> Dict[str, Any]:
    if not final_path.is_file():
        return {}
    try:
        data = _load_json(final_path)
    except Exception:
        return {}
    out: Dict[str, Any] = {
        "total_events": data.get("total_events"),
        "total_run_time_seconds": data.get("total_run_time_seconds"),
    }
    if "mitigation_summary" in data:
        out["mitigation_summary"] = data["mitigation_summary"]
    if "event_counts_by_type" in data:
        out["event_counts_by_type"] = data["event_counts_by_type"]
    if "attacker_coordination" in data:
        out["attacker_coordination"] = data["attacker_coordination"]
    return out


def execute_one_run(
    repo_root: Path,
    batch_dir: Path,
    spec: RunSpec,
    tuning_bundle: TuningBundle,
    sim_timeout_sec: int,
    analysis_timeout_sec: int,
) -> RunManifest:
    out_name = _universe_output_name(spec.universe)
    run_dir = batch_dir / out_name / spec.attacker_mode / spec.scenario
    if spec.coordination_strength is not None:
        run_dir = run_dir / f"cs_{spec.coordination_strength:g}"
    run_dir = run_dir / f"run_{spec.repeat_index:04d}"
    config_dir = run_dir / "config"
    sim_out = run_dir / "simulation_output"
    analysis_out = run_dir / "analysis"
    config_dir.mkdir(parents=True, exist_ok=True)
    sim_out.mkdir(parents=True, exist_ok=True)

    t0 = time.perf_counter()
    started = datetime.now(timezone.utc).isoformat()

    cfg, profiles, prov = build_run_config(
        spec.base_config,
        spec.base_profiles,
        spec.scenario,
        tuning_bundle,
        attacker_mode=spec.attacker_mode,
        campaign_source_dir=spec.campaign_source_dir,
        coordination_strength=spec.coordination_strength,
    )
    _save_json(config_dir / "simulation_config.json", cfg)
    _save_json(config_dir / "agent_profiles.json", profiles)

    # Setup inputs run_simulation reads from config_dir: belief clusters and the
    # orchestrator's day-0 subreddit context. Taken from the mode folder, else the
    # universe root (where the initializer writes them).
    mode_dir = spec.base_profiles.parent
    copied = copy_setup_inputs(mode_dir, config_dir, fallback_dir=mode_dir.parent)
    seeded = copied["belief_clustering_metadata.json"]
    seed_context_copied = copied["subreddit_seed_context.json"]
    for name, ok in copied.items():
        if not ok:
            log.warning("  %s: no %s in %s or %s", spec.label(), name, mode_dir, mode_dir.parent)

    log.info("  -> run_simulation %s (timeout=%ds)", spec.label(), sim_timeout_sec)
    sim_ok, sim_err = _run_simulation(
        repo_root, config_dir, sim_out, sim_timeout_sec, stream_output=False
    )
    analysis_ok = False
    analysis_err: Optional[str] = None
    excerpt: Dict[str, Any] = {}

    if sim_ok:
        excerpt = _final_output_excerpt(sim_out / "final_output.json")
        log.info(
            "  -> analyze_simulation %s (timeout=%ds)", spec.label(), analysis_timeout_sec
        )
        analysis_ok, analysis_err = _run_analyze(
            repo_root, sim_out, analysis_out, analysis_timeout_sec
        )
    else:
        analysis_err = "skipped (simulation failed)"

    finished = datetime.now(timezone.utc).isoformat()
    wall = time.perf_counter() - t0

    manifest = RunManifest(
        universe=spec.universe,
        attacker_mode=spec.attacker_mode,
        mitigation_scenario=spec.scenario,
        repeat_index=spec.repeat_index,
        run_dir=str(run_dir.resolve()),
        started_utc=started,
        finished_utc=finished,
        simulation_ok=sim_ok,
        simulation_error=sim_err if not sim_ok else None,
        analysis_ok=analysis_ok,
        analysis_error=analysis_err,
        wall_seconds=round(wall, 3),
        tuning_provenance=prov,
        final_output_excerpt=excerpt,
        belief_metadata_seeded=seeded,
        seed_context_copied=seed_context_copied,
        coordination_strength=spec.coordination_strength,
    )
    _save_json(config_dir / "run_manifest.json", asdict(manifest))
    return manifest


def _manifest_to_row(m: RunManifest) -> Dict[str, Any]:
    return {
        "universe": m.universe,
        "attacker_mode": m.attacker_mode,
        "mitigation_scenario": m.mitigation_scenario,
        "coordination_strength": "" if m.coordination_strength is None else m.coordination_strength,
        "repeat_index": m.repeat_index,
        "run_dir": m.run_dir,
        "simulation_ok": m.simulation_ok,
        "analysis_ok": m.analysis_ok,
        "wall_seconds": m.wall_seconds,
        "simulation_error": m.simulation_error or "",
        "analysis_error": m.analysis_error or "",
        "tuning_source": m.tuning_provenance.get("source", ""),
        "tuning_trial_id": m.tuning_provenance.get("trial_id", ""),
        "total_events": m.final_output_excerpt.get("total_events", ""),
        "total_run_time_seconds": m.final_output_excerpt.get("total_run_time_seconds", ""),
        "belief_metadata_seeded": m.belief_metadata_seeded,
        "seed_context_copied": m.seed_context_copied,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Batch-run analysis simulations (matrix × repeats)"
    )
    parser.add_argument(
        "--runs",
        type=int,
        default=1,
        help="Repeats per (universe, attacker mode, mitigation scenario)",
    )
    parser.add_argument(
        "--batch-id",
        default=None,
        help="Output folder name under auto_runs (default: UTC timestamp)",
    )
    parser.add_argument(
        "--output-root",
        default="Simulation_Setups/auto_runs",
        help="Parent directory for batch outputs",
    )
    parser.add_argument(
        "--tuning-results",
        default="Simulation_Setups/simulations/mitigation_tuning_grid/results/tuning_results.json",
        help="Path to tuning_results.json",
    )
    parser.add_argument(
        "--tuning-runs-root",
        default="Simulation_Setups/simulations/mitigation_tuning_grid",
        help="Folder containing runs/ (tuning trial configs)",
    )
    parser.add_argument(
        "--tuning-results-llm",
        default=None,
        help=(
            "Override tuning_results.json for llm_attackers (requires --tuning-runs-root-llm). "
            "Default: same as --tuning-results."
        ),
    )
    parser.add_argument(
        "--tuning-runs-root-llm",
        default=None,
        help="Runs root for llm_attackers tuning trials (requires --tuning-results-llm).",
    )
    parser.add_argument(
        "--tuning-results-template",
        default=None,
        help=(
            "Override tuning_results.json for template_attackers (requires --tuning-runs-root-template)."
        ),
    )
    parser.add_argument(
        "--tuning-runs-root-template",
        default=None,
        help="Runs root for template_attackers tuning trials (requires --tuning-results-template).",
    )
    parser.add_argument(
        "--tuning-results-no-attackers",
        default=None,
        help=(
            "Override tuning_results.json for no_attackers control (requires --tuning-runs-root-no-attackers)."
        ),
    )
    parser.add_argument(
        "--tuning-runs-root-no-attackers",
        default=None,
        help="Runs root for no_attackers tuning trials (requires --tuning-results-no-attackers).",
    )
    parser.add_argument(
        "--universes-root",
        default=None,
        help=(
            "Directory containing universe folders (default: "
            "Simulation_Setups/simulations/universes)"
        ),
    )
    parser.add_argument(
        "--bases",
        nargs="*",
        default=list(DEFAULT_BASES),
        help="Universe folder names under --universes-root (not auto-scanned from simulations/)",
    )
    parser.add_argument(
        "--only-universe",
        default=None,
        help="If set, only run this universe (e.g. destiny2_base_sim)",
    )
    parser.add_argument(
        "--discover-universes",
        action="store_true",
        help=(
            "Discover all universe directories under --universes-root and run them "
            "subject to --include-universes/--exclude-universes."
        ),
    )
    parser.add_argument(
        "--include-universes",
        default=None,
        help=(
            "Comma-separated universe ids to run (by folder name under --universes-root). "
            "Example: 'destiny2_base_sim,politics_base_sim'. "
            "If provided, overrides --exclude-universes."
        ),
    )
    parser.add_argument(
        "--exclude-universes",
        default=None,
        help=(
            "Comma-separated universe ids to skip (by folder name under --universes-root). "
            "Example: 'destiny2_base_sim,politics_base_sim'."
        ),
    )
    parser.add_argument(
        "--include-scenarios",
        default=None,
        help=(
            "Comma-separated mitigation scenario ids to run. "
            "Examples: 'none,duplicate_only' or 'rule_moderator'. "
            "If provided, overrides --exclude-scenarios."
        ),
    )
    parser.add_argument(
        "--exclude-scenarios",
        default=None,
        help=(
            "Comma-separated mitigation scenario ids to skip. "
            "Examples: 'coordination_only,all_mitigations' or 'rule_moderator'."
        ),
    )
    parser.add_argument(
        "--include-attacker-modes",
        default=None,
        help=(
            "Comma-separated attacker mode ids to run. "
            "Valid: 'template_attackers', 'llm_attackers', 'no_attackers' (control; zero attackers), "
            "'biased_moderator' (no_attackers + biased moderator; scenario 'none' only). "
            "Alias: 'none' -> no_attackers. "
            "Example: 'llm_attackers'. If provided, overrides --exclude-attacker-modes."
        ),
    )
    parser.add_argument(
        "--exclude-attacker-modes",
        default=None,
        help=(
            "Comma-separated attacker mode ids to skip. "
            "Example: 'template_attackers' or 'no_attackers'."
        ),
    )
    parser.add_argument(
        "--coordination-strengths",
        default=DEFAULT_COORDINATION_STRENGTHS,
        help=(
            "Comma-separated attacker coordination_strength values (0-1) swept for "
            f"{sorted(COORDINATION_SWEEP_SCENARIOS)} with {sorted(COORDINATION_SWEEP_MODES)}. "
            f"Default: {DEFAULT_COORDINATION_STRENGTHS}"
        ),
    )
    parser.add_argument(
        "--fixed-coordination-strength",
        action="store_true",
        help="No coordination_strength sweep; every run uses the base config value",
    )
    parser.add_argument("--max-workers", type=int, default=1)
    parser.add_argument(
        "--timeout-sec",
        type=int,
        default=3600,
        help="Per-simulation timeout (run_simulation subprocess)",
    )
    parser.add_argument(
        "--analysis-timeout-sec",
        type=int,
        default=3600,
        help="Per-run analyze_simulation timeout",
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s %(levelname)s [auto_runner] %(message)s",
        datefmt="%H:%M:%S",
        force=True,
    )

    if args.runs < 1:
        raise SystemExit("--runs must be >= 1")
    if args.max_workers < 1:
        raise SystemExit("--max-workers must be >= 1")

    repo_root = _repo_root()
    universes_root = (
        (repo_root / args.universes_root).resolve()
        if args.universes_root
        else _default_universes_root(repo_root)
    )
    tuning_results_path = (repo_root / args.tuning_results).resolve()
    tuning_runs_root = (repo_root / args.tuning_runs_root).resolve()
    output_root = (repo_root / args.output_root).resolve()

    batch_id = args.batch_id or datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    batch_dir = output_root / batch_id
    batch_dir.mkdir(parents=True, exist_ok=True)

    tuning_by_mode = build_tuning_bundles_by_attacker_mode(
        repo_root,
        args.tuning_results,
        args.tuning_runs_root,
        args.tuning_results_llm,
        args.tuning_runs_root_llm,
        args.tuning_results_template,
        args.tuning_runs_root_template,
        args.tuning_results_no_attackers,
        args.tuning_runs_root_no_attackers,
    )
    log.info(
        "Tuning sources: default %s | llm %s | template %s | no_attackers %s",
        tuning_results_path,
        tuning_by_mode["llm_attackers"].results_path,
        tuning_by_mode["template_attackers"].results_path,
        tuning_by_mode["no_attackers"].results_path,
    )

    def _parse_csv_ids(s: str) -> List[str]:
        return [x.strip() for x in s.split(",") if x.strip()]

    def _normalize_attacker_mode_token(tok: str) -> str:
        """CLI alias: 'none' means the no_attackers control mode (avoids clashing with mitigation scenario 'none')."""
        t = tok.strip()
        if t == "none":
            return "no_attackers"
        return t

    scenario_ordered = list(MITIGATION_SCENARIO_ORDER)
    scenario_ids = set(VALID_MITIGATION_SCENARIOS)

    if args.include_scenarios:
        include = set(_parse_csv_ids(args.include_scenarios))
        bad = include - scenario_ids
        if bad:
            raise SystemExit(
                f"--include-scenarios contains unknown scenario ids: {sorted(bad)}. "
                f"Valid: {sorted(scenario_ids)}"
            )
        scenarios = [s for s in scenario_ordered if s in include]
    else:
        scenarios = scenario_ordered[:]
        if args.exclude_scenarios:
            exclude = set(_parse_csv_ids(args.exclude_scenarios))
            bad = exclude - scenario_ids
            if bad:
                raise SystemExit(
                    f"--exclude-scenarios contains unknown scenario ids: {sorted(bad)}. "
                    f"Valid: {sorted(scenario_ids)}"
                )
            scenarios = [s for s in scenarios if s not in exclude]

    attacker_ordered = list(ATTACKER_MODES)
    attacker_ids = set(ATTACKER_MODES)
    if args.include_attacker_modes:
        include_a = set(
            _normalize_attacker_mode_token(x) for x in _parse_csv_ids(args.include_attacker_modes)
        )
        bad = include_a - attacker_ids
        if bad:
            raise SystemExit(
                f"--include-attacker-modes contains unknown ids: {sorted(bad)}. "
                f"Valid: {sorted(attacker_ids)}"
            )
        attacker_modes = [m for m in attacker_ordered if m in include_a]
    else:
        attacker_modes = attacker_ordered[:]
        if args.exclude_attacker_modes:
            exclude_a = set(
                _normalize_attacker_mode_token(x) for x in _parse_csv_ids(args.exclude_attacker_modes)
            )
            bad = exclude_a - attacker_ids
            if bad:
                raise SystemExit(
                    f"--exclude-attacker-modes contains unknown ids: {sorted(bad)}. "
                    f"Valid: {sorted(attacker_ids)}"
                )
            attacker_modes = [m for m in attacker_modes if m not in exclude_a]

    if not attacker_modes:
        raise SystemExit("No attacker modes selected after include/exclude filtering.")

    specs: List[RunSpec] = []
    log.info("Universes root: %s", universes_root)
    log.info("Mitigation scenarios: %s", scenarios)
    log.info("Attacker modes: %s", attacker_modes)

    universe_ids_available: List[str]
    if args.only_universe:
        bases = [args.only_universe]
        universe_ids_available = bases[:]
    elif args.discover_universes:
        if not universes_root.is_dir():
            raise SystemExit(f"--discover-universes but universes-root is missing: {universes_root}")
        universe_ids_available = sorted([p.name for p in universes_root.iterdir() if p.is_dir()])
        bases = universe_ids_available[:]
    else:
        bases = list(args.bases)
        universe_ids_available = bases[:]

    universe_id_set = set(universe_ids_available)
    if args.include_universes:
        include = set(_parse_csv_ids(args.include_universes))
        bad = include - universe_id_set
        if bad:
            raise SystemExit(
                f"--include-universes contains unknown universe ids: {sorted(bad)}. "
                f"Available under selection: {sorted(universe_id_set)}"
            )
        bases = [u for u in bases if u in include]
    elif args.exclude_universes:
        exclude = set(_parse_csv_ids(args.exclude_universes))
        bad = exclude - universe_id_set
        if bad:
            raise SystemExit(
                f"--exclude-universes contains unknown universe ids: {sorted(bad)}. "
                f"Available under selection: {sorted(universe_id_set)}"
            )
        bases = [u for u in bases if u not in exclude]

    if not bases:
        raise SystemExit("No universes selected after include/exclude filtering.")

    log.info("Universes selected: %s", bases)

    coordination_strengths: List[float] = []
    if not args.fixed_coordination_strength:
        try:
            coordination_strengths = sorted(
                {float(x) for x in _parse_csv_ids(args.coordination_strengths)}
            )
        except ValueError:
            raise SystemExit(
                f"--coordination-strengths must be numbers, got {args.coordination_strengths!r}"
            )
        bad_cs = [x for x in coordination_strengths if not 0.0 <= x <= 1.0]
        if bad_cs:
            raise SystemExit(f"--coordination-strengths must be in [0, 1], got {bad_cs}")
        if any(s in COORDINATION_SWEEP_SCENARIOS for s in scenarios):
            log.info(
                "coordination_strength sweep %s for %s x %s",
                coordination_strengths,
                sorted(COORDINATION_SWEEP_MODES & set(attacker_modes)),
                sorted(COORDINATION_SWEEP_SCENARIOS & set(scenarios)),
            )
    else:
        log.info("coordination_strength fixed at each base config value (no sweep)")

    if BIASED_MODERATOR_MODE in attacker_modes:
        bm_scenarios = [s for s in scenarios if s in BIASED_MODERATOR_SCENARIOS]
        skipped = [s for s in scenarios if s not in BIASED_MODERATOR_SCENARIOS]
        if skipped:
            log.info(
                "%s only runs scenarios %s; skipping %s for that mode",
                BIASED_MODERATOR_MODE,
                sorted(BIASED_MODERATOR_SCENARIOS),
                skipped,
            )
        if not bm_scenarios:
            log.warning(
                "%s selected but none of its scenarios %s are selected; it will have no runs",
                BIASED_MODERATOR_MODE,
                sorted(BIASED_MODERATOR_SCENARIOS),
            )

    for universe in bases:
        mode_dirs = validate_base_layout(universes_root, universe, attacker_modes)
        paths = {
            mode: (
                d / "simulation_config.json",
                d / "agent_profiles.json",
            )
            for mode, d in mode_dirs.items()
        }
        for attacker_mode in attacker_modes:
            campaign_dir: Optional[Path] = None
            if attacker_mode == BIASED_MODERATOR_MODE:
                bc, bp = paths[BIASED_MODERATOR_POPULATION_MODE]
                campaign_dir = mode_dirs[BIASED_MODERATOR_CAMPAIGN_MODE]
                # Fail before any run starts rather than mid-batch.
                try:
                    load_campaign_for_biased_moderator(campaign_dir)
                except ValueError as e:
                    raise SystemExit(f"Universe {universe!r}, {BIASED_MODERATOR_MODE}: {e}")
            else:
                bc, bp = paths[attacker_mode]
            for scenario in scenarios:
                if (
                    attacker_mode == BIASED_MODERATOR_MODE
                    and scenario not in BIASED_MODERATOR_SCENARIOS
                ):
                    continue
                sweep = (
                    coordination_strengths
                    and attacker_mode in COORDINATION_SWEEP_MODES
                    and scenario in COORDINATION_SWEEP_SCENARIOS
                )
                for strength in coordination_strengths if sweep else [None]:
                    for r in range(1, args.runs + 1):
                        specs.append(
                            RunSpec(
                                universe=universe,
                                attacker_mode=attacker_mode,
                                scenario=scenario,
                                repeat_index=r,
                                base_config=bc,
                                base_profiles=bp,
                                campaign_source_dir=campaign_dir,
                                coordination_strength=strength,
                            )
                        )

    total = len(specs)
    log.info(
        "Batch %s: %d runs (universes=%s, runs/cell=%d, workers=%d)",
        batch_id,
        total,
        bases,
        args.runs,
        args.max_workers,
    )
    log.info("Output: %s", batch_dir)

    manifests: List[RunManifest] = []
    lock = threading.Lock()
    started = [0]
    done = [0]

    def one(spec: RunSpec) -> RunManifest:
        with lock:
            started[0] += 1
            n = started[0]
            log.info("[%d/%d] START %s", n, total, spec.label())

        m = execute_one_run(
            repo_root,
            batch_dir,
            spec,
            tuning_by_mode[spec.attacker_mode],
            args.timeout_sec,
            args.analysis_timeout_sec,
        )
        with lock:
            done[0] += 1
            log.info(
                "[%d/%d] DONE %s sim_ok=%s analysis_ok=%s %.1fs",
                done[0],
                total,
                spec.label(),
                m.simulation_ok,
                m.analysis_ok,
                m.wall_seconds,
            )
        return m

    if args.max_workers <= 1:
        for s in specs:
            manifests.append(one(s))
    else:
        with ThreadPoolExecutor(max_workers=args.max_workers) as ex:
            futs = {ex.submit(one, s): s for s in specs}
            for fut in as_completed(futs):
                manifests.append(fut.result())

    manifests.sort(
        key=lambda m: (
            m.universe,
            m.attacker_mode,
            m.mitigation_scenario,
            -1.0 if m.coordination_strength is None else m.coordination_strength,
            m.repeat_index,
        )
    )

    summary = {
        "batch_id": batch_id,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "total_runs": len(manifests),
        "bases": bases,
        "runs_per_cell": args.runs,
        "mitigation_scenarios": scenarios,
        "attacker_modes": attacker_modes,
        "coordination_strengths": coordination_strengths or None,
        "tuning_results": str(tuning_results_path),
        "tuning_runs_root": str(tuning_runs_root),
        "tuning_by_attacker_mode": {
            mode: {
                "tuning_results": str(b.results_path),
                "tuning_runs_root": str(b.runs_root),
            }
            for mode, b in tuning_by_mode.items()
        },
        "runs": [asdict(m) for m in manifests],
    }
    _save_json(batch_dir / "summary.json", summary)

    csv_path = batch_dir / "summary.csv"
    rows = [_manifest_to_row(m) for m in manifests]
    if rows:
        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)

    ok_sim = sum(1 for m in manifests if m.simulation_ok)
    ok_an = sum(1 for m in manifests if m.analysis_ok)
    log.info(
        "Batch complete: simulation_ok=%d/%d, analysis_ok=%d/%d. summary.json + summary.csv -> %s",
        ok_sim,
        len(manifests),
        ok_an,
        len(manifests),
        batch_dir,
    )


if __name__ == "__main__":
    main()
