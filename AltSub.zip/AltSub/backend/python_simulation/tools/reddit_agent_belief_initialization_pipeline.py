#!/usr/bin/env python3
"""
Belief/Knowledge Initialization Pipeline for Reddit Agents

This module provides a pluggable pipeline to:
  1) collect per-user texts (submissions + comments),
  2) extract candidate beliefs via an LLM (or local model),
  3) deduplicate/canonicalize beliefs across users using embeddings+clustering,
  4) compute per-user belief strengths in [0,1],
  5) return canonical beliefs and a per-user mapping usable by the initializer.

Design goals:
  - Minimal hard dependencies; embeddings/clustering are optional.
  - Switchable LLM backend: OpenAI (via OPENAI_API_KEY) or a local HTTP endpoint.
  - Structured JSON I/O between stages.

Usage from reddit_agent_initializer.py (planned):
  from reddit_agent_belief_initialization_pipeline import BeliefInitializer, BeliefPipelineConfig
  belief_init = BeliefInitializer(BeliefPipelineConfig(...))
  canonical_beliefs, user_beliefs_map = belief_init.build_beliefs_for_users(conn, subreddit, usernames)

Returned structures:
  - canonical_beliefs: List[dict]
      [{ 'belief_id': str, 'canonical_text': str, 'example_paraphrases': List[str] }]
  - user_beliefs_map: Dict[str, Dict[str, float]]
      { username: { belief_id: strength_float_0_to_1 } }

Note: The default implementations for LLM and embeddings are conservative and designed
to be easy to wire-up. Replace stubs with your preferred providers if modifying.
"""

from __future__ import annotations

import os
import json
import time
import re
import math
import logging
from pathlib import Path
from dotenv import load_dotenv

_env_paths = [
    Path.cwd() / ".env",
    Path(__file__).parent.parent.parent / ".env",
    Path(__file__).parent.parent.parent.parent / "Simulation_Setups" / ".env",
]

for env_path in _env_paths:
    if env_path.exists():
        load_dotenv(env_path, override=False)
        logging.getLogger(__name__).debug(f"Loaded .env from {env_path}")
        break
import hashlib
from dataclasses import dataclass
from typing import Dict, List, Tuple, Optional

import sqlite3
import numpy as np
from sentence_transformers import SentenceTransformer
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics.pairwise import cosine_distances

from ..services.llm_provider import LLMProvider
from ..services.belief_nli import get_belief_nli
from ..services.llm_json import complete_json, parse_json_text

log = logging.getLogger(__name__)

# Comment bodies / selftexts Reddit leaves behind for removed or deleted content
_REMOVED_TEXT_MARKERS = {"[removed]", "[deleted]"}


def _usable_text(value) -> Optional[str]:
    """Return stripped text, or None for empty / removed / deleted content."""
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.lower() in _REMOVED_TEXT_MARKERS:
        return None
    return text


def _new_extraction_stats(total_users: int, mode: str) -> Dict:
    """Per-user belief extraction outcome counts for one pipeline run.

    extracted: LLM call succeeded and returned >= 1 belief
    empty:     LLM call succeeded but returned no usable beliefs
    no_text:   user had no usable text, so no LLM call was made
    failed:    LLM call / parse failed (reasons tallied in failure_reasons)
    """
    return {
        "mode": mode,
        "total_users": total_users,
        "extracted": 0,
        "empty": 0,
        "no_text": 0,
        "failed": 0,
        "failure_reasons": {},
    }


def _record_outcome(stats: Dict, status: str, error: str = "") -> None:
    stats[status] += 1
    if status == "failed":
        # First line only so identical causes group together
        reason = (error or "unknown error").split("\n")[0][:200]
        stats["failure_reasons"][reason] = stats["failure_reasons"].get(reason, 0) + 1


def extraction_failure_fraction(stats: Dict) -> float:
    """Fraction of attempted extractions (users with text) that failed."""
    attempted = stats["extracted"] + stats["empty"] + stats["failed"]
    return stats["failed"] / attempted if attempted else 0.0


@dataclass
class BeliefPipelineConfig:
    # LLM settings
    provider: str = "auto"  # "auto" | "openai" | "mistral"
    max_beliefs_per_user: int = 8
    use_batch_api: bool = False  # Use Mistral Batch API for 50% cost savings (async)
    batch_poll_interval: int = 10  # Seconds to wait between batch status checks

    # Embedding + clustering
    embedding_model: str = "all-MiniLM-L6-v2"  # sentence-transformers model
    cluster_threshold: float = 0.40  # cosine distance threshold (~0.60 cosine sim)
    # Too strict (0.18) = no clustering; Too loose (0.60+) = unrelated beliefs cluster
    min_cluster_size: int = 1

    # Strength computation params
    freq_gain: float = 0.5  # saturation gain for frequency

    # Execution controls
    max_chars_per_user: int = 6000  # truncate very large text

    # Subreddit
    subreddit: str = "r/politics"


class BeliefInitializer:
    def __init__(self, config: BeliefPipelineConfig):
        self.config = config
        # Outcome counts from the last build_beliefs_for_users call
        self.last_extraction_stats: Optional[Dict] = None
        self._init_llm_client()
        self._init_embedder()

    # LLM backend
    def _init_llm_client(self) -> None:
        """Initialize LLM provider"""
        provider = self.config.provider if self.config.provider != "auto" else None
        self._llm_provider = LLMProvider(preferred_provider=provider)

        if not self._llm_provider.is_available():
            log.error(
                "No LLM provider available. Set OPENAI_API_KEY or MISTRAL_API_KEY."
            )
        else:
            info = self._llm_provider.get_provider_info()
            log.info(
                f"BeliefInitializer using {info['provider']} with model {info['model']}"
            )

    def llm_available(self) -> bool:
        """True if an LLM provider is configured for belief extraction."""
        return self._llm_provider is not None and self._llm_provider.is_available()

    def _init_embedder(self) -> None:
        self._embedder = SentenceTransformer(self.config.embedding_model)
        log.info(f"Loaded embedder: {self.config.embedding_model}")

    def _embed(self, texts: List[str]) -> np.ndarray:
        return self._embedder.encode(texts, normalize_embeddings=True)

    # Pipeline stages
    def collect_user_text(
        self, conn: sqlite3.Connection, subreddit: str, username: str
    ) -> str:
        """Concatenate a user's comments and submissions for the subreddit, truncated.

        Removed / deleted bodies and selftexts are skipped so moderation
        placeholders never reach belief extraction.
        """
        comments_q = "SELECT body FROM comments WHERE subreddit = ? AND author = ?"
        posts_q = (
            "SELECT title, selftext FROM submissions WHERE subreddit = ? AND author = ?"
        )
        texts: List[str] = []
        try:
            for (body,) in conn.execute(comments_q, (subreddit, username)):
                body = _usable_text(body)
                if body:
                    texts.append(body)
            for title, selftext in conn.execute(posts_q, (subreddit, username)):
                title = _usable_text(title)
                if title:
                    texts.append(title)
                selftext = _usable_text(selftext)
                if selftext:
                    texts.append(selftext)
        except Exception as e:
            log.warning(f"collect_user_text failed for {username}: {e}")

        full = "\n".join(texts)
        if len(full) > self.config.max_chars_per_user:
            full = full[: self.config.max_chars_per_user]
        return full

    def _belief_extraction_prompt(self, text: str) -> str:
        """Extraction prompt shared by the sequential and batch paths.

        Beliefs are stance-normalized: each belief_text states what the user
        believes, so strength is plain endorsement. The sim has no stance field;
        an "oppose" stance on the opposite claim would be read as support.
        """
        return (
            "Extract up to {k} concise, atomic beliefs (claims) the user holds, stated or implied.\n"
            "Write each belief_text as the user believes it. If the user rejects a claim, write the claim "
            "they DO believe instead, never the claim they reject. For example, a user arguing against "
            '"The new expansion is worth buying" holds "The new expansion is not worth buying".\n'
            'Output strict JSON: an object {{"beliefs": [...]}} where each item has keys: belief_text, belief_confidence.\n'
            "belief_confidence ∈ [0,1] is how strongly the user holds the belief.\n"
            f"Beliefs must be specific to the subreddit domain of {self.config.subreddit}; avoid personal or generic statements.\n"
            'Example output: {{"beliefs": [{{"belief_text": "X causes Y", "belief_confidence": 0.8}}]}}\n\n'
            f"User content:\n{text}\n"
        ).format(k=self.config.max_beliefs_per_user)

    def _clean_extracted_beliefs(self, data) -> List[Dict[str, str]]:
        """Validate parsed extraction output into [{belief_text, belief_confidence}]."""
        if not isinstance(data, list):
            return []
        cleaned: List[Dict[str, str]] = []
        for o in data[: self.config.max_beliefs_per_user]:
            if not isinstance(o, dict):
                continue
            bt = str(o.get("belief_text", "")).strip()
            try:
                conf = float(o.get("belief_confidence", 0.5))
            except (TypeError, ValueError):
                continue
            if bt and conf == conf:  # conf == conf rejects NaN
                cleaned.append(
                    {"belief_text": bt, "belief_confidence": max(0.0, min(1.0, conf))}
                )
        return cleaned

    def llm_extract_beliefs_for_user(
        self, username: str, text: str
    ) -> List[Dict[str, str]]:
        """Ask LLM to extract concise, stance-normalized beliefs. Returns list of
        dicts with keys: belief_text, belief_confidence [0,1]."""
        return self._extract_beliefs_with_status(username, text)[0]

    def _extract_beliefs_with_status(
        self, username: str, text: str
    ) -> Tuple[List[Dict[str, str]], str, str]:
        """Like llm_extract_beliefs_for_user, but returns (beliefs, status, error)
        where status is "extracted" | "empty" | "no_text" | "failed"."""
        if not text.strip():
            return [], "no_text", ""
        prompt = self._belief_extraction_prompt(text)

        try:
            result = complete_json(
                self._llm_provider,
                [{"role": "user", "content": prompt}],
                temperature=0.2,
                max_tokens=1000,
                expect=list,
                wrap_key="beliefs",
                label=f"Belief extraction ({username})",
            )
            if not result.ok:
                log.warning(
                    f"llm_extract_beliefs_for_user failed ({username}): {result.error}\n"
                    f"  Raw response: {result.raw[:200]}..."
                )
                return [], "failed", result.error or "LLM JSON extraction failed"
            beliefs = self._clean_extracted_beliefs(result.data)
            return beliefs, ("extracted" if beliefs else "empty"), ""
        except Exception as e:
            log.warning(f"llm_extract_beliefs_for_user failed ({username}): {e}")
            return [], "failed", f"{type(e).__name__}: {e}"

    def _hash_norm(self, s: str) -> str:
        """Lightweight normalization + hashing used when embeddings unavailable."""
        key = " ".join(s.lower().strip().split())
        return hashlib.sha1(key.encode("utf-8")).hexdigest()

    def cluster_and_canonicalize(
        self, all_belief_texts: List[str]
    ) -> Tuple[Dict[int, List[int]], Dict[int, str]]:
        """Cluster beliefs. Returns (cluster_index -> list of item idxs, cluster_index -> canonical_text).

        Embedding clusters group beliefs by topic and can hold opposite claims, so
        each one is split into groups NLI accepts as the same belief.
        """
        if not all_belief_texts:
            return {}, {}
        if len(all_belief_texts) == 1:
            # AgglomerativeClustering needs at least 2 samples
            return {0: [0]}, {0: all_belief_texts[0]}

        # Embedding path
        embs = self._embed(all_belief_texts)
        # Agglomerative clustering using cosine distance
        dist = cosine_distances(embs)
        # Build connectivity based on threshold: treat as single-link (approx)
        # We approximate by converting distances to adjacency under threshold and clustering
        # via AgglomerativeClustering with distance_threshold.
        try:
            ac = AgglomerativeClustering(
                n_clusters=None,
                affinity="precomputed",
                linkage="complete",
                distance_threshold=self.config.cluster_threshold,
            )
            labels = ac.fit_predict(dist)
        except TypeError:
            # sklearn >=1.4 deprecations; fallback without affinity param
            ac = AgglomerativeClustering(
                n_clusters=None,
                metric="precomputed",
                linkage="complete",
                distance_threshold=self.config.cluster_threshold,
            )
            labels = ac.fit_predict(dist)

        topic_clusters: Dict[int, List[int]] = {}
        for i, lab in enumerate(labels):
            topic_clusters.setdefault(int(lab), []).append(i)

        # Split each topic cluster into NLI-equivalent groups. Members are visited
        # most-central first, so the medoid founds the first group; each later
        # member joins the first group whose founder it is equivalent to.
        nli = get_belief_nli()
        clusters: Dict[int, List[int]] = {}
        canonical: Dict[int, str] = {}
        for idxs in topic_clusters.values():
            subd = dist[np.ix_(idxs, idxs)]
            ordered = [idxs[j] for j in np.argsort(subd.sum(axis=0))]
            founder_label: Dict[int, int] = {}  # founder item idx -> cluster label
            for i in ordered:
                founders = list(founder_label)
                same = nli.same_belief_many(
                    [(all_belief_texts[i], all_belief_texts[f]) for f in founders],
                    [1.0 - dist[i, f] for f in founders],
                )
                f = next((f for f, ok in zip(founders, same) if ok), None)
                if f is None:
                    lab = len(clusters)
                    founder_label[i] = lab
                    clusters[lab] = [i]
                    canonical[lab] = all_belief_texts[i]
                else:
                    clusters[founder_label[f]].append(i)

        log.info(
            f"Belief clustering: {len(topic_clusters)} topic clusters split into "
            f"{len(clusters)} NLI-equivalent clusters"
        )
        return clusters, canonical

    def save_clustering_metadata(
        self,
        canonical_beliefs: List[Dict[str, str]],
        all_belief_texts: List[str],
        clusters: Dict[int, List[int]],
        cluster_to_id: Dict[int, str],
        output_file: str = "belief_clustering_metadata.json",
    ) -> None:
        """Save detailed clustering information for analysis and tuning."""

        cluster_details = []
        for seq_idx, belief_id in cluster_to_id.items():
            member_indices = clusters.get(seq_idx, [])
            member_texts = [all_belief_texts[i] for i in member_indices]

            canonical_text = next(
                (
                    b["canonical_text"]
                    for b in canonical_beliefs
                    if b["belief_id"] == belief_id
                ),
                "",
            )

            intra_similarity = None
            if len(member_texts) > 1:
                member_embs = self._embed(member_texts)
                dist_matrix = cosine_distances(member_embs)
                similarities = 1 - dist_matrix[np.triu_indices_from(dist_matrix, k=1)]
                intra_similarity = float(np.mean(similarities))

            cluster_details.append(
                {
                    "belief_id": belief_id,
                    "canonical_text": canonical_text,
                    "cluster_size": len(member_texts),
                    "member_texts": member_texts,
                    "intra_cluster_similarity": intra_similarity,
                }
            )

        # Calculate inter-cluster similarities (between canonical texts)
        canonical_texts = [b["canonical_text"] for b in canonical_beliefs]
        if len(canonical_texts) > 1:
            canonical_embs = self._embed(canonical_texts)
            inter_dist = cosine_distances(canonical_embs)
            closest_pairs = []
            for i in range(len(canonical_texts)):
                for j in range(i + 1, len(canonical_texts)):
                    similarity = 1 - inter_dist[i, j]
                    closest_pairs.append(
                        {
                            "belief_1": canonical_beliefs[i]["belief_id"],
                            "text_1": canonical_texts[i],
                            "belief_2": canonical_beliefs[j]["belief_id"],
                            "text_2": canonical_texts[j],
                            "similarity": float(similarity),
                        }
                    )
            closest_pairs.sort(key=lambda x: x["similarity"], reverse=True)
            closest_pairs = closest_pairs[:20]
        else:
            closest_pairs = []

        metadata = {
            "config": {
                "embedding_model": self.config.embedding_model,
                "cluster_threshold": self.config.cluster_threshold,
                "num_original_beliefs": len(all_belief_texts),
                "num_canonical_beliefs": len(canonical_beliefs),
                "reduction_ratio": (
                    len(canonical_beliefs) / len(all_belief_texts)
                    if all_belief_texts
                    else 0
                ),
            },
            "cluster_details": cluster_details,
            "closest_canonical_pairs": closest_pairs,
            "summary": {
                "singleton_clusters": sum(
                    1 for c in cluster_details if c["cluster_size"] == 1
                ),
                "multi_member_clusters": sum(
                    1 for c in cluster_details if c["cluster_size"] > 1
                ),
                "largest_cluster_size": max(
                    (c["cluster_size"] for c in cluster_details), default=0
                ),
                "avg_intra_similarity": (
                    float(
                        np.mean(
                            [
                                c["intra_cluster_similarity"]
                                for c in cluster_details
                                if c["intra_cluster_similarity"] is not None
                            ]
                        )
                    )
                    if any(
                        c["intra_cluster_similarity"] is not None
                        for c in cluster_details
                    )
                    else None
                ),
            },
        }

        with open(output_file, "w") as f:
            json.dump(metadata, f, indent=2)

        log.info(f"Saved clustering metadata to {output_file}")
        log.info(f"  Original beliefs: {len(all_belief_texts)}")
        log.info(f"  Canonical beliefs: {len(canonical_beliefs)}")
        log.info(f"  Reduction: {metadata['config']['reduction_ratio']:.1%}")
        log.info(f"  Singleton clusters: {metadata['summary']['singleton_clusters']}")
        log.info(
            f"  Multi-member clusters: {metadata['summary']['multi_member_clusters']}"
        )

    def compute_user_strengths(
        self,
        user_extractions: Dict[str, List[Dict[str, str]]],
        all_belief_texts: List[str],
        clusters: Dict[int, List[int]],
        usernames: List[str],
    ) -> Tuple[Dict[str, Dict[int, float]], Dict[Tuple[str, int], str]]:
        """Compute per-user strength per cluster index.

        Args:
            usernames: List of usernames in the order beliefs were collected

        Returns:
            user_strengths: Dict[username][cluster_id] = strength
            user_cluster_texts: Dict[(username, cluster_id)] = original_belief_text
        """
        # Map raw belief idx -> cluster id
        idx2cluster: Dict[int, int] = {}
        for c_id, idxs in clusters.items():
            for i in idxs:
                idx2cluster[i] = c_id

        # Build a mapping from raw belief idx to (user, confidence)
        # First, flatten per-user beliefs preserving original order
        flattened: List[Tuple[str, int, Dict[str, str]]] = []
        # We rebuild the order by walking user_extractions consistent with all_belief_texts
        text_to_positions: Dict[str, List[int]] = {}
        for pos, t in enumerate(all_belief_texts):
            text_to_positions.setdefault(t, []).append(pos)

        # Same order in which all_belief_texts was built
        for user in usernames:
            beliefs = user_extractions.get(user, [])
            for b in beliefs:
                t = str(b.get("belief_text", "")).strip()
                if not t or t not in text_to_positions or not text_to_positions[t]:
                    continue
                raw_idx = text_to_positions[t].pop(0)
                flattened.append((user, raw_idx, b))

        # Aggregate strengths per user per cluster AND track original texts
        user_strengths: Dict[str, Dict[int, float]] = {}
        user_cluster_texts: Dict[Tuple[str, int], str] = (
            {}
        )  # (user, cluster_id) -> original_text
        freq_gain = self.config.freq_gain

        # Beliefs are stance-normalized at extraction (belief_text is what the user
        # believes), so confidence is endorsement strength directly
        conf_sum: Dict[str, Dict[int, float]] = {}
        occur: Dict[str, Dict[int, int]] = {}
        for user, raw_idx, meta in flattened:
            c_id = idx2cluster.get(raw_idx)
            if c_id is None:
                continue
            conf = float(meta.get("belief_confidence", 0.5))
            conf_sum.setdefault(user, {})
            occur.setdefault(user, {})
            conf_sum[user][c_id] = conf_sum[user].get(c_id, 0.0) + conf
            occur[user][c_id] = occur[user].get(c_id, 0) + 1
            # Keep the user's first wording; it is shown to the LLM as their belief
            user_cluster_texts.setdefault(
                (user, c_id), str(meta.get("belief_text", "")).strip()
            )

        # Strength = mean confidence, scaled by a saturating frequency factor in
        # [0.75, 1): one mention keeps ~85% of confidence, repeated ones approach 100%
        for user, sums in conf_sum.items():
            user_strengths[user] = {}
            for c_id, total in sums.items():
                cnt = occur[user][c_id]
                boost = 1 - math.exp(-freq_gain * cnt)
                strength = (total / cnt) * (0.75 + 0.25 * boost)
                user_strengths[user][c_id] = float(max(0.0, min(1.0, strength)))

        return user_strengths, user_cluster_texts

    # Batch processing
    def _should_use_batch(self) -> bool:
        """Check if batch API should be used."""
        if not self.config.use_batch_api:
            return False
        # Only Mistral supports batch API currently
        info = self._llm_provider.get_provider_info()
        return info["provider"] == "mistral"

    def _llm_extract_beliefs_batch(
        self,
        user_texts: Dict[str, str],
    ) -> Optional[Dict[str, Tuple[List[Dict[str, str]], str, str]]]:
        """Extract beliefs for multiple users using Mistral Batch API.

        Args:
            user_texts: Dict mapping username to their text content

        Returns:
            Dict mapping username to (beliefs, status, error) as in
            _extract_beliefs_with_status, or None if the batch client is
            unavailable and the caller should fall back to sequential calls.
            Users with no text, or missing from the batch output, are absent.
        """
        import tempfile

        log.info(
            f"Using Mistral Batch API for {len(user_texts)} users (50% cost savings)"
        )

        batch_requests = []
        for username, text in user_texts.items():
            if not text.strip():
                continue

            prompt = self._belief_extraction_prompt(text)

            batch_requests.append(
                {
                    "custom_id": username,
                    "body": {
                        "messages": [{"role": "user", "content": prompt}],
                        "temperature": 0.2,
                        "max_tokens": 1000,
                        "response_format": {"type": "json_object"},
                    },
                }
            )

        if not batch_requests:
            return {}

        with tempfile.NamedTemporaryFile(mode="w", suffix=".jsonl", delete=False) as f:
            batch_file = f.name
            for req in batch_requests:
                f.write(json.dumps(req) + "\n")

        try:
            # Submit batch job using Mistral client
            try:
                from mistralai import Mistral  # type: ignore
            except ImportError:
                log.error(
                    "mistralai package not installed. Install with: pip install mistralai"
                )
                log.error("Falling back to sequential processing...")
                return None

            client = Mistral(api_key=os.getenv("MISTRAL_API_KEY"))

            log.info("Uploading batch file...")
            with open(batch_file, "rb") as f:
                uploaded_file = client.files.upload(
                    file={"file_name": "batch.jsonl", "content": f},
                    purpose="batch",  # Mistral defaults to fine tuning otherwise
                )

            log.info(f"Creating batch job with {len(batch_requests)} requests...")
            batch_job = client.batch.jobs.create(
                input_files=[uploaded_file.id],
                model=self._llm_provider.model,
                endpoint="/v1/chat/completions",
            )

            log.info(f"Batch job {batch_job.id} submitted. Polling for completion...")
            import time

            while True:
                status = client.batch.jobs.get(job_id=batch_job.id)
                log.info(
                    f"Batch status: {status.status} ({status.completed_requests or 0}/{status.total_requests or 0} complete)"
                )

                if status.status == "SUCCESS":
                    break
                elif status.status in ["FAILED", "CANCELLED"]:
                    raise RuntimeError(f"Batch job {status.status}")

                time.sleep(self.config.batch_poll_interval)

            log.info("Downloading batch results...")
            output_file_id = status.output_file
            response = client.files.download(file_id=output_file_id)

            if hasattr(response, "read"):
                output_content = response.read()
            elif hasattr(response, "content"):
                output_content = response.content
            elif hasattr(response, "text"):
                output_content = response.text.encode("utf-8")
            else:
                output_content = response

            results = {}
            output_text = (
                output_content.decode("utf-8")
                if isinstance(output_content, bytes)
                else str(output_content)
            )
            for line in output_text.strip().split("\n"):
                if not line.strip():
                    continue
                result = json.loads(line)
                username = result["custom_id"]

                # Extract beliefs from response (a per-request error has no choices)
                try:
                    response_content = result["response"]["body"]["choices"][0][
                        "message"
                    ]["content"]
                    data, _, err = parse_json_text(
                        response_content, expect=list, wrap_key="beliefs"
                    )
                    if data is None:
                        raise ValueError(err)
                    beliefs = self._clean_extracted_beliefs(data)
                    results[username] = (
                        beliefs,
                        "extracted" if beliefs else "empty",
                        "",
                    )
                except Exception as e:
                    log.warning(f"Failed to parse batch result for {username}: {e}")
                    results[username] = (
                        [],
                        "failed",
                        f"batch result unusable: {type(e).__name__}: {e}",
                    )

            log.info(
                f"Batch processing complete. Extracted beliefs for {len(results)} users."
            )
            return results

        finally:
            if os.path.exists(batch_file):
                os.unlink(batch_file)

    # Orchestration
    def _log_extraction_stats(self, stats: Dict) -> None:
        """WARNING-level summary of per-user extraction outcomes."""
        log.warning(
            "Belief extraction summary (%s): %d users -> %d with beliefs, "
            "%d empty (LLM ok, no beliefs), %d no usable text, "
            "%d FAILED (%.0f%% of attempted)",
            stats["mode"],
            stats["total_users"],
            stats["extracted"],
            stats["empty"],
            stats["no_text"],
            stats["failed"],
            100.0 * extraction_failure_fraction(stats),
        )
        for reason, n in sorted(
            stats["failure_reasons"].items(), key=lambda kv: -kv[1]
        ):
            log.warning("  belief extraction failure x%d: %s", n, reason)

    def build_beliefs_for_users(
        self,
        conn: sqlite3.Connection,
        subreddit: str,
        usernames: List[str],
        output_dir: Optional[str] = None,
    ) -> Tuple[
        List[Dict[str, str]], Dict[str, Dict[str, float]], Dict[str, Dict[str, str]]
    ]:
        """Main entry: returns (canonical_beliefs, user_beliefs_map, user_belief_texts).

        Returns:
            canonical_beliefs: List of canonical beliefs with IDs
            user_beliefs_map: Dict[username][belief_id] = strength
            user_belief_texts: Dict[username][belief_id] = original_belief_text
        """
        # 1) Collect per-user text
        user_texts: Dict[str, str] = {}
        for u in usernames:
            user_texts[u] = self.collect_user_text(conn, subreddit, u)

        # 2) Extract candidate beliefs (batch or sequential)
        user_extractions: Dict[str, List[Dict[str, str]]] = {}
        batch_results = None
        if self._should_use_batch():
            batch_results = self._llm_extract_beliefs_batch(user_texts)

        if batch_results is not None:
            stats = _new_extraction_stats(len(usernames), "mistral_batch")
            for u in usernames:
                if not user_texts[u].strip():
                    beliefs, status, err = [], "no_text", ""
                else:
                    beliefs, status, err = batch_results.get(
                        u, ([], "failed", "missing from batch output")
                    )
                user_extractions[u] = beliefs
                _record_outcome(stats, status, err)
        else:
            # Sequential processing (fallback for OpenAI or when batch disabled)
            stats = _new_extraction_stats(len(usernames), "sequential")
            for u in usernames:
                beliefs, status, err = self._extract_beliefs_with_status(
                    u, user_texts[u]
                )
                user_extractions[u] = beliefs
                _record_outcome(stats, status, err)

        self.last_extraction_stats = stats
        self._log_extraction_stats(stats)

        # 3) Collect all belief texts
        all_belief_texts: List[str] = []
        for user in usernames:
            beliefs = user_extractions.get(user, [])
            for b in beliefs:
                t = str(b.get("belief_text", "")).strip()
                if t:
                    all_belief_texts.append(t)

        if not all_belief_texts:
            log.warning("No beliefs extracted across users.")
            return [], {u: {} for u in usernames}, {u: {} for u in usernames}

        # 4) Cluster and canonicalize
        clusters, canonical_texts_dict = self.cluster_and_canonicalize(all_belief_texts)

        # Create a mapping from original cluster IDs (from sklearn) to sequential indices
        # sklearn cluster IDs can be arbitrary integers, but we need sequential 0, 1, 2...
        original_cluster_ids = sorted(clusters.keys())
        cluster_id_remap: Dict[int, int] = {
            orig_id: seq_idx for seq_idx, orig_id in enumerate(original_cluster_ids)
        }

        remapped_clusters: Dict[int, List[int]] = {
            cluster_id_remap[orig_id]: idxs for orig_id, idxs in clusters.items()
        }

        remapped_canonical_texts_dict: Dict[int, str] = {
            cluster_id_remap[orig_id]: canonical_texts_dict[orig_id]
            for orig_id in original_cluster_ids
        }

        remapped_canonical_texts: List[str] = [
            remapped_canonical_texts_dict[seq_idx]
            for seq_idx in range(len(original_cluster_ids))
        ]

        # 5) Compute user strengths by cluster id and get original texts
        user_cluster_strengths, user_cluster_original_texts = (
            self.compute_user_strengths(
                user_extractions, all_belief_texts, remapped_clusters, usernames
            )
        )

        # 6) Build canonical belief list with stable IDs and user mapping
        # Map cluster idx -> belief_id
        canonical_beliefs: List[Dict[str, str]] = []
        cluster_to_id: Dict[int, str] = {}
        for seq_idx in range(len(original_cluster_ids)):
            canon = remapped_canonical_texts[seq_idx]
            belief_id = hashlib.sha1(
                (canon or str(seq_idx)).encode("utf-8")
            ).hexdigest()[:16]
            cluster_to_id[seq_idx] = belief_id
            canonical_beliefs.append(
                {
                    "belief_id": belief_id,
                    "canonical_text": canon,
                    "example_paraphrases": [],
                }
            )

        user_beliefs_map: Dict[str, Dict[str, float]] = {}
        user_belief_texts: Dict[str, Dict[str, str]] = {}

        for user, c_map in user_cluster_strengths.items():
            user_beliefs_map[user] = {}
            user_belief_texts[user] = {}
            for c_idx, strength in c_map.items():
                b_id = cluster_to_id.get(c_idx)
                if b_id is not None:
                    user_beliefs_map[user][b_id] = float(max(0.0, min(1.0, strength)))

                    original_text = user_cluster_original_texts.get((user, c_idx), "")
                    if original_text:
                        user_belief_texts[user][b_id] = original_text

        # Save clustering metadata for analysis and tuning
        if output_dir:
            output_path = Path(output_dir)
            output_path.mkdir(parents=True, exist_ok=True)
            output_file = output_path / "belief_clustering_metadata.json"
        else:
            output_file = Path("belief_clustering_metadata.json")
        self.save_clustering_metadata(
            canonical_beliefs,
            all_belief_texts,
            remapped_clusters,
            cluster_to_id,
            output_file=str(output_file),
        )

        return canonical_beliefs, user_beliefs_map, user_belief_texts

    def canonicalize_synthetic_beliefs(
        self,
        synthetic_beliefs: Dict[str, float],
        canonical_beliefs: List[Dict[str, str]],
        similarity_threshold: float = 0.75,
    ) -> Dict[str, float]:
        """Map synthetic beliefs (e.g., from attackers) to canonical belief space.

        Args:
            synthetic_beliefs: Dict[belief_text] = strength
            canonical_beliefs: List of canonical beliefs from build_beliefs_for_users
            similarity_threshold: Minimum similarity to map to existing canonical belief

        Returns:
            Dict[belief_id] = strength, mapped to canonical belief IDs
        """
        if not synthetic_beliefs or not canonical_beliefs:
            return {}

        canonical_texts = [b["canonical_text"] for b in canonical_beliefs]
        canonical_ids = [b["belief_id"] for b in canonical_beliefs]

        synthetic_texts = list(synthetic_beliefs.keys())
        all_texts = canonical_texts + synthetic_texts
        all_embs = self._embed(all_texts)

        canonical_embs = all_embs[: len(canonical_texts)]
        synthetic_embs = all_embs[len(canonical_texts) :]

        mapped_beliefs: Dict[str, float] = {}
        mapping_log = []

        for i, synthetic_text in enumerate(synthetic_texts):
            synthetic_emb = synthetic_embs[i : i + 1]
            strength = synthetic_beliefs[synthetic_text]

            similarities = 1 - cosine_distances(synthetic_emb, canonical_embs)[0]
            best_idx = int(np.argmax(similarities))
            best_similarity = similarities[best_idx]

            if best_similarity >= similarity_threshold:
                belief_id = canonical_ids[best_idx]
                mapped_beliefs[belief_id] = (
                    mapped_beliefs.get(belief_id, 0.0) + strength
                )

                mapping_log.append(
                    {
                        "synthetic_text": synthetic_text,
                        "canonical_text": canonical_texts[best_idx],
                        "belief_id": belief_id,
                        "similarity": float(best_similarity),
                        "strength": strength,
                        "action": "mapped_to_existing",
                    }
                )
            else:
                new_belief_id = hashlib.sha1(
                    synthetic_text.encode("utf-8")
                ).hexdigest()[:16]
                mapped_beliefs[new_belief_id] = strength

                canonical_beliefs.append(
                    {
                        "belief_id": new_belief_id,
                        "canonical_text": synthetic_text,
                        "example_paraphrases": [],
                    }
                )
                canonical_texts.append(synthetic_text)
                canonical_ids.append(new_belief_id)

                # Re-embed canonical beliefs to include new one
                canonical_embs = self._embed(canonical_texts)

                mapping_log.append(
                    {
                        "synthetic_text": synthetic_text,
                        "canonical_text": synthetic_text,
                        "belief_id": new_belief_id,
                        "similarity": None,
                        "strength": strength,
                        "action": "created_new_canonical",
                    }
                )

        max_strength = max(mapped_beliefs.values()) if mapped_beliefs else 1.0
        if max_strength > 1.0:
            mapped_beliefs = {k: v / max_strength for k, v in mapped_beliefs.items()}

        log.info(f"Canonicalized {len(synthetic_beliefs)} synthetic beliefs:")
        log.info(
            f"  Mapped to existing: {sum(1 for m in mapping_log if m['action'] == 'mapped_to_existing')}"
        )
        log.info(
            f"  Created new canonical: {sum(1 for m in mapping_log if m['action'] == 'created_new_canonical')}"
        )

        with open("synthetic_belief_mapping.json", "w") as f:
            json.dump(
                {
                    "threshold": similarity_threshold,
                    "mappings": mapping_log,
                    "summary": {
                        "num_synthetic": len(synthetic_beliefs),
                        "num_mapped_to_existing": sum(
                            1
                            for m in mapping_log
                            if m["action"] == "mapped_to_existing"
                        ),
                        "num_new_canonical": sum(
                            1
                            for m in mapping_log
                            if m["action"] == "created_new_canonical"
                        ),
                    },
                },
                f,
                indent=2,
            )

        return mapped_beliefs

    def experiment_with_clustering_thresholds(
        self,
        all_belief_texts: List[str],
        thresholds: List[float] = None,
    ) -> Dict[float, Dict]:
        """Experiment with different clustering thresholds to find optimal setting.

        Args:
            all_belief_texts: List of all belief texts to cluster
            thresholds: List of distance thresholds to try (default: [0.20, 0.30, 0.40, 0.50, 0.60])

        Returns:
            Dict mapping threshold to clustering results
        """
        if thresholds is None:
            thresholds = [0.20, 0.30, 0.40, 0.50, 0.60]

        if not all_belief_texts:
            log.warning("No belief texts provided for threshold experimentation")
            return {}

        log.info(
            f"Experimenting with {len(thresholds)} clustering thresholds on {len(all_belief_texts)} beliefs..."
        )

        embs = self._embed(all_belief_texts)
        dist = cosine_distances(embs)

        results = {}

        for threshold in thresholds:
            log.info(f"  Testing threshold {threshold:.2f}...")

            try:
                ac = AgglomerativeClustering(
                    n_clusters=None,
                    affinity="precomputed",
                    linkage="complete",
                    distance_threshold=threshold,
                )
                labels = ac.fit_predict(dist)
            except TypeError:
                # sklearn >=1.4 deprecations
                ac = AgglomerativeClustering(
                    n_clusters=None,
                    metric="precomputed",
                    linkage="complete",
                    distance_threshold=threshold,
                )
                labels = ac.fit_predict(dist)

            clusters: Dict[int, List[int]] = {}
            for i, lab in enumerate(labels):
                clusters.setdefault(int(lab), []).append(i)

            cluster_sizes = [len(idxs) for idxs in clusters.values()]

            intra_similarities = []
            for idxs in clusters.values():
                if len(idxs) > 1:
                    subd = dist[np.ix_(idxs, idxs)]
                    avg_dist = np.mean(subd)
                    intra_similarities.append(1 - avg_dist)

            canonical_texts = []
            for idxs in clusters.values():
                if len(idxs) == 1:
                    canonical_texts.append(all_belief_texts[idxs[0]])
                else:
                    subd = dist[np.ix_(idxs, idxs)]
                    medoid_local = int(np.argmin(subd.sum(axis=0)))
                    canonical_texts.append(all_belief_texts[idxs[medoid_local]])

            min_inter_similarity = None
            if len(canonical_texts) > 1:
                canonical_embs = self._embed(canonical_texts)
                inter_dist = cosine_distances(canonical_embs)
                np.fill_diagonal(inter_dist, np.inf)
                min_dist = np.min(inter_dist)
                min_inter_similarity = 1 - min_dist

            results[threshold] = {
                "num_clusters": len(clusters),
                "reduction_ratio": len(clusters) / len(all_belief_texts),
                "singleton_clusters": sum(1 for size in cluster_sizes if size == 1),
                "multi_member_clusters": sum(1 for size in cluster_sizes if size > 1),
                "largest_cluster": max(cluster_sizes),
                "avg_cluster_size": float(np.mean(cluster_sizes)),
                "avg_intra_similarity": (
                    float(np.mean(intra_similarities)) if intra_similarities else None
                ),
                "min_inter_similarity": (
                    float(min_inter_similarity)
                    if min_inter_similarity is not None
                    else None
                ),
            }

        output = {
            "num_original_beliefs": len(all_belief_texts),
            "thresholds_tested": thresholds,
            "results": results,
            "recommendations": self._generate_threshold_recommendations(results),
        }

        with open("clustering_threshold_experiments.json", "w") as f:
            json.dump(output, f, indent=2)

        log.info(
            "Threshold experimentation complete. Results saved to clustering_threshold_experiments.json"
        )

        print("\n" + "=" * 70)
        print("CLUSTERING THRESHOLD EXPERIMENTATION RESULTS")
        print("=" * 70)
        print(f"Original beliefs: {len(all_belief_texts)}")
        print(
            "\nThreshold | Clusters | Reduction | Avg Intra-Sim | Min Inter-Sim | Quality"
        )
        print("-" * 70)

        for threshold in thresholds:
            r = results[threshold]
            quality = self._assess_clustering_quality(r)
            print(
                f"{threshold:9.2f} | {r['num_clusters']:8d} | {r['reduction_ratio']:9.1%} | "
                f"{r['avg_intra_similarity']:13.3f} | {r['min_inter_similarity']:13.3f} | {quality}"
            )

        print("\nRecommendations:")
        for rec in output["recommendations"]:
            print(f"  • {rec}")
        print("=" * 70 + "\n")

        return results

    def _generate_threshold_recommendations(
        self, results: Dict[float, Dict]
    ) -> List[str]:
        """Generate recommendations based on threshold experiment results."""
        recommendations = []

        # Find threshold with best balance
        best_threshold = None
        best_score = -1

        for threshold, metrics in results.items():
            # Score based on:
            # - High intra-cluster similarity (cohesive clusters)
            # - Low min inter-cluster similarity (distinct clusters)
            # - Reasonable reduction (30-70%)
            intra_sim = metrics.get("avg_intra_similarity", 0) or 0
            inter_sim = metrics.get("min_inter_similarity", 1) or 1
            reduction = metrics.get("reduction_ratio", 0)

            reduction_score = 1 - abs(reduction - 0.5)

            score = (
                (intra_sim * 0.4) + ((1 - inter_sim) * 0.4) + (reduction_score * 0.2)
            )

            if score > best_score:
                best_score = score
                best_threshold = threshold

        if best_threshold is not None:
            recommendations.append(
                f"Best overall threshold: {best_threshold:.2f} (score: {best_score:.3f})"
            )

        for threshold, metrics in results.items():
            if metrics.get("avg_intra_similarity", 1) < 0.7:
                recommendations.append(
                    f"Threshold {threshold:.2f} may be too loose (low intra-cluster similarity)"
                )
            if metrics.get("min_inter_similarity", 0) > 0.7:
                recommendations.append(
                    f"Threshold {threshold:.2f} may be too strict (high inter-cluster similarity)"
                )
            if metrics.get("reduction_ratio", 0) > 0.9:
                recommendations.append(
                    f"Threshold {threshold:.2f} causes excessive merging"
                )
            if metrics.get("reduction_ratio", 1) < 0.1:
                recommendations.append(
                    f"Threshold {threshold:.2f} causes excessive fragmentation"
                )

        return recommendations

    def _assess_clustering_quality(self, metrics: Dict) -> str:
        """Assess clustering quality based on metrics."""
        intra_sim = metrics.get("avg_intra_similarity", 0) or 0
        inter_sim = metrics.get("min_inter_similarity", 1) or 1
        reduction = metrics.get("reduction_ratio", 0)

        score = (
            (intra_sim * 0.4)
            + ((1 - inter_sim) * 0.4)
            + (1 - abs(reduction - 0.5)) * 0.2
        )

        if score > 0.7:
            return "Excellent"
        elif score > 0.6:
            return "Good"
        elif score > 0.5:
            return "Fair"
        elif score > 0.4:
            return "Poor"
        else:
            return "Bad"


__all__ = [
    "BeliefPipelineConfig",
    "BeliefInitializer",
]
