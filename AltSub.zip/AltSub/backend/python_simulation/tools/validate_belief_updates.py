#!/usr/bin/env python3
"""
Controlled post tests of the belief-update mechanism: does reading a post
change the statements it is about, in the right direction, without changing
unrelated ones?

Every test calls the simulation's own update (LLMRedditService.
update_axis_positions: same prompt, temperature and 0.15 cap) through the
simulation's LLM client, starting every statement at the same value
(--starts, default 0.5 = where organic users start, plus 0.25 and 0.75).

Inputs: validation/belief_space/scenario_items.json (shared with the semantic
check): each post has the expected reading of the statements it is about
('high' / 'low' / 'neutral'); statements not listed are unrelated.

Checks (pass criteria in CRITERIA):
  direction   high post -> target rises, low post -> target falls (change of
              at least MOVE in the right direction)
  neutral     ambivalent post -> target does not move away from neutral: from
              0.5 it stays within NEUTRAL_BAND; from 0.25 / 0.75 it may move
              toward 0.5 but not away from it by MOVE or more
  spillover   unrelated statements change by more than MOVE in at most
              off_target_max_rate of updates (off-topic posts: every statement)
  cap         proposals the LLM made beyond the cap (the code clamps them;
              reported, not a pass criterion)

Artifacts: <out-root>/<run_id>/ manifest.json, calls.jsonl (messages, raw
reply, proposed and clamped values), summary/*.csv, report.md.

Usage (from backend/):
  python -m python_simulation.tools.validate_belief_updates --dry-run
  python -m python_simulation.tools.validate_belief_updates --kind development
"""

import argparse
import json
import logging
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..core.belief_axes import NEUTRAL
from ..services.llm_json import extract_json_text, unit_float
from .validate_belief_semantics import (
    DEFAULT_ITEMS,
    SCENARIOS,
    VALIDATION_DIR,
    CallLog,
    Scenario,
    _git_state,
    _mean_sd,
    _sha,
    _write_csv,
    load_scenarios,
    make_provider,
    make_service,
)

log = logging.getLogger(__name__)

DEFAULT_OUT_ROOT = VALIDATION_DIR / "updates"
DEFAULT_STARTS = (0.5, 0.25, 0.75)
MOVE = 0.02          # a change at least this large counts as movement
NEUTRAL_BAND = 0.05  # from 0.5, ambivalent posts should move the target less than this

CRITERIA = {
    "direction_min_rate": 0.8,
    "neutral_min_rate": 0.8,
    "off_target_max_rate": 0.2,
}


def _proposed(raw: Optional[str], axes) -> Dict[str, Optional[float]]:
    """Values the LLM proposed (before the cap), from its raw reply."""
    alias = {f"a{n}": a.id for n, a in enumerate(axes, start=1)}
    out: Dict[str, Optional[float]] = {}
    try:
        data = json.loads(extract_json_text(raw or ""))
    except (ValueError, TypeError):
        return out
    if isinstance(data, dict):
        for k, v in data.items():
            sid = alias.get(str(k).strip("[] "))
            if sid is not None:
                out[sid] = unit_float(v)
    return out


def build_tasks(scenarios: List[Scenario], starts, reps: int) -> List[Dict[str, Any]]:
    tasks = []
    for sc in scenarios:
        for rep in range(1, reps + 1):
            for start in starts:
                for item in sc.items:
                    tasks.append({"kind": "update", "scenario": sc, "item": item, "start": start, "rep": rep})
    return tasks


def run_task(task: Dict[str, Any], service, calls: CallLog) -> None:
    sc: Scenario = task["scenario"]
    axes = sc.config.axes
    item = task["item"]
    positions = {a.id: task["start"] for a in axes}
    service._llm_provider.reset()
    t0 = time.perf_counter()
    updated = service.update_axis_positions(item["text"], dict(positions), axes)
    ex = service._llm_provider.exchanges()
    raw = ex[-1]["reply"] if ex else None
    calls.write({
        "scenario": sc.name, "kind": task["kind"], "item_id": item["id"],
        "expected": item.get("expected", {}), "start": task["start"], "rep": task["rep"],
        "temperature": ex[-1]["temperature"] if ex else None,
        "messages": ex[-1]["messages"] if ex else [], "raw": raw,
        "proposed": _proposed(raw, axes), "updated": updated,
        "delta": {sid: round(updated[sid] - positions[sid], 4) for sid in positions},
        "elapsed_s": round(time.perf_counter() - t0, 2),
    })


# Analysis


def _neutral_ok(delta: float, start: float) -> bool:
    """Ambivalent content: no movement away from neutral (toward 0.5 is fine)."""
    if abs(start - NEUTRAL) < 1e-9:
        return abs(delta) < NEUTRAL_BAND
    away = delta * (start - NEUTRAL) > 0
    return not (away and abs(delta) >= MOVE)


def analyze(records: List[Dict[str, Any]], cap: float) -> Dict[str, List[Dict[str, Any]]]:
    upd = [r for r in records if r["kind"] == "update"]
    tables: Dict[str, List[Dict[str, Any]]] = {}

    # direction / neutral per item x target x start
    groups: Dict[Tuple, List[float]] = {}
    for r in upd:
        for sid, label in r["expected"].items():
            groups.setdefault((r["scenario"], r["item_id"], sid, label, r["start"]), []).append(r["delta"][sid])
    rows = []
    for (sc, item_id, sid, label, start), ds in sorted(groups.items()):
        if label == "neutral":
            ok = sum(_neutral_ok(d, start) for d in ds)
            need = CRITERIA["neutral_min_rate"]
        else:
            sign = 1 if label == "high" else -1
            ok = sum(d * sign >= MOVE for d in ds)
            need = CRITERIA["direction_min_rate"]
        m, sd = _mean_sd(ds)
        rows.append({"scenario": sc, "item_id": item_id, "statement_id": sid, "expected": label,
                     "start": start, "reps": len(ds), "mean_delta": round(m, 4), "sd": round(sd, 4),
                     "ok_rate": round(ok / len(ds), 3), "pass": ok / len(ds) >= need})
    tables["targets"] = rows

    # spillover: unrelated statements per item target (off-topic posts: all statements)
    spill: Dict[Tuple, List[float]] = {}
    for r in upd:
        target = "|".join(sorted(r["expected"])) or "off-topic"
        for sid, d in r["delta"].items():
            if sid not in r["expected"]:
                spill.setdefault((r["scenario"], target, sid), []).append(d)
    tables["spillover"] = [
        {"scenario": sc, "item_target": target, "other_statement": sid, "updates": len(ds),
         "moved": sum(abs(d) >= MOVE for d in ds),
         "rate": round(sum(abs(d) >= MOVE for d in ds) / len(ds), 3),
         "mean_delta": round(sum(ds) / len(ds), 4),
         "pass": sum(abs(d) >= MOVE for d in ds) / len(ds) <= CRITERIA["off_target_max_rate"]}
        for (sc, target, sid), ds in sorted(spill.items())
    ]

    # cap: proposals beyond the cap (informational)
    cap_rows: Dict[str, List[int]] = {}
    for r in records:
        for sid, v in (r.get("proposed") or {}).items():
            if v is None:
                continue
            counts = cap_rows.setdefault(r["scenario"], [0, 0])
            counts[1] += 1
            counts[0] += abs(v - r["start"]) > cap + 1e-9
    tables["cap"] = [{"scenario": sc, "proposals": n, "beyond_cap": k, "rate": round(k / n, 3) if n else None,
                      "pass": True} for sc, (k, n) in sorted(cap_rows.items())]

    return tables


def write_report(path: Path, manifest: Dict[str, Any], tables: Dict[str, List[Dict[str, Any]]]) -> None:
    lines = [f"# Belief update tests: {manifest['run_id']}", "",
             f"- Kind: {manifest['kind']}  |  model: {manifest['model']}  |  reps: {manifest['reps']}"
             f"  |  starts: {manifest['starts']}",
             f"- Git: {manifest['git_commit']}{' (dirty)' if manifest['git_dirty'] else ''}",
             f"- Movement threshold {MOVE}, neutral band {NEUTRAL_BAND}, cap {manifest['cap']}",
             f"- Criteria: `{json.dumps(CRITERIA)}`", ""]
    for name, rows in tables.items():
        failed = [r for r in rows if not r.get("pass")]
        lines.append(f"## {name}: {len(rows) - len(failed)}/{len(rows)} pass")
        for r in failed:
            lines.append("- FAIL " + ", ".join(f"{k}={v}" for k, v in r.items() if k != "pass"))
        lines.append("")
    path.write_text("\n".join(lines), encoding="utf-8")


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Controlled post tests of the belief-update mechanism")
    parser.add_argument("--items", type=Path, default=DEFAULT_ITEMS)
    parser.add_argument("--out-root", type=Path, default=DEFAULT_OUT_ROOT)
    parser.add_argument("--provider", default="auto", help="auto | mistral | openai | local | stub")
    parser.add_argument("--scenario", choices=[*SCENARIOS, "all"], default="all")
    parser.add_argument("--starts", type=float, nargs="+", default=list(DEFAULT_STARTS))
    parser.add_argument("--reps", type=int, default=5)
    parser.add_argument("--kind", choices=["development", "record"], default="development")
    parser.add_argument("--max-workers", type=int, default=4)
    parser.add_argument("--label", default="")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    names = list(SCENARIOS) if args.scenario == "all" else [args.scenario]
    items_data = json.loads(Path(args.items).read_text(encoding="utf-8"))
    scenarios = load_scenarios(names, args.items)
    tasks = build_tasks(scenarios, args.starts, args.reps)
    if args.dry_run:
        print(f"{len(tasks)} update call(s)")
        return 0

    provider = make_provider(args.provider)
    if provider is None or not provider.is_available():
        print("No LLM provider available (set MISTRAL_API_KEY, or --provider stub)", file=sys.stderr)
        return 1
    service = make_service(provider)
    cap = service.config.belief_update_max_change

    run_id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + uuid.uuid4().hex[:6]
    run_dir = Path(args.out_root) / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    commit, dirty = _git_state()
    manifest = {
        "run_id": run_id, "kind": args.kind, "label": args.label,
        "created": datetime.now(timezone.utc).isoformat(), "git_commit": commit, "git_dirty": dirty,
        "model": getattr(provider, "model", None) or type(provider).__name__,
        "reps": args.reps, "starts": args.starts, "cap": cap, "criteria": CRITERIA,
        "movement_threshold": MOVE, "neutral_band": NEUTRAL_BAND,
        "update_path": "LLMRedditService.update_axis_positions (simulation prompt, temperature and cap)",
        "scenario_items": {"path": str(args.items), "sha": _sha(Path(args.items).read_text(encoding="utf-8"))},
        "belief_sets": {sc.name: {"source": sc.config.source,
                                  "statements": [{"id": a.id, "statement": a.statement} for a in sc.config.axes]}
                        for sc in scenarios},
    }
    (run_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")
    calls = CallLog(run_dir / "calls.jsonl", run_id, manifest["model"])
    log.info("Run %s: %d update call(s) -> %s", run_id, len(tasks), run_dir)
    with ThreadPoolExecutor(max_workers=max(1, args.max_workers)) as pool:
        for future in [pool.submit(run_task, t, service, calls) for t in tasks]:
            future.result()

    tables = analyze(calls.records, cap)
    for name, rows in tables.items():
        _write_csv(run_dir / "summary" / f"{name}.csv", rows)
    write_report(run_dir / "report.md", manifest, tables)
    print(f"Wrote {run_dir}")
    for name, rows in tables.items():
        print(f"  {name}: {sum(1 for r in rows if r.get('pass'))}/{len(rows)} pass")
    return 0


if __name__ == "__main__":
    sys.exit(main())
