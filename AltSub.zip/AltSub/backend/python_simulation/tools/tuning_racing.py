"""
Successive halving, Hyperband and racing for noisy, expensive evaluations.

This module only schedules: which configuration to evaluate, at which fidelity
(simulated days) and on which seeds. Running a simulation is the caller's
`evaluate` callback (parameter_tuning.SimulationEvaluator), so the logic here is
tested with synthetic objectives (tests/unit/test_tuning_racing.py).

Pipeline (run_search):

1. Successive halving over rungs. A rung is (days, seeds): every live config is
   run for `days` simulated days on the first `seeds` seeds of the tuning seed
   stream, ranked by mean objective, and the best 1/eta move on. All configs in
   a rung share the same seeds (common random numbers), so differences between
   configs are not differences between seeds. A rung with the same days as an
   earlier one reuses those runs and only adds the new seeds.
2. Hyperband (optional): several halving brackets, each starting at a later
   rung with fewer configs. The last bracket runs its configs at full fidelity
   only, so a config that looks bad in short runs (long-lookback detectors) is
   still found. Survivors of every bracket meet in the race.
3. Race (F-race style, as in irace): the finalists keep getting one more seed at
   the final rung's fidelity; after `race_min_seeds` seeds, a Friedman test
   across finalists (paired t-test when only two remain) decides whether they
   differ, and configs significantly worse than the leader (one-sided paired
   t-test, p < alpha) are dropped. Stops at one survivor or `race_max_seeds`.
4. Confirmation: the top `confirm_top` configs (and optionally the untuned
   baseline, config 0 = no parameter overrides) are rerun on held-out seeds that
   were never used for selection, at full fidelity. The selected config's score
   during tuning is biased upward (it won because some runs were lucky); the
   held-out score is the one to report.

A failed evaluation (timeout, crash after retries) counts as missing: a config's
mean uses its successful runs, and a config with no successful run ranks last.
Paired tests use only the seeds on which every compared config succeeded.
"""

from __future__ import annotations

import hashlib
import math
import statistics
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence, Tuple

Params = Dict[str, Any]

BASELINE_CONFIG_ID = 0  # untuned baseline: no parameter overrides


# Fidelity rungs and seeds
@dataclass(frozen=True)
class Rung:
    """One fidelity level: simulate `days` days (None = full run) on `seeds` seeds."""

    days: Optional[int]
    seeds: int

    @property
    def label(self) -> str:
        return f"{days_label(self.days)}x{self.seeds}"


def days_label(days: Optional[int]) -> str:
    return "full" if days is None else f"{days}d"


def _days_key(days: Optional[int]) -> float:
    return math.inf if days is None else float(days)


def parse_rungs(spec: str, full_days: Optional[int] = None) -> List[Rung]:
    """Parse "1:1,full:2,full:4" (days:seeds, comma separated).

    Days of `full` or >= full_days mean the full run (None). Rungs must not get
    cheaper: days and seeds are non-decreasing, and consecutive rungs differ.
    """
    rungs: List[Rung] = []
    for part in [p.strip() for p in spec.split(",") if p.strip()]:
        try:
            d_raw, s_raw = part.split(":")
            seeds = int(s_raw)
            days: Optional[int] = None if d_raw.strip().lower() == "full" else int(d_raw)
        except ValueError as e:
            raise ValueError(f"Bad rung {part!r}: expected days:seeds, e.g. 1:1 or full:4") from e
        if seeds < 1 or (days is not None and days < 1):
            raise ValueError(f"Bad rung {part!r}: days and seeds must be >= 1")
        if days is not None and full_days is not None and days >= full_days:
            days = None
        rungs.append(Rung(days, seeds))
    if not rungs:
        raise ValueError("No rungs given")
    for a, b in zip(rungs, rungs[1:]):
        if _days_key(b.days) < _days_key(a.days) or b.seeds < a.seeds:
            raise ValueError(f"Rungs must not get cheaper: {a.label} then {b.label}")
        if a == b:
            raise ValueError(f"Repeated rung {a.label}")
    return rungs


def derive_seeds(search_seed: int, stream: str, n: int) -> List[int]:
    """n deterministic run seeds for a named stream ("tuning", "heldout", ...).

    Different streams never share seeds, so held-out seeds are unseen by tuning.
    """
    seeds: List[int] = []
    seen = set()
    k = 0
    while len(seeds) < n:
        digest = hashlib.sha256(f"{search_seed}:{stream}:{k}".encode()).digest()
        value = int.from_bytes(digest[:4], "big") % (2**31 - 1) + 1
        k += 1
        if value not in seen:
            seen.add(value)
            seeds.append(value)
    return seeds


# Evaluations
@dataclass
class EvalRequest:
    config_id: int
    params: Params
    days: Optional[int]
    seed: int
    label: str  # where it was requested: "b0_r1", "race", "confirm"


@dataclass
class EvalResult:
    request: EvalRequest
    objective: Optional[float]  # None = failed
    details: Dict[str, Any] = field(default_factory=dict)

    @property
    def ok(self) -> bool:
        return self.objective is not None


# Called with a batch (run it in any order or in parallel); returns results in
# request order.
EvaluateFn = Callable[[List[EvalRequest]], List[EvalResult]]


class ScoreBook:
    """Every evaluation made, keyed by (config_id, days, seed); never repeated."""

    def __init__(self) -> None:
        self._results: Dict[Tuple[int, Optional[int], int], EvalResult] = {}

    def has(self, config_id: int, days: Optional[int], seed: int) -> bool:
        return (config_id, days, seed) in self._results

    def add(self, result: EvalResult) -> None:
        r = result.request
        self._results[(r.config_id, r.days, r.seed)] = result

    def get(self, config_id: int, days: Optional[int], seed: int) -> Optional[EvalResult]:
        return self._results.get((config_id, days, seed))

    def value(self, config_id: int, days: Optional[int], seed: int) -> Optional[float]:
        res = self.get(config_id, days, seed)
        return res.objective if res is not None else None

    def results(self) -> List[EvalResult]:
        return list(self._results.values())

    def __len__(self) -> int:
        return len(self._results)


def evaluate_missing(
    book: ScoreBook,
    evaluate: EvaluateFn,
    configs: Dict[int, Params],
    config_ids: Iterable[int],
    days: Optional[int],
    seeds: Sequence[int],
    label: str,
) -> int:
    """Evaluate every (config, seed) not yet in the book, as one batch. Returns the count."""
    requests = [
        EvalRequest(cid, configs[cid], days, seed, label)
        for cid in config_ids
        for seed in seeds
        if not book.has(cid, days, seed)
    ]
    if requests:
        results = evaluate(requests)
        if len(results) != len(requests):
            raise RuntimeError(f"evaluate returned {len(results)} results for {len(requests)} requests")
        for res in results:
            book.add(res)
    return len(requests)


# Scores and statistics
def _t_quantile(df: int, q: float = 0.975) -> float:
    from scipy import stats

    return float(stats.t.ppf(q, df))


@dataclass
class ConfigScore:
    """A config's objective at one fidelity over a set of seeds."""

    config_id: int
    days: Optional[int]
    seeds: Tuple[int, ...]
    values: List[float]  # successful runs only, in seed order
    n_failed: int

    @property
    def n(self) -> int:
        return len(self.values)

    @property
    def mean(self) -> float:
        return statistics.fmean(self.values) if self.values else -math.inf

    @property
    def sd(self) -> Optional[float]:
        return statistics.stdev(self.values) if len(self.values) >= 2 else None

    @property
    def ci95(self) -> Optional[Tuple[float, float]]:
        """95% t-interval for the mean (None with fewer than 2 runs)."""
        if self.sd is None:
            return None
        half = _t_quantile(self.n - 1) * self.sd / math.sqrt(self.n)
        return (self.mean - half, self.mean + half)

    def to_dict(self) -> Dict[str, Any]:
        ci = self.ci95
        return {
            "config_id": self.config_id,
            "days": self.days,
            "n": self.n,
            "n_failed": self.n_failed,
            "mean": self.mean if self.values else None,
            "sd": self.sd,
            "ci95": list(ci) if ci else None,
            "seeds": list(self.seeds),
            "values": list(self.values),
        }


def score_of(book: ScoreBook, config_id: int, days: Optional[int], seeds: Sequence[int]) -> ConfigScore:
    """Score over the seeds this config was run on (seeds it never ran are skipped;
    runs that failed count in n_failed)."""
    values: List[float] = []
    ran: List[int] = []
    failed = 0
    for seed in seeds:
        res = book.get(config_id, days, seed)
        if res is None:
            continue
        ran.append(seed)
        if res.objective is None:
            failed += 1
        else:
            values.append(res.objective)
    return ConfigScore(config_id, days, tuple(ran), values, failed)


def rank_scores(scores: Iterable[ConfigScore]) -> List[ConfigScore]:
    """Best first: higher mean, then fewer failures, then lower config id (stable ties)."""
    return sorted(scores, key=lambda s: (-s.mean, s.n_failed, s.config_id))


def paired_matrix(
    book: ScoreBook, config_ids: Sequence[int], days: Optional[int], seeds: Sequence[int]
) -> Tuple[List[int], List[List[float]]]:
    """(seeds where every config succeeded, rows[i][j] = value of config j on seed i)."""
    blocks: List[int] = []
    rows: List[List[float]] = []
    for seed in seeds:
        row = [book.value(cid, days, seed) for cid in config_ids]
        if all(v is not None for v in row):
            blocks.append(seed)
            rows.append([float(v) for v in row])  # type: ignore[arg-type]
    return blocks, rows


def paired_greater_p(a: Sequence[float], b: Sequence[float]) -> float:
    """One-sided paired t-test p-value for mean(a - b) > 0.

    Zero-variance differences (common with count-based objectives): p = 0 when
    every difference is the same positive number, 1 otherwise.
    """
    diffs = [x - y for x, y in zip(a, b)]
    if len(diffs) < 2:
        return 1.0
    if max(diffs) == min(diffs):
        return 0.0 if diffs[0] > 0 else 1.0
    from scipy import stats

    p = float(stats.ttest_rel(a, b, alternative="greater").pvalue)
    return 1.0 if math.isnan(p) else p


def friedman_p(rows: List[List[float]]) -> float:
    """Friedman test across configs (columns) blocked by seed (rows). 1.0 if undefined."""
    if len(rows) < 2 or len(rows[0]) < 3:
        return 1.0
    columns = list(zip(*rows))
    if all(len(set(row)) == 1 for row in rows):
        return 1.0  # every seed ties every config
    from scipy import stats

    try:
        p = float(stats.friedmanchisquare(*columns).pvalue)
    except ValueError:
        return 1.0
    return 1.0 if math.isnan(p) else p


def paired_difference(
    book: ScoreBook, a: int, b: int, days: Optional[int], seeds: Sequence[int]
) -> Optional[Dict[str, Any]]:
    """Mean and 95% CI of (a - b) over seeds where both succeeded."""
    blocks, rows = paired_matrix(book, [a, b], days, seeds)
    if not blocks:
        return None
    diffs = [r[0] - r[1] for r in rows]
    mean = statistics.fmean(diffs)
    out: Dict[str, Any] = {"config_id": a, "vs": b, "n": len(diffs), "mean_diff": mean, "ci95": None, "p_greater": None}
    if len(diffs) >= 2:
        sd = statistics.stdev(diffs)
        half = _t_quantile(len(diffs) - 1) * sd / math.sqrt(len(diffs))
        out["ci95"] = [mean - half, mean + half]
        out["p_greater"] = paired_greater_p([r[0] for r in rows], [r[1] for r in rows])
    return out


def noise_summary(
    book: ScoreBook, config_ids: Sequence[int], days: Optional[int], seeds: Sequence[int]
) -> Optional[Dict[str, Any]]:
    """Seed noise vs differences between configs at one fidelity.

    within_sd: pooled SD of a config's objective across seeds (run-to-run noise).
    between_sd: SD of the configs' means. A ratio within/between near or above 1
    means single runs cannot rank these configs; more seeds per config are needed.
    """
    scores = [score_of(book, cid, days, seeds) for cid in config_ids]
    variances = [s.sd**2 for s in scores if s.sd is not None]
    means = [s.mean for s in scores if s.values]
    if not variances or len(means) < 2:
        return None
    within = math.sqrt(statistics.fmean(variances))
    between = statistics.stdev(means)
    return {
        "days": days,
        "configs": len(means),
        "within_sd": within,
        "between_sd": between,
        "ratio": (within / between) if between > 0 else None,
    }


# Successive halving and Hyperband
@dataclass
class RungRecord:
    bracket: int
    rung_index: int
    rung: Rung
    scores: List[ConfigScore]  # ranked, best first
    promoted: List[int]
    new_runs: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bracket": self.bracket,
            "rung_index": self.rung_index,
            "rung": self.rung.label,
            "days": self.rung.days,
            "seeds": self.rung.seeds,
            "new_runs": self.new_runs,
            "promoted": list(self.promoted),
            "scores": [s.to_dict() for s in self.scores],
        }


def keep_count(n_alive: int, eta: int, min_keep: int = 1) -> int:
    return min(n_alive, max(min_keep, n_alive // eta))


def successive_halving(
    configs: Dict[int, Params],
    config_ids: Sequence[int],
    rungs: Sequence[Rung],
    eta: int,
    tuning_seeds: Sequence[int],
    book: ScoreBook,
    evaluate: EvaluateFn,
    *,
    start_rung: int = 0,
    bracket: int = 0,
    min_keep: int = 1,
    on_rung: Optional[Callable[[RungRecord], None]] = None,
) -> Tuple[List[int], List[RungRecord]]:
    """Run config_ids from rungs[start_rung] to the last rung.

    Returns (survivors ranked by final-rung mean, one record per rung). At the
    last rung nobody is cut; the race decides among the survivors.
    """
    alive = list(config_ids)
    records: List[RungRecord] = []
    last = len(rungs) - 1
    for i in range(start_rung, len(rungs)):
        rung = rungs[i]
        seeds = list(tuning_seeds[: rung.seeds])
        new = evaluate_missing(book, evaluate, configs, alive, rung.days, seeds, f"b{bracket}_r{i}")
        ranked = rank_scores(score_of(book, cid, rung.days, seeds) for cid in alive)
        if i == last:
            promoted = [s.config_id for s in ranked]
        else:
            # Configs with no successful run never move on
            viable = [s for s in ranked if s.values] or ranked
            promoted = [s.config_id for s in viable[: keep_count(len(alive), eta, min_keep)]]
        record = RungRecord(bracket, i, rung, ranked, promoted, new)
        records.append(record)
        if on_rung:
            on_rung(record)
        alive = promoted
    return alive, records


def hyperband_brackets(n_configs: int, n_rungs: int, eta: int) -> List[Tuple[int, int]]:
    """(start_rung, configs) per bracket: bracket s starts at rung s with n/eta^s configs."""
    return [(s, max(1, math.ceil(n_configs / eta**s))) for s in range(n_rungs)]


# Racing
@dataclass
class RaceStep:
    n_seeds: int
    alive_before: List[int]
    friedman_p: Optional[float]
    eliminated: Dict[int, float]  # config_id -> p-value vs leader
    leader: Optional[int]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "n_seeds": self.n_seeds,
            "alive_before": list(self.alive_before),
            "friedman_p": self.friedman_p,
            "eliminated": {str(k): v for k, v in self.eliminated.items()},
            "leader": self.leader,
        }


@dataclass
class RaceRecord:
    days: Optional[int]
    entrants: List[int]
    survivors: List[int]
    eliminated_order: List[int]  # first eliminated first
    steps: List[RaceStep]
    seeds_used: int
    new_runs: int

    def to_dict(self) -> Dict[str, Any]:
        return {
            "days": self.days,
            "entrants": list(self.entrants),
            "survivors": list(self.survivors),
            "eliminated_order": list(self.eliminated_order),
            "seeds_used": self.seeds_used,
            "new_runs": self.new_runs,
            "steps": [s.to_dict() for s in self.steps],
        }


def eliminate(
    book: ScoreBook,
    alive: Sequence[int],
    days: Optional[int],
    seeds: Sequence[int],
    alpha: float,
    min_blocks: int,
) -> Tuple[List[int], RaceStep]:
    """One racing test over the seeds so far; returns (still alive, step record)."""
    # A config with no successful run at all is out regardless of the test
    dead = [cid for cid in alive if not score_of(book, cid, days, seeds).values]
    candidates = [cid for cid in alive if cid not in dead]
    step = RaceStep(len(seeds), list(alive), None, {cid: 0.0 for cid in dead}, None)
    if len(candidates) <= 1:
        step.leader = candidates[0] if candidates else None
        return candidates, step
    blocks, rows = paired_matrix(book, candidates, days, seeds)
    if len(blocks) < min_blocks:
        return candidates, step
    col_means = [statistics.fmean(col) for col in zip(*rows)]
    leader_idx = max(range(len(candidates)), key=lambda j: (col_means[j], -candidates[j]))
    step.leader = candidates[leader_idx]
    if len(candidates) >= 3:
        step.friedman_p = friedman_p(rows)
        if step.friedman_p >= alpha:
            return candidates, step
    leader_vals = [r[leader_idx] for r in rows]
    survivors: List[int] = []
    for j, cid in enumerate(candidates):
        if j == leader_idx:
            survivors.append(cid)
            continue
        p = paired_greater_p(leader_vals, [r[j] for r in rows])
        if p < alpha:
            step.eliminated[cid] = p
        else:
            survivors.append(cid)
    return survivors, step


def race(
    configs: Dict[int, Params],
    entrants: Sequence[int],
    days: Optional[int],
    tuning_seeds: Sequence[int],
    start_seeds: int,
    max_seeds: int,
    alpha: float,
    min_seeds: int,
    book: ScoreBook,
    evaluate: EvaluateFn,
    on_step: Optional[Callable[[RaceStep], None]] = None,
) -> RaceRecord:
    """Add seeds one at a time to the live configs, dropping significant losers."""
    alive = list(entrants)
    eliminated_order: List[int] = []
    steps: List[RaceStep] = []
    n = max(1, start_seeds)
    max_seeds = max(max_seeds, n)
    new_runs = 0
    while True:
        new_runs += evaluate_missing(book, evaluate, configs, alive, days, tuning_seeds[:n], "race")
        if len(alive) <= 1:
            break
        if n >= min_seeds:
            alive, step = eliminate(book, alive, days, tuning_seeds[:n], alpha, min_seeds)
            steps.append(step)
            # Within one test, the lowest mean goes out first
            means = {c: score_of(book, c, days, tuning_seeds[:n]).mean for c in step.eliminated}
            eliminated_order.extend(sorted(step.eliminated, key=lambda c: (means[c], c)))
            if on_step:
                on_step(step)
        if len(alive) <= 1 or n >= max_seeds:
            break
        n += 1
    ranked = rank_scores(score_of(book, cid, days, tuning_seeds[:n]) for cid in alive)
    return RaceRecord(days, list(entrants), [s.config_id for s in ranked], eliminated_order, steps, n, new_runs)


# Whole search
@dataclass
class SearchSettings:
    method: str = "halving"  # "halving" | "hyperband"
    n_configs: int = 27
    eta: int = 3
    rungs: List[Rung] = field(default_factory=lambda: [Rung(1, 1), Rung(None, 2), Rung(None, 4)])
    race_max_seeds: int = 8
    race_alpha: float = 0.05
    race_min_seeds: int = 3
    confirm_top: int = 1
    confirm_seeds: int = 5
    confirm_baseline: bool = True
    min_keep: int = 1

    def validate(self) -> None:
        if self.method not in ("halving", "hyperband"):
            raise ValueError(f"Unknown search method {self.method!r}")
        if self.n_configs < 1 or self.eta < 2:
            raise ValueError("n_configs must be >= 1 and eta >= 2")
        if not self.rungs:
            raise ValueError("At least one rung is required")
        if not 0 < self.race_alpha < 1:
            raise ValueError("race_alpha must be in (0, 1)")
        if self.race_min_seeds < 2:
            raise ValueError("race_min_seeds must be >= 2 (a paired test needs two seeds)")
        if self.confirm_top < 0 or self.confirm_seeds < 0:
            raise ValueError("confirm_top and confirm_seeds must be >= 0")

    @property
    def tuning_seed_count(self) -> int:
        return max(self.race_max_seeds, self.rungs[-1].seeds)

    def brackets(self) -> List[Tuple[int, int]]:
        if self.method == "hyperband":
            return hyperband_brackets(self.n_configs, len(self.rungs), self.eta)
        return [(0, self.n_configs)]

    def to_dict(self) -> Dict[str, Any]:
        return {
            "method": self.method,
            "n_configs": self.n_configs,
            "eta": self.eta,
            "rungs": [r.label for r in self.rungs],
            "race_max_seeds": self.race_max_seeds,
            "race_alpha": self.race_alpha,
            "race_min_seeds": self.race_min_seeds,
            "confirm_top": self.confirm_top,
            "confirm_seeds": self.confirm_seeds,
            "confirm_baseline": self.confirm_baseline,
            "min_keep": self.min_keep,
        }


@dataclass
class SearchResult:
    settings: SearchSettings
    configs: Dict[int, Params]
    tuning_seeds: List[int]
    heldout_seeds: List[int]
    rung_records: List[RungRecord]
    race: RaceRecord
    confirmation: List[ConfigScore]  # held-out scores, includes the baseline if run
    baseline_diffs: List[Dict[str, Any]]  # paired (config - baseline) on held-out seeds
    book: ScoreBook

    @property
    def best_config_id(self) -> Optional[int]:
        return self.race.survivors[0] if self.race.survivors else None

    def ranking(self) -> List[Dict[str, Any]]:
        """Every tuned config, best first.

        Race survivors (by race mean), then race eliminations (latest first),
        then configs cut earlier (higher rung reached first, then mean there).
        """
        final_seeds = self.tuning_seeds[: self.race.seeds_used]
        reached: Dict[int, Tuple[int, int, ConfigScore]] = {}
        for rec in self.rung_records:
            for s in rec.scores:
                prev = reached.get(s.config_id)
                if prev is None or rec.rung_index >= prev[0]:
                    reached[s.config_id] = (rec.rung_index, rec.bracket, s)
        heldout = {s.config_id: s for s in self.confirmation}
        rows: List[Dict[str, Any]] = []

        def row(cid: int, stage: str, score: ConfigScore, rung_index: int) -> Dict[str, Any]:
            return {
                "config_id": cid,
                "params": self.configs[cid],
                "reached": stage,
                "rung_index": rung_index,
                "score": score,
                "heldout": heldout.get(cid),
            }

        listed = set()
        for cid in self.race.survivors:
            rows.append(row(cid, "race_survivor", score_of(self.book, cid, self.race.days, final_seeds), len(self.settings.rungs) - 1))
            listed.add(cid)
        for cid in reversed(self.race.eliminated_order):
            if cid in listed:
                continue
            rows.append(row(cid, "race_eliminated", score_of(self.book, cid, self.race.days, final_seeds), len(self.settings.rungs) - 1))
            listed.add(cid)
        rest = [(v[0], v[2]) for cid, v in reached.items() if cid not in listed]
        rest.sort(key=lambda t: (-t[0], -t[1].mean, t[1].n_failed, t[1].config_id))
        for rung_index, score in rest:
            rows.append(row(score.config_id, f"rung_{rung_index}", score, rung_index))
        return rows


def run_search(
    sample_config: Callable[[], Params],
    settings: SearchSettings,
    tuning_seeds: Sequence[int],
    heldout_seeds: Sequence[int],
    evaluate: EvaluateFn,
    *,
    baseline_params: Optional[Params] = None,
    on_rung: Optional[Callable[[RungRecord], None]] = None,
    on_race_step: Optional[Callable[[RaceStep], None]] = None,
) -> SearchResult:
    """Sample configs, halve (per bracket), race the survivors, confirm on held-out seeds."""
    settings.validate()
    if len(tuning_seeds) < settings.tuning_seed_count:
        raise ValueError(f"Need {settings.tuning_seed_count} tuning seeds, got {len(tuning_seeds)}")
    if set(tuning_seeds) & set(heldout_seeds):
        raise ValueError("Held-out seeds overlap the tuning seeds")
    book = ScoreBook()
    configs: Dict[int, Params] = {}
    next_id = 1
    records: List[RungRecord] = []
    finalists: List[int] = []
    for bracket, (start_rung, n) in enumerate(settings.brackets()):
        ids = []
        for _ in range(n):
            configs[next_id] = sample_config()
            ids.append(next_id)
            next_id += 1
        survivors, recs = successive_halving(
            configs, ids, settings.rungs, settings.eta, tuning_seeds, book, evaluate,
            start_rung=start_rung, bracket=bracket, min_keep=settings.min_keep, on_rung=on_rung,
        )
        records.extend(recs)
        finalists.extend(survivors)

    final = settings.rungs[-1]
    race_record = race(
        configs, finalists, final.days, tuning_seeds, final.seeds, settings.race_max_seeds,
        settings.race_alpha, settings.race_min_seeds, book, evaluate, on_step=on_race_step,
    )

    confirmation: List[ConfigScore] = []
    diffs: List[Dict[str, Any]] = []
    top = race_record.survivors[: settings.confirm_top]
    if top and settings.confirm_seeds > 0:
        seeds = list(heldout_seeds[: settings.confirm_seeds])
        if len(seeds) < settings.confirm_seeds:
            raise ValueError(f"Need {settings.confirm_seeds} held-out seeds, got {len(heldout_seeds)}")
        ids = list(top)
        if settings.confirm_baseline:
            configs[BASELINE_CONFIG_ID] = dict(baseline_params or {})
            ids.append(BASELINE_CONFIG_ID)
        # Full fidelity regardless of the rungs
        evaluate_missing(book, evaluate, configs, ids, None, seeds, "confirm")
        confirmation = [score_of(book, cid, None, seeds) for cid in ids]
        if settings.confirm_baseline:
            for cid in top:
                d = paired_difference(book, cid, BASELINE_CONFIG_ID, None, seeds)
                if d is not None:
                    diffs.append(d)

    return SearchResult(
        settings, configs, list(tuning_seeds), list(heldout_seeds), records, race_record,
        confirmation, diffs, book,
    )


def plan_budget(settings: SearchSettings) -> Dict[str, Any]:
    """Worst-case run counts for a search (the race may stop early): total runs,
    full-length runs, and simulated days spent in shortened runs."""
    settings.validate()
    brackets = []
    total_runs = 0
    short_days = 0  # simulated days in shortened runs
    full_runs = 0
    for b, (start, n) in enumerate(settings.brackets()):
        alive = n
        done: Dict[Optional[int], int] = {}  # days -> seeds already run per config
        rung_rows = []
        for i in range(start, len(settings.rungs)):
            rung = settings.rungs[i]
            new_per_config = rung.seeds - done.get(rung.days, 0)
            runs = alive * new_per_config
            done[rung.days] = rung.seeds
            rung_rows.append({"rung": rung.label, "configs": alive, "new_runs": runs})
            total_runs += runs
            if rung.days is None:
                full_runs += runs
            else:
                short_days += runs * rung.days
            if i < len(settings.rungs) - 1:
                alive = keep_count(alive, settings.eta, settings.min_keep)
        brackets.append({"bracket": b, "start_rung": start, "configs": n, "rungs": rung_rows, "finalists": alive})
    finalists = sum(b["finalists"] for b in brackets)
    final = settings.rungs[-1]
    race_runs = finalists * max(0, max(settings.race_max_seeds, final.seeds) - final.seeds)
    confirm_n = min(settings.confirm_top, finalists) + (1 if settings.confirm_baseline and settings.confirm_top else 0)
    confirm_runs = confirm_n * settings.confirm_seeds
    total_runs += race_runs + confirm_runs
    full_runs += confirm_runs
    if final.days is None:
        full_runs += race_runs
    else:
        short_days += race_runs * final.days
    return {
        "brackets": brackets,
        "finalists": finalists,
        "race_runs_max": race_runs,
        "confirm_runs": confirm_runs,
        "total_runs_max": total_runs,
        "full_runs_max": full_runs,
        "short_run_days_max": short_days,
    }
