"""
Collect per-run results of an auto_runner batch into thesis-ready tables.

Reads every run_*/ under a batch root (config/run_manifest.json,
simulation_output/final_output.json, daily snapshots, and
analysis/belief_alignment_change_summary.csv) and writes, into --out-dir:

    thesis_results.csv   one row per run (events, flags/bans, belief alignment,
                         account-level MCC on bans and on flags)
    thesis_results.tex   LaTeX tables plus one macro per number, so chapter
                         text can quote \\ResDestinyTemplateDupEvents etc.

Coordination-only runs are excluded by default (--exclude-scenarios).

From repository root:

    python -m backend.python_simulation.tools.thesis_tables ^
        --root Simulation_Setups/auto_runs/completed_set_2c ^
        --out-dir path/to/thesis
"""

from __future__ import annotations

import argparse
import csv
import json
import logging
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from .account_mcc import ATTACKER_AGENT_TYPES, account_confusion

log = logging.getLogger(__name__)

# Display order and labels; keys not listed here are appended in sorted order
UNIVERSE_LABELS = {
    "destiny2_base_sim_small": ("Destiny", "Commercial"),
    "politics_base_sim_small": ("Politics", "Political"),
}
MODE_LABELS = {
    "llm_attackers": ("Llm", "LLM"),
    "template_attackers": ("Template", "Template"),
    "no_attackers": ("Control", "No attackers"),
    "biased_moderator": ("BiasedMod", "Biased moderator"),
}
SCENARIO_LABELS = {
    "none": ("None", "None"),
    "duplicate_only": ("Dup", "Duplicate-only"),
    "rate_limit_only": ("Rate", "Rate-limit-only"),
    "coordination_only": ("Coord", "Coordination-only"),
    "rule_moderator": ("Mod", "Moderator-only"),
    "all_mitigations_except_coordination": ("Stack", "Stacked (no coordination)"),
    "all_mitigations": ("All", "All mitigations"),
}
ATTACKER_MODES = ("llm_attackers", "template_attackers")
FLAG_SOURCES = ("duplicate", "rate_limit", "coordination", "rule_moderator")

CSV_FIELDS = [
    "universe", "attacker_mode", "mitigation_scenario", "coordination_strength",
    "repeat_index", "simulation_ok", "analysis_ok",
    "total_events", "posts", "replies", "upvotes", "downvotes",
    "attacker_posts", "attacker_replies", "organic_posts", "organic_replies",
    "flags_attacker", "flags_organic", "bans_attacker", "bans_organic",
    *[f"flags_{s}" for s in FLAG_SOURCES],
    "coordination_edges", "coordinated_upvotes", "coordinated_comments",
    "biased_removals", "biased_bans",
    "delta_cosine", "delta_shared_beliefs", "end_cosine",
    "delta_alignment", "end_alignment", "mean_abs_position_change",
    "mcc_banned", "mcc_flagged", "attacker_ban_hours", "run_dir",
]


def _load_json(path: Path) -> Optional[Dict[str, Any]]:
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError) as exc:
        log.warning("Could not read %s: %s", path, exc)
        return None


def _alignment(analysis_dir: Path) -> Dict[str, Optional[float]]:
    """change_mean rows of belief_alignment_change_summary.csv (absent without attackers).

    Free-text belief runs give cosine/shared-belief rows; belief axes runs give
    axis_alignment (alignment with the campaign targets) and position change."""
    out: Dict[str, Optional[float]] = {
        "delta_cosine": None, "delta_shared_beliefs": None, "end_cosine": None,
        "delta_alignment": None, "end_alignment": None, "mean_abs_position_change": None,
    }
    path = analysis_dir / "belief_alignment_change_summary.csv"
    if not path.is_file():
        return out
    with open(path, newline="", encoding="utf-8") as f:
        for row in csv.DictReader(f):
            if row["metric"] == "cosine_similarity":
                out["delta_cosine"] = float(row["change_mean"])
                out["end_cosine"] = float(row["end_mean"])
            elif row["metric"] == "shared_beliefs":
                out["delta_shared_beliefs"] = float(row["change_mean"])
            elif row["metric"] == "axis_alignment":
                out["delta_alignment"] = float(row["change_mean"])
                out["end_alignment"] = float(row["end_mean"])
            elif row["metric"] == "mean_abs_position_change":
                out["mean_abs_position_change"] = float(row["change_mean"])
    return out


def _flag_ban_counts(final: Dict[str, Any]) -> Dict[str, int]:
    """Flags (summed) and bans (accounts) on attacker vs organic accounts."""
    summary = final.get("mitigation_summary", {})
    types = {str(k): v for k, v in summary.get("agent_type_by_id", {}).items()}
    out = {"flags_attacker": 0, "flags_organic": 0, "bans_attacker": 0, "bans_organic": 0}
    for agent_id, count in (summary.get("flag_counts_by_agent") or {}).items():
        side = "attacker" if types.get(str(agent_id)) in ATTACKER_AGENT_TYPES else "organic"
        out[f"flags_{side}"] += int(count)
    for agent_id in summary.get("banned_agent_ids") or []:
        side = "attacker" if types.get(str(agent_id)) in ATTACKER_AGENT_TYPES else "organic"
        out[f"bans_{side}"] += 1
    return out


def _collect_run(run_dir: Path) -> Optional[Dict[str, Any]]:
    manifest = _load_json(run_dir / "config" / "run_manifest.json")
    final = _load_json(run_dir / "simulation_output" / "final_output.json")
    if manifest is None or final is None:
        return None

    summary = final.get("mitigation_summary", {})
    agent_types = {str(k): v for k, v in summary.get("agent_type_by_id", {}).items()}
    counts = final.get("event_counts_by_type", {})
    actions = _flag_ban_counts(final)
    banned = account_confusion(final, "banned")
    flagged = account_confusion(final, "flagged")

    row: Dict[str, Any] = {
        "universe": manifest["universe"],
        "attacker_mode": manifest["attacker_mode"],
        "mitigation_scenario": manifest["mitigation_scenario"],
        "coordination_strength": manifest.get("coordination_strength"),
        "repeat_index": manifest.get("repeat_index", 1),
        "simulation_ok": manifest.get("simulation_ok"),
        "analysis_ok": manifest.get("analysis_ok"),
        "total_events": final.get("total_events", 0),
        "posts": counts.get("post", 0),
        "replies": counts.get("reply", 0),
        "upvotes": counts.get("upvote", 0),
        "downvotes": counts.get("downvote", 0),
        "flags_attacker": actions["flags_attacker"],
        "flags_organic": actions["flags_organic"],
        "bans_attacker": actions["bans_attacker"],
        "bans_organic": actions["bans_organic"],
        "coordination_edges": len(summary.get("coordination_edges", []) or []),
        "coordinated_upvotes": final.get("attacker_coordination", {}).get("upvotes_executed", 0),
        "coordinated_comments": final.get("attacker_coordination", {}).get("comments_executed", 0),
        # Account-level MCC (attackers positive); undefined without attackers
        "mcc_banned": round(banned["mcc"], 4) if banned["n_attackers"] else None,
        "mcc_flagged": round(flagged["mcc"], 4) if flagged["n_attackers"] else None,
        "attacker_ban_hours": (
            round(banned["attacker_detect_hours"], 2)
            if banned["attacker_detect_hours"] is not None else None
        ),
        "run_dir": str(run_dir),
    }

    # Content authorship from the surviving event ledger (removed items are gone)
    for key in ("attacker_posts", "attacker_replies", "organic_posts", "organic_replies"):
        row[key] = 0
    media = _load_json(run_dir / "simulation_output" / "media_events.json") or {}
    events = media.get("events", media) if isinstance(media, dict) else media
    for e in events or []:
        if e.get("seed"):
            continue  # pre-existing Reddit content, not agent activity
        kind = {"post": "posts", "reply": "replies"}.get(e.get("type"))
        if kind is None:
            continue
        side = "attacker" if agent_types.get(str(e.get("user_id"))) in ATTACKER_AGENT_TYPES else "organic"
        row[f"{side}_{kind}"] += 1

    # Flag sources and biased-moderator actions come from the daily snapshots
    for s in FLAG_SOURCES:
        row[f"flags_{s}"] = 0
    row["biased_removals"] = 0
    row["biased_bans"] = 0
    for snap_path in sorted((run_dir / "simulation_output" / "daily_snapshots").glob("day_*_data.json")):
        snap = _load_json(snap_path) or {}
        for flag in snap.get("mitigation_data", {}).get("flags_today", []):
            key = f"flags_{flag.get('source')}"
            if key in row:
                row[key] += 1
        for action in snap.get("biased_moderation_log", []) or []:
            if action.get("action_type") == "ban_user":
                row["biased_bans"] += 1
            else:
                row["biased_removals"] += 1

    row.update(_alignment(run_dir / "analysis"))
    return row


def collect(batch_root: Path, exclude_scenarios: Iterable[str]) -> List[Dict[str, Any]]:
    excluded = set(exclude_scenarios)
    rows = []
    for manifest_path in sorted(batch_root.rglob("run_*/config/run_manifest.json")):
        row = _collect_run(manifest_path.parent.parent)
        if row is None:
            continue
        if row["mitigation_scenario"] in excluded:
            continue
        rows.append(row)
    return rows


def _order(keys: Iterable[str], labels: Dict[str, Any]) -> List[str]:
    keys = set(keys)
    return [k for k in labels if k in keys] + sorted(keys - set(labels))


def _label(labels: Dict[str, Any], key: str, idx: int) -> str:
    return labels[key][idx] if key in labels else key


def _fmt(value: Any, decimals: int = 0) -> str:
    if value is None or value == "":
        return "--"
    if decimals:
        return f"{float(value):.{decimals}f}"
    return str(int(value))


def _index(rows: List[Dict[str, Any]]) -> Dict[tuple, Dict[str, Any]]:
    # Repeats/sweeps collapse to the first run; the CSV keeps all of them
    out: Dict[tuple, Dict[str, Any]] = {}
    for r in rows:
        out.setdefault((r["universe"], r["attacker_mode"], r["mitigation_scenario"]), r)
    return out


def _macro_name(universe: str, mode: str, scenario: str, metric: str) -> str:
    return "Res" + "".join(
        _label(labels, key, 0).replace("_", "")
        for labels, key in ((UNIVERSE_LABELS, universe), (MODE_LABELS, mode), (SCENARIO_LABELS, scenario))
    ) + metric


MACRO_METRICS = {
    # metric suffix: (row key, decimals)
    "Events": ("total_events", 0),
    "Posts": ("posts", 0),
    "Replies": ("replies", 0),
    "AttackerPosts": ("attacker_posts", 0),
    "AttackerReplies": ("attacker_replies", 0),
    "FlagsAttacker": ("flags_attacker", 0),
    "FlagsOrganic": ("flags_organic", 0),
    "BansAttacker": ("bans_attacker", 0),
    "BansOrganic": ("bans_organic", 0),
    "DeltaCos": ("delta_cosine", 3),
    "DeltaShared": ("delta_shared_beliefs", 2),
    "DeltaAlign": ("delta_alignment", 3),
    "MccBanned": ("mcc_banned", 2),
    "MccFlagged": ("mcc_flagged", 2),
}


def _wide_table(
    idx, universes, scenarios, modes, cell, caption, label, colspec_mode="r"
) -> List[str]:
    """Rows = scenarios; columns = universe x mode."""
    lines = [
        r"\begin{table}[t]",
        r"  \centering",
        f"  \\caption{{{caption}}}",
        f"  \\label{{{label}}}",
        f"  \\begin{{tabular}}{{l{colspec_mode * (len(universes) * len(modes))}}}",
        r"    \toprule",
    ]
    header = " & ".join(
        f"\\multicolumn{{{len(modes)}}}{{c}}{{{_label(UNIVERSE_LABELS, u, 1)}}}" for u in universes
    )
    lines.append(f"    Mitigation & {header} \\\\")
    rules = " ".join(
        f"\\cmidrule(lr){{{2 + i * len(modes)}-{1 + (i + 1) * len(modes)}}}" for i in range(len(universes))
    )
    lines.append(f"    {rules}")
    mode_header = " & ".join(_label(MODE_LABELS, m, 1) for _ in universes for m in modes)
    lines.append(f"     & {mode_header} \\\\")
    lines.append(r"    \midrule")
    for s in scenarios:
        cells = [cell(idx.get((u, m, s))) for u in universes for m in modes]
        lines.append(f"    {_label(SCENARIO_LABELS, s, 1)} & " + " & ".join(cells) + r" \\")
    lines += [r"    \bottomrule", r"  \end{tabular}", r"\end{table}", ""]
    return lines


def _as_macro(name: str, table_lines: List[str]) -> List[str]:
    """Wrap a table so the chapter places it with \\<name> after one \\input"""
    return [f"\\newcommand{{\\{name}}}{{%"] + table_lines[:-1] + ["}", ""]


def render_tex(rows: List[Dict[str, Any]], batch_name: str) -> str:
    idx = _index(rows)
    universes = _order({r["universe"] for r in rows}, UNIVERSE_LABELS)
    scenarios = _order(
        {r["mitigation_scenario"] for r in rows if r["attacker_mode"] in ATTACKER_MODES}, SCENARIO_LABELS
    )
    modes_present = {r["attacker_mode"] for r in rows}
    attack_modes = [m for m in ATTACKER_MODES if m in modes_present]
    event_modes = attack_modes + (["no_attackers"] if "no_attackers" in modes_present else [])

    out = [
        f"% Generated by tools/thesis_tables.py from batch {batch_name}. Do not edit by hand;",
        "% re-run the script instead. Requires booktabs. \\input this file once, then place",
        "% tables with \\TableMitigationEvents, \\TableMitigationBans, \\TableMitigationFlags and",
        "% \\TableBeliefAlign<Universe>; quote numbers with the \\Res... macros below.",
        "",
        "% ---- Per-run macros: \\Res<Universe><Mode><Scenario><Metric> ----",
    ]
    for (u, m, s), r in sorted(idx.items()):
        for metric, (key, decimals) in MACRO_METRICS.items():
            out.append(f"\\newcommand{{\\{_macro_name(u, m, s, metric)}}}{{{_fmt(r.get(key), decimals)}}}")
    out.append("")

    out += _as_macro("TableMitigationEvents", _wide_table(
        idx, universes, scenarios, event_modes,
        lambda r: _fmt(r and r["total_events"]),
        "Total simulation events by mitigation scenario. Commercial $=$ \\nolinkurl{r/Destiny2}; "
        "political $=$ \\nolinkurl{r/worldnews}.",
        "tab:mitigation-events",
    ))
    out += _as_macro("TableMitigationBans", _wide_table(
        idx, universes, scenarios, attack_modes,
        lambda r: "--" if r is None else f"{r['bans_attacker']}/{r['bans_organic']}",
        "Bans by mitigation scenario, shown as attacker/organic accounts banned.",
        "tab:mitigation-bans", colspec_mode="c",
    ))
    out += _as_macro("TableMitigationFlags", _wide_table(
        idx, universes, scenarios, attack_modes,
        lambda r: "--" if r is None else f"{r['flags_attacker']}/{r['flags_organic']}",
        "Flags by mitigation scenario, shown as flags on attacker/organic accounts.",
        "tab:mitigation-flags", colspec_mode="c",
    ))
    for u in universes:
        short = _label(UNIVERSE_LABELS, u, 0).lower()
        # Belief axes runs report alignment with the campaign targets instead of cosine
        axes_runs = any(
            (idx.get((u, m, s)) or {}).get("delta_alignment") is not None
            for m in attack_modes for s in scenarios
        )
        key = "delta_alignment" if axes_runs else "delta_cosine"
        measure = (
            "alignment with the campaign's target belief-axis positions"
            if axes_runs else "cosine similarity to the campaign vector"
        )
        table = [
            r"\begin{table}[t]",
            r"  \centering",
            f"  \\caption{{Mean change in {measure} for non-attacker agents "
            f"(first vs.\\ last daily simulation snapshot), {_label(UNIVERSE_LABELS, u, 1).lower()} scenario.}}",
            f"  \\label{{tab:belief-align-{short}}}",
            "  \\begin{tabular}{l" + "c" * len(attack_modes) + "}",
            r"    \toprule",
            "    Mitigation scenario & " + " & ".join(f"{_label(MODE_LABELS, m, 1)} attackers" for m in attack_modes) + r" \\",
            r"    \midrule",
        ]
        for s in scenarios:
            cells = [_fmt((idx.get((u, m, s)) or {}).get(key), 3) for m in attack_modes]
            table.append(f"    {_label(SCENARIO_LABELS, s, 1)} & " + " & ".join(cells) + r" \\")
        table += [r"    \bottomrule", r"  \end{tabular}", r"\end{table}", ""]
        out += _as_macro(f"TableBeliefAlign{_label(UNIVERSE_LABELS, u, 0)}", table)
    return "\n".join(out)


def write_csv(rows: List[Dict[str, Any]], path: Path) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for r in rows:
            writer.writerow({k: r.get(k) for k in CSV_FIELDS})


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Build thesis result tables from an auto_runner batch.")
    parser.add_argument("--root", type=Path, required=True, help="Batch root, e.g. Simulation_Setups/auto_runs/completed_set_2c")
    parser.add_argument("--out-dir", type=Path, default=None, help="Where to write thesis_results.{csv,tex} (default: --root)")
    parser.add_argument(
        "--exclude-scenarios", default="coordination_only",
        help="Comma-separated mitigation scenarios to leave out (default: coordination_only; '' keeps all)",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)
    logging.basicConfig(level=logging.INFO, format="%(levelname)s [thesis_tables] %(message)s")

    excluded = [s for s in args.exclude_scenarios.split(",") if s.strip()]
    rows = collect(args.root, excluded)
    if not rows:
        log.error("No runs with run_manifest.json + final_output.json under %s", args.root)
        return 1
    out_dir = args.out_dir or args.root
    out_dir.mkdir(parents=True, exist_ok=True)
    write_csv(rows, out_dir / "thesis_results.csv")
    (out_dir / "thesis_results.tex").write_text(render_tex(rows, args.root.name), encoding="utf-8")
    failed = [r for r in rows if not (r["simulation_ok"] and r["analysis_ok"])]
    log.info("%d runs (excluded scenarios: %s) -> %s", len(rows), excluded or "none", out_dir)
    if failed:
        log.warning("%d runs did not finish simulation+analysis cleanly; check them before quoting", len(failed))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
