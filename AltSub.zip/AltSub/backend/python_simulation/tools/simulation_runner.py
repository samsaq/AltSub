#!/usr/bin/env python3
"""
simulation_runner.py

Utility script to batch-run all Python simulations under `Simulation_Setups/simulations`
using their `run_simulation.sh` scripts.

Behavior:
- Discovers all subdirectories of `Simulation_Setups/simulations`
- Skips any directory whose name ends with `_small` (these are test setups)
- For each remaining directory:
  - Runs `./run_simulation.sh` via bash
  - Streams the simulation's own logging directly to the terminal
  - Prints a large, multi-line banner at start and end so runs are easy to see
  - Measures and reports wall-clock runtime per simulation
- If a simulation exits with a non-zero status, prints a clear failure banner
  and continues to the next simulation.

Example:
    python -m python_simulation.tools.simulation_runner
"""

import os
import sys
import time
import subprocess
from pathlib import Path
from typing import List, Tuple


def _print_banner(lines: List[str], char: str = "=", width: int = 80) -> None:
    """Print a prominent multi-line banner."""
    border = char * width
    print(border)
    for line in lines:
        # Center the line within the width, but don't truncate
        if len(line) < width:
            padded = f" {line.center(width - 2)} "
        else:
            padded = line
        print(padded)
    print(border)
    print()


def _format_duration(seconds: float) -> str:
    """Format a duration in seconds into a human-readable string."""
    seconds = float(seconds)
    if seconds < 60:
        return f"{seconds:.2f}s"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{int(minutes)}m {sec:.1f}s"
    hours, minutes = divmod(minutes, 60)
    return f"{int(hours)}h {int(minutes)}m {sec:.1f}s"


def discover_simulation_dirs() -> List[Path]:
    """
    Discover all simulation directories under Simulation_Setups/simulations.

    Skips any directory whose name ends with '_small'.
    """
    # Locate project root from this file:
    # backend/python_simulation/tools/simulation_runner.py
    this_file = Path(__file__).resolve()
    project_root = this_file.parents[3]

    sims_root = project_root / "Simulation_Setups" / "simulations"
    if not sims_root.exists():
        raise FileNotFoundError(f"Simulations root not found: {sims_root}")

    sim_dirs: List[Path] = []
    for child in sorted(sims_root.iterdir()):
        if not child.is_dir():
            continue
        name = child.name
        # Skip test/small setups
        if name.endswith("_small"):
            continue
        # Require the presence of run_simulation.sh to consider it a simulation
        if not (child / "run_simulation.sh").exists():
            continue
        sim_dirs.append(child)

    return sim_dirs


def run_simulation(sim_dir: Path) -> Tuple[int, float]:
    """
    Run a single simulation by invoking its run_simulation.sh via bash.

    Returns:
        (return_code, duration_seconds)
    """
    start_time = time.perf_counter()

    cmd = ["bash", "run_simulation.sh"]

    process = subprocess.Popen(cmd, cwd=str(sim_dir))
    try:
        return_code = process.wait()
    except KeyboardInterrupt:
        # Propagate interrupt but try to terminate the child gracefully
        process.terminate()
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            process.kill()
        raise

    duration = time.perf_counter() - start_time
    return return_code, duration


def main() -> None:
    try:
        sim_dirs = discover_simulation_dirs()
    except Exception as e:
        _print_banner(
            [
                "SIMULATION RUNNER ERROR",
                f"Failed to discover simulations: {e}",
            ],
            char="!",
        )
        sys.exit(1)

    if not sim_dirs:
        _print_banner(
            ["SIMULATION RUNNER", "No simulations found to run."],
            char="=",
        )
        return

    total_start = time.perf_counter()
    results: List[Tuple[str, int, float]] = []

    _print_banner(
        [
            "SIMULATION RUNNER",
            f"Discovered {len(sim_dirs)} simulation(s) under Simulation_Setups/simulations",
        ],
        char="=",
    )

    for idx, sim_dir in enumerate(sim_dirs, start=1):
        sim_name = sim_dir.name
        _print_banner(
            [
                f"STARTING SIMULATION {idx}/{len(sim_dirs)}",
                f"Name: {sim_name}",
                f"Path: {sim_dir}",
            ],
            char="#",
        )

        try:
            return_code, duration = run_simulation(sim_dir)
        except KeyboardInterrupt:
            _print_banner(
                [
                    f"SIMULATION {sim_name} INTERRUPTED BY USER",
                    f"Index: {idx}/{len(sim_dirs)}",
                ],
                char="!",
            )
            results.append((sim_name, -1, 0.0))
            break
        except Exception as e:
            _print_banner(
                [
                    f"SIMULATION {sim_name} CRASHED",
                    f"Index: {idx}/{len(sim_dirs)}",
                    f"Error: {e}",
                ],
                char="!",
            )
            results.append((sim_name, -1, 0.0))
            continue

        status = "SUCCESS" if return_code == 0 else f"FAILED (code={return_code})"
        results.append((sim_name, return_code, duration))

        _print_banner(
            [
                f"FINISHED SIMULATION {idx}/{len(sim_dirs)}",
                f"Name: {sim_name}",
                f"Status: {status}",
                f"Runtime: {_format_duration(duration)}",
            ],
            char="*",
        )

    total_duration = time.perf_counter() - total_start

    _print_banner(
        [
            "SIMULATION RUNNER SUMMARY",
            f"Total simulations attempted: {len(results)}",
            f"Total wall-clock time: {_format_duration(total_duration)}",
            "",
            "Per-simulation results:",
        ],
        char="=",
    )

    for name, code, dur in results:
        if code == 0:
            status = "OK"
        elif code == -1:
            status = "INTERRUPTED"
        else:
            status = f"ERR({code})"
        print(f"  - {name}: {status}, runtime={_format_duration(dur)}")

    print()


if __name__ == "__main__":
    main()
