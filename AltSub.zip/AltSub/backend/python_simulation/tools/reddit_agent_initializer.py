#!/usr/bin/env python3
"""
Reddit Agent Initializer for Construct API Simulation

This script processes Reddit data from SQLite database to initialize agents
for the Construct API simulation. It extracts user behavioral patterns,
creates belief networks, and generates XML configuration files.

Based on the research parameters from previous work and Reddit data analysis.
"""

import sqlite3
import json
import logging
import numpy as np
from datetime import datetime, timedelta
from typing import Any, Dict, List, Tuple, Optional, Set
from dataclasses import dataclass
from collections import defaultdict, Counter
import xml.etree.ElementTree as ET
from xml.dom import minidom
import argparse
import os
import sys
import pandas as pd
from pathlib import Path
from dotenv import load_dotenv

_env_paths = [
    Path.cwd() / ".env",
    Path(__file__).parent.parent.parent / ".env",
    Path(__file__).parent.parent.parent.parent / "Simulation_Setups" / ".env",
]

for env_path in _env_paths:
    if env_path.exists():
        load_dotenv(env_path, override=False)
        logging.getLogger(__name__).debug(f"Loaded .env from {env_path}")
        break
from .reddit_agent_belief_initialization_pipeline import (
    BeliefInitializer as BeliefPipeline,
    BeliefPipelineConfig,
    extraction_failure_fraction,
)
from ..services.llm_provider import get_llm_provider
from ..core.belief_axes import (
    BELIEF_MODELS,
    campaign_positions,
    complete_positions,
    resolve_belief_config,
)
from ..services.llm_json import complete_json
from ..core.rule_moderator_schedule import generate_rule_moderator_schedules
from ..core.activity_sessions import session_length_timesteps
from .reddit_hourly_activity import DEFAULT_TZ as DEFAULT_ACTIVITY_TZ, hourly_multipliers
from ..services.subreddit_seed_context import build_seed_context, save_seed_context

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)
log = logging.getLogger(__name__)

# Bot / service accounts that must never be sampled as real users
# ("<sub>-ModTeam" accounts are excluded by pattern in get_active_users). Kept
# as an explicit list: a generic "ends with bot" rule would drop real users
# (e.g. "Plex_the_robot"). Extend per run with --exclude-authors.
DEFAULT_EXCLUDED_AUTHORS = [
    "AutoModerator",
    "RemindMeBot",
    "PoliticsModeratorBot",
    "sneakpeekbot",
    "WikiSummarizerBot",
    "RepostSleuthBot",
    "SaveVideo",
    "savevideobot",
    "AmputatorBot",
    "haikusbot",
    "B0tRank",
    "LuckyNumber-Bot",
    "TweetLinkerBot",
    "VredditDownloader",
    "GifReversingBot",
    "FatFingerHelperBot",
    "exclaim_bot",
    "nice-scores",
]

# Abort initialization when more than this fraction of attempted per-user belief
# extractions failed (empty-but-ok results do not count), unless
# --allow-belief-failures is passed.
MAX_BELIEF_FAILURE_FRACTION = 0.5


# Coordination (co-action network) detector CLI flags -> mitigation_config keys.
# Defaults match MitigationSystem.
COORDINATION_DETECTOR_FLAGS = [
    ("--coordination-lookback-window", int, 144, "Coordination lookback (timesteps, default: 144)"),
    ("--coordination-sync-window", int, 6, "Max timesteps between synchronised co-actions (default: 6)"),
    ("--coordination-min-shared-targets", int, 3, "Co-engagement: min synchronised shared targets (default: 3)"),
    ("--coordination-content-similarity-threshold", float, 0.8, "Co-content: min text similarity (default: 0.8)"),
    ("--coordination-min-content-matches", int, 2, "Co-content: min matching text pairs (default: 2)"),
    ("--coordination-min-amplifications", int, 3, "Fast amplification: min distinct items (default: 3)"),
    ("--coordination-significance", float, 0.01, "Family-wise (Bonferroni) significance for co-engagement / fast-amplification edges (default: 0.01)"),
]

class BeliefExtractionError(RuntimeError):
    """Belief extraction unusable (no LLM provider / too many failures)."""


@dataclass
class AgentProfile:
    """Represents an agent profile extracted from Reddit data"""

    username: str
    subreddit: str

    read_density: float
    post_probability: float
    pr_comment: float
    pr_upvote: float
    pr_downvote: float

    activity_level: str  # 'reader', 'voter', 'commenter', 'poster'
    frequency_of_use: str  # 'twice_daily', 'daily', 'twice_weekly', 'weekly', 'monthly'
    # these session lengths are based on (https://arxiv.org/pdf/1703.05267)
    session_duration: str  # 'short', 'medium', 'long'
    active_time_slots: List[str]

    total_posts: int
    total_comments: int
    avg_score: float
    controversiality: float

    beliefs: Dict[str, float]  # belief_id -> strength (0-1)
    trust_network: Dict[str, float]  # other_agent -> trust_level (0-1)

    user_type: str  # 'regular', 'moderator', 'attacker'


# Time slot meaning "any hour of the day"; session start hours within it are
# weighted by the subreddit's hour-of-day activity
ALL_DAY_SLOTS = ("12am-12am",)


class RedditAgentInitializer:
    """Main class for processing Reddit data and initializing agents"""

    def __init__(
        self,
        db_path: str,
        target_subreddit: str,
        sample_size: int = 1000,
        num_moderator: int = 0,
        num_attacker: int = 0,
        num_template_attacker: int = 0,
        num_llm_users: int = 0,
        moderation_delay: int = 12,
        ban_threshold: int = 3,
        duration_days: int = 14,
        interval_minutes: int = 5,
        llm_service_url: str = "http://localhost:5000",
        llm_voting_enabled: bool = False,
        # Prompt options written to llm_config (see LLMServiceConfig)
        verbal_acceptance_labels: bool = False,
        attacker_target_narrative: str = "",
        # In-process orchestrator campaign settings (read by run_simulation.py)
        campaign_objective: str = "amplify_narrative",
        coordination_strength: float = 0.8,
        attack_intensity: float = 0.7,
        daily_post_target: int = 5,
        # Attacker amplification of fellow attackers' posts (CoordinationHub)
        coordination_comment_prob: float = 0.5,
        coordination_delay_min: int = 1,
        coordination_delay_max: int = 6,
        # Mitigation system parameters
        enable_duplicate_detection: bool = False,
        enable_rate_limiting: bool = False,
        enable_coordinated_detection: bool = False,
        mitigation_scan_frequency: int = 10,
        duplicate_similarity_threshold: float = 0.85,
        rate_limit_window: int = 24,
        rate_limit_threshold: int = 10,
        coordination_similarity_threshold: float = 0.3,
        mitigation_ban_threshold: int = 3,
        use_embedding_similarity_for_duplicates: bool = False,
        # Co-action network coordination detector (other than the similarity threshold);
        # keys as in mitigation_config, missing keys use MitigationSystem defaults
        coordination_detection_params: Optional[Dict[str, Any]] = None,
        # Rule mitigation moderators (feed + MitigationSystem flags)
        enable_rule_moderators: bool = False,
        num_rule_moderator: int = 0,
        rule_moderator_active_fraction: float = 0.33,
        rule_moderator_read_density: int = 15,
        rule_moderator_schedule_seed: int = 42,
        rule_moderator_detection_threshold: float = 0.7,
        # Biased moderator parameters
        enable_biased_moderator: bool = False,
        biased_mod_risk_tolerance: float = 0.5,
        biased_mod_scan_frequency: int = 12,  # every hour for 5 min timesteps
        biased_mod_detection_threshold: float = 0.7,
        subreddit_rules: str = "Be civil. No personal attacks. Stay on topic.",
        biased_mod_beliefs_file: str = "biased_moderator_beliefs.json",
        # File path parameters
        campaign_templates_dir: str = "campaign_templates",
        # Custom library path (for Construct API shared library)
        custom_library_path: Optional[
            str
        ] = None,  # If None, Construct will search in executable directory
        # Belief caching parameters
        cached_beliefs_file: Optional[str] = None,
        # Feed ordering strategy
        feed_strategy: str = "default",
        # Belief capping (bloat mitigation)
        enable_belief_capping: bool = True,
        belief_cap: int = 60,
        protect_attacker_beliefs: bool = False,
        attacker_similarity_threshold: float = 0.6,
        weak_belief_threshold: float = 0.2,
        # Python runtime execution settings (used by run_simulation.py)
        enable_timestep_parallelism: bool = False,
        llm_max_concurrency: int = 8,
        llm_rate_limit_qps: float = 0.0,
        time_model: str = "event",
        run_seed: Optional[int] = None,
        # Session start hours are weighted by the subreddit's hour-of-day activity
        # in the Reddit database, read in this timezone (simulation hour 0 =
        # midnight there). hourly_activity_weights (24 values) overrides the
        # database-derived weights.
        activity_timezone: str = DEFAULT_ACTIVITY_TZ,
        hourly_activity_weights: Optional[List[float]] = None,
        belief_model: str = "axes",
        belief_axes_file: Optional[str] = None,
        # LLM provider/model metadata for Python simulation execution
        llm_provider: str = "auto",
        llm_model: str = "mistral-small-latest",
        # When True, regular + LLM user profiles use largest-remainder mixes matching
        # activity_distribution, frequency_distribution, and session_duration_distribution
        # (avoids empty small samples where random draws yield no posters/commenters).
        stratify_agent_mix: bool = True,
        # Real-user sampling: authors excluded on top of DEFAULT_EXCLUDED_AUTHORS
        exclude_authors: Optional[List[str]] = None,
        # When False, belief extraction with no LLM provider or a >50% per-user
        # failure rate aborts initialization instead of writing zero-belief agents
        allow_belief_failures: bool = False,
    ):
        self.db_path = db_path
        self.target_subreddit = target_subreddit
        # Interpret sample_size as the number of regular users
        self.num_regular = int(sample_size)
        self.num_moderator = int(num_moderator)
        self.num_attacker = int(num_attacker)
        self.num_template_attacker = int(num_template_attacker)
        self.num_llm_users = int(num_llm_users)
        self.enable_rule_moderators = bool(enable_rule_moderators)
        self.num_rule_moderator = int(num_rule_moderator)
        self.rule_moderator_active_fraction = float(rule_moderator_active_fraction)
        self.rule_moderator_read_density = int(rule_moderator_read_density)
        self.rule_moderator_schedule_seed = int(rule_moderator_schedule_seed)
        self.rule_moderator_detection_threshold = float(
            rule_moderator_detection_threshold
        )
        self.sample_size = self.num_regular  # backward-compatibility alias
        self.agents: List[AgentProfile] = []
        self.agent_activity_schedules: Dict[int, np.ndarray] = {}
        self.moderation_delay = int(max(0, moderation_delay))
        self.ban_threshold = int(max(1, ban_threshold))
        self.duration_days = int(max(1, duration_days))
        self.interval_minutes = int(max(1, interval_minutes))
        total_minutes = self.duration_days * 24 * 60
        self.num_timesteps = int(total_minutes // self.interval_minutes)

        self.llm_service_url = llm_service_url
        self.llm_voting_enabled = llm_voting_enabled
        self.verbal_acceptance_labels = bool(verbal_acceptance_labels)

        self.attacker_target_narrative = attacker_target_narrative
        self.campaign_objective = campaign_objective
        self.coordination_strength = float(coordination_strength)
        self.attack_intensity = float(attack_intensity)
        self.daily_post_target = int(daily_post_target)
        self.coordination_comment_prob = float(coordination_comment_prob)
        self.coordination_delay_min = int(coordination_delay_min)
        self.coordination_delay_max = int(coordination_delay_max)

        self.enable_duplicate_detection = enable_duplicate_detection
        self.enable_rate_limiting = enable_rate_limiting
        self.enable_coordinated_detection = enable_coordinated_detection
        self.mitigation_scan_frequency = mitigation_scan_frequency
        self.duplicate_similarity_threshold = duplicate_similarity_threshold
        self.rate_limit_window = rate_limit_window
        self.rate_limit_threshold = rate_limit_threshold
        self.coordination_similarity_threshold = coordination_similarity_threshold
        self.coordination_detection_params = dict(coordination_detection_params or {})
        self.mitigation_ban_threshold = mitigation_ban_threshold
        self.use_embedding_similarity_for_duplicates = use_embedding_similarity_for_duplicates

        self.enable_biased_moderator = enable_biased_moderator
        self.biased_mod_risk_tolerance = biased_mod_risk_tolerance
        self.biased_mod_scan_frequency = biased_mod_scan_frequency
        self.biased_mod_detection_threshold = biased_mod_detection_threshold
        self.subreddit_rules_text = subreddit_rules
        self.biased_mod_beliefs_file = biased_mod_beliefs_file

        self.campaign_templates_dir = campaign_templates_dir
        self.custom_library_path = custom_library_path

        self.cached_beliefs_file = cached_beliefs_file

        self.feed_strategy = feed_strategy

        self.enable_belief_capping = enable_belief_capping
        self.belief_cap = belief_cap
        self.protect_attacker_beliefs = protect_attacker_beliefs
        self.attacker_similarity_threshold = attacker_similarity_threshold
        self.weak_belief_threshold = weak_belief_threshold

        self.enable_timestep_parallelism = bool(enable_timestep_parallelism)
        self.llm_max_concurrency = int(max(1, llm_max_concurrency))
        self.llm_rate_limit_qps = float(max(0.0, llm_rate_limit_qps))
        # Simulation engine ("discrete" timesteps or "event"-driven) and run seed
        self.time_model = time_model
        self.run_seed = run_seed
        # Belief model ("axes" default, or "free_text") and its axes
        # (core/belief_axes.py; file > built-in set for the subreddit)
        self.belief_model = belief_model
        self.belief_axes_file = belief_axes_file
        self.belief_config = None
        self._axis_positions: Dict[str, Dict[str, float]] = {}
        self._axis_placement_stats: Dict[str, int] = {}

        self.llm_provider = llm_provider
        self.llm_model = llm_model
        self.stratify_agent_mix = bool(stratify_agent_mix)

        # Bot / mod accounts never sampled as real users (see get_active_users)
        self.exclude_authors = sorted(
            set(DEFAULT_EXCLUDED_AUTHORS)
            | {a.strip() for a in (exclude_authors or []) if a and a.strip()}
        )
        self.allow_belief_failures = bool(allow_belief_failures)
        # Per-user belief extraction outcome counts (None when cached beliefs are used)
        self._belief_extraction_stats: Optional[Dict] = None

        # Research-based parameters from previous work
        self.activity_distribution = {
            "reader": 0.40,
            "voter": 0.25,
            "commenter": 0.20,
            "poster": 0.15,
        }

        # Frequency of use distribution based on statista polling data
        self.frequency_distribution = {
            "twice_daily": 0.20,
            "daily": 0.30,
            "twice_weekly": 0.10,
            "weekly": 0.20,
            "monthly": 0.20,
        }

        # these session lengths are based on (https://arxiv.org/pdf/1703.05267)
        self.session_duration_distribution = {
            "short": 0.50,  # p=0.9 for geometric distribution
            "medium": 0.25,  # p=0.2 for geometric distribution
            "long": 0.25,  # p=0.05 for geometric distribution
        }

        # Time of day: a session can start in any hour, with the start hour drawn
        # in proportion to the subreddit's observed hour-of-day activity (posts +
        # comments, bots excluded; tools/reddit_hourly_activity.py). Loaded
        # lazily from the database on first use (see _get_hourly_weights).
        self.activity_timezone = activity_timezone
        if hourly_activity_weights is not None:
            w = [float(x) for x in hourly_activity_weights]
            if len(w) != 24 or any(x < 0 for x in w) or sum(w) <= 0:
                raise ValueError(
                    "hourly_activity_weights must be 24 non-negative values with a positive sum"
                )
            mean = sum(w) / 24
            self._hourly_weights: Optional[List[float]] = [x / mean for x in w]
            self._hourly_weights_source: Optional[str] = "override"
        else:
            self._hourly_weights = None
            self._hourly_weights_source = None

        # Default behavioral parameters
        # which ones are applicable depends on activity level of the user
        self.default_params = {
            "read_density": 10,  # average number of posts to read during an active time step
            "post_probability": 0.1,  # probability of posting during an active time step
            "pr_comment": 0.1,
            "pr_upvote": 0.15,
            "pr_downvote": 0.05,
        }

        self.knowledge_probability = (
            0.005
        )
        self.trust_range = (0.1, 0.9)  # Uniform distribution for trust weights
        self.default_trust = 0.5

        self.timesteps_per_hour = int(
            60 // self.interval_minutes
        )  # e.g., 12 timesteps per hour for 5-min intervals
        self.timesteps_per_day = self.timesteps_per_hour * 24

        # Optional env overrides for rule moderators (aligned with run_simulation.py)
        env_en = os.getenv("MITIGATION_ENABLE_RULE_MODERATORS")
        if env_en is not None and str(env_en).strip() != "":
            self.enable_rule_moderators = str(env_en).strip().lower() in (
                "1",
                "true",
                "yes",
                "on",
            )
        env_n = os.getenv("MITIGATION_RULE_MODERATOR_COUNT")
        if env_n is not None and str(env_n).strip() != "":
            try:
                self.num_rule_moderator = int(env_n)
                if self.num_rule_moderator > 0:
                    self.enable_rule_moderators = True
            except ValueError:
                log.warning("Invalid MITIGATION_RULE_MODERATOR_COUNT: %s", env_n)
        env_frac = os.getenv("MITIGATION_RULE_MODERATOR_ACTIVE_FRACTION")
        if env_frac is not None and str(env_frac).strip() != "":
            try:
                self.rule_moderator_active_fraction = float(env_frac)
            except ValueError:
                log.warning(
                    "Invalid MITIGATION_RULE_MODERATOR_ACTIVE_FRACTION: %s", env_frac
                )
        env_rd = os.getenv("MITIGATION_RULE_MODERATOR_READ_DENSITY")
        if env_rd is not None and str(env_rd).strip() != "":
            try:
                self.rule_moderator_read_density = int(env_rd)
            except ValueError:
                log.warning("Invalid MITIGATION_RULE_MODERATOR_READ_DENSITY: %s", env_rd)
        env_seed = os.getenv("MITIGATION_RULE_MODERATOR_SCHEDULE_SEED")
        if env_seed is not None and str(env_seed).strip() != "":
            try:
                self.rule_moderator_schedule_seed = int(env_seed)
            except ValueError:
                log.warning("Invalid MITIGATION_RULE_MODERATOR_SCHEDULE_SEED: %s", env_seed)

        if self.num_rule_moderator > 0:
            self.enable_rule_moderators = True
        if self.enable_rule_moderators and self.num_rule_moderator == 0:
            self.num_rule_moderator = 1

        self.total_agents = (
            self.num_regular
            + self.num_moderator
            + self.num_attacker
            + self.num_template_attacker
            + self.num_llm_users
            + self.num_rule_moderator
        )

    def load_database(self) -> sqlite3.Connection:
        """Load the SQLite database"""
        if not os.path.exists(self.db_path):
            raise FileNotFoundError(f"Database not found: {self.db_path}")

        conn = sqlite3.connect(self.db_path)
        log.info(f"Connected to database: {self.db_path}")
        return conn

    def get_active_users(self, conn: sqlite3.Connection) -> List[str]:
        """Get list of active users in the target subreddit.

        Skips deleted accounts, AutoModerator, "<sub>-ModTeam" removal-notice
        accounts and self.exclude_authors (matched case-insensitively, since
        Reddit usernames are).
        """
        excluded = sorted({a.lower() for a in self.exclude_authors})
        placeholders = ", ".join("?" for _ in excluded) or "''"
        query = f"""
        SELECT DISTINCT author 
        FROM (
            SELECT author FROM comments WHERE subreddit = ? COLLATE NOCASE AND author != '[deleted]'
            UNION
            SELECT author FROM submissions WHERE subreddit = ? COLLATE NOCASE AND author != '[deleted]'
        )
        WHERE author IS NOT NULL
          AND author NOT LIKE '%-ModTeam'
          AND LOWER(author) NOT IN ({placeholders})
        ORDER BY RANDOM()
        LIMIT ?
        """
        total_users_needed = self.num_regular + self.num_llm_users

        cursor = conn.execute(
            query,
            (
                self.target_subreddit,
                self.target_subreddit,
                *excluded,
                total_users_needed,
            ),
        )
        users = [row[0] for row in cursor.fetchall()]
        log.info(f"Found {len(users)} active users in r/{self.target_subreddit}")
        return users

    def calculate_user_activity_level(self) -> str:
        """Sample user activity level from prior research distribution (not inferred from data)."""
        activity_levels = list(self.activity_distribution.keys())
        probabilities = list(self.activity_distribution.values())
        return str(np.random.choice(activity_levels, p=probabilities))

    def _allocate_stratified_categories(
        self, n: int, distribution: Dict[str, float]
    ) -> List[str]:
        """
        Largest-remainder allocation so category counts match distribution proportions.

        Returns a shuffled list of length n (each entry is a category key).
        """
        if n <= 0:
            return []
        keys = list(distribution.keys())
        weights = np.array(
            [max(0.0, float(distribution[k])) for k in keys], dtype=float
        )
        s = float(weights.sum())
        if s <= 0:
            weights = np.ones(len(keys), dtype=float) / len(keys)
        else:
            weights = weights / s
        exact = n * weights
        floors = np.floor(exact).astype(int)
        counts = floors.tolist()
        remaining = n - int(sum(counts))
        frac = (exact - floors).tolist()
        order = sorted(range(len(keys)), key=lambda i: frac[i], reverse=True)
        for j in range(remaining):
            counts[order[j]] += 1
        out: List[str] = []
        for k, c in zip(keys, counts):
            out.extend([k] * c)
        np.random.shuffle(out)
        return out

    def calculate_behavioral_parameters(self, activity_level: str) -> Dict[str, float]:
        """Assign behavioral parameters from prior research (fixed probabilities per category)."""
        params = self.default_params.copy()
        # Map activity level → applicable behaviors
        if activity_level == "reader":
            params["post_probability"] = 0.0
            params["pr_comment"] = 0.0
            params["pr_upvote"] = 0.0
            params["pr_downvote"] = 0.0
        elif activity_level == "voter":
            params["post_probability"] = 0.0
            params["pr_comment"] = 0.0
            params["pr_upvote"] = 0.15
            params["pr_downvote"] = 0.05
        elif activity_level == "commenter":
            params["post_probability"] = 0.0
            params["pr_comment"] = 0.1
            params["pr_upvote"] = 0.15
            params["pr_downvote"] = 0.05
        elif activity_level == "poster":
            params["post_probability"] = 0.1
            params["pr_comment"] = 0.1
            params["pr_upvote"] = 0.15
            params["pr_downvote"] = 0.05
        # Read density remains from research default (interpreted as per active step)
        return params

    def extract_user_data(
        self, conn: sqlite3.Connection, username: str
    ) -> Optional[Dict]:
        """Extract comprehensive user data from database"""
        posts_query = """
        SELECT score, created_utc, num_comments, upvote_ratio
        FROM submissions 
        WHERE author = ? AND subreddit = ?
        """
        posts = conn.execute(posts_query, (username, self.target_subreddit)).fetchall()

        comments_query = """
        SELECT score, created_utc, controversiality
        FROM comments 
        WHERE author = ? AND subreddit = ?
        """
        comments = conn.execute(
            comments_query, (username, self.target_subreddit)
        ).fetchall()

        if not posts and not comments:
            return None

        total_posts = len(posts)
        total_comments = len(comments)

        all_scores = [post[0] for post in posts] + [comment[0] for comment in comments]
        avg_score = np.mean(all_scores) if all_scores else 0

        controversiality = (
            np.mean([comment[2] for comment in comments if comment[2] is not None])
            if comments
            else 0
        )

        all_timestamps = [post[1] for post in posts] + [
            comment[1] for comment in comments
        ]
        if all_timestamps:
            timestamps = sorted(all_timestamps)
            time_span = (max(timestamps) - min(timestamps)) / (24 * 3600)  # Days
            posts_per_day = total_posts / max(1, time_span)
            comments_per_day = total_comments / max(1, time_span)
        else:
            posts_per_day = 0
            comments_per_day = 0

        return {
            "total_posts": total_posts,
            "total_comments": total_comments,
            "avg_score": avg_score,
            "controversiality": controversiality,
            "posts_per_day": posts_per_day,
            "comments_per_day": comments_per_day,
            "all_timestamps": all_timestamps,
        }

    def generate_trust_network(
        self, all_users: List[str], username: str
    ) -> Dict[str, float]:
        """Generate trust network for user"""
        trust_network = {}

        other_users = [u for u in all_users if u != username]
        num_trust_relationships = np.random.poisson(3)

        for other_user in np.random.choice(
            other_users, min(num_trust_relationships, len(other_users)), replace=False
        ):
            trust_level = np.random.uniform(*self.trust_range)
            trust_network[other_user] = trust_level

        return trust_network

    def _get_hourly_weights(self) -> List[float]:
        """Hour-of-day session start weights (24 values, mean 1).

        From the target subreddit's activity in the Reddit database, unless
        hourly_activity_weights was given. If the database has no usable data
        the weights fall back to uniform (logged, and recorded in the config's
        activity_schedule_config.source).
        """
        if self._hourly_weights is None:
            subreddit = self.target_subreddit.strip()
            if subreddit.lower().startswith("r/"):
                subreddit = subreddit[2:]
            try:
                self._hourly_weights = hourly_multipliers(
                    self.db_path, subreddit=subreddit, tz_name=self.activity_timezone
                )
                self._hourly_weights_source = "reddit_database"
                log.info(
                    "Session start hours weighted by r/%s hour-of-day activity (%s): %s",
                    subreddit, self.activity_timezone,
                    ", ".join(f"{w:.2f}" for w in self._hourly_weights),
                )
            except Exception as e:
                log.warning(
                    "Could not derive hour-of-day activity weights from %s (%s); "
                    "session start hours will be uniform over the day",
                    self.db_path, e,
                )
                self._hourly_weights = [1.0] * 24
                self._hourly_weights_source = "uniform_fallback"
        return self._hourly_weights

    def generate_activity_schedule(
        self,
        frequency: str,
        session_duration: str,
        active_time_slots: List[str],
    ) -> np.ndarray:
        """
        Generate boolean activity schedule for all timesteps in simulation.

        Returns:
            Boolean array of shape (num_timesteps,) where True = active, False = inactive
        """
        schedule = np.zeros(self.num_timesteps, dtype=bool)

        session_length = self._get_session_length(session_duration)

        allowed_hours = self._parse_time_slots(active_time_slots)

        sessions = self._generate_session_starts(
            frequency, allowed_hours, session_length
        )

        for day, start_timestep in sessions:
            absolute_timestep = (day * self.timesteps_per_day) + start_timestep

            if absolute_timestep >= self.num_timesteps:
                break

            end_timestep = min(absolute_timestep + session_length, self.num_timesteps)
            schedule[absolute_timestep:end_timestep] = True

        return schedule

    def _get_session_length(
        self, session_duration: str, timestep_minutes: int = 5
    ) -> int:
        """Convert session duration to number of timesteps"""
        # Shared with runtime attacker campaign sessions
        return session_length_timesteps(session_duration)

    def _parse_time_slots(self, time_slots: List[str]) -> Set[int]:
        """Convert time slot strings to set of allowed hours (0-23)"""
        allowed_hours = set()

        time_slot_map = {
            # Whole day (regular / LLM / attacker profiles)
            "12am-12am": range(0, 24),
            # 6-hour blocks (older profiles)
            "12am-6am": range(0, 6),
            "6am-12pm": range(6, 12),
            "12pm-6pm": range(12, 18),
            "6pm-12am": range(18, 24),
            # 3-hour slots, still used by fixed moderator profiles / older profiles
            "6am-9am": range(6, 9),
            "9am-12pm": range(9, 12),
            "12pm-3pm": range(12, 15),
            "3pm-6pm": range(15, 18),
            "6pm-9pm": range(18, 21),
            "9pm-12am": range(21, 24),
        }

        for slot in time_slots:
            if slot in time_slot_map:
                allowed_hours.update(time_slot_map[slot])

        # If no valid time slots, allow all hours
        if not allowed_hours:
            log.error(
                f"No valid time slots provided, allowing all hours for input time slots: {time_slots}"
            )
            allowed_hours = set(range(24))

        return allowed_hours

    def _generate_session_starts(
        self, frequency: str, allowed_hours: Set[int], session_duration: int
    ) -> List[Tuple[int, int]]:
        """
        Generate (day, timestep) tuples for session starts based on frequency, active hours, and session duration.

        Only generates sessions that can fit entirely within allowed hours
        (wrapping past midnight). A session starts in a random timestep of its
        start hour, and the start hour is drawn in proportion to the
        subreddit's hour-of-day activity weights (_get_hourly_weights).

        Args:
            frequency: How often to generate sessions
            allowed_hours: Set of hours (0-23) when agent can be active
            session_duration: Length of session in timesteps

        Returns:
            List of (day, timestep_within_day) tuples indicating when sessions should start
        """
        sessions = []

        if not allowed_hours:
            log.warning("No allowed hours provided, cannot generate sessions")
            return sessions

        # A session starting at hour H needs hours [H, H+session_length_in_hours) to be allowed
        session_hours = int(np.ceil(session_duration / self.timesteps_per_hour))

        valid_start_hours = []
        for hour in sorted(allowed_hours):
            # Check if this hour and the next (session_hours-1) hours are all
            # allowed; hours wrap past midnight, so an all-day slot lets a
            # late-evening session run into the next day
            can_fit = True
            for h_offset in range(session_hours):
                if (hour + h_offset) % 24 not in allowed_hours:
                    can_fit = False
                    break
            if can_fit:
                valid_start_hours.append(hour)

        if not valid_start_hours:
            log.warning(
                f"No valid start hours for session length {session_duration} timesteps "
                f"({session_hours} hours) within allowed hours {sorted(allowed_hours)}"
            )
            # Fallback: try to use any allowed hour and let session be truncated
            valid_start_hours = sorted(list(allowed_hours))

        hour_weights = self._get_hourly_weights()
        start_p = np.array([hour_weights[h] for h in valid_start_hours], dtype=float)
        if start_p.sum() > 0:
            start_p = start_p / start_p.sum()
        else:
            start_p = np.full(len(valid_start_hours), 1.0 / len(valid_start_hours))

        for day in range(self.duration_days):
            session_count = 0

            if frequency == "twice_daily":
                session_count = 2
            elif frequency == "daily":
                session_count = 1
            elif frequency == "twice_weekly":
                # ~2 sessions per week (2/7 chance per day)
                if np.random.random() < (2.0 / 7.0):
                    session_count = 1
            elif frequency == "weekly":
                # ~1 session per week (1/7 chance per day)
                if np.random.random() < (1.0 / 7.0):
                    session_count = 1
            elif frequency == "monthly":
                # ~1 session per month (1/30 chance per day)
                if np.random.random() < (1.0 / 30.0):
                    session_count = 1
            else:
                log.warning(f"Unknown frequency: {frequency}, defaulting to daily")
                session_count = 1

            used_timesteps_today = set()

            for _ in range(session_count):
                if len(valid_start_hours) == 0:
                    break

                max_attempts = 20
                for attempt in range(max_attempts):
                    # Pick a start hour, weighted by hour-of-day activity
                    hour = int(np.random.choice(valid_start_hours, p=start_p))

                    timestep_in_hour = np.random.randint(0, self.timesteps_per_hour)
                    timestep_in_day = (
                        hour * self.timesteps_per_hour
                    ) + timestep_in_hour

                    session_range = set(
                        range(timestep_in_day, timestep_in_day + session_duration)
                    )
                    if not session_range.intersection(used_timesteps_today):
                        sessions.append((day, timestep_in_day))
                        used_timesteps_today.update(session_range)
                        break
                else:
                    log.debug(
                        f"Could not find non-overlapping session for day {day} "
                        f"(attempt {session_count}, already used {len(used_timesteps_today)} timesteps)"
                    )
                    # Skip this session rather than create an overlap

        return sessions

    def save_attacker_natural_schedules(
        self, agents: List[AgentProfile], output_dir: str
    ) -> str:
        """
        Save natural activity schedules for attacker agents to JSON file.

        These schedules represent when attackers would naturally be active
        if they were behaving as normal users (not campaign-activated).

        Args:
            agents: List of all agent profiles
            output_dir: Directory to save the schedules

        Returns:
            Path to the saved schedules file
        """
        natural_schedules = {}

        for agent_idx, agent in enumerate(agents):
            if agent.user_type == "attacker":
                if agent_idx in self.agent_activity_schedules:
                    schedule = self.agent_activity_schedules[agent_idx]
                    natural_schedules[str(agent_idx)] = schedule.astype(int).tolist()

                    log.info(
                        f"Saved natural schedule for attacker agent_{agent_idx}: "
                        f"{schedule.sum()} active timesteps out of {len(schedule)}"
                    )

        if not natural_schedules:
            log.warning("No attacker natural schedules to save")
            return ""

        schedule_path = os.path.join(output_dir, "attacker_natural_schedules.json")
        with open(schedule_path, "w") as f:
            json.dump(natural_schedules, f, indent=2)

        log.info(
            f"Saved {len(natural_schedules)} attacker natural schedules to {schedule_path}"
        )
        return schedule_path

    def _ensure_narrative_from_default_campaign_template(self) -> None:
        """
        When template attackers are used without an explicit narrative, read the
        narrative from campaign_templates/default_campaign.json (same file
        TemplateAttackerAgent loads). Avoids duplicating the narrative in every
        experiment_config / shell wrapper.
        """
        if (self.attacker_target_narrative or "").strip():
            return
        if self.num_template_attacker <= 0:
            return

        base = Path(self.campaign_templates_dir)
        if not base.is_absolute():
            base = Path.cwd() / base
        template_file = base / "default_campaign.json"
        if not template_file.is_file():
            log.warning(
                "Template attackers enabled but attacker_target_narrative is empty and "
                f"default campaign file not found: {template_file}"
            )
            return
        try:
            with open(template_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except (OSError, json.JSONDecodeError) as e:
            log.warning(
                "Could not read campaign template for narrative fallback: %s", e
            )
            return

        narrative = (data.get("narrative") or "").strip()
        if not narrative:
            narrative = (data.get("description") or "").strip()
        if not narrative:
            narrative = (data.get("campaign_name") or "").strip()

        if not narrative:
            log.warning(
                "Campaign template %s has no usable narrative, description, or campaign_name",
                template_file,
            )
            return

        self.attacker_target_narrative = narrative
        log.info(
            "Filled attacker_target_narrative from %s (%d chars)",
            template_file.name,
            len(narrative),
        )

    def generate_campaign_narrative_beliefs(self, narrative: str) -> Dict[str, float]:
        """Generate synthetic beliefs from campaign narrative using LLM"""
        if not narrative or not narrative.strip():
            log.warning(
                "No campaign narrative provided, using empty beliefs for attackers"
            )
            return {}

        try:
            llm = get_llm_provider()
            if not llm.is_available():
                log.warning(
                    "No LLM provider available, cannot generate campaign beliefs. Using fallback."
                )
                # Fallback: create a simple belief from the narrative
                belief_id = "campaign_narrative_" + str(hash(narrative))[:16]
                return {belief_id: 0.9}

            prompt = f"""
Extract 3-5 core beliefs that someone who strongly supports this narrative would hold.

Target Narrative: "{narrative}"

Output strict JSON: an object {{"beliefs": [...]}} whose list holds concise belief statements (strings only).
These should be atomic, specific claims that directly support the narrative.

Example output: {{"beliefs": ["Climate change is caused by human activity", "Immediate action on emissions is necessary", "Renewable energy should be prioritized"]}}
"""

            result = complete_json(
                llm,
                [
                    {
                        "role": "system",
                        "content": "You are a belief extraction system. Return only valid JSON.",
                    },
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=300,
                expect=list,
                wrap_key="beliefs",
                label="Campaign belief extraction",
            )
            belief_texts = (
                [t.strip() for t in result.data if isinstance(t, str) and t.strip()]
                if result.ok
                else []
            )
            if not belief_texts:
                log.warning(
                    f"Campaign belief extraction failed ({result.error or 'no beliefs'}), "
                    "using fallback belief"
                )
                belief_id = "campaign_narrative_" + str(hash(narrative))[:16]
                return {belief_id: 0.9}

            campaign_beliefs = {}
            for belief_text in belief_texts[:5]:
                import hashlib

                belief_id = (
                    "campaign_"
                    + hashlib.sha1(belief_text.encode("utf-8")).hexdigest()[:16]
                )
                # High strength (0.85-0.95) with slight variation
                strength = 0.85 + (hash(belief_text) % 100) / 1000.0
                campaign_beliefs[belief_id] = float(np.clip(strength, 0.85, 0.95))

                if not hasattr(self, "_campaign_beliefs_texts"):
                    self._campaign_beliefs_texts = {}
                self._campaign_beliefs_texts[belief_id] = belief_text

            log.info(
                f"Generated {len(campaign_beliefs)} campaign-aligned beliefs from narrative"
            )
            return campaign_beliefs

        except Exception as e:
            log.error(f"Failed to generate campaign beliefs: {e}")
            belief_id = "campaign_narrative_" + str(hash(narrative))[:16]
            return {belief_id: 0.9}

    def create_attacker_profile(
        self,
        username: str,
        campaign_beliefs: Dict[str, float],
        all_users: List[str],
    ) -> AgentProfile:
        """Create attacker agent profile with campaign-aligned beliefs"""
        activity_level = "poster"
        behavioral_params = self.calculate_behavioral_parameters(activity_level)

        beliefs = dict(campaign_beliefs)

        # Generate trust network (minimal - attackers don't rely on trust)
        trust_network = {}

        frequency = "twice_daily"
        session_duration = "medium"
        active_time_slots = list(ALL_DAY_SLOTS)

        return AgentProfile(
            username=username,
            subreddit=self.target_subreddit,
            read_density=behavioral_params["read_density"],
            post_probability=behavioral_params["post_probability"],
            pr_comment=behavioral_params["pr_comment"],
            pr_upvote=behavioral_params["pr_upvote"],
            pr_downvote=behavioral_params["pr_downvote"],
            activity_level=activity_level,
            frequency_of_use=frequency,
            session_duration=session_duration,
            active_time_slots=active_time_slots,
            total_posts=0,  # Synthetic agent, no historical data
            total_comments=0,
            avg_score=0,
            controversiality=0,
            beliefs=beliefs,
            trust_network=trust_network,
            user_type="attacker",
        )

    def create_template_attacker_profile(
        self,
        username: str,
        campaign_beliefs: Dict[str, float],
        all_users: List[str],
    ) -> AgentProfile:
        """Create template attacker agent profile with campaign-aligned beliefs"""
        activity_level = "poster"
        behavioral_params = self.calculate_behavioral_parameters(activity_level)

        beliefs = dict(campaign_beliefs)

        # Generate trust network (minimal - attackers don't rely on trust)
        trust_network = {}

        frequency = "twice_daily"
        session_duration = "medium"
        active_time_slots = list(ALL_DAY_SLOTS)

        return AgentProfile(
            username=username,
            subreddit=self.target_subreddit,
            read_density=behavioral_params["read_density"],
            post_probability=behavioral_params["post_probability"],
            pr_comment=behavioral_params["pr_comment"],
            pr_upvote=behavioral_params["pr_upvote"],
            pr_downvote=behavioral_params["pr_downvote"],
            activity_level=activity_level,
            frequency_of_use=frequency,
            session_duration=session_duration,
            active_time_slots=active_time_slots,
            total_posts=0,  # Synthetic agent, no historical data
            total_comments=0,
            avg_score=0,
            controversiality=0,
            beliefs=beliefs,
            trust_network=trust_network,
            user_type="template_attacker",
        )

    def create_llm_agent_profile(
        self,
        conn: sqlite3.Connection,
        username: str,
        all_users: List[str],
        user_beliefs_map: Dict[str, Dict[str, float]],
        activity_level_override: Optional[str] = None,
        frequency_override: Optional[str] = None,
        session_duration_override: Optional[str] = None,
    ) -> Optional[AgentProfile]:
        """Create LLM-based agent profile from user data"""
        user_data = self.extract_user_data(conn, username)
        if not user_data:
            return None

        activity_level = activity_level_override or self.calculate_user_activity_level()
        behavioral_params = self.calculate_behavioral_parameters(activity_level)

        beliefs = dict(user_beliefs_map.get(username, {}))
        trust_network = self.generate_trust_network(all_users, username)

        if frequency_override:
            frequency = frequency_override
        else:
            if user_data["posts_per_day"] + user_data["comments_per_day"] > 2:
                frequency = "twice_daily"
            elif user_data["posts_per_day"] + user_data["comments_per_day"] > 1:
                frequency = "daily"
            elif user_data["posts_per_day"] + user_data["comments_per_day"] > 0.3:
                frequency = "twice_weekly"
            elif user_data["posts_per_day"] + user_data["comments_per_day"] > 0.1:
                frequency = "weekly"
            else:
                frequency = "monthly"

        if session_duration_override:
            session_duration = session_duration_override
        else:
            session_duration = str(
                np.random.choice(
                    list(self.session_duration_distribution.keys()),
                    p=list(self.session_duration_distribution.values()),
                )
            )

        active_time_slots = list(ALL_DAY_SLOTS)

        return AgentProfile(
            username=username,
            subreddit=self.target_subreddit,
            read_density=behavioral_params["read_density"],
            post_probability=behavioral_params["post_probability"],
            pr_comment=behavioral_params["pr_comment"],
            pr_upvote=behavioral_params["pr_upvote"],
            pr_downvote=behavioral_params["pr_downvote"],
            activity_level=activity_level,
            frequency_of_use=frequency,
            session_duration=session_duration,
            active_time_slots=active_time_slots,
            total_posts=user_data["total_posts"],
            total_comments=user_data["total_comments"],
            avg_score=user_data["avg_score"],
            controversiality=user_data["controversiality"],
            beliefs=beliefs,
            trust_network=trust_network,
            user_type="llm_user",
        )

    def create_agent_profile(
        self,
        conn: sqlite3.Connection,
        username: str,
        all_users: List[str],
        user_beliefs_map: Dict[str, Dict[str, float]],
        activity_level_override: Optional[str] = None,
        frequency_override: Optional[str] = None,
        session_duration_override: Optional[str] = None,
    ) -> Optional[AgentProfile]:
        """Create agent profile from user data"""
        user_data = self.extract_user_data(conn, username)
        if not user_data:
            return None

        activity_level = activity_level_override or self.calculate_user_activity_level()
        behavioral_params = self.calculate_behavioral_parameters(activity_level)

        # Use precomputed beliefs from belief pipeline; fallback to empty if missing
        beliefs = dict(user_beliefs_map.get(username, {}))
        trust_network = self.generate_trust_network(all_users, username)

        # User type is set externally per simulation; default to 'regular'
        user_type = "regular"

        if frequency_override:
            frequency = frequency_override
        else:
            if user_data["posts_per_day"] + user_data["comments_per_day"] > 2:
                frequency = "twice_daily"
            elif user_data["posts_per_day"] + user_data["comments_per_day"] > 1:
                frequency = "daily"
            elif user_data["posts_per_day"] + user_data["comments_per_day"] > 0.3:
                frequency = "twice_weekly"
            elif user_data["posts_per_day"] + user_data["comments_per_day"] > 0.1:
                frequency = "weekly"
            else:
                frequency = "monthly"

        if session_duration_override:
            session_duration = session_duration_override
        else:
            session_duration = str(
                np.random.choice(
                    list(self.session_duration_distribution.keys()),
                    p=list(self.session_duration_distribution.values()),
                )
            )

        active_time_slots = list(ALL_DAY_SLOTS)

        return AgentProfile(
            username=username,
            subreddit=self.target_subreddit,
            read_density=behavioral_params["read_density"],
            post_probability=behavioral_params["post_probability"],
            pr_comment=behavioral_params["pr_comment"],
            pr_upvote=behavioral_params["pr_upvote"],
            pr_downvote=behavioral_params["pr_downvote"],
            activity_level=activity_level,
            frequency_of_use=frequency,
            session_duration=session_duration,
            active_time_slots=active_time_slots,
            total_posts=user_data["total_posts"],
            total_comments=user_data["total_comments"],
            avg_score=user_data["avg_score"],
            controversiality=user_data["controversiality"],
            beliefs=beliefs,
            trust_network=trust_network,
            user_type=user_type,
        )

    def _check_belief_extraction(self, stats: Optional[Dict]) -> None:
        """Fail loudly if most per-user belief extractions failed."""
        if not stats:
            return
        frac = extraction_failure_fraction(stats)
        if frac <= MAX_BELIEF_FAILURE_FRACTION:
            if stats["failed"]:
                log.warning(
                    "%d/%d belief extractions failed (%.0f%%); those users start with no beliefs.",
                    stats["failed"],
                    stats["extracted"] + stats["empty"] + stats["failed"],
                    100.0 * frac,
                )
            return
        reasons = "; ".join(
            f"{reason} (x{n})"
            for reason, n in sorted(
                stats["failure_reasons"].items(), key=lambda kv: -kv[1]
            )[:3]
        )
        msg = (
            f"Belief extraction failed for {stats['failed']} of "
            f"{stats['extracted'] + stats['empty'] + stats['failed']} users "
            f"({100.0 * frac:.0f}% > {100.0 * MAX_BELIEF_FAILURE_FRACTION:.0f}% limit). "
            f"Top reasons: {reasons}. Fix the LLM provider, or pass "
            "--allow-belief-failures to continue anyway."
        )
        if not self.allow_belief_failures:
            raise BeliefExtractionError(msg)
        log.warning(msg + " Continuing (--allow-belief-failures).")

    def process_agents(
        self, conn: sqlite3.Connection, output_dir: str = None
    ) -> List[AgentProfile]:
        """Process all agents from the database"""
        log.info("Starting agent processing...")

        active_users = self.get_active_users(conn)
        total_requested = self.num_regular + self.num_llm_users

        # Limit to only the number of agents we actually plan to create (random sample for representativeness)
        if total_requested <= 0:
            selected_users: List[str] = []
        elif len(active_users) <= total_requested:
            selected_users = list(active_users)
        else:
            idx = np.random.permutation(len(active_users))[:total_requested]
            selected_users = [active_users[i] for i in idx]

        # Partition selected users for the different agent types that draw from real users
        regular_candidates = selected_users[: self.num_regular]
        llm_candidates = selected_users[
            self.num_regular : self.num_regular + self.num_llm_users
        ]
        # Build beliefs once across the selected users via the belief pipeline
        # Or load from cache if available. The belief statements model starts
        # every organic user neutral (0.5) on every statement, so it needs no
        # per-user extraction.
        if self.belief_model == "axes":
            log.info(
                "Belief statements model: users start neutral on every statement; "
                "skipping per-user belief extraction"
            )
            canonical_beliefs = []
            user_beliefs_map = {username: {} for username in selected_users}
            user_belief_texts = {username: {} for username in selected_users}
        elif self.cached_beliefs_file:
            log.info(f"Loading cached beliefs from {self.cached_beliefs_file}")
            import json

            with open(self.cached_beliefs_file, "r") as f:
                cached_data = json.load(f)

            canonical_beliefs = []
            for belief in cached_data.get("canonical_beliefs", []):
                canonical_beliefs.append(
                    {
                        "belief_id": belief["belief_id"],
                        "canonical_text": belief["canonical_text"],
                    }
                )

            # Extract user beliefs - map from canonical format to expected format
            user_beliefs_map = {}
            for user_data in cached_data.get("user_beliefs", []):
                username = user_data["username"]
                beliefs_dict = {}
                for belief_entry in user_data["beliefs"]:
                    belief_id = belief_entry["belief_id"]
                    strength = belief_entry["strength"]
                    beliefs_dict[belief_id] = strength
                user_beliefs_map[username] = beliefs_dict

            log.info(f"Loaded {len(canonical_beliefs)} canonical beliefs from cache")
            log.info(f"Loaded belief maps for {len(user_beliefs_map)} users from cache")

            filtered_user_beliefs = {}
            for username in selected_users:
                if username in user_beliefs_map:
                    filtered_user_beliefs[username] = user_beliefs_map[username]
                else:
                    log.warning(
                        f"User {username} not found in cached beliefs, will have empty beliefs"
                    )
                    filtered_user_beliefs[username] = {}
            user_beliefs_map = filtered_user_beliefs
            user_belief_texts = {username: {} for username in selected_users}
        else:
            belief_cfg = BeliefPipelineConfig(subreddit=self.target_subreddit)
            belief_init = BeliefPipeline(belief_cfg)
            if selected_users and not belief_init.llm_available():
                msg = (
                    "No LLM provider available for belief extraction "
                    f"({len(selected_users)} users need beliefs). Set MISTRAL_API_KEY "
                    "or OPENAI_API_KEY, pass --cached-beliefs-file, or pass "
                    "--allow-belief-failures to continue with zero beliefs."
                )
                if not self.allow_belief_failures:
                    raise BeliefExtractionError(msg)
                log.warning(msg + " Continuing (--allow-belief-failures).")
            (
                canonical_beliefs,
                user_beliefs_map,
                user_belief_texts,
            ) = belief_init.build_beliefs_for_users(
                conn, self.target_subreddit, selected_users, output_dir=output_dir
            )
            log.info(
                f"Belief pipeline produced {len(canonical_beliefs)} canonical beliefs."
            )
            self._belief_extraction_stats = belief_init.last_extraction_stats
            self._check_belief_extraction(self._belief_extraction_stats)

        self._canonical_beliefs = canonical_beliefs
        self._user_beliefs_map = user_beliefs_map
        self._user_belief_texts = user_belief_texts
        log.info(f"Processing {len(active_users)} candidate users...")

        agents = []
        strat_reg_act: Optional[List[str]] = None
        strat_reg_freq: Optional[List[str]] = None
        strat_reg_sess: Optional[List[str]] = None
        if self.stratify_agent_mix and self.num_regular > 0:
            strat_reg_act = self._allocate_stratified_categories(
                self.num_regular, self.activity_distribution
            )
            strat_reg_freq = self._allocate_stratified_categories(
                self.num_regular, self.frequency_distribution
            )
            strat_reg_sess = self._allocate_stratified_categories(
                self.num_regular, self.session_duration_distribution
            )
            log.info(
                "Stratified mix for %s regular users: activity=%s frequency=%s session=%s",
                self.num_regular,
                dict(Counter(strat_reg_act)),
                dict(Counter(strat_reg_freq)),
                dict(Counter(strat_reg_sess)),
            )

        if self.num_regular > 0:
            for username in regular_candidates:
                if len(agents) >= self.num_regular:
                    break

                idx = len(agents)
                agent = self.create_agent_profile(
                    conn,
                    username,
                    selected_users,
                    user_beliefs_map,
                    activity_level_override=strat_reg_act[idx]
                    if strat_reg_act is not None
                    else None,
                    frequency_override=strat_reg_freq[idx]
                    if strat_reg_freq is not None
                    else None,
                    session_duration_override=strat_reg_sess[idx]
                    if strat_reg_sess is not None
                    else None,
                )
                if agent:
                    agent_index = len(agents)
                    agents.append(agent)

                    schedule = self.generate_activity_schedule(
                        agent.frequency_of_use,
                        agent.session_duration,
                        agent.active_time_slots,
                    )
                    self.agent_activity_schedules[agent_index] = schedule

                    log.info(
                        f"Created agent {len(agents)}/{self.sample_size}: {username}"
                    )

            log.info(
                f"Created {len(agents)} regular user profiles (target {self.num_regular})"
            )

        if self.num_moderator > 0:
            log.info(f"Creating {self.num_moderator} moderator profiles...")
            moderator_agents = []

            for i in range(self.num_moderator):
                activity_level = "commenter"
                behavioral_params = self.calculate_behavioral_parameters(activity_level)

                moderator = AgentProfile(
                    username=f"moderator_{i}",
                    subreddit=self.target_subreddit,
                    read_density=behavioral_params["read_density"],
                    post_probability=behavioral_params["post_probability"],
                    pr_comment=behavioral_params["pr_comment"],
                    pr_upvote=behavioral_params["pr_upvote"],
                    pr_downvote=behavioral_params["pr_downvote"],
                    activity_level=activity_level,
                    frequency_of_use="daily",
                    session_duration="long",
                    active_time_slots=["9am-12pm"],
                    total_posts=0,
                    total_comments=0,
                    avg_score=0,
                    controversiality=0,
                    beliefs={},
                    trust_network={},
                    user_type="moderator",
                )
                agent_index = len(agents) + len(moderator_agents)
                moderator_agents.append(moderator)

                # Moderators are currently assumed always active (for automod, change this in future if we are simulating human moderators)
                schedule = np.ones(self.num_timesteps, dtype=bool)
                self.agent_activity_schedules[agent_index] = schedule

            agents.extend(moderator_agents)
            log.info(f"Created {len(moderator_agents)} moderator profiles")

        self._ensure_narrative_from_default_campaign_template()

        shared_campaign_beliefs: Optional[Dict[str, float]] = None
        if (
            self.num_attacker > 0
            or self.num_template_attacker > 0
            or self.enable_biased_moderator
        ):
            shared_campaign_beliefs = self.generate_campaign_narrative_beliefs(
                self.attacker_target_narrative
            )

        if self.num_attacker > 0:
            log.info(
                f"Creating {self.num_attacker} attacker profiles with campaign-aligned beliefs..."
            )

            campaign_beliefs = dict(shared_campaign_beliefs or {})

            if not campaign_beliefs:
                log.warning(
                    "No campaign beliefs generated, attackers will have minimal beliefs"
                )

            attacker_agents = []
            for i in range(self.num_attacker):
                attacker = self.create_attacker_profile(
                    username=f"attacker_{i}",
                    campaign_beliefs=campaign_beliefs,
                    all_users=selected_users,
                )
                agent_index = len(agents) + len(attacker_agents)
                attacker_agents.append(attacker)

                schedule = self.generate_activity_schedule(
                    attacker.frequency_of_use,
                    attacker.session_duration,
                    attacker.active_time_slots,
                )
                self.agent_activity_schedules[agent_index] = schedule

                log.info(
                    f"Attacker agent_{agent_index} natural schedule: "
                    f"{schedule.sum()} active timesteps (will self-regulate when not campaigning)"
                )

            agents.extend(attacker_agents)
            log.info(
                f"Created {len(attacker_agents)} attacker profiles with "
                f"{len(campaign_beliefs)} campaign-aligned beliefs"
            )

        if self.num_template_attacker > 0:
            log.info(
                f"Creating {self.num_template_attacker} template attacker profiles with campaign-aligned beliefs..."
            )

            # Same distilled beliefs as LLM attackers (single LLM call shared above)
            campaign_beliefs = dict(shared_campaign_beliefs or {})
            if not campaign_beliefs:
                log.warning(
                    "No campaign beliefs generated, template attackers will have minimal beliefs"
                )

            template_attacker_agents = []
            for i in range(self.num_template_attacker):
                template_attacker = self.create_template_attacker_profile(
                    username=f"template_attacker_{i}",
                    campaign_beliefs=campaign_beliefs,
                    all_users=selected_users,
                )
                agent_index = len(agents) + len(template_attacker_agents)
                template_attacker_agents.append(template_attacker)

                schedule = self.generate_activity_schedule(
                    template_attacker.frequency_of_use,
                    template_attacker.session_duration,
                    template_attacker.active_time_slots,
                )
                self.agent_activity_schedules[agent_index] = schedule

                log.info(
                    f"Template attacker agent_{agent_index} natural schedule: "
                    f"{schedule.sum()} active timesteps"
                )

            agents.extend(template_attacker_agents)
            log.info(
                f"Created {len(template_attacker_agents)} template attacker profiles with "
                f"{len(campaign_beliefs)} campaign-aligned beliefs"
            )

        if self.num_llm_users > 0:
            log.info(f"Creating {self.num_llm_users} LLM user profiles...")
            llm_users: List[AgentProfile] = []

            strat_llm_act: Optional[List[str]] = None
            strat_llm_freq: Optional[List[str]] = None
            strat_llm_sess: Optional[List[str]] = None
            if self.stratify_agent_mix:
                strat_llm_act = self._allocate_stratified_categories(
                    self.num_llm_users, self.activity_distribution
                )
                strat_llm_freq = self._allocate_stratified_categories(
                    self.num_llm_users, self.frequency_distribution
                )
                strat_llm_sess = self._allocate_stratified_categories(
                    self.num_llm_users, self.session_duration_distribution
                )
                log.info(
                    "Stratified mix for %s LLM users: activity=%s frequency=%s session=%s",
                    self.num_llm_users,
                    dict(Counter(strat_llm_act)),
                    dict(Counter(strat_llm_freq)),
                    dict(Counter(strat_llm_sess)),
                )

            # Prefer the partitioned candidates; if we ran out, fall back to any remaining active users.
            if llm_candidates:
                candidate_pool = llm_candidates
            else:
                candidate_pool = [
                    u for u in active_users if u not in regular_candidates
                ]

            if not candidate_pool:
                candidate_pool = list(active_users)

            # Reference set for trust network generation (preserve order, remove duplicates)
            all_llm_references = list(dict.fromkeys(selected_users + candidate_pool))

            for username in candidate_pool:
                if len(llm_users) >= self.num_llm_users:
                    break

                idx = len(llm_users)
                agent = self.create_llm_agent_profile(
                    conn,
                    username,
                    all_llm_references,
                    user_beliefs_map,
                    activity_level_override=strat_llm_act[idx]
                    if strat_llm_act is not None
                    else None,
                    frequency_override=strat_llm_freq[idx]
                    if strat_llm_freq is not None
                    else None,
                    session_duration_override=strat_llm_sess[idx]
                    if strat_llm_sess is not None
                    else None,
                )
                if agent:
                    agent_index = len(agents) + len(llm_users)
                    llm_users.append(agent)

                    schedule = self.generate_activity_schedule(
                        agent.frequency_of_use,
                        agent.session_duration,
                        agent.active_time_slots,
                    )
                    self.agent_activity_schedules[agent_index] = schedule

                    log.info(
                        f"Created LLM agent {len(llm_users)}/{self.num_llm_users}: {username}"
                    )

            agents.extend(llm_users)
            log.info(
                f"Created {len(llm_users)} LLM user profiles (target {self.num_llm_users})"
            )

        if self.enable_rule_moderators and self.num_rule_moderator > 0:
            log.info(
                "Creating %s rule_moderator profile(s) for mitigation...",
                self.num_rule_moderator,
            )
            rm_schedules = generate_rule_moderator_schedules(
                self.num_timesteps,
                self.timesteps_per_day,
                self.num_rule_moderator,
                self.rule_moderator_active_fraction,
                self.rule_moderator_schedule_seed,
            )
            for i in range(self.num_rule_moderator):
                rm = AgentProfile(
                    username=f"rule_moderator_{i}",
                    subreddit=self.target_subreddit,
                    read_density=float(self.rule_moderator_read_density),
                    post_probability=0.0,
                    pr_comment=0.0,
                    pr_upvote=0.0,
                    pr_downvote=0.0,
                    activity_level="reader",
                    frequency_of_use="daily",
                    session_duration="long",
                    active_time_slots=["12am-12am"],
                    total_posts=0,
                    total_comments=0,
                    avg_score=0.0,
                    controversiality=0.0,
                    beliefs={},
                    trust_network={},
                    user_type="rule_moderator",
                )
                agent_index = len(agents)
                agents.append(rm)
                self.agent_activity_schedules[agent_index] = rm_schedules[i]
            log.info(
                "Added %s rule_moderator agent(s) with staggered daily schedules",
                self.num_rule_moderator,
            )

        if self.enable_biased_moderator:
            log.info(
                "Creating biased_moderator profile (campaign beliefs from attacker_target_narrative)..."
            )
            bc = dict(shared_campaign_beliefs or {})
            if not bc:
                log.warning(
                    "Biased moderator enabled but campaign belief distillation returned no beliefs "
                    "(empty narrative, LLM unavailable, or parse failure). "
                    "Re-run with a campaign narrative or check LLM provider."
                )
            behavioral_params = self.calculate_behavioral_parameters("commenter")
            biased_mod = AgentProfile(
                username="biased_moderator_0",
                subreddit=self.target_subreddit,
                read_density=behavioral_params["read_density"],
                post_probability=0.0,
                pr_comment=0.0,
                pr_upvote=0.0,
                pr_downvote=0.0,
                activity_level="commenter",
                frequency_of_use="daily",
                session_duration="long",
                active_time_slots=["9am-12pm"],
                total_posts=0,
                total_comments=0,
                avg_score=0.0,
                controversiality=0.0,
                beliefs=bc,
                trust_network={},
                user_type="biased_moderator",
            )
            agent_index = len(agents)
            agents.append(biased_mod)
            self.agent_activity_schedules[agent_index] = np.ones(
                self.num_timesteps, dtype=bool
            )
            log.info(
                "Added biased_moderator agent with %s campaign-aligned beliefs",
                len(bc),
            )

        return agents

    def place_agents_on_axes(self, agents: List[AgentProfile]) -> None:
        """Belief statements model: starting acceptance for every agent.

        Campaign agents (attackers, biased moderator) hold the campaign targets;
        every other agent starts at the statements' priors (neutral, 0.5).
        """
        config = self.belief_config
        stats = {"campaign": 0, "prior": 0}
        for agent in agents:
            if agent.user_type in ("attacker", "template_attacker", "biased_moderator"):
                self._axis_positions[agent.username] = campaign_positions(config)
                stats["campaign"] += 1
            elif agent.user_type != "rule_moderator":
                self._axis_positions[agent.username] = complete_positions(config, None)
                stats["prior"] += 1
        self._axis_placement_stats = stats
        log.info(f"Belief statements: starting values for {len(config.axes)} statements ({stats})")

    def generate_construct_xml(self, agents: List[AgentProfile], output_path: str):
        """Generate Construct API XML configuration file"""
        log.info(f"Generating Construct XML configuration...")

        output_dir = os.path.dirname(output_path)

        root = ET.Element("construct")

        construct_params = ET.SubElement(root, "construct_parameters")
        ET.SubElement(
            construct_params, "param", name="verbose initialization", value="true"
        )
        ET.SubElement(construct_params, "param", name="verbose runtime", value="true")
        interval_hours = float(self.interval_minutes) / 60.0
        ET.SubElement(
            construct_params,
            "param",
            name="interval time duration",
            value=f"{interval_hours}",
        )
        ET.SubElement(
            construct_params,
            "param",
            name="maximum post inactivity",
            value="24.0",
        )

        if self.custom_library_path:
            ET.SubElement(
                construct_params,
                "param",
                name="custom library",
                value=self.custom_library_path,
            )

        models = ET.SubElement(root, "models")
        reddit_model = ET.SubElement(models, "model", name="Reddit Interaction Model")

        ET.SubElement(
            reddit_model,
            "param",
            name="enable duplicate detection",
            value=str(self.enable_duplicate_detection).lower(),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="enable rate limiting",
            value=str(self.enable_rate_limiting).lower(),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="enable coordinated detection",
            value=str(self.enable_coordinated_detection).lower(),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="mitigation scan frequency",
            value=str(self.mitigation_scan_frequency),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="duplicate similarity threshold",
            value=str(self.duplicate_similarity_threshold),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="rate limit window",
            value=str(self.rate_limit_window),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="rate limit threshold",
            value=str(self.rate_limit_threshold),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="coordination suspicion threshold",
            value=str(self.coordination_similarity_threshold),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="mitigation ban threshold",
            value=str(self.mitigation_ban_threshold),
        )

        ET.SubElement(
            reddit_model,
            "param",
            name="interval time duration",
            value=f"{interval_hours}",
        )
        # Allow posts to persist for a day by default
        ET.SubElement(
            reddit_model,
            "param",
            name="maximum post inactivity",
            value="6.0",
        )

        ET.SubElement(
            reddit_model,
            "param",
            name="enable biased moderator",
            value=str(self.enable_biased_moderator).lower(),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="biased mod risk tolerance",
            value=str(self.biased_mod_risk_tolerance),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="biased mod scan frequency",
            value=str(self.biased_mod_scan_frequency),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="biased mod detection threshold",
            value=str(self.biased_mod_detection_threshold),
        )
        ET.SubElement(
            reddit_model,
            "param",
            name="subreddit rules text",
            value=self.subreddit_rules_text,
        )

        campaign_templates_dir_abs = os.path.abspath(self.campaign_templates_dir)
        ET.SubElement(
            reddit_model,
            "param",
            name="campaign templates directory",
            value=campaign_templates_dir_abs,
        )

        ET.SubElement(models, "model", name="Knowledge Trust Model")

        if self.num_attacker > 0:
            ET.SubElement(models, "model", name="Attacker Campaign Controller")
            log.info("Added Attacker Campaign Controller model (attackers detected)")

        nodesets = ET.SubElement(root, "nodesets")

        agents_nodeset = ET.SubElement(nodesets, "nodeset", name="agent")
        # regular users first, then moderators, then attackers, then LLM users
        index_map: List[Tuple[int, str]] = []
        total_regular = min(self.num_regular, len(agents))
        for i in range(total_regular):
            index_map.append((i, "regular"))
        next_index = total_regular
        for _ in range(self.num_moderator):
            index_map.append((next_index, "moderator"))
            next_index += 1
        for _ in range(self.num_attacker):
            index_map.append((next_index, "attacker"))
            next_index += 1
        for _ in range(self.num_llm_users):
            index_map.append((next_index, "llm_user"))
            next_index += 1
        for i, forced_type in index_map:
            # guard for cases where behavioral list is shorter than planned totals
            if i >= len(agents):
                break
            agent = agents[i]
            agent_node = ET.SubElement(agents_nodeset, "node", name=f"agent_{i}")

            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit post density",
                value=str(agent.read_density),
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit post probability",
                value=str(agent.post_probability),
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit reply probability",
                value=str(agent.pr_comment),
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit upvote probability",
                value=str(agent.pr_upvote),
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit downvote probability",
                value=str(agent.pr_downvote),
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit reading density",
                value=str(agent.read_density),
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit view reply probability",
                value="0.3",
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit thread browsing probability",
                value="0.2",
            )
            # Force user type to the requested class ordering (regular/moderator/attacker)
            ET.SubElement(
                agent_node, "attribute", name="Reddit user type", value=forced_type
            )
            # If moderator, set moderation delay (maps to node_attributes.moderation_delay)
            if forced_type == "moderator":
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="Reddit moderation delay",
                    value=str(self.moderation_delay),
                )

            if forced_type == "llm_user":
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="llm service url",
                    value=self.llm_service_url,
                )
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="llm voting enabled",
                    value=str(self.llm_voting_enabled).lower(),
                )

            if forced_type == "attacker":
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="llm service url",
                    value=self.llm_service_url,
                )
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="llm voting enabled",
                    value=str(self.llm_voting_enabled).lower(),
                )
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="Reddit campaign id",
                    value="default_campaign",
                )
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="Reddit coordination strength",
                    value="0.8",
                )
                ET.SubElement(
                    agent_node, "attribute", name="Reddit attack intensity", value="0.6"
                )

                schedules_path = os.path.join(
                    output_dir, "attacker_natural_schedules.json"
                )
                schedules_path_abs = os.path.abspath(schedules_path)
                ET.SubElement(
                    agent_node,
                    "attribute",
                    name="Reddit natural schedules file",
                    value=schedules_path_abs,
                )

            ET.SubElement(
                agent_node, "attribute", name="can send knowledge", value="true"
            )
            ET.SubElement(
                agent_node, "attribute", name="can receive knowledge", value="true"
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge trust", value="true"
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="can receive knowledge trust",
                value="true",
            )

        mitigation_agent_count = 0

        if self.enable_duplicate_detection:
            agent_id = next_index + mitigation_agent_count
            agent_node = ET.SubElement(agents_nodeset, "node", name=f"agent_{agent_id}")
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit user type",
                value="duplicate_detection",
            )
            # Mitigation agents need can_send/receive knowledge set
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can receive knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge trust", value="false"
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="can receive knowledge trust",
                value="false",
            )
            mitigation_agent_count += 1
            log.info(f"Added duplicate detection mitigation agent (agent_{agent_id})")

        if self.enable_rate_limiting:
            agent_id = next_index + mitigation_agent_count
            agent_node = ET.SubElement(agents_nodeset, "node", name=f"agent_{agent_id}")
            ET.SubElement(
                agent_node, "attribute", name="Reddit user type", value="rate_limit"
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can receive knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge trust", value="false"
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="can receive knowledge trust",
                value="false",
            )
            mitigation_agent_count += 1
            log.info(f"Added rate limiting mitigation agent (agent_{agent_id})")

        if self.enable_coordinated_detection:
            agent_id = next_index + mitigation_agent_count
            agent_node = ET.SubElement(agents_nodeset, "node", name=f"agent_{agent_id}")
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit user type",
                value="coordinated_behavior",
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can receive knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge trust", value="false"
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="can receive knowledge trust",
                value="false",
            )
            mitigation_agent_count += 1
            log.info(f"Added coordinated behavior mitigation agent (agent_{agent_id})")

        if self.enable_biased_moderator:
            agent_id = next_index + mitigation_agent_count
            agent_node = ET.SubElement(agents_nodeset, "node", name=f"agent_{agent_id}")
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit user type",
                value="biased_moderator",
            )

            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit llm service url",
                value=self.llm_service_url,
            )
            ET.SubElement(
                agent_node, "attribute", name="Reddit llm model", value="gpt-4o-mini"
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit creativity temperature",
                value="0.3",
            )
            ET.SubElement(
                agent_node, "attribute", name="Reddit max tokens", value="300"
            )

            beliefs_file_path = os.path.abspath(self.biased_mod_beliefs_file)
            ET.SubElement(
                agent_node,
                "attribute",
                name="Reddit biased moderator beliefs file",
                value=beliefs_file_path,
            )

            ET.SubElement(
                agent_node, "attribute", name="can send knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can receive knowledge", value="false"
            )
            ET.SubElement(
                agent_node, "attribute", name="can send knowledge trust", value="false"
            )
            ET.SubElement(
                agent_node,
                "attribute",
                name="can receive knowledge trust",
                value="false",
            )
            mitigation_agent_count += 1
            log.info(f"Added biased LLM moderator agent (agent_{agent_id})")

        if mitigation_agent_count > 0:
            log.info(f"Total mitigation agents added: {mitigation_agent_count}")

        knowledge_nodeset = ET.SubElement(nodesets, "nodeset", name="knowledge")
        all_beliefs = set()
        for agent in agents:
            all_beliefs.update(agent.beliefs.keys())

        belief_text_map = {}
        if hasattr(self, "_canonical_beliefs"):
            for belief in self._canonical_beliefs:
                belief_text_map[belief["belief_id"]] = belief["canonical_text"]

        if hasattr(self, "_campaign_beliefs_texts"):
            belief_text_map.update(self._campaign_beliefs_texts)

        for belief_id in all_beliefs:
            knowledge_node = ET.SubElement(knowledge_nodeset, "node", name=belief_id)
            if belief_id in belief_text_map:
                ET.SubElement(
                    knowledge_node,
                    "attribute",
                    name="belief_text",
                    value=belief_text_map[belief_id],
                )
                ET.SubElement(
                    knowledge_node,
                    "attribute",
                    name="canonical_text",
                    value=belief_text_map[belief_id],
                )

        subreddits_nodeset = ET.SubElement(nodesets, "nodeset", name="subreddits")
        subreddit_node = ET.SubElement(
            subreddits_nodeset, "node", name=self.target_subreddit
        )
        # Subreddit attribute: ban threshold (maps to node_attributes.banned_threshold)
        ET.SubElement(
            subreddit_node,
            "attribute",
            name="banned threshold",
            value=str(self.ban_threshold),
        )

        # Activity nodeset (required by Social_Media base class)
        activity_nodeset = ET.SubElement(nodesets, "nodeset", name="activity")
        activity_actions = [
            "post",
            "read",
            "reply",
            "quote",
            "repost",
            "upvote",
            "downvote",
            "expand",
            "tree",
        ]
        for action_name in activity_actions:
            ET.SubElement(activity_nodeset, "node", name=action_name)

        time_nodeset = ET.SubElement(nodesets, "nodeset", name="time")
        for i in range(self.num_timesteps):
            ET.SubElement(time_nodeset, "node", name=f"time_{i}")

        networks = ET.SubElement(root, "networks")

        knowledge_network = ET.SubElement(
            networks,
            "network",
            name="knowledge network",
            edge_type="bool",
            default="false",
        )
        ET.SubElement(
            knowledge_network, "source", nodeset="agent", representation="dense"
        )
        ET.SubElement(
            knowledge_network, "target", nodeset="knowledge", representation="dense"
        )
        generator_kn = ET.SubElement(
            knowledge_network, "generator", type="random binary"
        )
        ET.SubElement(generator_kn, "param", name="density", value="0.2")

        # Subreddit membership network (required by the Reddit model)
        subreddit_network = ET.SubElement(
            networks,
            "network",
            name="subreddit membership network",
            edge_type="bool",
            default="false",
        )
        ET.SubElement(
            subreddit_network, "source", nodeset="agent", representation="dense"
        )
        ET.SubElement(
            subreddit_network, "target", nodeset="subreddits", representation="dense"
        )
        # Deterministically link every (planned) agent index to the single subreddit node
        for i, _ in index_map:
            ET.SubElement(
                subreddit_network,
                "link",
                source=f"agent_{i}",
                target=self.target_subreddit,
                value="true",
                src_name=f"agent_{i}",
                trg_name=self.target_subreddit,
            )

        knowledge_trust_network = ET.SubElement(
            networks,
            "network",
            name="knowledge trust network",
            edge_type="float",
            default="0.5",
        )
        ET.SubElement(
            knowledge_trust_network, "source", nodeset="agent", representation="dense"
        )
        ET.SubElement(
            knowledge_trust_network,
            "target",
            nodeset="knowledge",
            representation="dense",
        )

        # Initialize with actual belief strengths from the belief pipeline
        if hasattr(self, "_canonical_beliefs") and hasattr(self, "_user_beliefs_map"):
            belief_id_to_index = {}
            for i, belief in enumerate(self._canonical_beliefs):
                belief_id_to_index[belief["belief_id"]] = i

            for agent_idx, agent in enumerate(agents):
                for belief_id, strength in agent.beliefs.items():
                    if belief_id in belief_id_to_index:
                        knowledge_index = belief_id_to_index[belief_id]
                        ET.SubElement(
                            knowledge_trust_network,
                            "link",
                            source=f"agent_{agent_idx}",
                            target=belief_id,
                            value=str(strength),
                            src_name=f"agent_{agent_idx}",
                            trg_name=belief_id,
                        )
        else:
            # Fallback to random uniform if no belief data
            generator_tr = ET.SubElement(
                knowledge_trust_network, "generator", type="random uniform"
            )
            ET.SubElement(generator_tr, "param", name="min", value="0.1")
            ET.SubElement(generator_tr, "param", name="max", value="0.9")

        # Agent active time network (controls when agents are active)
        active_time_network = ET.SubElement(
            networks,
            "network",
            name="Reddit agent active time network",
            edge_type="bool",
            default="false",
        )
        ET.SubElement(
            active_time_network, "source", nodeset="agent", representation="dense"
        )
        ET.SubElement(
            active_time_network, "target", nodeset="time", representation="sparse"
        )

        for agent_idx, schedule in self.agent_activity_schedules.items():
            agent = agents[agent_idx]

            if agent.user_type == "attacker":
                # Attackers: always active in network (for campaign responsiveness)
                for timestep in range(self.num_timesteps):
                    ET.SubElement(
                        active_time_network,
                        "link",
                        source=f"agent_{agent_idx}",
                        target=f"time_{timestep}",
                        value="true",
                        src_name=f"agent_{agent_idx}",
                        trg_name=f"time_{timestep}",
                    )
            else:
                active_timesteps = np.where(schedule)[0]
                for timestep in active_timesteps:
                    ET.SubElement(
                        active_time_network,
                        "link",
                        source=f"agent_{agent_idx}",
                        target=f"time_{timestep}",
                        value="true",
                        src_name=f"agent_{agent_idx}",
                        trg_name=f"time_{timestep}",
                    )

        log.info(
            f"Generated activity schedules for {len(self.agent_activity_schedules)} agents"
        )

        activity_network = ET.SubElement(
            networks,
            "network",
            name="agent activity weights network",
            edge_type="float",
            default="0.0",
        )
        ET.SubElement(
            activity_network, "source", nodeset="agent", representation="dense"
        )
        ET.SubElement(
            activity_network, "target", nodeset="activity", representation="dense"
        )

        for agent_idx, agent in enumerate(agents):
            activity_weights = {
                "post": max(0.0, float(agent.post_probability)),
                "reply": max(0.0, float(agent.pr_comment)),
                "quote": 0.0,
                "repost": 0.0,
                "upvote": max(0.0, float(agent.pr_upvote)),
                "downvote": max(0.0, float(agent.pr_downvote)),
                "read": max(0.0, float(agent.read_density)),
                "expand": 0.5,
                "tree": 0.5,
            }

            for action_name in activity_actions:
                weight = activity_weights.get(action_name, 0.0)
                if weight <= 0:
                    continue
                ET.SubElement(
                    activity_network,
                    "link",
                    source=f"agent_{agent_idx}",
                    target=action_name,
                    value=str(weight),
                    src_name=f"agent_{agent_idx}",
                    trg_name=action_name,
                )

        outputs = ET.SubElement(root, "outputs")

        output = ET.SubElement(outputs, "output", type="dynetml")
        ET.SubElement(
            output,
            "param",
            name="network names",
            value="knowledge network,subreddit membership network,knowledge trust network,Reddit agent active time network",
        )
        ET.SubElement(
            output, "param", name="output file", value="reddit_simulation_output.xml"
        )
        ET.SubElement(output, "param", name="timeperiods", value="all")

        events_output = ET.SubElement(outputs, "output", type="media events")
        ET.SubElement(
            events_output, "param", name="model name", value="Reddit Interaction Model"
        )
        ET.SubElement(
            events_output, "param", name="output file", value="media_events.json"
        )
        ET.SubElement(
            events_output, "param", name="start time", value="2024-01-01T00:00:00"
        )
        ET.SubElement(
            events_output,
            "param",
            name="time conversion to seconds",
            value=str(self.interval_minutes * 60),
        )

        tree = ET.ElementTree(root)
        ET.indent(tree, space="  ", level=0)
        tree.write(output_path, encoding="utf-8", xml_declaration=True)
        log.info(f"XML configuration written to {output_path}")

    def generate_json_config(self, agents: List[AgentProfile], output_path: str):
        """Generate JSON configuration file for Python simulation"""
        log.info(f"Generating JSON configuration...")

        config = {
            "simulation_config": {
                "duration_days": self.duration_days,
                "interval_minutes": self.interval_minutes,
                "target_subreddit": self.target_subreddit,
                "total_agents": len(agents),
                "num_regular": self.num_regular,
                "num_moderator": self.num_moderator,
                "num_attacker": self.num_attacker,
                "num_template_attacker": self.num_template_attacker,
                "num_llm_users": self.num_llm_users,
                "attacker_target_narrative": self.attacker_target_narrative,
                "stratify_agent_mix": self.stratify_agent_mix,
            },
            "llm_config": {
                "llm_service_url": self.llm_service_url,
                "llm_voting_enabled": self.llm_voting_enabled,
                "verbal_acceptance_labels": self.verbal_acceptance_labels,
                "provider": self.llm_provider,
                "model": self.llm_model,
            },
            "runtime_config": {
                "enable_timestep_parallelism": self.enable_timestep_parallelism,
                "llm_max_concurrency": self.llm_max_concurrency,
                "llm_rate_limit_qps": self.llm_rate_limit_qps,
                "time_model": self.time_model,
                **({"seed": self.run_seed} if self.run_seed is not None else {}),
            },
            "belief_config": self.belief_config.to_dict() if self.belief_config else None,
            "activity_schedule_config": {
                "timezone": self.activity_timezone,
                "hourly_session_start_weights": [round(w, 4) for w in self._get_hourly_weights()],
                "source": self._hourly_weights_source,
            },
            "mitigation_config": {
                "enable_duplicate_detection": self.enable_duplicate_detection,
                "enable_rate_limiting": self.enable_rate_limiting,
                "enable_coordinated_detection": self.enable_coordinated_detection,
                "mitigation_scan_frequency": self.mitigation_scan_frequency,
                "duplicate_similarity_threshold": self.duplicate_similarity_threshold,
                "rate_limit_window": self.rate_limit_window,
                "rate_limit_threshold": self.rate_limit_threshold,
                "coordination_similarity_threshold": self.coordination_similarity_threshold,
                **self.coordination_detection_params,
                "mitigation_ban_threshold": self.mitigation_ban_threshold,
                "use_embedding_similarity_for_duplicates": self.use_embedding_similarity_for_duplicates,
                "enable_rule_moderators": self.enable_rule_moderators,
                "rule_moderator_count": self.num_rule_moderator,
                "rule_moderator_active_fraction": self.rule_moderator_active_fraction,
                "rule_moderator_read_density": self.rule_moderator_read_density,
                "rule_moderator_schedule_seed": self.rule_moderator_schedule_seed,
                "rule_moderator_detection_threshold": self.rule_moderator_detection_threshold,
                "subreddit_rules": self.subreddit_rules_text,
            },
            "biased_moderator_config": {
                "enable_biased_moderator": self.enable_biased_moderator,
                "biased_mod_risk_tolerance": self.biased_mod_risk_tolerance,
                "biased_mod_scan_frequency": self.biased_mod_scan_frequency,
                "biased_mod_detection_threshold": self.biased_mod_detection_threshold,
                "subreddit_rules": self.subreddit_rules_text,
                "biased_moderator_uses_campaign_beliefs": True,
                "biased_mod_beliefs_file": self.biased_mod_beliefs_file,
            },
            "feed_config": {
                "feed_strategy": self.feed_strategy,
            },
            "belief_capping_config": {
                "enabled": self.enable_belief_capping,
                "belief_cap": self.belief_cap,
                "protect_attacker_beliefs": self.protect_attacker_beliefs,
                "attacker_similarity_threshold": self.attacker_similarity_threshold,
                "weak_belief_threshold": self.weak_belief_threshold,
            },
            "campaign_config": {
                "campaign_templates_dir": self.campaign_templates_dir,
                "target_narrative": self.attacker_target_narrative,
                "objective": self.campaign_objective,
                "coordination_strength": self.coordination_strength,
                "attack_intensity": self.attack_intensity,
                "daily_post_target": self.daily_post_target,
                "coordination_comment_prob": self.coordination_comment_prob,
                "coordination_delay_min": self.coordination_delay_min,
                "coordination_delay_max": self.coordination_delay_max,
                "campaign_belief_texts": getattr(
                    self, "_campaign_beliefs_texts", {}
                ),
            },
            "agent_activity_schedules": {
                str(agent_idx): schedule.astype(int).tolist()
                for agent_idx, schedule in self.agent_activity_schedules.items()
            },
        }

        with open(output_path, "w") as f:
            json.dump(config, f, indent=2)

        log.info(f"JSON configuration written to {output_path}")

    def save_agent_data(self, agents: List[AgentProfile], output_path: str):
        """Save agent data to JSON file for further processing"""
        agent_data = []
        user_belief_texts = getattr(self, "_user_belief_texts", None) or {}
        for agent in agents:
            # The user's own wording of each belief, shown to the LLM in prompts
            own_texts = user_belief_texts.get(agent.username, {})
            belief_texts = {b: own_texts[b] for b in agent.beliefs if b in own_texts}
            agent_dict = {
                "username": agent.username,
                "subreddit": agent.subreddit,
                "behavioral_params": {
                    "read_density": agent.read_density,
                    "post_probability": agent.post_probability,
                    "pr_comment": agent.pr_comment,
                    "pr_upvote": agent.pr_upvote,
                    "pr_downvote": agent.pr_downvote,
                },
                "activity_patterns": {
                    "activity_level": agent.activity_level,
                    "frequency_of_use": agent.frequency_of_use,
                    "session_duration": agent.session_duration,
                    "active_time_slots": agent.active_time_slots,
                },
                "content_metrics": {
                    "total_posts": agent.total_posts,
                    "total_comments": agent.total_comments,
                    "avg_score": agent.avg_score,
                    "controversiality": agent.controversiality,
                },
                "beliefs": agent.beliefs,
                "belief_texts": belief_texts,
                **(
                    {"axis_positions": self._axis_positions[agent.username]}
                    if agent.username in self._axis_positions
                    else {}
                ),
                "trust_network": agent.trust_network,
                "user_type": agent.user_type,
            }
            agent_data.append(agent_dict)

        with open(output_path, "w") as f:
            json.dump(agent_data, f, indent=2)
        log.info(f"Agent data saved to {output_path}")

    def run(self, output_dir: str = "simulation_output"):
        """Main execution method"""
        log.info("Starting Reddit Agent Initialization...")

        os.makedirs(output_dir, exist_ok=True)

        conn = self.load_database()

        try:
            agents = self.process_agents(conn, output_dir=output_dir)

            self.belief_config = resolve_belief_config(
                self.target_subreddit, self.belief_axes_file, self.belief_model
            )
            if self.belief_model == "axes":
                self.place_agents_on_axes(agents)

            # Generate XML configuration (for backward compatibility with Construct API)
            xml_path = os.path.join(output_dir, "reddit_simulation_config.xml")
            self.generate_construct_xml(agents, xml_path)

            json_config_path = os.path.join(output_dir, "simulation_config.json")
            self.generate_json_config(agents, json_config_path)

            json_path = os.path.join(output_dir, "agent_profiles.json")
            self.save_agent_data(agents, json_path)

            if self.num_attacker > 0:
                self.save_attacker_natural_schedules(agents, output_dir)

            # Real recent subreddit discussion for the orchestrator's day-0 plan.
            # Written for every setup (not only LLM-attacker ones) so one init's
            # output can be copied into any mode folder without a separate step.
            try:
                seed_path = save_seed_context(
                    build_seed_context(conn, self.target_subreddit), output_dir
                )
                log.info(f"Saved orchestrator seed context to {seed_path}")
            except Exception as e:
                log.warning(
                    f"Could not build orchestrator seed context ({e}); day-0 campaign "
                    "plans will have no subreddit context. Build it later with "
                    "python -m python_simulation.services.subreddit_seed_context"
                )

            self.generate_summary_report(agents, output_dir)

            log.info(f"Initialization complete! Output saved to {output_dir}")

        finally:
            conn.close()

    def generate_summary_report(self, agents: List[AgentProfile], output_dir: str):
        """Generate summary report of agent initialization"""
        report_path = os.path.join(output_dir, "initialization_report.txt")

        with open(report_path, "w") as f:
            f.write("Reddit Agent Initialization Report\n")
            f.write("=" * 50 + "\n\n")

            f.write(f"Target Subreddit: r/{self.target_subreddit}\n")
            f.write(f"Total Agents Created: {len(agents)}\n")
            f.write(f"Sample Size: {self.sample_size}\n")
            f.write(
                f"Stratify agent mix (proportional activity/frequency/session): "
                f"{self.stratify_agent_mix}\n\n"
            )

            activity_counts = Counter(agent.activity_level for agent in agents)
            f.write("Activity Level Distribution:\n")
            for level, count in activity_counts.items():
                pct = (count / len(agents) * 100) if agents else 0.0
                f.write(f"  {level}: {count} ({pct:.1f}%)\n")
            f.write("\n")

            user_type_counts = Counter(agent.user_type for agent in agents)
            f.write("User Type Distribution:\n")
            for user_type, count in user_type_counts.items():
                pct = (count / len(agents) * 100) if agents else 0.0
                f.write(f"  {user_type}: {count} ({pct:.1f}%)\n")
            f.write("\n")

            f.write("Behavioral Parameters Summary:\n")
            f.write(
                f"  Average Read Density: {np.mean([a.read_density for a in agents]):.2f}\n"
            )
            f.write(
                f"  Average Post Probability: {np.mean([a.post_probability for a in agents]):.3f}\n"
            )
            f.write(
                f"  Average Comment Probability: {np.mean([a.pr_comment for a in agents]):.3f}\n"
            )
            f.write(
                f"  Average Upvote Probability: {np.mean([a.pr_upvote for a in agents]):.3f}\n"
            )
            f.write(
                f"  Average Downvote Probability: {np.mean([a.pr_downvote for a in agents]):.3f}\n\n"
            )

            if self.belief_config is not None:
                f.write(f"Belief model: {self.belief_model} ({self.belief_config.source})\n")
                for axis in self.belief_config.axes:
                    values = [p[axis.id] for p in self._axis_positions.values() if axis.id in p]
                    mean = f"{np.mean(values):.2f}" if values else "n/a"
                    target = self.belief_config.campaign_targets.get(axis.id)
                    f.write(
                        f"  {axis.id}: mean position {mean}"
                        + (f", campaign target {target:.2f}" if target is not None else "")
                        + "\n"
                    )
                if self._axis_placement_stats:
                    f.write(f"  Starting values: {self._axis_placement_stats}\n")
                f.write("\n")

            all_beliefs = set()
            for agent in agents:
                all_beliefs.update(agent.beliefs.keys())
            f.write(f"Total Unique Beliefs: {len(all_beliefs)}\n")
            f.write(
                f"Average Beliefs per Agent: {np.mean([len(a.beliefs) for a in agents]):.1f}\n"
            )
            f.write(
                f"Average Trust Relationships: {np.mean([len(a.trust_network) for a in agents]):.1f}\n"
            )

            f.write("\nBelief Extraction:\n")
            stats = self._belief_extraction_stats
            if self.cached_beliefs_file:
                f.write(f"  Source: cached beliefs file {self.cached_beliefs_file}\n")
            elif not stats:
                f.write("  Not run (no real users selected)\n")
            else:
                f.write(f"  Mode: {stats['mode']}\n")
                f.write(f"  Users: {stats['total_users']}\n")
                f.write(f"  With beliefs: {stats['extracted']}\n")
                f.write(f"  Empty (LLM ok, no beliefs): {stats['empty']}\n")
                f.write(f"  No usable text: {stats['no_text']}\n")
                f.write(
                    f"  Failed: {stats['failed']} "
                    f"({100.0 * extraction_failure_fraction(stats):.0f}% of attempted)\n"
                )
                for reason, n in sorted(
                    stats["failure_reasons"].items(), key=lambda kv: -kv[1]
                ):
                    f.write(f"    x{n}: {reason}\n")
                f.write(f"  Failures allowed: {self.allow_belief_failures}\n")

        log.info(f"Summary report written to {report_path}")


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Initialize Reddit agents for Construct API simulation"
    )
    parser.add_argument("--db-path", required=True, help="Path to SQLite database")
    parser.add_argument("--subreddit", required=True, help="Target subreddit name")
    parser.add_argument(
        "--num-regular-users",
        type=int,
        dest="sample_size",  # backward-compatibility alias
        default=1000,
        help="Number of regular users to create",
    )
    parser.add_argument(
        "--output-dir", default="simulation_output", help="Output directory"
    )
    # User type counts (regular inferred from --sample-size)
    parser.add_argument(
        "--num-moderator", type=int, default=0, help="Number of moderators to include"
    )
    parser.add_argument(
        "--num-attacker", type=int, default=0, help="Number of attackers to include"
    )
    parser.add_argument(
        "--num-template-attackers",
        type=int,
        default=0,
        help="Number of template-based attackers to include",
    )
    parser.add_argument(
        "--num-llm-users",
        type=int,
        default=0,
        help="Number of LLM-based users to include",
    )
    # Moderator and subreddit controls
    parser.add_argument(
        "--moderation-delay",
        type=int,
        default=12,
        help="Moderator delay (time steps) before content can be removed (>=0)",
    )
    parser.add_argument(
        "--ban-threshold",
        type=int,
        default=3,
        help="Subreddit ban threshold (>=1) for number of removals before user is banned",
    )
    # Time configuration
    parser.add_argument(
        "--duration-days",
        type=int,
        default=14,
        help="Total simulation duration in days (default: 14)",
    )
    parser.add_argument(
        "--interval-minutes",
        type=int,
        default=5,
        help="Time step interval in minutes (default: 5)",
    )
    parser.add_argument(
        "--llm-service-url",
        default="http://localhost:5000",
        help="LLM service URL for LLM users",
    )
    parser.add_argument(
        "--verbal-acceptance-labels",
        action="store_true",
        help="Show Likert-style labels (rejects / neutral / accepts ...) next to acceptance values",
    )
    parser.add_argument(
        "--llm-voting-enabled",
        action="store_true",
        default=False,
        help="Enable LLM-based voting for LLM users and attackers (default: False)",
    )
    parser.add_argument(
        "--llm-provider",
        default="auto",
        help="LLM provider for Python simulation runtime metadata (e.g. auto/openai/mistral/local)",
    )
    parser.add_argument(
        "--llm-model",
        default="mistral-small-latest",
        help="LLM model for Python simulation runtime metadata",
    )
    parser.add_argument(
        "--attacker-target-narrative",
        default="",
        help=(
            "Target narrative for attacker campaign (used to generate attacker beliefs). "
            "If empty and --num-template-attackers > 0, narrative is read from "
            "campaign_templates_dir/default_campaign.json (narrative, then description, then campaign_name)."
        ),
    )
    # Campaign settings for the in-process orchestrator (written to campaign_config)
    parser.add_argument(
        "--campaign-objective",
        default="amplify_narrative",
        choices=["amplify_narrative", "disrupt_discourse"],
        help="Attacker campaign objective (default: amplify_narrative)",
    )
    parser.add_argument(
        "--coordination-strength",
        type=float,
        default=0.8,
        help="Attacker campaign coordination strength (0-1, default: 0.8)",
    )
    parser.add_argument(
        "--attack-intensity",
        type=float,
        default=0.7,
        help="Attacker campaign intensity (0-1, default: 0.7)",
    )
    parser.add_argument(
        "--daily-post-target",
        type=int,
        default=5,
        help="Attacker campaign posts-per-day target (default: 5)",
    )
    parser.add_argument(
        "--coordination-comment-prob",
        type=float,
        default=0.5,
        help="Chance an attacker amplification of a fellow attacker post includes a comment (default: 0.5)",
    )
    parser.add_argument(
        "--coordination-delay-min",
        type=int,
        default=1,
        help="Min timesteps between an attacker post and its amplification (default: 1)",
    )
    parser.add_argument(
        "--coordination-delay-max",
        type=int,
        default=6,
        help="Max timesteps between an attacker post and its amplification (default: 6)",
    )
    parser.add_argument(
        "--exclude-authors",
        default="",
        help="Comma-separated extra authors never sampled as real users "
        "(added to the built-in bot list; AutoModerator and *-ModTeam are always excluded)",
    )
    parser.add_argument(
        "--allow-belief-failures",
        action="store_true",
        default=False,
        help="Continue when no LLM provider is available for belief extraction or "
        "more than 50%% of users' extractions fail (default: abort)",
    )

    # Mitigation system configuration
    parser.add_argument(
        "--enable-duplicate-detection",
        action="store_true",
        default=False,
        help="Enable duplicate content detection mitigation",
    )
    parser.add_argument(
        "--use-embedding-similarity-for-duplicates",
        action="store_true",
        default=False,
        help="Use embedding (all-MiniLM-L6-v2) cosine similarity for duplicate detection; else Jaccard",
    )
    parser.add_argument(
        "--enable-rate-limiting",
        action="store_true",
        default=False,
        help="Enable rate limiting mitigation",
    )
    parser.add_argument(
        "--enable-coordinated-detection",
        action="store_true",
        default=False,
        help="Enable coordinated behavior detection mitigation",
    )
    parser.add_argument(
        "--mitigation-scan-frequency",
        type=int,
        default=50,
        help="How often mitigation agents scan (every N timesteps)",
    )
    parser.add_argument(
        "--duplicate-similarity-threshold",
        type=float,
        default=0.85,
        help="Text similarity threshold for duplicate detection (0.0-1.0)",
    )
    parser.add_argument(
        "--rate-limit-window",
        type=int,
        default=12,
        help="Time window for rate limiting (timesteps)",
    )
    parser.add_argument(
        "--rate-limit-threshold",
        type=int,
        default=100,
        help="Maximum posts/comments per rate limit window",
    )
    parser.add_argument(
        "--coordination-similarity-threshold",
        "--coordination-suspicion-threshold",  # deprecated alias
        dest="coordination_similarity_threshold",
        type=float,
        default=0.3,
        help="Coordination co-engagement TF-IDF cosine threshold (0-1, default: 0.3). "
        "--coordination-suspicion-threshold is a deprecated alias.",
    )
    for flag, typ, default, text in COORDINATION_DETECTOR_FLAGS:
        parser.add_argument(flag, type=typ, default=default, help=text)
    parser.add_argument(
        "--use-embedding-similarity-for-coordination",
        action="store_true",
        default=False,
        help="Coordination co-content uses embedding cosine similarity; else Jaccard",
    )
    parser.add_argument(
        "--mitigation-ban-threshold",
        type=int,
        default=3,
        help="Number of flags before ban (default: 3 strikes)",
    )
    parser.add_argument(
        "--enable-rule-moderators",
        action="store_true",
        default=False,
        help="Add rule_moderator agents (feed review + MitigationSystem flags)",
    )
    parser.add_argument(
        "--num-rule-moderator",
        type=int,
        default=0,
        help="Number of rule_moderator agents",
    )
    parser.add_argument(
        "--rule-moderator-active-fraction",
        type=float,
        default=0.25,
        help="Fraction of each day each rule moderator is active (one contiguous block)",
    )
    parser.add_argument(
        "--rule-moderator-read-density",
        type=int,
        default=25,
        help="Feed items per timestep when a rule moderator is active",
    )
    parser.add_argument(
        "--rule-moderator-schedule-seed",
        type=int,
        default=42,
        help="RNG seed for staggered moderator activity schedules",
    )
    parser.add_argument(
        "--rule-moderator-detection-threshold",
        type=float,
        default=0.7,
        help="Minimum LLM confidence (0-1) to flag a rules violation",
    )
    parser.add_argument(
        "--rule-moderator-moderation-delay-timesteps",
        type=int,
        default=None,
        help="Deprecated, ignored: rule moderators no longer delay moderation. "
        "Still accepted so existing setup scripts keep working.",
    )

    # Biased moderator configuration
    parser.add_argument(
        "--enable-biased-moderator",
        action="store_true",
        default=False,
        help="Enable biased LLM moderator",
    )
    parser.add_argument(
        "--biased-mod-risk-tolerance",
        type=float,
        default=0.5,
        help="Risk tolerance for biased moderator (0.0-1.0, higher = more aggressive)",
    )
    parser.add_argument(
        "--biased-mod-scan-frequency",
        type=int,
        default=12,
        help="How often biased moderator scans (timesteps)",
    )
    parser.add_argument(
        "--biased-mod-detection-threshold",
        type=float,
        default=0.7,
        help="Minimum contradiction score to consider action (0.0-1.0)",
    )
    parser.add_argument(
        "--subreddit-rules",
        default="Be civil. No personal attacks. Stay on topic.",
        help="Subreddit rules text for moderator context",
    )
    parser.add_argument(
        "--biased-mod-beliefs-file",
        default="biased_moderator_beliefs.json",
        help="JSON file containing moderator synthetic beliefs",
    )

    # File paths
    parser.add_argument(
        "--campaign-templates-dir",
        default="campaign_templates",
        help="Directory containing campaign template JSON files for template attackers",
    )
    parser.add_argument(
        "--custom-library-path",
        default=None,
        help="Path to libconstructAPI.so (if not in same directory as construct executable)",
    )

    # Belief caching
    parser.add_argument(
        "--cached-beliefs-file",
        default=None,
        help="Path to cached belief pipeline output JSON (skips belief extraction to save time)",
    )
    parser.add_argument(
        "--feed-strategy",
        type=str,
        default="default",
        choices=[
            "default",
            "chronological",
            "score-based",
            "engagement-weighted",
            "reddit-hot",
            "reddit-all-hot",
        ],
        help="Feed ordering strategy for Python simulation (default: default)",
    )
    parser.add_argument(
        "--enable-timestep-parallelism",
        action="store_true",
        default=False,
        help="Enable per-timestep agent parallelism metadata for Python simulation runtime",
    )
    parser.add_argument(
        "--llm-max-concurrency",
        type=int,
        default=8,
        help="Max concurrent LLM calls metadata for Python simulation runtime",
    )
    parser.add_argument(
        "--llm-rate-limit-qps",
        type=float,
        default=0.0,
        help="Client-side LLM rate limit (QPS) metadata for Python simulation runtime",
    )
    parser.add_argument(
        "--time-model",
        choices=("discrete", "event"),
        default="event",
        help="Simulation engine: continuous-time event-driven (default) or the previous fixed-timestep engine (discrete)",
    )
    parser.add_argument(
        "--belief-model",
        choices=BELIEF_MODELS,
        default="axes",
        help="Belief model: acceptance of fixed belief statements (default) or free-text beliefs",
    )
    parser.add_argument(
        "--belief-axes-file",
        default=None,
        help="JSON file of belief statements and campaign targets (default: built-in set for the subreddit)",
    )
    parser.add_argument(
        "--activity-timezone",
        default=DEFAULT_ACTIVITY_TZ,
        help="IANA timezone that simulation hour 0 refers to when weighting session start "
        f"hours by the subreddit's hour-of-day activity (default: {DEFAULT_ACTIVITY_TZ})",
    )
    parser.add_argument(
        "--run-seed",
        type=int,
        default=None,
        help="Seed for the simulation run's random streams (default: random, logged)",
    )

    # Belief capping (bloat mitigation)
    parser.add_argument(
        "--enable-belief-capping",
        action="store_true",
        default=False,
        help="Enable belief capping: cap agent belief set size and consolidate at end of day (default: False)",
    )
    parser.add_argument(
        "--belief-cap",
        type=int,
        default=60,
        help="Maximum number of beliefs per agent when belief capping is enabled (default: 60)",
    )
    parser.add_argument(
        "--protect-attacker-beliefs",
        action="store_true",
        default=False,
        help="When belief capping is on: never drop or merge attacker-related beliefs with non-attacker (default: False)",
    )
    parser.add_argument(
        "--attacker-similarity-threshold",
        type=float,
        default=0.6,
        help="Similarity threshold (0-1) to classify beliefs as attacker-related by semantics (default: 0.6)",
    )
    parser.add_argument(
        "--weak-belief-threshold",
        type=float,
        default=0.2,
        help="During consolidation, drop non-protected beliefs with strength below this (0-1) (default: 0.2)",
    )
    parser.add_argument(
        "--stratify-agent-mix",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Regular + LLM users: assign activity level, frequency, and session duration in "
        "exact proportion to initializer distributions (largest remainder), not i.i.d. sampling. "
        "On by default: the non-stratified path derives frequency from each user's own "
        "activity span, which overstates how often occasional posters are active. "
        "Use --no-stratify-agent-mix to turn it off.",
    )

    args = parser.parse_args()
    if args.rule_moderator_moderation_delay_timesteps is not None:
        log.warning(
            "--rule-moderator-moderation-delay-timesteps is deprecated and ignored "
            "(rule moderators no longer delay moderation)"
        )

    initializer = RedditAgentInitializer(
        db_path=args.db_path,
        target_subreddit=args.subreddit,
        sample_size=args.sample_size,
        num_moderator=args.num_moderator,
        num_attacker=args.num_attacker,
        num_template_attacker=args.num_template_attackers,
        num_llm_users=args.num_llm_users,
        moderation_delay=args.moderation_delay,
        ban_threshold=args.ban_threshold,
        duration_days=args.duration_days,
        interval_minutes=args.interval_minutes,
        llm_service_url=args.llm_service_url,
        llm_voting_enabled=args.llm_voting_enabled,
        verbal_acceptance_labels=args.verbal_acceptance_labels,
        llm_provider=args.llm_provider,
        llm_model=args.llm_model,
        attacker_target_narrative=args.attacker_target_narrative,
        campaign_objective=args.campaign_objective,
        coordination_strength=args.coordination_strength,
        attack_intensity=args.attack_intensity,
        daily_post_target=args.daily_post_target,
        enable_duplicate_detection=args.enable_duplicate_detection,
        enable_rate_limiting=args.enable_rate_limiting,
        enable_coordinated_detection=args.enable_coordinated_detection,
        mitigation_scan_frequency=args.mitigation_scan_frequency,
        duplicate_similarity_threshold=args.duplicate_similarity_threshold,
        rate_limit_window=args.rate_limit_window,
        rate_limit_threshold=args.rate_limit_threshold,
        coordination_similarity_threshold=args.coordination_similarity_threshold,
        coordination_detection_params={
            **{
                flag[2:].replace("-", "_"): getattr(args, flag[2:].replace("-", "_"))
                for flag, _t, _d, _h in COORDINATION_DETECTOR_FLAGS
            },
            "use_embedding_similarity_for_coordination": args.use_embedding_similarity_for_coordination,
        },
        coordination_comment_prob=args.coordination_comment_prob,
        coordination_delay_min=args.coordination_delay_min,
        coordination_delay_max=args.coordination_delay_max,
        mitigation_ban_threshold=args.mitigation_ban_threshold,
        use_embedding_similarity_for_duplicates=args.use_embedding_similarity_for_duplicates,
        enable_rule_moderators=args.enable_rule_moderators,
        num_rule_moderator=args.num_rule_moderator,
        rule_moderator_active_fraction=args.rule_moderator_active_fraction,
        rule_moderator_read_density=args.rule_moderator_read_density,
        rule_moderator_schedule_seed=args.rule_moderator_schedule_seed,
        rule_moderator_detection_threshold=args.rule_moderator_detection_threshold,
        enable_biased_moderator=args.enable_biased_moderator,
        biased_mod_risk_tolerance=args.biased_mod_risk_tolerance,
        biased_mod_scan_frequency=args.biased_mod_scan_frequency,
        biased_mod_detection_threshold=args.biased_mod_detection_threshold,
        subreddit_rules=args.subreddit_rules,
        biased_mod_beliefs_file=args.biased_mod_beliefs_file,
        campaign_templates_dir=args.campaign_templates_dir,
        custom_library_path=args.custom_library_path,
        cached_beliefs_file=args.cached_beliefs_file,
        feed_strategy=args.feed_strategy,
        enable_belief_capping=args.enable_belief_capping,
        belief_cap=args.belief_cap,
        protect_attacker_beliefs=args.protect_attacker_beliefs,
        attacker_similarity_threshold=args.attacker_similarity_threshold,
        weak_belief_threshold=args.weak_belief_threshold,
        enable_timestep_parallelism=args.enable_timestep_parallelism,
        llm_max_concurrency=args.llm_max_concurrency,
        llm_rate_limit_qps=args.llm_rate_limit_qps,
        time_model=args.time_model,
        run_seed=args.run_seed,
        activity_timezone=args.activity_timezone,
        belief_model=args.belief_model,
        belief_axes_file=args.belief_axes_file,
        stratify_agent_mix=args.stratify_agent_mix,
        exclude_authors=args.exclude_authors.split(","),
        allow_belief_failures=args.allow_belief_failures,
    )

    try:
        initializer.run(args.output_dir)
    except BeliefExtractionError as e:
        log.error(f"Initialization aborted: {e}")
        sys.exit(2)


if __name__ == "__main__":
    main()
