#!/usr/bin/env python3
"""
Budget grid tuning of the mitigation parameters (evenly spread values, one
shared value per parameter for both scenarios), producing tuning_results.json
in the format tools/auto_runner.py reads.

Design (fixed by the budget of ~80 simulations):
  - Stage 1, one mechanism at a time, 10 evenly spaced values of its one tuned
    parameter; the values alternate between the two universes (interleaved),
    so one curve of 10 points covers both scenarios:
      stage_1_duplicate_only        duplicate_similarity_threshold 0.60 .. 0.90
      stage_1_rate_limit_only       rate_limit_threshold 2 .. 20 actions / 24 h
      stage_1_rule_moderation_only  rule_moderator_detection_threshold 0.90 .. 0.99
  - Stage 2, duplicate + rate limit + rule moderators together (auto_runner's
    all_mitigations_except_coordination): 10 Latin-hypercube settings in a
    neighbourhood of the stage-1 winners, again alternating universes.
  - Every setting runs on both attacker setups of its universe (llm_attackers,
    template_attackers) with the same seed; score = mean account-level MCC
    (tools/account_mcc.py): stage 1 "flagged by the mechanism", stage 2 "banned".
  - Untuned baseline: the combined mechanisms at their current defaults, both
    universes x both attacker types.
  Fixed for all runs: hourly scans (12 steps), 24 h duplicate lookback and rate
  window (288 steps), Jaccard similarity, three-strike bans, coordination off.

Each simulation is a subprocess (python -m python_simulation.run_simulation,
run from backend/); LLM_RATE_LIMIT_QPS caps each run so --concurrency runs stay
under the provider limit. Finished runs (final_output.json present) are reused,
so an interrupted tuning resumes.

Usage (from backend/):
  python -m python_simulation.tools.grid_tuning --dry-run
  python -m python_simulation.tools.grid_tuning --stub --concurrency 8      # offline check
  python -m python_simulation.tools.grid_tuning --concurrency 24 --qps 1.3  # real tuning
"""

import argparse
import csv
import json
import logging
import os
import random
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from ..core.config_paths import resolve_config_paths
from ..core.rule_moderator_schedule import (
    RULE_MODERATOR_MITIGATION_DEFAULTS,
    inject_rule_moderator_agents,
)
from .account_mcc import account_confusion

log = logging.getLogger(__name__)

BACKEND = Path(__file__).resolve().parents[2]
REPO = BACKEND.parent
UNIVERSES_DIR = REPO / "Simulation_Setups" / "simulations" / "universes"
DEFAULT_UNIVERSES = ("politics_base_sim_small", "destiny2_base_sim_small")
MODES = ("llm_attackers", "template_attackers")
SETUP_FILES = ("subreddit_seed_context.json", "belief_clustering_metadata.json")

FIXED = {
    "mitigation_scan_frequency": 12,          # hourly
    "duplicate_lookback_window": 288,         # 24 h
    "rate_limit_window": 288,                 # 24 h
    "use_embedding_similarity_for_duplicates": False,  # Jaccard
    "mitigation_ban_threshold": 3,
    "enable_coordinated_detection": False,
}
FLAGS = {  # scenario -> (duplicate, rate, rule moderators)
    "duplicate_only": (True, False, False),
    "rate_limit_only": (False, True, False),
    "rule_moderation_only": (False, False, True),
    "all_mitigations_except_coordination": (True, True, True),
}
SOURCES = {"duplicate_only": ("duplicate",), "rate_limit_only": ("rate_limit",),
           "rule_moderation_only": ("rule_moderator",)}
STAGE1 = {
    "stage_1_duplicate_only": ("duplicate_only", "duplicate_similarity_threshold", 0.60, 0.90, float),
    "stage_1_rate_limit_only": ("rate_limit_only", "rate_limit_threshold", 2, 20, int),
    "stage_1_rule_moderation_only": ("rule_moderation_only", "rule_moderator_detection_threshold", 0.90, 0.99, float),
}
STAGE2 = ("stage_2_all_mitigations_except_coordination", "all_mitigations_except_coordination")
# Stage-2 neighbourhood around each stage-1 winner (half-width) and range limits
NEIGHBOURHOOD = {"duplicate_similarity_threshold": (0.05, 0.60, 0.90),
                 "rate_limit_threshold": (4, 2, 20),
                 "rule_moderator_detection_threshold": (0.03, 0.90, 0.99)}


def grid(lo, hi, n, kind):
    vals = [lo + (hi - lo) * i / (n - 1) for i in range(n)]
    return [int(round(v)) for v in vals] if kind is int else [round(v, 4) for v in vals]


@dataclass
class Evaluation:
    stage: str
    scenario: str
    trial_id: int
    universe: str
    params: Dict[str, Any]
    seed: int
    runs: Dict[str, Path] = field(default_factory=dict)  # mode -> run dir

    @property
    def decision(self) -> str:
        return "banned" if self.stage.startswith("stage_2") or self.stage == "baseline" else "flagged"


def build_config(universe: str, mode: str, scenario: str, params: Dict[str, Any], stub: bool,
                 baseline: bool = False) -> Tuple[dict, list]:
    src = UNIVERSES_DIR / universe / mode
    cfg = resolve_config_paths(json.loads((src / "simulation_config.json").read_text(encoding="utf-8")), src)
    prof = json.loads((src / "agent_profiles.json").read_text(encoding="utf-8"))
    m = cfg.setdefault("mitigation_config", {})
    dup, rate, rule = FLAGS[scenario]
    m.update(FIXED)
    m["enable_duplicate_detection"], m["enable_rate_limiting"] = dup, rate
    m["enable_rule_moderators"] = rule
    if rule:
        for k, v in RULE_MODERATOR_MITIGATION_DEFAULTS.items():
            m.setdefault(k, v)
    if not baseline:
        m.update(params)
    if rule and not any(p.get("user_type") == "rule_moderator" for p in prof):
        cfg, prof = inject_rule_moderator_agents(cfg, prof)
    if stub:
        cfg.setdefault("llm_config", {})["provider"] = "stub"
    return cfg, prof


def write_run(run_dir: Path, universe: str, mode: str, cfg: dict, prof: list) -> None:
    conf = run_dir / "config"
    conf.mkdir(parents=True, exist_ok=True)
    (conf / "simulation_config.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    (conf / "agent_profiles.json").write_text(json.dumps(prof, indent=2), encoding="utf-8")
    for name in SETUP_FILES:
        f = UNIVERSES_DIR / universe / mode / name
        if f.exists():
            shutil.copy2(f, conf / name)


def plan_evaluation(root: Path, ev: Evaluation, stub: bool) -> None:
    trial = root / "runs" / ev.stage / ev.scenario / f"trial_{ev.trial_id:04d}"
    first_cfg = None
    for mode in MODES:
        cfg, prof = build_config(ev.universe, mode, ev.scenario, ev.params, stub, ev.stage == "baseline")
        cfg.setdefault("runtime_config", {})["seed"] = ev.seed
        run_dir = trial / ev.universe / mode
        write_run(run_dir, ev.universe, mode, cfg, prof)
        ev.runs[mode] = run_dir
        first_cfg = first_cfg or cfg
    # Canonical candidate config auto_runner reads (it uses mitigation_config only)
    (trial / "config").mkdir(parents=True, exist_ok=True)
    (trial / "config" / "simulation_config.json").write_text(json.dumps(first_cfg, indent=2), encoding="utf-8")


def run_one(run_dir: Path, seed: int, qps: float, timeout: int) -> Tuple[bool, str, float]:
    final = run_dir / "output" / "final_output.json"
    if final.exists():
        return True, "reused", 0.0
    env = dict(os.environ)
    env.pop("SIM_SEED", None)
    env["LLM_RATE_LIMIT_QPS"] = str(qps)
    env["SIM_TIME_MODEL"] = "event"
    cmd = [sys.executable, "-m", "python_simulation.run_simulation", "--config-dir", str(run_dir / "config"),
           "--output-dir", str(run_dir / "output"), "--seed", str(seed)]
    t0 = time.perf_counter()
    with open(run_dir / "run.log", "w", encoding="utf-8") as logf:
        try:
            proc = subprocess.run(cmd, cwd=str(BACKEND), env=env, stdout=logf, stderr=subprocess.STDOUT,
                                  timeout=timeout)
        except subprocess.TimeoutExpired:
            return False, f"timeout after {timeout}s", time.perf_counter() - t0
    ok = proc.returncode == 0 and final.exists()
    return ok, "" if ok else f"exit {proc.returncode}", time.perf_counter() - t0


def score(ev: Evaluation) -> Dict[str, Any]:
    sources = SOURCES.get(ev.scenario) if ev.decision == "flagged" else None
    per, row = {}, {"tp": 0, "fp": 0, "fn": 0, "tn": 0}
    for mode, run_dir in ev.runs.items():
        final = run_dir / "output" / "final_output.json"
        if not final.exists():
            return {"objective_value": None, "error": f"{mode}: no final_output.json"}
        c = account_confusion(json.loads(final.read_text(encoding="utf-8")), ev.decision, sources)
        per[mode] = round(c["mcc"], 4)
        for k in row:
            row[k] += c[k]
    return {"objective_value": round(sum(per.values()) / len(per), 4), "mcc_by_setup": per, **row,
            "decision": ev.decision, "error": None}


def run_wave(root: Path, evals: List[Evaluation], concurrency: int, qps: float, timeout: int,
             stub: bool) -> List[Dict[str, Any]]:
    for ev in evals:
        plan_evaluation(root, ev, stub)
    jobs = [(ev, mode) for ev in evals for mode in MODES]
    log.info("Wave: %d evaluation(s), %d simulation(s), concurrency %d", len(evals), len(jobs), concurrency)
    status: Dict[Tuple[int, str], Tuple[bool, str, float]] = {}
    done = [0]

    def job(item):
        ev, mode = item
        res = run_one(ev.runs[mode], ev.seed, qps, timeout)
        status[(id(ev), mode)] = res
        done[0] += 1
        log.info("[%d/%d] %s %s trial_%04d %s %s: %s (%.0fs)", done[0], len(jobs), ev.stage, ev.universe,
                 ev.trial_id, mode, ev.params, "ok" if res[0] else "FAIL " + res[1], res[2])
        return res

    with ThreadPoolExecutor(max_workers=max(1, concurrency)) as pool:
        list(pool.map(job, jobs))
    rows = []
    for ev in evals:
        r = {"stage": ev.stage, "scenario": ev.scenario, "trial_id": ev.trial_id, "universe": ev.universe,
             "params": ev.params, "seed": ev.seed, **score(ev),
             "run_seconds": round(sum(status[(id(ev), m)][2] for m in MODES), 1)}
        rows.append(r)
    return rows


def stage1_evaluations(points: int, base_seed: int, universes) -> List[Evaluation]:
    evals = []
    for s_idx, (stage, (scenario, param, lo, hi, kind)) in enumerate(STAGE1.items()):
        for i, value in enumerate(grid(lo, hi, points, kind), start=1):
            evals.append(Evaluation(stage, scenario, i, universes[(i - 1) % len(universes)],
                                    {param: value}, base_seed + 100 * (s_idx + 1) + i))
    return evals


def best(rows: List[Dict[str, Any]], stage: str) -> Optional[Dict[str, Any]]:
    ok = [r for r in rows if r["stage"] == stage and r["objective_value"] is not None]
    if not ok:
        return None
    top = max(r["objective_value"] for r in ok)
    tied = sorted([r for r in ok if r["objective_value"] == top], key=lambda r: r["fp"])
    tied = [r for r in tied if r["fp"] == tied[0]["fp"]]
    return tied[len(tied) // 2]  # middle of an exact tie plateau (sorted by trial = value order)


def stage2_evaluations(rows, points: int, base_seed: int, universes, rng: random.Random) -> List[Evaluation]:
    centre = {}
    for stage, (_sc, param, lo, hi, kind) in STAGE1.items():
        b = best(rows, stage)
        centre[param] = b["params"][param] if b else (lo + hi) / 2
    columns = {}
    for param, (half, lo, hi) in NEIGHBOURHOOD.items():
        a, z = max(lo, centre[param] - half), min(hi, centre[param] + half)
        kind = int if param == "rate_limit_threshold" else float
        col = grid(a, z, points, kind)
        rng.shuffle(col)  # Latin hypercube: each column's values once, randomly paired
        columns[param] = col
    return [Evaluation(STAGE2[0], STAGE2[1], i + 1, universes[i % len(universes)],
                       {p: columns[p][i] for p in columns}, base_seed + 500 + i + 1)
            for i in range(points)]


def write_results(root: Path, rows: List[Dict[str, Any]], baseline: List[Dict[str, Any]], args) -> None:
    res = root / "results"
    res.mkdir(parents=True, exist_ok=True)
    stages = {}
    for stage in list(STAGE1) + [STAGE2[0]]:
        ok = [r for r in rows if r["stage"] == stage and r["objective_value"] is not None]
        b = best(rows, stage)
        rest = sorted([r for r in ok if r is not b], key=lambda r: (-r["objective_value"], r["fp"]))
        stages[stage] = ([b] if b else []) + rest  # auto_runner uses stages[stage][0]
    payload = {
        "method": "grid", "points_per_stage": args.points, "universes": list(args.universes),
        "attacker_setups": list(MODES), "fixed_parameters": FIXED,
        "ranges": {s: {"parameter": p, "min": lo, "max": hi} for s, (_sc, p, lo, hi, _k) in STAGE1.items()},
        "stage_2_neighbourhood": NEIGHBOURHOOD, "objective": "mean account-level MCC over the two attacker "
        "setups; stage 1: flagged by the mechanism, stage 2 and baseline: banned",
        "baseline": baseline, "stages": stages,
        "recommended_parameters": {s: (e[0]["params"] if e else None) for s, e in stages.items()},
    }
    (res / "tuning_results.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    with open(res / "tuning_evaluations.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["stage", "trial_id", "universe", "params", "objective_value", "mcc_by_setup",
                                          "tp", "fp", "fn", "tn", "seed", "run_seconds", "error"])
        w.writeheader()
        for r in baseline + rows:
            w.writerow({k: (json.dumps(r.get(k)) if k in ("params", "mcc_by_setup") else r.get(k)) for k in w.fieldnames})
    lines = ["Grid tuning results", ""]
    for r in baseline:
        lines.append(f"baseline {r['universe']}: MCC {r['objective_value']} {r.get('mcc_by_setup')}")
    for stage, entries in stages.items():
        lines.append(f"\n[{stage}] best: {entries[0]['params'] if entries else None}")
        for r in sorted((e for e in entries), key=lambda e: e["trial_id"]):
            lines.append(f"  trial {r['trial_id']:>2} {r['universe'][:8]:<8} {json.dumps(r['params'])}: MCC {r['objective_value']} "
                         f"{r.get('mcc_by_setup')} tp {r['tp']} fp {r['fp']} fn {r['fn']}")
    (res / "tuning_results.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n\n")[0])
    ap.add_argument("--out", type=Path, default=REPO / "Simulation_Setups" / "simulations" / "mitigation_tuning_grid")
    ap.add_argument("--universes", nargs="+", default=list(DEFAULT_UNIVERSES))
    ap.add_argument("--points", type=int, default=10)
    ap.add_argument("--concurrency", type=int, default=24)
    ap.add_argument("--qps", type=float, default=1.3, help="LLM_RATE_LIMIT_QPS per simulation")
    ap.add_argument("--timeout", type=int, default=3600, help="seconds per simulation")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--stub", action="store_true", help="offline check with the stub LLM")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s [grid] %(message)s", datefmt="%H:%M:%S")

    for u in args.universes:
        for m in MODES:
            if not (UNIVERSES_DIR / u / m / "simulation_config.json").exists():
                print(f"Missing setup {UNIVERSES_DIR / u / m}", file=sys.stderr)
                return 1
    s1 = stage1_evaluations(args.points, args.seed, args.universes)
    base = [Evaluation("baseline", "all_mitigations_except_coordination", i + 1, u, {}, args.seed + i + 1)
            for i, u in enumerate(args.universes)]
    n_sims = 2 * (len(base) + len(s1) + args.points)
    if args.dry_run:
        print(f"{len(base)} baseline + {len(s1)} stage-1 + {args.points} stage-2 evaluations = {n_sims} simulations; "
              f"wave 1 {2 * (len(base) + len(s1))}, wave 2 {2 * args.points}")
        for e in base + s1:
            print(f"  {e.stage} trial {e.trial_id} {e.universe} {e.params}")
        return 0
    root = args.out
    root.mkdir(parents=True, exist_ok=True)
    wave1 = run_wave(root, base + s1, args.concurrency, args.qps, args.timeout, args.stub)
    baseline = [r for r in wave1 if r["stage"] == "baseline"]
    rows = [r for r in wave1 if r["stage"] != "baseline"]
    rows += run_wave(root, stage2_evaluations(rows, args.points, args.seed, args.universes,
                                              random.Random(args.seed)),
                     args.concurrency, args.qps, args.timeout, args.stub)
    write_results(root, rows, baseline, args)
    return 0


if __name__ == "__main__":
    sys.exit(main())
