"""
Re-run analyze_simulation on existing run folders (no simulation).

Use when batch outputs already exist under e.g. Simulation_Setups/auto_runs/.../run_0001/
with simulation_output/ + config/agent_profiles.json but analysis/ was built with
missing profile paths (e.g. campaign_effectiveness.csv showing zero attacker posts).

This module uses only the stdlib plus subprocess so you can dry-run without importing
backend.python_simulation (which pulls numpy, etc.). Full regeneration still requires
the same environment as analyze_simulation (pandas, matplotlib, ...).

From repository root (recommended — matches auto_runner cwd):

    python backend/python_simulation/tools/regenerate_analysis_batch.py ^
        --root Simulation_Setups/auto_runs/completed_set_1

Or equivalently:

    python -m backend.python_simulation.tools.regenerate_analysis_batch ^
        --root Simulation_Setups/auto_runs/completed_set_1
"""

from __future__ import annotations

import argparse
import logging
import subprocess
import sys
from pathlib import Path
from typing import Iterable, List, Tuple

log = logging.getLogger(__name__)


def _repo_root() -> Path:
    # .../backend/python_simulation/tools/this_file.py -> repo root
    return Path(__file__).resolve().parents[3]


def _discover_runs(batch_root: Path) -> List[Tuple[Path, Path]]:
    """Return (simulation_output_dir, analysis_output_dir) pairs."""
    pairs: List[Tuple[Path, Path]] = []
    for run_dir in sorted(batch_root.rglob("run_*")):
        if not run_dir.is_dir():
            continue
        sim_out = run_dir / "simulation_output"
        snaps = sim_out / "daily_snapshots"
        if not sim_out.is_dir() or not snaps.is_dir():
            continue
        analysis_out = run_dir / "analysis"
        pairs.append((sim_out.resolve(), analysis_out.resolve()))
    return pairs


def _run_one_analyze(
    repo_root: Path, sim_out: Path, analysis_out: Path, timeout_sec: int | None
) -> bool:
    cmd = [
        sys.executable,
        "-m",
        "backend.python_simulation.tools.analyze_simulation",
        "--input-dir",
        str(sim_out),
        "--output-dir",
        str(analysis_out),
    ]
    analysis_out.mkdir(parents=True, exist_ok=True)
    try:
        proc = subprocess.run(
            cmd,
            cwd=str(repo_root),
            capture_output=True,
            text=True,
            timeout=timeout_sec,
            check=False,
        )
    except subprocess.TimeoutExpired:
        log.error("Timeout analyzing %s", sim_out)
        return False
    if proc.returncode != 0:
        err = (proc.stderr or proc.stdout or "").strip()
        log.error("analyze_simulation failed (%s): %s", sim_out, err[-1200:])
        return False
    return True


def main(argv: Iterable[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Regenerate analysis/ from existing simulation_output/ trees."
    )
    parser.add_argument(
        "--root",
        type=Path,
        required=True,
        help="Batch root directory (searched recursively for run_*/simulation_output)",
    )
    parser.add_argument(
        "--repo-root",
        type=Path,
        default=None,
        help="Repository root (cwd for -m analyze_simulation). Default: infer from this file",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=None,
        help="Per-run timeout in seconds (default: no limit)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="List run folders that would be analyzed, then exit",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="DEBUG logging",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s %(message)s",
    )

    batch_root = args.root.resolve()
    if not batch_root.is_dir():
        log.error("Not a directory: %s", batch_root)
        return 1

    repo_root = (args.repo_root or _repo_root()).resolve()

    pairs = _discover_runs(batch_root)
    if not pairs:
        log.warning(
            "No run_*/simulation_output with daily_snapshots under %s", batch_root
        )
        return 1

    log.info("Found %d run(s) with simulation_output", len(pairs))
    if args.dry_run:
        for sim_out, _ in pairs:
            print(sim_out.parent)
        return 0

    ok = 0
    fail = 0
    for sim_out, analysis_out in pairs:
        log.info("Analyzing %s -> %s", sim_out, analysis_out)
        if _run_one_analyze(repo_root, sim_out, analysis_out, args.timeout):
            ok += 1
        else:
            fail += 1

    log.info("Done: %d ok, %d failed", ok, fail)
    return 0 if fail == 0 else 2


if __name__ == "__main__":
    sys.exit(main())
