#!/usr/bin/env python3
"""
Average post / comment text length (in words) per subreddit from the monthly
Pushshift SQLite extracts in Simulation_Setups/reddit_databases.

Only items that actually carry text are counted:
  * Posts: the selftext body (title is reported separately). Link / image /
    video posts with an empty selftext are skipped.
  * Comments: the body.
Skipped in both cases: empty or whitespace-only text, "[removed]" / "[deleted]"
placeholders, and text with no words left after cleaning (e.g. a bare URL).
By default moderator / bot content (AutoModerator, *-ModTeam accounts and
moderator-distinguished items, which are mostly removal notices and stickied
rule reminders) is also skipped; pass --include-mod-content to keep it.

Word counting: HTML entities are unescaped, markdown links "[text](url)" are
reduced to their text, bare URLs are removed, and the remaining whitespace
tokens are counted if they contain at least one letter or digit (so markdown
bullets, "---" rules, lone punctuation etc. are not words).

Usage:
    python -m python_simulation.tools.reddit_text_length_stats
    python -m python_simulation.tools.reddit_text_length_stats --db path/to/2025-06-politics.db
    python -m python_simulation.tools.reddit_text_length_stats --json stats.json
    python -m python_simulation.tools.reddit_text_length_stats --include-mod-content
"""

import argparse
import html
import json
import re
import sqlite3
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional

DEFAULT_DB_DIR = Path(__file__).resolve().parents[3] / "Simulation_Setups" / "reddit_databases"

PLACEHOLDER_TEXTS = {"[removed]", "[deleted]", "[removed by reddit]"}
BOT_AUTHORS = {"automoderator"}
MOD_DISTINGUISHED = {"moderator", "admin"}

_MD_LINK_RE = re.compile(r"\[([^\]]*)\]\([^)]*\)")
_URL_RE = re.compile(r"(?:https?://|www\.)\S+", re.IGNORECASE)
_WORDLIKE_RE = re.compile(r"[^\W_]", re.UNICODE)


def count_words(text: str) -> int:
    """Count words in a Reddit markdown string (see module docstring)."""
    text = html.unescape(text)
    text = _MD_LINK_RE.sub(r"\1", text)
    text = _URL_RE.sub(" ", text)
    return sum(1 for tok in text.split() if _WORDLIKE_RE.search(tok))


def is_mod_or_bot(author: Optional[str], distinguished: Optional[str]) -> bool:
    if distinguished and distinguished.lower() in MOD_DISTINGUISHED:
        return True
    if not author:
        return False
    a = author.lower()
    return a in BOT_AUTHORS or a.endswith("-modteam")


def _percentile(sorted_values: List[int], p: float) -> Optional[float]:
    if not sorted_values:
        return None
    k = (len(sorted_values) - 1) * p / 100.0
    f = int(k)
    if f >= len(sorted_values) - 1:
        return float(sorted_values[-1])
    return sorted_values[f] + (k - f) * (sorted_values[f + 1] - sorted_values[f])


def length_stats(values: List[int]) -> Dict[str, Optional[float]]:
    if not values:
        return {"count": 0, "mean": None, "median": None, "p10": None, "p90": None, "p99": None, "min": None, "max": None}
    s = sorted(values)
    return {
        "count": len(s),
        "mean": sum(s) / len(s),
        "median": _percentile(s, 50),
        "p10": _percentile(s, 10),
        "p90": _percentile(s, 90),
        "p99": _percentile(s, 99),
        "min": s[0],
        "max": s[-1],
    }


class _Bucket:
    """Accumulates lengths and skip reasons for one (subreddit, kind)."""

    def __init__(self) -> None:
        self.total = 0
        self.lengths: List[int] = []
        self.skipped: Dict[str, int] = defaultdict(int)
        self.min_utc: Optional[int] = None
        self.max_utc: Optional[int] = None

    def see_time(self, utc: Optional[int]) -> None:
        if utc is None:
            return
        self.min_utc = utc if self.min_utc is None else min(self.min_utc, utc)
        self.max_utc = utc if self.max_utc is None else max(self.max_utc, utc)

    def summary(self) -> dict:
        def iso(t: Optional[int]) -> Optional[str]:
            return datetime.fromtimestamp(t, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if t is not None else None

        return {
            "total_items": self.total,
            "with_text": len(self.lengths),
            "with_text_fraction": len(self.lengths) / self.total if self.total else None,
            "skipped": dict(self.skipped),
            "first_item": iso(self.min_utc),
            "last_item": iso(self.max_utc),
            "words": length_stats(self.lengths),
        }


def _classify(text: Optional[str], author: Optional[str], distinguished: Optional[str], include_mod: bool):
    """Return (word_count, skip_reason). Exactly one is non-None."""
    if not include_mod and is_mod_or_bot(author, distinguished):
        return None, "mod_or_bot"
    if text is None or not text.strip():
        return None, "empty"
    if text.strip().lower() in PLACEHOLDER_TEXTS:
        return None, "removed_or_deleted"
    n = count_words(text.strip())
    if n == 0:
        return None, "no_words_after_cleaning"
    return n, None


def analyze_db(db_path: Path, include_mod: bool) -> Dict[str, dict]:
    conn = sqlite3.connect(f"file:{db_path.as_posix()}?mode=ro", uri=True)
    try:
        posts: Dict[str, _Bucket] = defaultdict(_Bucket)
        titles: Dict[str, _Bucket] = defaultdict(_Bucket)
        comments: Dict[str, _Bucket] = defaultdict(_Bucket)

        for sub, title, selftext, author, distinguished, utc in conn.execute(
            "SELECT subreddit, title, selftext, author, distinguished, created_utc FROM submissions"
        ):
            sub = (sub or "<unknown>").lower()
            b = posts[sub]
            b.total += 1
            b.see_time(utc)
            n, reason = _classify(selftext, author, distinguished, include_mod)
            if n is None:
                b.skipped[reason] += 1
            else:
                b.lengths.append(n)

            t = titles[sub]
            t.total += 1
            t.see_time(utc)
            tn, treason = _classify(title, author, distinguished, include_mod)
            if tn is None:
                t.skipped[treason] += 1
            else:
                t.lengths.append(tn)

        for sub, body, author, distinguished, utc in conn.execute(
            "SELECT subreddit, body, author, distinguished, created_utc FROM comments"
        ):
            sub = (sub or "<unknown>").lower()
            b = comments[sub]
            b.total += 1
            b.see_time(utc)
            n, reason = _classify(body, author, distinguished, include_mod)
            if n is None:
                b.skipped[reason] += 1
            else:
                b.lengths.append(n)
    finally:
        conn.close()

    result: Dict[str, dict] = {}
    for sub in sorted(set(posts) | set(comments)):
        result[sub] = {
            "database": db_path.name,
            "post_body": posts[sub].summary(),
            "post_title": titles[sub].summary(),
            "comment": comments[sub].summary(),
        }
    return result


def _fmt(v: Optional[float], nd: int = 1) -> str:
    if v is None:
        return "-"
    return f"{v:.{nd}f}" if isinstance(v, float) else str(v)


def format_report(results: Dict[str, dict], include_mod: bool) -> str:
    lines = [
        "Reddit text length (words) per subreddit",
        f"Mod/bot content: {'included' if include_mod else 'excluded'}",
        "",
    ]
    for sub, r in results.items():
        span = f"{r['comment']['first_item'] or r['post_body']['first_item']} -> {r['comment']['last_item'] or r['post_body']['last_item']}"
        lines.append(f"r/{sub}  ({r['database']}, {span})")
        header = f"  {'kind':<11} {'items':>9} {'w/ text':>9} {'%text':>6} {'mean':>7} {'median':>7} {'p10':>6} {'p90':>7} {'p99':>7} {'max':>7}"
        lines.append(header)
        for label, key in (("post body", "post_body"), ("post title", "post_title"), ("comment", "comment")):
            s = r[key]
            w = s["words"]
            frac = s["with_text_fraction"]
            lines.append(
                f"  {label:<11} {s['total_items']:>9} {s['with_text']:>9} "
                f"{(_fmt(frac * 100) if frac is not None else '-'):>6} "
                f"{_fmt(w['mean']):>7} {_fmt(w['median']):>7} {_fmt(w['p10']):>6} "
                f"{_fmt(w['p90']):>7} {_fmt(w['p99']):>7} {_fmt(w['max']):>7}"
            )
        for label, key in (("post body", "post_body"), ("comment", "comment")):
            sk = r[key]["skipped"]
            if sk:
                parts = ", ".join(f"{k}={v}" for k, v in sorted(sk.items(), key=lambda kv: -kv[1]))
                lines.append(f"  skipped {label}: {parts}")
        lines.append("")
    return "\n".join(lines)


def _resolve_dbs(db_args: Optional[Iterable[str]], db_dir: Path) -> List[Path]:
    if db_args:
        paths = [Path(p) for p in db_args]
    else:
        paths = sorted(db_dir.glob("*.db"))
    missing = [p for p in paths if not p.is_file()]
    if missing:
        raise FileNotFoundError(f"Database(s) not found: {', '.join(str(m) for m in missing)}")
    if not paths:
        raise FileNotFoundError(f"No .db files found in {db_dir}")
    return paths


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Average post/comment text length (words) per subreddit from Pushshift SQLite extracts.")
    parser.add_argument("--db", nargs="+", help="Specific .db file(s). Default: every *.db in --db-dir.")
    parser.add_argument("--db-dir", type=Path, default=DEFAULT_DB_DIR, help=f"Directory of .db files (default: {DEFAULT_DB_DIR}).")
    parser.add_argument("--include-mod-content", action="store_true", help="Keep AutoModerator / *-ModTeam / moderator-distinguished items.")
    parser.add_argument("--json", type=Path, help="Also write the full stats to this JSON file.")
    parser.add_argument("--output", type=Path, help="Write the text report here instead of stdout.")
    args = parser.parse_args(argv)

    try:
        dbs = _resolve_dbs(args.db, args.db_dir)
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    results: Dict[str, dict] = {}
    for db in dbs:
        print(f"Reading {db.name} ...", file=sys.stderr)
        for sub, r in analyze_db(db, args.include_mod_content).items():
            key = sub if sub not in results else f"{sub} ({db.name})"
            results[key] = r

    report = format_report(results, args.include_mod_content)
    if args.output:
        args.output.write_text(report, encoding="utf-8")
        print(f"Wrote {args.output}", file=sys.stderr)
    else:
        print(report)
    if args.json:
        args.json.write_text(json.dumps(results, indent=2), encoding="utf-8")
        print(f"Wrote {args.json}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
