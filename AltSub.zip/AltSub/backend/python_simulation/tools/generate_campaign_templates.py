#!/usr/bin/env python3
"""
Campaign Template Generator

Uses an LLM to generate diverse templates for template-based attacks,
then allows human editing and validation before use in simulations.

This tool helps create realistic pre-LLM astroturfing campaign templates
for baseline comparison with LLM-driven campaigns.
"""

import json
import argparse
import os
import sys
from pathlib import Path
from typing import Dict, List, Any
from dotenv import load_dotenv

try:  # python -m python_simulation.tools.generate_campaign_templates (from backend/)
    from ..services.llm_provider import get_llm_provider
    from ..services.llm_json import complete_json
except ImportError:  # run as a script: import through the package so its relative imports work
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from python_simulation.services.llm_provider import get_llm_provider
    from python_simulation.services.llm_json import complete_json


def generate_templates_for_narrative(
    narrative: str,
    campaign_name: str,
    num_posts: int = 10,
    num_replies: int = 6,
    output_dir: str = None,
):
    """
    Generate templates using LLM, then save for manual review

    Args:
        narrative: The narrative the campaign is promoting/attacking
        campaign_name: Name/ID for the campaign
        num_posts: Number of post templates to generate
        num_replies: Number of reply templates to generate
        output_dir: Directory to save template file
    """

    llm = get_llm_provider(preferred_provider="mistral")

    # We distill argument techniques and strategy from https://arxiv.org/pdf/2401.06373's taxonomy of argumentation strategies.
    post_prompt = f"""
Generate {num_posts} diverse template variations for astroturfing posts 
promoting this narrative: "{narrative}"

Requirements:
1. Each template should have {{placeholder}} variables for variation
   - Example: "Why should we trust {{expert_group}} about {{topic}}?"
   - Variables should allow multiple substitutions for variety
2. Include different tones: skeptical, concerned, authoritative, casual, dismissive
3. Include different intensities (0.0-1.0):
   - Low (0.3-0.4): Subtle, hard to detect
   - Medium (0.5-0.7): Clear stance but measured
   - High (0.8-1.0): Direct, forceful, obvious advocacy
4. Mix argument types, covering a wide range of persuasion techniques and strategies:
   - Evidence/logical appeals (evidence-based persuasion, logical reasoning, use of statistics or data)
   - Authority/credibility (expert endorsements, non-expert testimonials, reference to authorities)
   - Social/normative influence (social proof, shared values, injunctive norms, alliance building)
   - Commitment and consistency (public commitment, foot-in-the-door, loyalty appeals)
   - Exchange/reciprocity (negotiation, favor, compensation)
   - Appraisal/affirmation (encouragement, positive or negative emotional appeals, affirmation)
   - Emotional storytelling (storytelling, framing, priming, invoking emotions)
   - Biases and heuristics (anchoring, confirmation bias, reflective thinking)
   - Scarcity/urgency (supply scarcity, time pressure)
   - Threats or negative consequences (threats, social punishment, discouragement)
   - Deceptive tactics (false information, misrepresentation, rumors, exploiting weaknesses)
   - Whataboutism/deflection
   - Anecdotal or personal stories
   - Discouragement or sabotage
5. Make them sound natural and conversational like real Reddit posts

Return ONLY valid JSON with this EXACT structure (no markdown, no backticks):
{{
  "posts": [
    {{
      "id": "descriptive_id_1",
      "template": "text with {{variable1}} and {{variable2}}",
      "variables": {{
        "variable1": ["option1", "option2", "option3"],
        "variable2": ["choice1", "choice2", "choice3"]
      }},
      "tone": "skeptical",
      "intensity": 0.7
    }}
  ]
}}
"""

    print(f"Generating {num_posts} post templates for '{narrative}'...")
    post_result = complete_json(
        llm,
        [{"role": "user", "content": post_prompt}],
        temperature=0.8,
        max_tokens=num_posts * 1000,
        expect=list,
        wrap_key="posts",
        label="Post templates",
    )
    post_templates = [t for t in (post_result.data or []) if isinstance(t, dict)]
    if not post_result.ok:
        print(f"ERROR generating post templates: {post_result.error}")
        print(f"Current provider: {llm.get_provider_info()}")

    # Reply templates: every context states that the reply is written by a campaign member.
    n_fellow = num_replies // 3
    n_opposing = num_replies // 3
    n_neutral = num_replies - n_fellow - n_opposing
    reply_prompt = f"""
Generate {num_replies} diverse reply template variations for an astroturfing campaign
promoting this narrative: "{narrative}"

EVERY reply is written by a campaign member and must SUPPORT the narrative above.
No reply may agree with, concede to, or argue for the opposing side.

The "context" field says what kind of comment the campaign member is replying to:
1. "fellow_attacker_post" ({n_fellow} replies): replying to a post that already pushes
   the narrative. Agree with and amplify it.
2. "opposing_viewpoint" ({n_opposing} replies): replying to someone who DISAGREES with
   the narrative. Push back on them and defend the narrative (rebut, cast doubt on
   their claim, or redirect to the narrative). Do not argue their side.
3. "neutral" ({n_neutral} replies): replying to an unrelated or undecided comment.
   Sound casual and blend in, while still nudging toward the narrative.

Requirements:
1. Use {{placeholder}} variables for variation
2. Exactly {n_fellow} fellow_attacker_post, {n_opposing} opposing_viewpoint and
   {n_neutral} neutral replies ({num_replies} in total)
3. Keep replies concise (1-3 sentences typical for Reddit)
4. Make them sound like natural Reddit comments, each one different (no repeats)

Return ONLY valid JSON (no markdown):
{{
  "replies": [
    {{
      "id": "reply_id_1",
      "template": "text with {{variable}}",
      "variables": {{
        "variable": ["option1", "option2", "option3"]
      }},
      "context": "fellow_attacker_post"
    }}
  ]
}}
"""

    print(f"Generating {num_replies} reply templates...")
    reply_result = complete_json(
        llm,
        [{"role": "user", "content": reply_prompt}],
        temperature=0.8,
        max_tokens=num_replies * 1000,
        expect=list,
        wrap_key="replies",
        label="Reply templates",
    )
    reply_templates = [t for t in (reply_result.data or []) if isinstance(t, dict)]
    if not reply_result.ok:
        print(f"ERROR generating reply templates: {reply_result.error}")

    keyword_prompt = f"""
For a campaign about "{narrative}", generate:
1. 10-15 upvote keywords: phrases that align with the narrative (campaign would upvote)
2. 10-15 downvote keywords: phrases that oppose the narrative (campaign would downvote)

Make them specific enough to be useful but general enough to catch variations.

Return ONLY valid JSON:
{{
  "upvote_keywords": ["keyword1", "keyword2", ...],
  "downvote_keywords": ["keyword1", "keyword2", ...]
}}
"""

    print("Generating voting keywords...")
    keyword_result = complete_json(
        llm,
        [{"role": "user", "content": keyword_prompt}],
        temperature=0.7,
        max_tokens=1600,
        label="Voting keywords",
    )
    keyword_data = keyword_result.data or {}
    upvote_keywords = [k for k in keyword_data.get("upvote_keywords", []) if isinstance(k, str)]
    downvote_keywords = [k for k in keyword_data.get("downvote_keywords", []) if isinstance(k, str)]
    if not keyword_result.ok:
        print(f"ERROR generating voting keywords: {keyword_result.error}")

    # Don't replace an existing (possibly hand-reviewed) template file with an empty one
    if not post_templates and not reply_templates:
        print("ERROR: no post or reply templates were generated; not writing a template file.")
        return None

    campaign_templates = {
        "campaign_name": campaign_name,
        "narrative": narrative,
        "description": f"LLM-generated templates for {narrative}",
        "templates": {
            "posts": post_templates,
            "replies": reply_templates,
            "voting_rules": {
                "upvote_keywords": upvote_keywords,
                "downvote_keywords": downvote_keywords,
            },
        },
    }

    if output_dir is None:
        # Default to Simulation_Setups/campaign_templates relative to project root
        script_dir = Path(__file__).parent
        project_root = script_dir.parent.parent.parent
        output_dir = project_root / "Simulation_Setups" / "campaign_templates"
    else:
        output_dir = Path(output_dir)

    output_dir.mkdir(parents=True, exist_ok=True)
    output_file = output_dir / f"{campaign_name}.json"

    with open(output_file, "w", encoding="utf-8") as f:
        json.dump(campaign_templates, f, indent=2, ensure_ascii=False)

    print(f"\n✓ Generated templates saved to: {output_file}")
    print(f"  - {len(post_templates)} post templates")
    print(f"  - {len(reply_templates)} reply templates")
    print(f"  - {len(upvote_keywords)} upvote keywords")
    print(f"  - {len(downvote_keywords)} downvote keywords")

    return campaign_templates


def validate_template_file(file_path: str) -> bool:
    """
    Validate that a template file has the correct structure

    Args:
        file_path: Path to template JSON file

    Returns:
        True if valid, False otherwise
    """
    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        required_fields = ["campaign_name", "narrative", "templates"]
        for field in required_fields:
            if field not in data:
                print(f"❌ Missing required field: {field}")
                return False

        templates = data["templates"]
        if "posts" not in templates:
            print("❌ Missing 'posts' in templates")
            return False
        if "replies" not in templates:
            print("❌ Missing 'replies' in templates")
            return False
        if "voting_rules" not in templates:
            print("❌ Missing 'voting_rules' in templates")
            return False

        for i, post in enumerate(templates["posts"]):
            if "template" not in post:
                print(f"❌ Post {i} missing 'template' field")
                return False
            if "variables" not in post:
                print(f"❌ Post {i} missing 'variables' field")
                return False

        for i, reply in enumerate(templates["replies"]):
            if "template" not in reply:
                print(f"❌ Reply {i} missing 'template' field")
                return False
            if "variables" not in reply:
                print(f"❌ Reply {i} missing 'variables' field")
                return False

        print(f"✓ Template file is valid")
        print(f"  - {len(templates['posts'])} post templates")
        print(f"  - {len(templates['replies'])} reply templates")

        return True

    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON: {e}")
        return False
    except Exception as e:
        print(f"❌ Error validating file: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Generate campaign templates for template-based attackers"
    )
    parser.add_argument(
        "--narrative",
        help="The narrative the campaign is promoting (e.g., 'climate change is exaggerated')",
    )
    parser.add_argument(
        "--campaign-name",
        help="Campaign identifier (e.g., 'climate_denial_baseline')",
    )
    parser.add_argument(
        "--num-posts",
        type=int,
        default=10,
        help="Number of post templates to generate (default: 10)",
    )
    parser.add_argument(
        "--num-replies",
        type=int,
        default=6,
        help="Number of reply templates to generate (default: 6)",
    )
    parser.add_argument(
        "--output-dir",
        default=None,
        help="Directory to save template file (default: Simulation_Setups/campaign_templates)",
    )
    parser.add_argument(
        "--validate",
        help="Validate an existing template file instead of generating new one",
    )

    args = parser.parse_args()

    if args.validate:
        print(f"Validating template file: {args.validate}")
        is_valid = validate_template_file(args.validate)
        exit(0 if is_valid else 1)
    else:
        print("=" * 60)
        print("Campaign Template Generator")
        print("=" * 60)
        print(f"Narrative: {args.narrative}")
        print(f"Campaign Name: {args.campaign_name}")
        print("=" * 60)

        output_dir = args.output_dir
        if output_dir is None:
            script_dir = Path(__file__).parent
            project_root = script_dir.parent.parent.parent
            output_dir = str(project_root / "Simulation_Setups" / "campaign_templates")

        templates = generate_templates_for_narrative(
            narrative=args.narrative,
            campaign_name=args.campaign_name,
            num_posts=args.num_posts,
            num_replies=args.num_replies,
            output_dir=output_dir,
        )
        if templates is None:
            sys.exit(1)

        print("\n" + "=" * 60)
        print("Next steps:")
        print("1. Review and edit the generated file")
        print("2. Validate with: python generate_campaign_templates.py \\")
        output_file_path = Path(output_dir) / f"{args.campaign_name}.json"
        print(f"   --validate {output_file_path}")
        print("3. Copy template to your simulation folder as 'default_campaign.json'")
        print("   or update campaign_id in simulation config to match campaign_name")
        print("=" * 60)


if __name__ == "__main__":
    env_paths = [
        Path.cwd() / ".env",
        Path(__file__).parent.parent.parent / ".env",
        Path(__file__).parent.parent.parent.parent / "Simulation_Setups" / ".env",
    ]
    for env_path in env_paths:
        if env_path.exists():
            load_dotenv(env_path, override=False)
            break

    main()
