#!/usr/bin/env python3
"""
Summarize profiling.log (NDJSON) into human-readable averages and stats.

Reads the simulation profiling log, groups by message type, and reports
count, mean, min, max, p50, p95 for numeric fields. Use after a run to
quickly see where time and scale metrics sit without reading raw NDJSON.

Usage:
    python -m python_simulation.tools.summarize_profiling_log --input path/to/profiling.log
    python -m python_simulation.tools.summarize_profiling_log --input profiling.log --output profiling_summary.txt

Output:
    Writes profiling_summary.txt (or stdout) with a short report. Optional --json writes
    profiling_summary.json with the same stats for scripting.
"""

import argparse
import json
import sys
from pathlib import Path
from collections import defaultdict


def _percentile(sorted_values, p):
    if not sorted_values:
        return None
    k = (len(sorted_values) - 1) * p / 100.0
    f = int(k)
    if f >= len(sorted_values) - 1:
        return sorted_values[-1]
    return sorted_values[f] + (k - f) * (sorted_values[f + 1] - sorted_values[f])


def _stats(values):
    if not values:
        return {"count": 0, "mean": None, "min": None, "max": None, "p50": None, "p95": None, "p99": None, "n_nonzero": 0, "mean_nonzero": None}
    s = sorted(values)
    n = len(s)
    nonzero = [x for x in values if x != 0]
    return {
        "count": n,
        "mean": sum(s) / n,
        "min": s[0],
        "max": s[-1],
        "p50": _percentile(s, 50),
        "p95": _percentile(s, 95),
        "p99": _percentile(s, 99),
        "n_nonzero": len(nonzero),
        "mean_nonzero": sum(nonzero) / len(nonzero) if nonzero else None,
    }


def summarize(entries):
    """Group by message, collect numeric data fields, compute stats."""
    by_message = defaultdict(lambda: defaultdict(list))
    for e in entries:
        msg = e.get("message") or "unknown"
        data = e.get("data") or {}
        for k, v in data.items():
            if isinstance(v, (int, float)):
                by_message[msg][k].append(v)
    result = {}
    for msg, fields in by_message.items():
        result[msg] = {k: _stats(v) for k, v in fields.items()}
        result[msg]["_count"] = max((len(v) for v in fields.values()), default=0)
    return result


def _fmt(v):
    if v is None:
        return "—"
    if isinstance(v, float):
        return f"{v:.1f}" if v != int(v) else str(int(v))
    return str(v)


def _is_duration_like(key):
    return "ms" in key.lower() or "duration" in key.lower()


def format_report(summary):
    lines = []
    lines.append("Profiling log summary")
    lines.append("=" * 60)
    lines.append("")
    lines.append("How to read: n = number of log entries. mean/min/max/p50/p95/p99 = stats over values.")
    lines.append("For duration fields, when most values are 0, 'when>0' shows count and mean of nonzero only.")
    lines.append("")
    for msg, data in sorted(summary.items()):
        count = data.pop("_count", 0)
        lines.append(f"\n[{msg}] (n = {count})")
        for key, st in sorted(data.items()):
            if st["count"] == 0:
                continue
            line = f"  {key}: mean={_fmt(st['mean'])} min={_fmt(st['min'])} max={_fmt(st['max'])} p50={_fmt(st['p50'])} p95={_fmt(st['p95'])} p99={_fmt(st.get('p99'))}"
            if _is_duration_like(key) and st.get("n_nonzero", 0) > 0 and st["n_nonzero"] < st["count"]:
                line += f"  | when>0: n={st['n_nonzero']} mean={_fmt(st.get('mean_nonzero'))}"
            lines.append(line)
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="Summarize simulation profiling log (NDJSON) into averages and stats."
    )
    parser.add_argument(
        "--input",
        "-i",
        type=Path,
        default=Path("profiling.log"),
        help="Path to profiling.log (default: profiling.log)",
    )
    parser.add_argument(
        "--output",
        "-o",
        type=Path,
        default=None,
        help="Write report here (default: stdout)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Also write profiling_summary.json next to --input",
    )
    args = parser.parse_args()

    inp = args.input.resolve()
    if not inp.exists():
        print(f"Error: input file not found: {inp}", file=sys.stderr)
        sys.exit(1)

    entries = []
    with open(inp, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    if not entries:
        report = "No valid NDJSON entries found in profiling log.\n"
        summary = {}
    else:
        summary = summarize(entries)
        report = format_report({k: dict(v) for k, v in summary.items()})  # copy so format_report can pop _count
        if args.json:
            json_path = inp.parent / "profiling_summary.json"
            with open(json_path, "w", encoding="utf-8") as jf:
                json.dump(summary, jf, indent=2)
            print(f"Wrote {json_path}", file=sys.stderr)

    if args.output:
        args.output = args.output.resolve()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        with open(args.output, "w", encoding="utf-8") as out:
            out.write(report)
        print(f"Wrote {args.output}", file=sys.stderr)
    else:
        print(report)


if __name__ == "__main__":
    main()
